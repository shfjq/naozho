# CPDAY10 P0-9.4

源提交 cd3021ec5c01ed0e527a402db734dd4b59a8a0dc。

模块与其全部共享源码分别在 kernelsu/naozho_power 和 platform/station。

分析见 [ANALYSIS.md](kernelsu/naozho_power/ANALYSIS.md)，构建与离线测试见 [TESTS.md](kernelsu/naozho_power/TESTS.md)，安装、验收及恢复见 [DSH.md](kernelsu/naozho_power/DSH.md)。
