package com.naozho.power;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Strict parsers for the limited owner-user experiment. Unrecognised evidence cannot authorize delivery. */
final class TrialChecks {
    static final String FREEME = "com.droiclaw.launcher3/com.freeme.launcher.FreemeLauncher";
    static final String CLOCK = "com.naozho.clock/.MainActivity";
    static final String RECEIVER = "com.naozho.clock/.mode.ConfirmedPowerReceiver";
    static final String ACTION = "com.naozho.clock.action.CONFIRMED_POWER_DOUBLE";
    private static final Pattern EVENT = Pattern.compile(
            "^\\[\\s*(\\d{1,10})\\.(\\d{6})\\]\\s+([0-9a-f]{4}) ([0-9a-f]{4}) ([0-9a-f]{8})$");
    private static final Pattern FIELD = Pattern.compile("^\\s*(Path|Enabled|KeyLayoutFile|KeyCharacterMapFile):\\s*(.*?)\\s*$");
    private static final Pattern DEVICE = Pattern.compile("^    -?\\d+: .*");

    static final class Refused extends Exception {
        Refused(String reason) { super(reason); }
        private static final long serialVersionUID = 1;
    }

    static String one(String text, String regex, String reason) throws Refused {
        Matcher m = Pattern.compile(regex, Pattern.MULTILINE).matcher(text);
        if (!m.find()) throw new Refused(reason);
        String value = m.group(1);
        if (m.find()) throw new Refused(reason);
        return value;
    }

    static boolean dedicatedKeys(String hex, String bus) {
        if (!bus.matches("001[89c]")) return false;
        // CPDAY10 arm64: sysfs prints unsigned-long words, most significant first.
        String[] words = hex.trim().split("\\s+");
        if (words.length == 0 || words.length > 12) return false;
        BigInteger keys = BigInteger.ZERO;
        for (String word : words) {
            if (!word.matches("[0-9a-fA-F]{1,16}")) return false;
            keys = keys.shiftLeft(64).or(new BigInteger(word, 16));
        }
        BigInteger allowed = BigInteger.ZERO.setBit(114).setBit(115).setBit(116);
        return keys.testBit(116) && keys.andNot(allowed).signum() == 0;
    }

    static final class Layout {
        String path, kl, kcm, enabled;
    }

    static Layout layout(String dump, String node) throws Refused {
        List<Layout> devices = new ArrayList<>();
        boolean hub = false;
        Layout current = null;
        for (String line : dump.split("\n")) {
            if (line.equals("Event Hub State:")) { hub = true; continue; }
            if (!hub) continue;
            if (!line.isEmpty() && !Character.isWhitespace(line.charAt(0))) break;
            if (DEVICE.matcher(line).matches()) { current = new Layout(); devices.add(current); continue; }
            Matcher field = FIELD.matcher(line);
            if (current == null || !field.matches()) continue;
            String v = field.group(2);
            switch (field.group(1)) {
                case "Path": current.path = v; break;
                case "KeyLayoutFile": current.kl = v; break;
                case "KeyCharacterMapFile": current.kcm = v; break;
                case "Enabled": current.enabled = v; break;
                default: break;
            }
        }
        Layout found = null;
        for (Layout d : devices) {
            if (!node.equals(d.path)) continue;
            if (found != null || !"true".equals(d.enabled) || d.kl == null || d.kcm == null)
                throw new Refused("eventhub_evidence_ambiguous");
            found = d;
        }
        if (found == null) throw new Refused("eventhub_node_missing");
        return found;
    }

    static boolean powerMapping(String kl, String kcm) {
        boolean found = false;
        for (String raw : kl.split("\n")) {
            String line = raw.split("#", -1)[0].trim();
            if (line.matches("key\\s+usage\\s+.*")) continue; // The trial rejects any live MSC_SCAN event.
            String[] parts = line.split("\\s+");
            if (parts.length < 3 || !parts[0].equals("key")) continue;
            try {
                if (Integer.decode(parts[1]) == 116) {
                    if (found || !parts[2].equals("POWER")) return false;
                    found = true;
                }
            } catch (NumberFormatException bad) { return false; }
        }
        // No HID usage/MSC_SCAN is admitted by the input reader.
        for (String raw : kcm.split("\n")) {
            String[] parts = raw.split("#", -1)[0].trim().split("\\s+");
            if (parts.length >= 3 && parts[0].equals("map") && parts[1].equals("key")) {
                try {
                    if (!parts[2].equals("usage") && Integer.decode(parts[2]) == 116) return false;
                } catch (NumberFormatException bad) { return false; }
            }
        }
        return found;
    }

    static void awakeSince(String dump, long firstUptime) throws Refused {
        if (!one(dump, "^ *displayGroupId=(\\d+) *$", "display_groups_unconfirmed").equals("0"))
            throw new Refused("unexpected_display_group");
        if (!one(dump, "^ *mWakefulness=(\\w+) *$", "wake_state_unknown").equals("Awake") ||
            !one(dump, "^ *mWakefulnessChanging=(\\w+) *$", "wake_transition_unknown").equals("false"))
            throw new Refused("display_not_stably_awake");
        for (String field : new String[]{"mLastWakeTime", "mLastSleepTime"}) {
            String stamp = one(dump, "^ *" + field + "=(\\d{1,15})(?: \\([^\\r\\n]*\\))? *$", "power_history_unknown");
            if (Long.parseLong(stamp) >= firstUptime) throw new Refused("sleep_or_wake_since_first_down");
        }
    }

    static String focus(String dump) throws Refused {
        return one(dump, "^ *mCurrentFocus=Window\\{[^\\s{}]+ u0 ([^\\s{}]+)\\} *$", "foreground_unknown");
    }

    static String[] broadcast(int boot, long first, long up) {
        return new String[]{"/system/bin/am", "broadcast", "--user", "0", "--receiver-foreground",
                "--exclude-stopped-packages", "-n", RECEIVER, "-a", ACTION, "--ei", "boot_count",
                Integer.toString(boot), "--el", "first_elapsed", Long.toString(first), "--el",
                "released_elapsed", Long.toString(up)};
    }

    static final class Edge {
        final long ms;
        final int type, code, value;
        Edge(long ms, int type, int code, int value) {
            this.ms = ms;
            this.type = type;
            this.code = code;
            this.value = value;
        }

        int powerValue(long now) throws Refused {
            if (type == 0 && code == 0) return -1; // SYN_REPORT
            if (type == 0 && code == 3) throw new Refused("input_sync_dropped");
            if (type == 1 && (code == 114 || code == 115)) throw new Refused("volume_or_chord_observed");
            if (type != 1 || code != 116) throw new Refused("unexpected_event_or_usage_mapping");
            if (value < 0 || value > 2) throw new Refused("unknown_key_transition");
            if (now < ms || now - ms > 100) throw new Refused("kernel_time_unusable_or_input_delayed");
            return value;
        }
    }

    static Edge parse(String line) throws Refused {
        if (line.startsWith("could not open /dev/input/")) throw new Refused("power_node_open_denied_or_gone");
        if (line.startsWith("Can't enable monotonic clock reporting:"))
            throw new Refused("kernel_monotonic_clock_unavailable");
        Matcher m = EVENT.matcher(line);
        if (!m.matches()) throw new Refused("getevent_format_or_clock_error");
        return new Edge(Long.parseLong(m.group(1))*1000 + Integer.parseInt(m.group(2))/1000,
                Integer.parseInt(m.group(3),16), Integer.parseInt(m.group(4),16),
                (int) Long.parseLong(m.group(5),16));
    }
}
