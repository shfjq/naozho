package com.naozho.power;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.view.KeyEvent;
import com.naozho.station.StationPowerShortcut;
import com.naozho.power.TrialChecks.Refused;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/** One explicitly initiated 60-second trial. No boot worker, hooks, input grabbing or injection. */
public final class PowerTrial implements TrialHandoff.Environment {
    private final TrialHandoff handoff = new TrialHandoff();
    private final boolean live;
    private final Path source;
    private final int boot;
    private final String focusSection;
    private final long deadline;
    private final AtomicLong observed = new AtomicLong();
    private final AtomicInteger queued = new AtomicInteger();
    private final AtomicReference<String> result = new AtomicReference<>();
    private final CountDownLatch done = new CountDownLatch(1);
    private long handled;
    private volatile boolean sending;
    private StationPowerShortcut shortcut;

    private PowerTrial(boolean live, Path source, int boot, String focusSection) {
        this.live = live;
        this.source = source;
        this.boot = boot;
        this.focusSection = focusSection;
        deadline = SystemClock.elapsedRealtime() + 60_000;
    }

    private boolean active() {
        return result.get() == null && Board.enabled() && SystemClock.elapsedRealtime() < deadline;
    }

    private void stop(String reason) {
        if (sending && !reason.startsWith("request_submitted")) reason = "dispatch_unconfirmed_" + reason;
        if (result.compareAndSet(null, reason)) done.countDown();
    }

    private boolean submit(long firstUpTime, long lastUpTime, long firstElapsed, long releasedElapsed) {
        try {
            stop(handoff.finish(live, boot, handled, firstUpTime, firstElapsed, releasedElapsed, this));
            return true;
        } catch (Exception e) { stop(reason(e)); return false; }
    }

    @Override public boolean unchanged(long serial) throws Exception {
        return active() && observed.get() == serial && Board.sameSource(source);
    }

    @Override public void proveForeground(long firstUptime) throws Exception {
        Board.ownerUser();
        Board.awake(firstUptime);
        Board.requireLauncher(Board.command(1100, 3*1024*1024, Board.DS, "window", focusSection));
    }

    @Override public long elapsed() { return SystemClock.elapsedRealtime(); }

    @Override public void send(int currentBoot, long first, long up) throws Exception {
        if (!active() || observed.get() != handled) throw new Refused("input_or_trial_changed");
        sending = true;
        Board.send(currentBoot, first, up);
    }

    private static String reason(Exception error) {
        // No shell output, full window dumps, unrelated inputs or call metadata in the report.
        return error instanceof Refused ? error.getMessage() : "unavailable_" + error.getClass().getSimpleName();
    }

    private void listen(Process input, Handler handler) {
        try (BufferedReader lines = new BufferedReader(new InputStreamReader(input.getInputStream(), StandardCharsets.US_ASCII))) {
            String line;
            while (active() && (line = lines.readLine()) != null) {
                TrialChecks.Edge e = TrialChecks.parse(line);
                int value = e.powerValue(SystemClock.uptimeMillis());
                if (value == -1) continue;
                long serial = observed.incrementAndGet();
                if (queued.incrementAndGet() > 16) throw new Refused("input_queue_overflow");
                handler.post(() -> {
                    queued.decrementAndGet();
                    if (!active()) { stop("trial_disabled_or_expired"); return; }
                    handled = serial;
                    int action = value == 0 ? KeyEvent.ACTION_UP : KeyEvent.ACTION_DOWN;
                    KeyEvent event = new KeyEvent(e.ms, e.ms, action, KeyEvent.KEYCODE_POWER, value == 2 ? 1 : 0);
                    // A recent wake or sleep invalidates this speculative sequence at commit.
                    shortcut.onPowerKey(event, true);
                });
            }
            stop("source_closed_or_disabled");
        } catch (Exception e) { stop(reason(e)); }
    }

    private void run(int multi, int longPress) throws Exception {
        Board.ownerUser();
        Board.awake(SystemClock.uptimeMillis());
        if (!Board.sameSource(source)) throw new Refused("source_changed");
        HandlerThread worker = new HandlerThread("naozho-power-trial");
        worker.start();
        Handler handler = new Handler(worker.getLooper());
        Process input = null;
        try {
            shortcut = new StationPowerShortcut(handler, () -> active() ? 1 : -1, multi, longPress, this::submit);
            input = new ProcessBuilder("/system/bin/timeout", "65", "/system/bin/getevent", "-t", Board.node(source)).redirectErrorStream(true).start();
            Process stream = input;
            Thread reader = new Thread(() -> listen(stream, handler), "power-only");
            reader.setDaemon(true);
            reader.start();
            System.out.println(live ? "ready=return_once" : "ready=observe_only");
            // Nothing runs persistently. Regular key checks and the final check also respect disable.
            while (!done.await(500, TimeUnit.MILLISECONDS)) {
                if (!active()) stop("trial_disabled_or_timed_out");
            }
        } finally {
            if (input != null) input.destroyForcibly();
            worker.quitSafely();
            worker.join(3000);
        }
        String outcome = result.get();
        if (!"observed_qualified_double_no_request".equals(outcome) &&
                !"request_submitted_verify_app_focus_and_lock".equals(outcome)) throw new Refused(outcome);
        System.out.println("result=" + outcome);
    }

    public static void main(String[] args) {
        try {
            if (args.length != 1 || !(args[0].equals("inventory") || args[0].equals("observe") || args[0].equals("return")))
                throw new Refused("unknown_mode");
            Board.environment();
            try (FileChannel lock = FileChannel.open(Board.MODULE.resolve("trial.lock"), StandardOpenOption.CREATE,
                    StandardOpenOption.WRITE); FileLock claim = lock.tryLock()) {
                if (claim == null) throw new Refused("another_trial_active");
                Path source = Board.discover();
                System.out.println("candidate=" + Board.node(source));
                Board.verifyLayout(source);
                System.out.println("source=" + source.getFileName() + " scan=116 mapping=POWER");
                if (args[0].equals("inventory")) { System.out.println("result=inventory_only"); return; }
                int multi = Board.number(Board.command(1500,128,"/system/bin/settings","--user","0","get","secure","multi_press_timeout"),
                        100, 500, "unknown_multi_press_window");
                String setting = Board.command(1500,128,"/system/bin/settings","--user","0","get","secure","long_press_timeout");
                int limit = setting.equals("null") ? 250 : Math.min(250, Board.number(setting, 100, 5000, "unknown_hold_window"));
                boolean live = args[0].equals("return");
                if (live) {
                    Board.verifyFramework();
                    String pkg = Board.command(1800, 1024*1024, Board.DS, "package", "com.naozho.clock");
                    if (!TrialChecks.one(pkg, "^ *versionName=(\\S+) *$", "app_version_unknown").equals("0.6.13-dev") ||
                        !TrialChecks.one(pkg, "^ *versionCode=(\\d+)\\b.*$", "app_version_unknown").equals("28"))
                        throw new Refused("expected_clock_0_6_13_dev_28");
                    String owners = Board.command(1800,4096,"/system/bin/dpm","list-owners");
                    if (!owners.matches("(?s).*User\\s+0:\\s+admin=com\\.naozho\\.clock/\\.display\\.ClockDeviceAdmin,DeviceOwner(?:,|\\s|$).*"))
                        throw new Refused("owner_not_confirmed");
                }
                new PowerTrial(live, source, Board.boot(), Board.launcherSection()).run(multi, limit);
            }
        } catch (Exception e) {
            System.out.println("result=" + reason(e));
            System.exit(1);
        }
    }
}
