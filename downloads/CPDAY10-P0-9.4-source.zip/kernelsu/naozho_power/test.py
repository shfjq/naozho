#!/usr/bin/env python3
"""Rebuild twice, validate module contents and run both JVM suites without any Android device."""
import argparse
import hashlib
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--android-jar", type=Path, required=True)
    cli.add_argument("--d8", type=Path, required=True)
    cli.add_argument("--out", type=Path, required=True)
    args = cli.parse_args()
    base = Path(__file__).resolve().parent
    station = base.parents[1] / "platform/station"
    jdk = Path(os.environ["JAVA_HOME"]) / "bin"
    build = [sys.executable, base / "build.py", "--android-jar", args.android_jar, "--d8", args.d8]
    with tempfile.TemporaryDirectory() as folder:
        tmp = Path(folder)
        second = tmp / "second.zip"
        subprocess.run([*build, "--out", args.out], check=True)
        subprocess.run([*build, "--out", second], check=True)
        if args.out.read_bytes() != second.read_bytes():
            raise RuntimeError("Non-reproducible module")
        with ZipFile(args.out) as archive:
            expected = {"action.sh", "customize.sh", "module.prop", "power-trial.jar", "skip_mount", "trial.sh"}
            if set(archive.namelist()) != expected or len(archive.namelist()) != len(expected) or archive.testzip():
                raise RuntimeError("Unexpected module structure or CRC")
            with ZipFile(io.BytesIO(archive.read("power-trial.jar"))) as jar:
                if jar.namelist() != ["classes.dex"] or jar.testzip() or not jar.read("classes.dex").startswith(b"dex\n"):
                    raise RuntimeError("Invalid DEX jar")
            for name in sorted(expected):
                if name.endswith(".sh"):
                    if (archive.getinfo(name).external_attr >> 16) & 0o777 != 0o755:
                        raise RuntimeError("Bad script permissions")
                    subprocess.run(["sh", "-n", base / "module" / name], check=True)
        classes = tmp / "classes"
        classes.mkdir()
        power = base / "src/com/naozho/power"
        sources = [power / "TrialChecks.java", power / "TrialHandoff.java",
                   *sorted((base / "tests").rglob("*.java")), *sorted((station / "src").rglob("*.java")),
                   *sorted((station / "tests").rglob("*.java"))]
        subprocess.run([jdk / "javac", "--release", "11", "-Xlint:all", "-Werror", "-d", classes, *sources], check=True)
        for name in ["com.naozho.power.PowerTrialTest", "com.naozho.station.StationPowerArbiterTest"]:
            result = subprocess.run([jdk / "java", "-cp", classes, name], check=True, capture_output=True, text=True)
            print(result.stdout, end="")
            print(name, "PASS count", sum(line.startswith("PASS ") for line in result.stdout.splitlines()))
        print("package reproducible; ZIP/DEX entries, CRCs, scripts and modes OK")
        print("sha256", hashlib.sha256(args.out.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
