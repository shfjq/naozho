项目源码提交 0fb030a7d8988fc35d613fe7079e53ef460fefc2。日常模块构建、离线测试及权限范围见 tools/p097/P0973-report.md；部署、停用及验收见 tools/p097/P0973-DSH.md。本次仅构建 KernelSU 模块，保留既有 0.6.13-dev / 28 APK。
