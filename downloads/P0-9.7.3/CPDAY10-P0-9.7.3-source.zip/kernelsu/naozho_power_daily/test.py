"""Offline regression of the shipped native loop, daily decision code, protected receipts and DSH tooling."""
from pathlib import Path
import subprocess
import os
import sys
import tempfile
root=Path(__file__).resolve().parent; repo=root.parents[1]
jdk=Path(os.environ['JAVA_HOME']); java=jdk/'bin/java'
shared=root.parent/'naozho_power'
with tempfile.TemporaryDirectory() as t:
    temp=Path(t)
    def run(*cmd,**kwargs):subprocess.run(cmd,check=True,**kwargs)
    run('gcc','-std=c17','-Wall','-Wextra','-Werror','-pthread','-I'+str(jdk/'include'),'-I'+str(jdk/'include/linux'),
        root/'tests/native_test.c','-Wl,--wrap=fstat,--wrap=ioctl','-o',temp/'native')
    run(temp/'native')
    station=repo/'platform/station'
    src=[*(shared/'src/com/naozho/power'/n for n in ('TrialChecks.java','TrialHandoff.java','DeliveryProof.java')),
         *(root/'src/com/naozho/power'/n for n in ('DailyReturn.java','Foreground.java','VisibleWindowDump.java','WindowGeometry.java','WindowAttributes.java','DailyLog.java','SessionLease.java','TimingLease.java','TimingSample.java','PolicyReceipt.java')),
         *station.glob('src/**/*.java'),*station.glob('tests/**/*.java'),*shared.glob('tests/**/*.java'),*root.glob('tests/*.java')]
    run(jdk/'bin/javac','--release','11','-Xlint:all','-Werror','-d',temp,*src)
    for cls in ('com.naozho.power.DailyTest','com.naozho.power.DeliveryProofTest','com.naozho.station.StationPowerArbiterTest'):
        run(java,'-cp',temp,cls)
    run(java,'-cp',temp,'com.naozho.power.FreemeWindowsTest',root/'tests/fixtures/freeme-0971-evidence.json')
    run(java,'-cp',temp,'com.naozho.power.LayoutFieldsTest',root/'tests/fixtures/freeme-102-attrs.txt')
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join(str(repo/'tools'/f) for f in ('p095','p097')))
    run(sys.executable,'-m','unittest','discover','-s',repo/'tools/p097',env=env)
    for script in (root/'module').glob('*.sh'):run('sh','-n',script)
