package com.naozho.power;

import java.nio.file.*;
import java.util.*;
import static com.naozho.power.DailyTest.ok;

/** P0-9.7.2 supplied excerpts. The raw fixture never acquires flags not present in the report. */
public final class LayoutFieldsTest {
    private static final String[] NAMES={"ScreenDecorOverlayBottom","ScreenDecorOverlay","NavigationBar0",
            "StatusBar",TrialChecks.FREEME,"ImageWallpaper"};
    private static final String[] FRAMES={"[0,682][720,720]","[0,0][720,38]","[0,698][720,720]",
            "[0,0][720,44]","[0,0][720,720]","[0,0][720,720]"};
    private static String[] windows(Path fixture, boolean synthetic) throws Exception {
        String[] excerpts=Files.readString(fixture).trim().split("(?m)(?=^Window #)");
        if (excerpts.length!=6) throw new AssertionError("six excerpts required");
        String[] rows=new String[6];
        for(int i=0;i<rows.length;i++) {
            String section=excerpts[i].substring(excerpts[i].indexOf('\n')+1).trim();
            // The excerpt omits the closing LayoutParams brace. Add only the WMS envelope
            // (including geometry and window tokens) as test scaffolding.
            String attrs=section.replace("\n","\n      ");
            if (synthetic && (i==0 || i==1 || i==5))
                attrs+="\n      fl="+(i==5?"NOT_FOCUSABLE":"NOT_FOCUSABLE NOT_TOUCHABLE");
            String row=DailyTest.window(i,Integer.toHexString(i+1),NAMES[i],
                    i==4?"com.droiclaw.launcher3":FreemeWindowsTest.SYS, "PLACEHOLDER","PLACEHOLDER");
            int start=row.indexOf("mAttrs="),end=row.indexOf("\n    isOnScreen=",start);
            rows[i]=(row.substring(0,start)+attrs+"}"+row.substring(end)).replace("[0,0][720,35]",FRAMES[i]);
        }
        return rows;
    }

    private static Foreground.Windows check(String[] rows) throws Exception {
        return Foreground.inspectSnapshot(VisibleWindowDump.project(FreemeWindowsTest.scene(rows)),"5");
    }
    private static WindowAttributes attrs(String text) { return WindowAttributes.parse("    mAttrs="+text); }

    public static void main(String[] args) throws Exception {
        Path evidence=Path.of(args[0]);
        boolean synthetic=args.length>1 && args[1].equals("emit-completed");
        String[] partial=windows(evidence,false), full=windows(evidence,true);
        if (args.length>1) { System.out.print(FreemeWindowsTest.scene(synthetic?full:partial)); return; }
        Foreground.Windows excerpt=check(partial);
        ok("excerpt only: three supplied flags recovered, three unavailable",excerpt.rows.size()==6 &&
                excerpt.blockingCount==3 && excerpt.unknownCount==3 && excerpt.decorCount==2 && excerpt.focused.equals(TrialChecks.FREEME));
        for(int i=0;i<6;i++) {
            boolean supplied=(i>=2 && i<=4);
            String row=excerpt.rows.get(i);
            ok("per-window extraction diagnostics "+i,row.contains("window_block_index="+i+" flags_line_found="+supplied) &&
                    row.contains("flags_parse_status="+(supplied?"parsed":"missing_flags")));
        }
        ok("two exact host flag lists match the shared collector",excerpt.bars.size()==2 &&
                excerpt.bars.get(0).contains("flags=NOT_FOCUSABLE,NOT_TOUCH_MODAL,WATCH_OUTSIDE_TOUCH ") &&
                excerpt.bars.get(1).contains("flags=NOT_FOCUSABLE,HARDWARE_ACCELERATED,DRAWS_SYSTEM_BAR_BACKGROUNDS "));
        ok("observed Freeme public flags",excerpt.rows.get(4).contains("flags_value_count=6"));
        Foreground.Windows complete=check(full);
        Foreground.verify(complete,TrialChecks.FREEME);
        ok("separate completed-format case: 6/4/1/0/0",complete.visibleCount==6 && complete.decorCount==4 &&
                complete.interactiveCount==1 && complete.blockingCount==0 && complete.unknownCount==0);
        ok("decor roles counted individually",complete.rows.get(0).contains("verified_passive_decor") &&
                complete.rows.get(1).contains("verified_passive_decor") && complete.rows.get(5).contains("class=wallpaper"));
        for(String key:List.of("fl=", "fl =", "flags=", "flags =")) {
            for(String before:List.of(" ", "\n", "\n  ", "\n    ", "\n\t", "\r\n           ")) {
                String[] rows=full.clone();
                rows[2]=rows[2].replace("\n      fl=",before+key);
                Foreground.verify(check(rows),TrialChecks.FREEME); ok("inline or continuation: "+key+" separator length "+before.length(),true);
            }
        }
        WindowAttributes deep=attrs("{sim={adjust={mode=pan fl=SECURE}}\n ty=STATUS_BAR pfl=SECURE\n  flags = FLAG_NOT_FOCUSABLE\n HARDWARE_ACCELERATED sysui=SECURE vsysui=SECURE}");
        ok("nested and sibling namespaces isolated; type/value on later lines",
                deep.known() && !deep.secure() && deep.focusable().equals("false") && deep.valueCount==2 && deep.type.equals("STATUS_BAR"));
        ok("nested public-looking field alone insufficient",attrs("{sim={fl=NOT_TOUCHABLE} ty=STATUS_BAR pfl=NOT_TOUCHABLE}").status.equals("missing_flags"));
        ok("nonpublic fields optional",attrs("{ty=BASE_APPLICATION fl=HARDWARE_ACCELERATED}").known());
        ok("unsupported public format has distinct reason",attrs("{ty=STATUS_BAR flags=VENDOR_UNKNOWN}").status.equals("unknown_token"));
        ok("missing outer boundary identified separately",attrs("{ty=STATUS_BAR sim={adjust=pan}\n  fl=NOT_FOCUSABLE").status.equals("attrs_unclosed"));
        ok("duplicate nonadjacent public values cannot be merged",attrs("{fl=NOT_FOCUSABLE sim={adjust=pan} flags=SECURE}").status.equals("duplicate_flags"));
        String[] moved=full.clone();
        moved[0]=full[3].replace("Window #3","Window #0"); moved[3]=full[0].replace("Window #0","Window #3");
        Foreground.verify(check(moved),TrialChecks.FREEME); ok("reordered windows retain their own flags",true);
        String[] bad=full.clone();
        bad[4]=bad[4].replace("fl=LAYOUT_IN_SCREEN","pfl=LAYOUT_IN_SCREEN");
        Foreground.Windows identity=check(bad);
        ok("focused Freeme identifiable, missing security flags still veto",
                identity.rows.get(4).contains("class=app") && identity.veto!=null && identity.blockingCount==1);
        bad=full.clone(); bad[1]=bad[1].replace("fl=NOT_FOCUSABLE NOT_TOUCHABLE","pfl=NOT_FOCUSABLE NOT_TOUCHABLE");
        Foreground.Windows isolated=check(bad);
        ok("neither neighbor supplies missing flags",isolated.rows.get(1).contains("flags_line_found=false") && isolated.blockingCount==1);
        bad=full.clone(); bad[0]=bad[0].replace("fl=NOT_FOCUSABLE NOT_TOUCHABLE}","}\n      fl=NOT_FOCUSABLE NOT_TOUCHABLE");
        ok("orphan flags rejected",check(bad).rows.get(0).contains("parser_error=flags_outside_attrs"));
        String raw=FreemeWindowsTest.scene(full);
        String historical=raw.replace("  mBlurEnabled", "  Windows waiting to resize:\n    mAttrs={ty=STATUS_BAR fl=SECURE}\n  mBlurEnabled");
        Foreground.verify(Foreground.inspectSnapshot(VisibleWindowDump.project(historical),"5"),TrialChecks.FREEME);
        ok("summary copies never included in current list",true);
        DailyTest.reject("missing collector completion",()->VisibleWindowDump.project(raw.replace("  mBlurEnabled=true","")));
        DailyTest.reject("foreign list header refused",()->VisibleWindowDump.project(raw.replace("WINDOW MANAGER WINDOWS","WINDOW MANAGER HISTORY")));
        System.out.println("Layout field JVM cases "+DailyTest.count);
    }
}
