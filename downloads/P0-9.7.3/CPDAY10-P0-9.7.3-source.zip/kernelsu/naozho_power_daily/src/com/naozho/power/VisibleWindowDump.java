package com.naozho.power;

import java.util.regex.Pattern;
import com.naozho.power.TrialChecks.Refused;

/** Project the live window list once, before looking up any field. Keep unabridged LayoutParams
 * only in memory. An indented field or an inner brace cannot terminate a window record. */
final class VisibleWindowDump {
    private static final String HEADER="WINDOW MANAGER WINDOWS (dumpsys window windows)";
    private static final Pattern FOOTER=Pattern.compile("^  mBlurEnabled=(?:true|false)[ \\t]*$");
    private static final Pattern STATE=Pattern.compile("^(?:mOwnerUid|mDisplayId|isOnScreen|isVisible|mHasSurface|mViewVisibility|mTouchableInsets|touchable region|Frames: parent)=");
    private static final Pattern ATTR=Pattern.compile("^mAttrs[ \\t]*=[ \\t]*\\{");
    private static final Pattern SECTION=Pattern.compile("^  (?:[A-Z][^=]*:|m[A-Za-z0-9]+=[^ ].*)$");
    private static final Pattern FLAGS=Pattern.compile("^(?:fl|flags)[ \\t]*=");
    static String project(String raw) throws Refused {
        String[] lines=raw.split("\\r?\\n",-1);
        if (lines.length==0 || !HEADER.equals(lines[0].trim())) throw new Refused("window_snapshot_header");
        boolean ended=false, inWindow=false, summaries=false;
        int depth=0;
        StringBuilder out=new StringBuilder(HEADER).append('\n');
        for (int i=1;i<lines.length;i++) {
            String line=lines[i], trim=line.trim();
            if (FOOTER.matcher(line).matches()) {
                if (depth>0) out.append("    attrs_incomplete=true\n");
                ended=true; break;
            }
            if (trim.startsWith("Window #")) {
                if (!line.startsWith("  Window #") || summaries) throw new Refused("window_block_boundary");
                if (depth>0) out.append("    attrs_incomplete=true\n");
                out.append(line).append('\n'); inWindow=true; depth=0; continue;
            }
            if (line.startsWith("  Hiding System Alert Windows:") || line.startsWith("  Windows force removing:"))
                throw new Refused("windows_unconfirmed");
            if (!inWindow) continue;
            if (STATE.matcher(trim).find()) {
                if (depth>0) out.append("    attrs_incomplete=true\n");
                depth=0; out.append("    ").append(trim).append('\n'); continue;
            }
            if (ATTR.matcher(trim).find()) {
                // Keep distinct occurrences, including duplicates, so the field decoder can veto.
                depth=0;
                out.append("    ").append(trim).append('\n');
            } else if (depth>0 && !SECTION.matcher(line).matches()) {
                out.append(line).append('\n');
            } else if (FLAGS.matcher(trim).find()) {
                // A public-looking line outside LayoutParams is diagnosable but never trusted.
                out.append("    orphan_public_flags=true\n"); continue;
            } else if (SECTION.matcher(line).matches()) {
                summaries=true; inWindow=false; continue;
            } else continue;
            for (int c=0;c<line.length();c++) {
                char ch=line.charAt(c);
                if (ch=='{') depth++;
                if (ch=='}') depth--;
            }
            if (depth<0) throw new Refused("attrs_brace_mismatch");
        }
        if (!ended) throw new Refused("window_snapshot_incomplete");
        return out.append("WMS_WINDOWS_END").toString();
    }
    private VisibleWindowDump() {}
}
