package com.naozho.power;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Read only public LayoutParams flags. Private flags and input regions use different namespaces. */
final class WindowAttributes {
    private static final int FOCUS=0x8, TOUCH=0x10, SECURE=0x2000, RELEVANT=FOCUS|TOUCH|SECURE;
    private static final Pattern ATTR=Pattern.compile("(?m)^[ \\t]*mAttrs[ \\t]*=[ \\t]*\\{");
    private static final Pattern KEY=Pattern.compile("(?<![^\\s])([A-Za-z_][A-Za-z0-9_.]*)[ \\t]*=[ \\t]*");
    // ExportedProperty flagMapping of WindowManager.LayoutParams.flags on Android 16.
    private static final String OTHER=" ALLOW_LOCK_WHILE_SCREEN_ON DIM_BEHIND BLUR_BEHIND NOT_TOUCH_MODAL TOUCHABLE_WHEN_WAKING KEEP_SCREEN_ON LAYOUT_IN_SCREEN LAYOUT_NO_LIMITS FULLSCREEN FORCE_NOT_FULLSCREEN DITHER SCALED IGNORE_CHEEK_PRESSES LAYOUT_INSET_DECOR ALT_FOCUSABLE_IM WATCH_OUTSIDE_TOUCH SHOW_WHEN_LOCKED SHOW_WALLPAPER TURN_SCREEN_ON DISMISS_KEYGUARD SPLIT_TOUCH HARDWARE_ACCELERATED LOCAL_FOCUS_MODE LAYOUT_IN_OVERSCAN TRANSLUCENT_STATUS TRANSLUCENT_NAVIGATION SLIPPERY LAYOUT_ATTACHED_IN_DECOR DRAWS_SYSTEM_BAR_BACKGROUNDS ";
    final String source, status;
    String type="unknown";
    final int bits;
    final int valueCount;
    final String publicValue;
    final boolean found;
    private WindowAttributes(String source,String status,int bits,boolean found,int count,String value) {
        publicValue=value; this.source=source; this.status=status; this.bits=bits; this.found=found; valueCount=count;
    }
    private static WindowAttributes error(String source,String status,boolean found,int count) {
        return new WindowAttributes(source,status,0,found,count,"unavailable");
    }
    boolean known() { return status.equals("parsed"); }
    boolean secure() { return (bits&SECURE)!=0; }
    String focusable() { return known()?Boolean.toString((bits&FOCUS)==0):"unknown"; }
    String touchable() { return known()?Boolean.toString((bits&TOUCH)==0):"unknown"; }

    static WindowAttributes parse(String body) {
        Matcher attrs=ATTR.matcher(body);
        if (!attrs.find()) {
            boolean orphan=body.contains("\n    orphan_public_flags=true");
            return error(orphan?"outside_attrs":"none","missing_attrs",orphan,0);
        }
        int start=attrs.end();
        if (attrs.find()) return error("multiple","duplicate_attrs",false,0);
        // Mask nested values while preserving newlines. Only the matching outer brace closes
        // LayoutParams. In particular, sim={adjust=pan} is a value, not the end of mAttrs.
        StringBuilder top=new StringBuilder();
        int depth=1, end=start;
        for (;end<body.length();end++) {
            char c=body.charAt(end);
            if (c=='{') depth++;
            else if (c=='}') {
                depth--;
                if (depth==0) break;
            }
            top.append(depth==1 && c!='}'?c:c=='\n'?'\n':' ');
        }
        boolean closed=depth==0 && !body.contains("\n    attrs_incomplete=true");
        WindowAttributes result=decode(top,closed,body.contains("\n    orphan_public_flags=true"));
        Matcher type=Pattern.compile("(?:^|\\s)ty[ \\t]*=[ \\t]*([A-Z_]{1,48})(?=\\s|$)").matcher(top);
        if (type.find()) {
            String name=type.group(1);
            if (!type.find()) result.type=name;
        }
        return result;
    }

    private static WindowAttributes decode(StringBuilder top,boolean closed,boolean orphan) {
        Matcher key=KEY.matcher(top);
        int valueStart=-1,valueEnd=-1,fields=0;
        String origin="none";
        while (key.find()) {
            if (valueStart>=0 && valueEnd<0) valueEnd=key.start();
            if (!(key.group(1).equals("fl") || key.group(1).equals("flags"))) continue;
            fields++;
            origin=top.lastIndexOf("\n",key.start())<0?"attrs_inline":"flags_line";
            valueStart=key.end(); valueEnd=-1;
        }
        if (!closed) return error(origin,"attrs_unclosed",fields>0,0);
        if (orphan) return error("outside_attrs","flags_outside_attrs",true,0);
        if (fields==0) return error("none","missing_flags",false,0);
        if (fields!=1) return error("multiple","duplicate_flags",true,0);
        String raw=top.substring(valueStart,valueEnd<0?top.length():valueEnd).trim();
        if (raw.isEmpty()) return error(origin,"empty_flags",true,0);
        String[] tokens=raw.split("(?:[\\s|,]+)");
        int count=tokens.length;
        int bits=0;
        boolean named=false,numeric=false;
        for (String token:tokens) {
            if (token.startsWith("FLAG_")) token=token.substring(5);
            if (token.equals("NOT_FOCUSABLE")) { bits|=FOCUS; named=true; }
            else if (token.equals("NOT_TOUCHABLE")) { bits|=TOUCH; named=true; }
            else if (token.equals("SECURE")) { bits|=SECURE; named=true; }
            else if (token.matches("[A-Z_]+") && OTHER.contains(" "+token+" ")) named=true;
            else if (token.matches("0[xX][0-9a-fA-F]{1,8}")) {
                bits|=(int)Long.parseLong(token.substring(2),16); numeric=true;
            } else if (token.matches("(?=.*[0-9])(?=.*[A-Fa-f])[A-Fa-f0-9]{1,8}")) {
                bits|=(int)Long.parseLong(token,16); numeric=true;
            } else if (token.matches("-?[0-9]{1,10}")) {
                long decimal=Long.parseLong(token);
                if (decimal<Integer.MIN_VALUE || decimal>0xffffffffL) return error(origin,"invalid_mask",true,count);
                // Some formatters emit a bare hex mask, others decimal. Accept only if the
                // interpretation of all three security-relevant bits is unambiguous.
                if (token.charAt(0)!='-' && token.length()<=8 && ((Long.parseLong(token,16)^decimal)&RELEVANT)!=0)
                    return error(origin,"ambiguous_radix",true,count);
                bits|=(int)decimal; numeric=true;
            } else return error(origin,"unknown_token",true,count);
        }
        if (!named && !numeric || raw.endsWith("|") || raw.endsWith(",")) return error(origin,"invalid_mask",true,count);
        return new WindowAttributes(origin+"_"+(named?(numeric?"mixed":"names"):"mask"),"parsed",bits,true,count,String.join(",",tokens));
    }
}
