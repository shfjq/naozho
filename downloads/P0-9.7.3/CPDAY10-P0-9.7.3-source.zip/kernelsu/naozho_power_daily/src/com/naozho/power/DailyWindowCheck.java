package com.naozho.power;

import android.os.Build;

/** Read-only Freeme diagnostic. Independent of arming and timing, with no broadcast sender. */
public final class DailyWindowCheck {
    public static void main(String[] args) {
        try {
            boolean bars=args.length==1 && args[0].equals("--bar-fields");
            if ((args.length!=0 && !bars) || Build.VERSION.SDK_INT!=36 ||
                !"CPDAY10".equals(DailyBoard.cmd("/system/bin/getprop","ro.product.device"))) throw new TrialChecks.Refused("unsupported_device");
            Board.ownerUser();
            Foreground.Windows windows=new Foreground.Windows();
            try {
                String before=DailyBoard.displayFocus(), id=Foreground.rawFocusId(before);
                windows=Foreground.inspectSnapshot(DailyBoard.visibleWindows(),id);
                String page=Foreground.focus(before);
                if (!page.equals(TrialChecks.FREEME)) throw new TrialChecks.Refused("not_freeme");
                Foreground.verify(windows,page);
                Foreground.confirmFocus(page,id,DailyBoard.displayFocus());
            } catch (TrialChecks.Refused stop) { windows.reject(stop.getMessage()); }
            if (bars) {
                if (windows.veto!=null && windows.bars.isEmpty()) System.out.println("error="+windows.veto);
                for (String row:windows.bars) System.out.println(row);
                return;
            }
            System.out.println("decision="+(windows.veto==null?"ordinary_freeme":windows.veto)+windows.totals());
            for (String row:windows.rows) System.out.println(row);
        } catch (Exception error) {
            System.err.println("STOP "+DailyPower.reason(error)); System.exit(1);
        }
    }
    private DailyWindowCheck() {}
}
