package com.naozho.power;

import static com.naozho.power.TrialChecks.Refused;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

final class WakeApkIdentity {
    private static final String CLOCK = WakeBoard.PKG;
    private static final String DIGEST = "[0-9a-f]{64}";
    private static final Set<String> REQUIRED = Set.of("35/0.6.20-dev", "36/0.6.21-dev", "37/0.6.22-dev", "38/0.6.23-dev", "39/0.6.24-dev", "40/0.6.25-dev");
    private final String signer;
    private final Map<String, String> approved;
    // Package replacements have fresh code paths. Reuse a digest on the same path only
    // when dev/inode/ctime/mtime/size prove this is the same file. Otherwise hash again.
    private Path hashedPath;
    private Map<String, Object> hashedStat;
    private String hashedDigest;

    WakeApkIdentity(String text) throws Refused {
        String[] rows = text.trim().split("\n", -1);
        if (rows.length != REQUIRED.size() + 1 || !rows[0].matches("signer\t" + DIGEST))
            throw new Refused("apk_allowlist_invalid");
        signer = rows[0].substring("signer\t".length());
        approved = new HashMap<>();
        for (int i = 1; i < rows.length; i++) {
            String[] row = rows[i].split("\t", -1);
            if (row.length != 4 || !CLOCK.equals(row[0]) || !row[1].matches("[1-9][0-9]*") ||
                    !row[2].matches("[0-9.]+-dev") || !row[3].matches(DIGEST) ||
                    approved.put(row[1] + "/" + row[2], row[3]) != null)
                throw new Refused("apk_allowlist_invalid");
        }
        if (!REQUIRED.equals(approved.keySet()) || approved.values().stream().distinct().count() != approved.size())
            throw new Refused("apk_allowlist_invalid");
    }

    static final class Installed {
        final String packageName, versionName, source, signer;
        final long versionCode;
        final int uid;
        Installed(String packageName, long versionCode, String versionName, String source, String signer, int uid) {
            this.packageName = packageName;
            this.versionCode = versionCode;
            this.versionName = versionName;
            this.source = source;
            this.signer = signer;
            this.uid = uid;
        }
        void requireSame(Installed next) throws Refused {
            if (uid != next.uid) throw new Refused("apk_uid_mismatch");
            if (versionCode != next.versionCode || !Objects.equals(versionName, next.versionName) ||
                    !Objects.equals(source, next.source) || !Objects.equals(signer, next.signer) ||
                    !Objects.equals(packageName, next.packageName))
                throw new Refused("apk_replaced_during_request");
        }
    }

    static void checkUid(int uid, int installedUid) throws Refused {
        if (uid < 10000 || uid >= 100000 || uid != installedUid) throw new Refused("apk_uid_mismatch");
    }

    synchronized void verify(Installed apk) throws Exception {
        if (!CLOCK.equals(apk.packageName) || apk.source == null ||
                !apk.source.matches("/[^\\s]+/base\\.apk")) throw new Refused("apk_unconfirmed");
        if (!signer.equals(apk.signer)) throw new Refused("apk_signer_mismatch");
        checkUid(apk.uid, apk.uid);
        String expected = approved.get(apk.versionCode + "/" + apk.versionName);
        if (expected == null) throw new Refused("apk_version_unapproved");
        Path path = Paths.get(apk.source);
        try {
            Map<String, Object> before = stat(path);
            if (before != null && path.equals(hashedPath) && before.equals(hashedStat)) {
                if (!expected.equals(hashedDigest)) throw new Refused("apk_changed");
                return;
            }
            String actual = DailyBoard.sha(path);
            if (!expected.equals(actual) || !Objects.equals(before, stat(path)))
                throw new Refused("apk_changed");
            if (before != null) {
                hashedPath = path;
                hashedStat = before;
                hashedDigest = actual;
            }
        } catch (IOException unreadable) {
            throw new Refused("apk_file_unavailable");
        }
    }

    private static Map<String, Object> stat(Path path) throws IOException, Refused {
        if (!Files.readAttributes(path, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS).isRegularFile())
            throw new Refused("apk_unconfirmed");
        try {
            return Files.readAttributes(path, "unix:dev,ino,ctime,lastModifiedTime,size", LinkOption.NOFOLLOW_LINKS);
        } catch (UnsupportedOperationException | IllegalArgumentException unavailable) {
            return null;
        }
    }
}
