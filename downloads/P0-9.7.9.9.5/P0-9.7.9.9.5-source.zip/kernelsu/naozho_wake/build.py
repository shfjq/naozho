#!/usr/bin/env python3
"""Build only the reachable wake observer code using the Android SDK R8. No NDK or Root needed."""
import argparse
import hashlib
import os
from pathlib import Path
import re
import subprocess
import tempfile
from zipfile import ZipFile
from importlib.util import spec_from_file_location, module_from_spec

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CLOCK = "com.naozho.clock"
APPROVED_VERSIONS = {(CLOCK, "35", "0.6.20-dev"), (CLOCK, "36", "0.6.21-dev"), (CLOCK, "37", "0.6.22-dev"),
                     (CLOCK, "38", "0.6.23-dev"), (CLOCK, "39", "0.6.24-dev"), (CLOCK, "40", "0.6.25-dev")}
spec = spec_from_file_location("daily_archive", HERE.parent / "naozho_power_daily/build.py")
helper = module_from_spec(spec)
spec.loader.exec_module(helper)

def sources():
    probe = ROOT / "probes/wake-observer/src/com/naozho/wakeprobe"
    shared = HERE.parent / "naozho_power/src/com/naozho/power"
    return [*HERE.joinpath("protocol").rglob("*.java"), *HERE.joinpath("src").rglob("*.java"), probe/"WakeCycle.java", probe/"PowerEvidence.java", probe/"PowerRead.java",
            *(shared/name for name in ("Board.java", "DeliveryProof.java", "TrialChecks.java")),
            *HERE.parent.joinpath("naozho_power_daily/src").rglob("*.java"),
            *ROOT.joinpath("platform/station/src").rglob("*.java"),
            *ROOT.joinpath("platform/station/android").rglob("*.java")]

def verify_apks(apks, apksigner, aapt2, identities):
    header, *rows = identities.decode("ascii").splitlines()
    kind, cert = header.split("\t")
    if kind != "signer" or not re.fullmatch(r"[0-9a-f]{64}", cert):
        raise ValueError("invalid signer binding")
    approved = {tuple(row.split("\t")) for row in rows}
    required = len(APPROVED_VERSIONS)
    if len(rows) != required or {row[:3] for row in approved} != APPROVED_VERSIONS or any(
            len(row) != 4 or not re.fullmatch(r"[0-9a-f]{64}", row[3]) for row in approved):
        raise ValueError("identity table must pin versions 35, 36, 37, 38, 39 and 40")
    if len({row[3] for row in approved}) != required or len(apks) != required:
        raise ValueError("supply all six distinct original APKs")
    verified = set()
    for apk in apks:
        digest = hashlib.sha256(apk.read_bytes()).hexdigest()
        badging = subprocess.check_output([aapt2, "dump", "badging", apk], text=True)
        info = re.search(r"^package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'", badging, re.M)
        identity = (*info.groups(), digest) if info else ()
        if identity not in approved or identity in verified:
            raise ValueError("APK does not match a distinct approved version: " + apk.name)
        result = subprocess.check_output([apksigner, "verify", "--verbose", "--print-certs", apk], text=True)
        signers = re.findall(r"^Signer #\d+ certificate SHA-256 digest: ([0-9a-f]{64})$", result, re.M)
        if signers != [cert] or "Verified using v2 scheme (APK Signature Scheme v2): true" not in result:
            raise ValueError("APK v2 signer mismatch: " + apk.name)
        verified.add(identity)
        print(f"Approved {identity[1]} {identity[2]} {identity[3]} signer={cert}")


def build(args):
    identities = (HERE / "module/clock-identities.tsv").read_bytes()
    verify_apks(args.apk, args.apksigner, args.aapt2, identities)
    java = Path(os.environ["JAVA_HOME"])/"bin"
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        classes = work/"classes"
        classes.mkdir()
        subprocess.run([java/"javac","--release","11","-cp",args.sdk,"-d",classes,*sorted(sources())],check=True)
        jar = work/"classes.jar"
        jar.write_bytes(helper.archive({p.relative_to(classes).as_posix():p.read_bytes()
                                        for p in classes.rglob("*.class")}))
        rules = work/"rules"
        rules.write_text("-dontobfuscate\n-dontoptimize\n-keep class com.naozho.power.WakeDaemon "
                         "{ public static void main(java.lang.String[]); }\n")
        dex = work/"wake.jar"
        subprocess.run([java/"java","-cp",args.r8,"com.android.tools.r8.R8","--release","--min-api","34",
                        "--pg-conf",rules,"--lib",args.sdk,"--output",dex,jar],check=True)
        with ZipFile(dex) as z:
            data = z.read("classes.dex")
        for forbidden in (b"multi_press_timeout",b"libpowerinput",b"android.intent.action.SCREEN_ON",b"EVIOCGRAB",
                          b"Lcom/naozho/power/TimingSetup;",b"Lcom/naozho/power/DailyInput;"):
            if forbidden in data:
                raise ValueError("unexpected code retained: "+repr(forbidden))
        files = {p.name:p.read_bytes() for p in (HERE/"module").iterdir() if p.is_file()}
        files["wake.jar"] = helper.archive({"classes.dex":data})
        if files.get("clock-identities.tsv") != identities:
            raise ValueError("APK identities changed during build")
        args.out.write_bytes(helper.archive(files))
if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    for arg in ("sdk", "r8", "apksigner", "aapt2", "out"):
        parser.add_argument("--"+arg,required=True,type=Path)
    parser.add_argument("--apk", required=True, action="append", type=Path,
                        help="Repeat for each original approved APK")
    build(parser.parse_args())
