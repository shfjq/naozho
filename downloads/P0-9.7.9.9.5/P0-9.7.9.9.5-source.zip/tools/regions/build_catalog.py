"""Offline reproducible WGS84 forecast-centre catalog. See SOURCES.md."""
import json,math,pathlib
D=pathlib.Path(__file__).resolve().parent
raw=json.loads((D/'mainland-centres-gcj02.json').read_text())
supp=json.loads((D/'supplement-wgs84.json').read_text())
def delta(lat,lon):
 x=lon-105;y=lat-35
 a=-100+2*x+3*y+.2*y*y+.1*x*y+.2*math.sqrt(abs(x))
 a+=(20*math.sin(6*x*math.pi)+20*math.sin(2*x*math.pi))*2/3
 a+=(20*math.sin(y*math.pi)+40*math.sin(y/3*math.pi))*2/3
 a+=(160*math.sin(y/12*math.pi)+320*math.sin(y*math.pi/30))*2/3
 b=300+x+2*y+.1*x*x+.1*x*y+.1*math.sqrt(abs(x))
 b+=(20*math.sin(6*x*math.pi)+20*math.sin(2*x*math.pi))*2/3
 b+=(20*math.sin(x*math.pi)+40*math.sin(x/3*math.pi))*2/3
 b+=(150*math.sin(x/12*math.pi)+300*math.sin(x/30*math.pi))*2/3
 rad=lat/180*math.pi;m=1-.00669342162296594323*math.sin(rad)**2
 return a*180/((6378245*(1-.00669342162296594323))/(m*math.sqrt(m))*math.pi),b*180/(6378245/math.sqrt(m)*math.cos(rad)*math.pi)
def wgs(geo):
 lon,lat=map(float,geo.split());a,b=lat,lon
 for _ in range(12):
  d,e=delta(a,b);a-=a+d-lat;b-=b+e-lon
 return round(a,4),round(b,4)
def node(r,typ):
 lat,lon=wgs(r['geo']);return dict(code=r['id'].ljust(6,'0'),name=r['name'],type=typ,latitude=lat,longitude=lon)
provinces=[]
for r in [r for r in raw if r['deep']=='0']:
 code=r['id'];p=node(r,'municipality' if code in ['11','12','31','50'] else 'sar' if code in ['81','82'] else 'autonomous_region' if code in ['15','45','54','64','65'] else 'province');children=[]
 if code in ['11','12','31','50']:
  children=[node(c,'district') for c in raw if c['deep']=='2' and c['id'].startswith(code)]
 elif code=='71':
  # AreaCity custom six-digit code scheme; 7130/7131 reserved here for Kinmen/Lienchiang.
  twcodes={'台北市':'710100','高雄市':'710200','台南市':'710300','台中市':'710400','南投縣':'710600','基隆市':'710700','新竹市':'710800','嘉義市':'710900','新北市':'711100','宜蘭縣':'711200','新竹縣':'711300','桃園縣':'711400','苗栗縣':'711500','彰化縣':'711700','嘉義縣':'711900','雲林縣':'712100','屏東縣':'712400','台東縣':'712500','花蓮縣':'712600','澎湖縣':'712700','金門縣':'713000','連江縣':'713100'}
  simplify=str.maketrans('縣義雲蓮連門東','县义云莲连门东')
  for name,xy in supp['taiwan'].items():
   children.append(dict(code=twcodes[name],name=('桃园市' if name=='桃園縣' else name.translate(simplify)),type='county_city',latitude=xy[0],longitude=xy[1]))
  p['latitude'],p['longitude']=supp['taiwan']['台北市']
 elif code in ['81','82']:
  codes=json.loads((D/('hongkong-codes.json' if code=='81' else 'macau-codes.json')).read_text())
  eng=['Central and Western','Wan Chai','Eastern','Southern','Yau Tsim Mong','Sham Shui Po','Kowloon City','Wong Tai Sin','Kwun Tong','Tsuen Wan','Tuen Mun','Yuen Long','North','Tai Po','Sai Kung','Sha Tin','Kwai Tsing','Islands']
  for i,c in enumerate(codes):
   lat,lon=supp['hongkong'][eng[i]] if code=='81' else supp['macau'][c['name']]
   children.append(dict(code=c['code'],name=c['name'],type='district',latitude=lat,longitude=lon))
  p['latitude'],p['longitude']=(22.28,114.16) if code=='81' else (22.19,113.54)
 else:
  for c in raw:
   if c['pid']==code and c['deep']=='1':
    typ='autonomous_prefecture' if c['name'].endswith('自治州') else 'league' if c['name'].endswith('盟') else 'prefecture' if c['name'].endswith('地区') else 'county_city' if len(c['id'])==6 else 'city'
    children.append(node(c,typ))
 p['cities']=sorted(children,key=lambda c:c['code']);provinces.append(p)
# Preserve the project's published Ningbo representative centre (not a device default).
for p in provinces:
 for c in p['cities']:
  if c['code']=='330200':c.update(latitude=29.8683,longitude=121.544)
out=dict(version='2025.251231.260403+forecast-centres-1',coordinate_system='WGS84',provinces=provinces)
assert len(provinces)==34
codes=[n['code'] for p in provinces for n in [p]+p['cities']];assert len(codes)==len(set(codes))
path=D.parents[1]/'app/src/main/assets/china_regions.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n')
print(len(provinces),sum(len(p['cities']) for p in provinces),path.stat().st_size)
