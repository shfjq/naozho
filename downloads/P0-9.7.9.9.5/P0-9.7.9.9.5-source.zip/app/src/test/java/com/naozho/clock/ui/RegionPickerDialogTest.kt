package com.naozho.clock.ui

import android.app.Application
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import com.naozho.clock.display.DisplaySettings
import com.naozho.clock.display.ScreenCapabilities
import com.naozho.clock.display.withRegion
import com.naozho.clock.weather.WeatherLocation
import com.naozho.clock.weather.RegionCatalog
import com.naozho.clock.weather.RegionChoice
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35], application=Application::class, qualifiers="w360dp-h360dp-xhdpi")
class RegionPickerDialogTest {
    @get:Rule val compose = createEmptyComposeRule()
    @Test fun twoLevelsDoNotSaveUntilConfirmAndCancelIsIndependent() {
        val host = Robolectric.buildActivity(ComponentActivity::class.java).setup()
        val catalog = RegionCatalog.load(RuntimeEnvironment.getApplication())
        var confirmed:RegionChoice?=null
        var cancelled=0
        host.get().setContent { MaterialTheme { RegionPickerDialog(catalog,null,{cancelled++},{confirmed=it}) } }
        compose.onNode(hasScrollAction()).performScrollToNode(hasText("浙江省"))
        compose.onNodeWithText("浙江省").performClick()
        compose.onNodeWithText("宁波市").performClick()
        assertNull(confirmed)
        compose.onNodeWithText("已选择：浙江省 · 宁波市").assertExists()
        compose.onNodeWithText("确定").performClick()
        assertEquals("330200", confirmed?.city?.code)
        assertEquals(0,cancelled)
        host.pause().stop().destroy()
    }
    @Test fun reopenShowsSavedChoiceAndCancelNeverConfirms() {
        val host=Robolectric.buildActivity(ComponentActivity::class.java).setup()
        val catalog=RegionCatalog.load(RuntimeEnvironment.getApplication())
        var confirmed=0;var cancelled=0
        host.get().setContent { MaterialTheme { RegionPickerDialog(catalog,catalog.choice("330000","330200"),{cancelled++},{confirmed++}) } }
        compose.onNodeWithText("已选择：浙江省 · 宁波市").assertExists()
        compose.onNodeWithText("返回省份列表").performClick()
        compose.onNodeWithText("选择省份").assertExists()
        compose.onNodeWithText("取消").performClick()
        assertEquals(1,cancelled);assertEquals(0,confirmed)
        host.pause().stop().destroy()
    }
    @Test fun settingsPickerImmediatelyCallsRegionPersistenceWithoutSavingOtherFormFields() {
        val host=Robolectric.buildActivity(ComponentActivity::class.java).setup()
        var stored=DisplaySettings(weatherLocation=WeatherLocation("旧位置",31.0,121.0), weatherAuto=true)
        var regionSaves=0;var formSaves=0
        host.get().setContent { MaterialTheme {
            DisplaySettingsScreen(stored,ScreenCapabilities(),false,{}, {formSaves++},
                {},{},{},{},{},{},{},{_,_->}, regionSelected={choice -> stored=stored.withRegion(choice);regionSaves++})
        } }
        compose.onNode(hasScrollAction()).performScrollToNode(hasText("选择省/市"))
        compose.onNodeWithText("选择省/市").performClick()
        compose.onNodeWithTag("region-options").performScrollToNode(hasText("浙江省"))
        compose.onNodeWithText("浙江省").performClick()
        compose.onNodeWithText("宁波市").performClick()
        assertEquals(0,regionSaves)
        compose.onNodeWithText("确定").performClick()
        assertEquals(1,regionSaves);assertEquals(0,formSaves)
        assertEquals("宁波市",stored.weatherLocation?.label)
        assertFalse(stored.weatherAuto);assertEquals(0L,stored.weatherResolvedAt)
        compose.onNodeWithText("当前地区：浙江省 · 宁波市").assertExists()
        host.pause().stop().destroy()
    }

}
