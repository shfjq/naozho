package com.naozho.clock.weather

import android.app.Application
import com.naozho.clock.display.DisplayPreferences
import com.naozho.clock.display.DisplaySettings
import com.naozho.clock.display.withRegion
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class RegionCatalogTest {
    private val app get() = RuntimeEnvironment.getApplication()
    private fun text() = app.assets.open("china_regions.json").bufferedReader().use { it.readText() }
    private fun catalog() = RegionCatalog.load(app)
    private fun ningbo() = catalog().choice("330000", "330200")!!

    @Test fun bundledCoverageAndCodes() {
        val regions = catalog()
        assertEquals(34, regions.provinces.size)
        assertEquals(498, regions.provinces.sumOf { it.cities.size })
        val codes = regions.provinces.flatMap { listOf(it.region.code) + it.cities.map { c -> c.code } }
        assertEquals(codes.size, codes.toSet().size)
        for (p in regions.provinces) {
            assertTrue(p.cities.isNotEmpty())
            for (r in listOf(p.region) + p.cities) {
                assertTrue(r.name.isNotBlank())
                assertTrue(r.latitude in -90.0..90.0 && r.longitude in -180.0..180.0)
            }
        }
        assertSame(regions, RegionCatalog.load(app))
    }
    @Test fun municipalitySarAndTaiwanHaveSelectableChildren() {
        assertEquals(16, catalog().cities("110000").size)
        assertEquals(16, catalog().cities("120000").size)
        assertEquals(16, catalog().cities("310000").size)
        assertEquals(37, catalog().cities("500000").size)
        assertEquals(18, catalog().cities("810000").size)
        assertEquals(8, catalog().cities("820000").size)
        assertEquals(22, catalog().cities("710000").size)
        assertEquals(23, catalog().provinces.count { it.region.type == "province" })
    }
    @Test fun autonomousPrefecturesLeaguesAndDirectAdminUnitsAreNotDropped() {
        assertNotNull(catalog().choice("150000", "152900"))
        assertNotNull(catalog().choice("540000", "542500"))
        assertNotNull(catalog().choice("420000", "429021"))
        assertNotNull(catalog().choice("650000", "659012"))
        assertTrue(catalog().cities("510000").any { it.type == "autonomous_prefecture" })
    }
    @Test fun sameNamedDistrictsAndWrongProvinceAreSeparatedByCode() {
        assertNotNull(catalog().choice("110000", "110105"))
        assertNotNull(catalog().choice("220000", "220100"))
        assertNull(catalog().choice("310000", "330200"))
        assertTrue(catalog().cities("missing").isEmpty())
    }
    @Test fun legacyNingboIsRecognizedWithoutMigratingAnyPreference() {
        val before = DisplaySettings(weatherLocation = WeatherLocation("宁波市",29.8683,121.544))
        assertEquals("浙江省 · 宁波市", catalog().infer(before.weatherLocation)?.label)
        assertEquals(29.8683, ningbo().city.latitude, 0.0)
        assertEquals(121.544, ningbo().city.longitude, 0.0)
        assertNull(catalog().infer(WeatherLocation("宁波市", 31.0, 121.0)))
        assertEquals(before, before.copy())
    }
    @Test fun cancelOrBrowsingNeverWritesPreferencesAndConfirmPersistsOffline() {
        val raw = app.getSharedPreferences("region-test",0)
        raw.edit().clear().commit()
        val prefs = DisplayPreferences(raw)
        val old = DisplaySettings(weatherLocation = WeatherLocation("旧位置",31.0,121.0),weatherAuto=true,weatherResolvedAt=15)
        prefs.save(old)
        val snapshot = raw.all.toMap()
        catalog().cities("330000"); ningbo()
        assertEquals(snapshot,raw.all) // Browsing/cancel has no persistence callback.
        val updated = old.withRegion(ningbo())
        prefs.save(updated)
        val restored = DisplayPreferences(raw).state.value
        assertEquals(updated, restored)
        assertFalse(restored.weatherAuto)
        assertEquals(0L,restored.weatherResolvedAt)
        assertEquals("330000",raw.getString("weatherProvinceCode",null))
        assertEquals("330200",raw.getString("weatherCityCode",null))
        assertEquals("29.8683",raw.getString("weatherLat",null))
        assertEquals("121.544",raw.getString("weatherLon",null))
    }
    @Test fun oldPreferencesRemainUnchangedOnReadAndManualCoordinatesStayAvailable() {
        val raw = app.getSharedPreferences("legacy-region-test",0)
        raw.edit().clear().putString("weatherLabel","宁波市").putString("weatherLat","29.8683")
            .putString("weatherLon","121.544").putBoolean("weatherAuto",false).putString("unrelated","keep").commit()
        val before = raw.all.toMap()
        val prefs = DisplayPreferences(raw)
        assertEquals(before,raw.all)
        assertEquals("keep",raw.getString("unrelated",null))
        assertEquals(ningbo().city.location,prefs.state.value.weatherLocation)
        assertNotNull(WeatherLocation.parse("自行输入","30.5","120.2"))
        assertNull(WeatherLocation.parse("","",""))
    }
    private fun reject(change: (JSONObject)->Unit) {
        val root = JSONObject(text());change(root)
        try { RegionCatalog.parse(root.toString());fail("invalid catalog accepted") } catch (_:IllegalArgumentException) {}
    }
    @Test fun invalidCoordinateSystemRejected() = reject { it.put("coordinate_system","GCJ02") }
    @Test fun duplicateCodeRejected() = reject { r ->
        val cities=r.getJSONArray("provinces").getJSONObject(0).getJSONArray("cities")
        cities.getJSONObject(1).put("code",cities.getJSONObject(0).getString("code"))
    }
    @Test fun emptyNameRejected() = reject { it.getJSONArray("provinces").getJSONObject(0).put("name","") }
    @Test fun emptyProvinceRejected() = reject { it.getJSONArray("provinces").getJSONObject(0).put("cities",org.json.JSONArray()) }
    @Test fun outOfRangeCoordinatesRejected() = reject { it.getJSONArray("provinces").getJSONObject(0).put("latitude",91) }
    @Test fun outOfProvinceCodeRejected() = reject {
        it.getJSONArray("provinces").getJSONObject(0).getJSONArray("cities").getJSONObject(0).put("code","990101")
    }
    @Test fun oldCityRequestCannotPublishAfterRegionChangeEvenIfCoordinatesReturnToOldValue() = runBlocking {
        val started=CompletableDeferred<Unit>();val finish=CompletableDeferred<Unit>()
        var cached:CachedWeather?=null
        val cache=object:WeatherCache {
            override fun read()=cached
            override fun write(value:CachedWeather) { cached=value }
            override fun failure():WeatherFailure?=null
            override fun writeFailure(value:WeatherFailure) {}
        }
        val repo=WeatherRepository(WeatherSource { started.complete(Unit);finish.await();WeatherReading(12.0,0) },cache,{100L})
        val a=WeatherLocation("旧城市",31.0,121.0)
        repo.display(a,true)
        val request=launch { repo.refresh() };started.await()
        repo.display(ningbo().city.location,true);repo.display(a,true)
        finish.complete(Unit);request.join()
        assertNull(cached);assertNull(repo.state.value.last)
    }
}
