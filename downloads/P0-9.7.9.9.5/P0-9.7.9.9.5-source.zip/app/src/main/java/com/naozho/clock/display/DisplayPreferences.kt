package com.naozho.clock.display

import android.content.SharedPreferences
import androidx.core.content.edit
import com.naozho.clock.weather.WeatherLocation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

internal data class DisplaySettings(
    val dayStart: Int = 7 * 60,
    val nightStart: Int = 22 * 60,
    val nightPercent: Int = 12,
    val idleSeconds: Int = 30,
    val showOnLockScreen: Boolean = true,
    val weatherLocation: WeatherLocation? = null,
    /** True when [weatherLocation] was filled in automatically instead of typed by hand. */
    val weatherAuto: Boolean = false,
    /** Wall-clock time of the last successful automatic resolve, 0 when never resolved. */
    val weatherResolvedAt: Long = 0L,
    val weatherProvinceCode: String? = null,
    val weatherCityCode: String? = null,
) {
    init {
        require(dayStart in 0..1439 && nightStart in 0..1439 && dayStart != nightStart)
        require(nightPercent in 5..50 && (idleSeconds == 0 || idleSeconds in 10..300))
    }

    fun brightness(minuteOfDay: Int): Float {
        val atNight = if (nightStart < dayStart) minuteOfDay in nightStart until dayStart
        else minuteOfDay >= nightStart || minuteOfDay < dayStart
        return if (atNight) nightPercent / 100f else -1f
    }
}

internal class DisplayPreferences(private val prefs: SharedPreferences) {
    private val data = MutableStateFlow(read())
    val state = data.asStateFlow()

    fun save(settings: DisplaySettings) {
        val location = settings.weatherLocation
        prefs.edit {
            putInt("dayStart", settings.dayStart)
            putInt("nightStart", settings.nightStart)
            putInt("nightPercent", settings.nightPercent)
            putInt("idleSeconds", settings.idleSeconds)
            putBoolean("showOnLockScreen", settings.showOnLockScreen)
            putString("weatherLabel", location?.label)
            putString("weatherLat", location?.latitude?.toString())
            putString("weatherLon", location?.longitude?.toString())
            putBoolean("weatherAuto", settings.weatherAuto)
            putLong("weatherResolvedAt", settings.weatherResolvedAt)
            putString("weatherProvinceCode", settings.weatherProvinceCode)
            putString("weatherCityCode", settings.weatherCityCode)
        }
        data.value = settings
    }

    private fun read(): DisplaySettings {
        val defaults = DisplaySettings()
        val day = prefs.getInt("dayStart", defaults.dayStart).takeIf { it in 0..1439 } ?: defaults.dayStart
        val night = prefs.getInt("nightStart", defaults.nightStart).takeIf { it in 0..1439 && it != day }
            ?: if (day == defaults.nightStart) defaults.dayStart else defaults.nightStart
        return DisplaySettings(
            dayStart = day,
            nightStart = night,
            nightPercent = prefs.getInt("nightPercent", defaults.nightPercent).coerceIn(5, 50),
            idleSeconds = prefs.getInt("idleSeconds", defaults.idleSeconds)
                .takeIf { it == 0 || it in 10..300 } ?: defaults.idleSeconds,
            showOnLockScreen = prefs.getBoolean("showOnLockScreen", defaults.showOnLockScreen),
            weatherLocation = readWeatherLocation(prefs),
            weatherAuto = prefs.getBoolean("weatherAuto", false),
            weatherResolvedAt = prefs.getLong("weatherResolvedAt", 0L),
            weatherProvinceCode = prefs.getString("weatherProvinceCode", null),
            weatherCityCode = prefs.getString("weatherCityCode", null),
        )
    }
}

internal fun readWeatherLocation(prefs: SharedPreferences): WeatherLocation? =
    WeatherLocation.parse(
        prefs.getString("weatherLabel", "").orEmpty(),
        prefs.getString("weatherLat", "").orEmpty(),
        prefs.getString("weatherLon", "").orEmpty(),
    )

/** Region coordinates stay in the existing weather fields; codes only identify the UI selection. */
internal fun DisplaySettings.withRegion(choice: com.naozho.clock.weather.RegionChoice) = copy(
    weatherLocation = choice.city.location, weatherAuto = false, weatherResolvedAt = 0L,
    weatherProvinceCode = choice.province.code, weatherCityCode = choice.city.code,
)
