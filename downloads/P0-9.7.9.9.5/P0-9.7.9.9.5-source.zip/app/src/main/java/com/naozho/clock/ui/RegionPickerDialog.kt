package com.naozho.clock.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.naozho.clock.weather.RegionCatalog
import com.naozho.clock.weather.RegionChoice

@Composable
internal fun RegionPickerDialog(catalog: RegionCatalog, current: RegionChoice?,
    dismiss: () -> Unit, confirm: (RegionChoice) -> Unit) {
    var provinceCode by rememberSaveable { mutableStateOf(current?.province?.code) }
    var cityCode by rememberSaveable { mutableStateOf(current?.city?.code) }
    val province = catalog.provinces.find { it.region.code == provinceCode }
    val listState = key(provinceCode) { rememberLazyListState() }
    val choice = catalog.choice(provinceCode.orEmpty(), cityCode.orEmpty())
    Dialog(onDismissRequest = dismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        BackHandler(enabled = province != null) { provinceCode = null }
        Surface(Modifier.safeDrawingPadding().padding(12.dp).fillMaxWidth().widthIn(max = 540.dp)
            .fillMaxHeight(.94f), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(16.dp)) {
                Text(province?.region?.name ?: "选择省份", style = MaterialTheme.typography.titleLarge)
                if (province != null) TextButton({ provinceCode = null }) { Text("返回省份列表") }
                Text(choice?.let { "已选择：${it.label}" } ?: "请选择省份和市/区，确定后保存。",
                    style = MaterialTheme.typography.bodyMedium)
                LazyColumn(Modifier.weight(1f).fillMaxWidth().testTag("region-options"), state = listState) {
                    if (province == null) items(catalog.provinces, key = { it.region.code }) { p ->
                        ListItem(headlineContent = { Text(p.region.name) }, modifier = Modifier.clickable {
                            provinceCode = p.region.code
                            if (catalog.choice(p.region.code, cityCode.orEmpty()) == null) cityCode = null
                        })
                        HorizontalDivider()
                    } else items(province.cities, key = { it.code }) { city ->
                        ListItem(headlineContent = { Text(city.name) }, leadingContent = {
                            RadioButton(cityCode == city.code, onClick = null)
                        }, modifier = Modifier.clickable { cityCode = city.code })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(dismiss) { Text("取消") }
                    Button(onClick = { choice?.let(confirm) }, enabled = choice != null && province != null) { Text("确定") }
                }
            }
        }
    }
}
