package com.naozho.clock.weather

import android.content.Context
import org.json.JSONObject
import kotlin.math.abs

internal data class Region(val code: String, val name: String, val type: String,
    val latitude: Double, val longitude: Double) {
    val location get() = WeatherLocation(name, latitude, longitude)
}
internal data class RegionProvince(val region: Region, val cities: List<Region>)
internal data class RegionChoice(val province: Region, val city: Region) {
    val label get() = "${province.name} · ${city.name}"
}

/** Immutable, code-indexed catalogue. Parsing and validation have no Android dependency. */
internal class RegionCatalog private constructor(val provinces: List<RegionProvince>) {
    private val byProvince = provinces.associateBy { it.region.code }
    private val choices = provinces.flatMap { p -> p.cities.map { RegionChoice(p.region, it) } }
    private val byCity = choices.associateBy { it.city.code }
    fun cities(provinceCode: String): List<Region> = byProvince[provinceCode]?.cities.orEmpty()
    fun choice(provinceCode: String, cityCode: String): RegionChoice? =
        byCity[cityCode]?.takeIf { it.province.code == provinceCode }
    fun infer(location: WeatherLocation?): RegionChoice? = location?.let { saved ->
        choices.singleOrNull { it.city.name == saved.label &&
            abs(it.city.latitude - saved.latitude) <= 0.02 && abs(it.city.longitude - saved.longitude) <= 0.02 }
    }
    companion object {
        @Volatile private var cached: RegionCatalog? = null
        fun load(context: Context): RegionCatalog = cached ?: synchronized(this) {
            cached ?: context.applicationContext.assets.open("china_regions.json").bufferedReader().use {
                parse(it.readText())
            }.also { cached = it }
        }
        fun parse(text: String): RegionCatalog {
            val root = JSONObject(text)
            require(root.getString("coordinate_system") == "WGS84") { "Coordinate system" }
            val seen = mutableSetOf<String>()
            fun node(json: JSONObject): Region {
                val code = json.getString("code")
                val name = json.getString("name")
                val type = json.getString("type")
                val lat = json.getDouble("latitude")
                val lon = json.getDouble("longitude")
                require(code.matches(Regex("[0-9]{6}")) && seen.add(code)) { "Duplicate or invalid region code" }
                require(name.isNotBlank() && type.isNotBlank()) { "Empty region name/type" }
                require(lat in -90.0..90.0 && lon in -180.0..180.0) { "Invalid coordinates" }
                return Region(code, name, type, lat, lon)
            }
            val list = root.getJSONArray("provinces")
            require(list.length() == 34) { "Expected 34 provinces" }
            val provinces = (0 until list.length()).map { i ->
                val json = list.getJSONObject(i)
                val region = node(json)
                val cities = json.getJSONArray("cities")
                require(cities.length() > 0) { "Empty province" }
                RegionProvince(region, (0 until cities.length()).map { j ->
                    node(cities.getJSONObject(j)).also { require(it.code.take(2) == region.code.take(2)) }
                })
            }
            return RegionCatalog(provinces)
        }
    }
}
