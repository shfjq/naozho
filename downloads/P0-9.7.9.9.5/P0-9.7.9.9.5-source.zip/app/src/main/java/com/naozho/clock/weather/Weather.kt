package com.naozho.clock.weather

import android.content.SharedPreferences
import androidx.core.content.edit
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import org.json.JSONObject

internal data class WeatherLocation(val label: String, val latitude: Double, val longitude: Double) {
    init {
        require(latitude in -90.0..90.0 && longitude in -180.0..180.0)
    }

    val key: String get() = "$latitude,$longitude"

    companion object {
        fun parse(label: String, latitude: String, longitude: String): WeatherLocation? {
            val lat = latitude.trim().toDoubleOrNull() ?: return null
            val lon = longitude.trim().toDoubleOrNull() ?: return null
            if (lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
            return WeatherLocation(label.trim().take(32), lat, lon)
        }
    }
}

internal data class WeatherReading(val celsius: Double, val code: Int) {
    init {
        require(celsius in -150.0..150.0 && code in 0..999)
    }
}

internal data class CachedWeather(val locationKey: String, val reading: WeatherReading, val updatedAt: Long)
internal data class WeatherFailure(val locationKey: String, val reason: String, val attemptedAt: Long)

internal fun interface WeatherSource {
    suspend fun fetch(location: WeatherLocation): WeatherReading
}

internal interface WeatherCache {
    fun read(): CachedWeather?
    fun write(cached: CachedWeather)
    fun failure(): WeatherFailure?
    fun writeFailure(value: WeatherFailure)
}

internal class PreferenceWeatherCache(private val prefs: SharedPreferences) : WeatherCache {
    override fun read(): CachedWeather? {
        val raw = prefs.getString("last", null) ?: return null
        return runCatching {
            val json = JSONObject(raw)
            CachedWeather(
                json.getString("location"),
                WeatherReading(json.getDouble("celsius"), json.getInt("code")),
                json.getLong("updatedAt").also { require(it > 0L) },
            )
        }.getOrNull()
    }

    override fun write(cached: CachedWeather) {
        val json = JSONObject().put("location", cached.locationKey)
            .put("celsius", cached.reading.celsius).put("code", cached.reading.code)
            .put("updatedAt", cached.updatedAt)
        check(prefs.edit().putString("last", json.toString()).commit())
    }

    override fun failure(): WeatherFailure? {
        val raw = prefs.getString("last_failure", null) ?: return null
        return runCatching {
            val row = JSONObject(raw)
            WeatherFailure(row.getString("location"), row.getString("reason"), row.getLong("at"))
        }.getOrNull()
    }

    override fun writeFailure(value: WeatherFailure) {
        val row = JSONObject().put("location", value.locationKey).put("reason", value.reason)
            .put("at", value.attemptedAt)
        prefs.edit { putString("last_failure", row.toString()) }
    }
}

internal data class WeatherState(
    val location: WeatherLocation? = null,
    val last: CachedWeather? = null,
    val cached: Boolean = true,
    val refreshing: Boolean = false,
    val online: Boolean = false,
    val lastFailure: WeatherFailure? = null,
    val locationStatus: String = "unverified_saved_location",
) {
    val pendingFailure: WeatherFailure?
        get() = lastFailure?.takeIf { it.attemptedAt > (last?.updatedAt ?: -1L) }
}

internal class WeatherRepository(
    private val source: WeatherSource,
    private val cache: WeatherCache,
    private val now: () -> Long = System::currentTimeMillis,
) {
    private val data = MutableStateFlow(WeatherState())
    private val refreshLock = Mutex()
    private var locationGeneration = 0L
    val state = data.asStateFlow()

    fun locationStatus(status: String) { data.value = data.value.copy(locationStatus = status) }

    fun display(location: WeatherLocation?, online: Boolean) {
        val old = data.value
        val sameLocation = location?.key == old.location?.key
        if (!sameLocation) locationGeneration++
        val reading = if (sameLocation) old.last else cache.read()?.takeIf { it.locationKey == location?.key }
        val failure = if (sameLocation) old.lastFailure else cache.failure()?.takeIf { it.locationKey == location?.key }
        data.value = WeatherState(location, reading, cached = !online || !sameLocation || old.cached,
            refreshing = sameLocation && old.refreshing, online = online, lastFailure = failure)
    }

    suspend fun refresh(force: Boolean = false) {
        if (!refreshLock.tryLock()) return
        try {
            val previous = data.value
            val location = previous.location ?: return
            val generation = locationGeneration
            if (!force && !isDue(now(), previous.last)) return
            if (!previous.online) {
                recordFailure(location, "offline")
                return
            }
            data.value = previous.copy(refreshing = true)
            try {
                val current = CachedWeather(location.key, source.fetch(location), now())
                if (generation != locationGeneration || data.value.location?.key != location.key) return
                cache.write(current)
                data.value = data.value.copy(last = current, cached = !data.value.online)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failed: Exception) {
                if (generation == locationGeneration && data.value.location?.key == location.key) recordFailure(location, when (failed) {
                    is java.net.SocketTimeoutException -> "timeout"
                    is IOException -> "network_or_http"
                    is org.json.JSONException, is IllegalArgumentException -> "invalid_response"
                    else -> "cache_write_failed"
                })
            } finally {
                if (generation == locationGeneration && data.value.location?.key == location.key) data.value = data.value.copy(refreshing = false)
            }
        } finally {
            refreshLock.unlock()
        }
    }

    private fun recordFailure(location: WeatherLocation, reason: String) {
        val failure = WeatherFailure(location.key, reason, now())
        cache.writeFailure(failure)
        data.value = data.value.copy(cached = true, lastFailure = failure)
    }

    companion object {
        const val REFRESH_INTERVAL = 60 * 60_000L
        const val RETRY_INTERVAL = 15 * 60_000L

        fun isDue(now: Long, last: CachedWeather?): Boolean =
            last == null || now - last.updatedAt !in 0L until REFRESH_INTERVAL

        fun recoveryDeadline(now: Long, state: WeatherState): Long {
            val regular = state.last?.takeUnless { isDue(now, it) }?.let { it.updatedAt + REFRESH_INTERVAL }
            return minOf(regular ?: Long.MAX_VALUE, now + RETRY_INTERVAL)
        }

        fun nextDeadline(now: Long, state: WeatherState): Long {
            val last = state.last
            if (last != null && !isDue(now, last)) return last.updatedAt + REFRESH_INTERVAL
            val failure = state.pendingFailure
            if (failure != null && now - failure.attemptedAt in 0L until RETRY_INTERVAL)
                return failure.attemptedAt + RETRY_INTERVAL
            return now + RETRY_INTERVAL
        }
    }
}

internal class OpenMeteoSource : WeatherSource {
    override suspend fun fetch(location: WeatherLocation): WeatherReading = withContext(Dispatchers.IO) {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}" +
                "&longitude=${location.longitude}&current=temperature_2m,weather_code&temperature_unit=celsius",
        )
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 3_500
            connection.readTimeout = 3_500
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Accept", "application/json")
            if (connection.responseCode != HttpURLConnection.HTTP_OK) throw IOException("Weather response")
            val body = connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (output.size() + count > 65_536) throw IOException("Weather response too large")
                    output.write(buffer, 0, count)
                }
                output.toString(Charsets.UTF_8.name())
            }
            parseCurrent(body)
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        fun parseCurrent(body: String): WeatherReading {
            val current = JSONObject(body).getJSONObject("current")
            return WeatherReading(current.getDouble("temperature_2m"), current.getInt("weather_code"))
        }
    }
}

internal fun weatherDescription(code: Int): String = when (code) {
    0 -> "晴"
    1, 2 -> "多云"
    3 -> "阴"
    45, 48 -> "雾"
    51, 53, 55 -> "毛毛雨"
    56, 57, 66, 67 -> "冻雨"
    61, 63, 65 -> "雨"
    71, 73, 75, 77 -> "雪"
    80, 81, 82 -> "阵雨"
    85, 86 -> "阵雪"
    95, 96, 99 -> "雷雨"
    else -> "未知天气"
}
