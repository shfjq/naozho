# 离线天气地区目录的来源与坐标

目录版本 `2025.251231.260403+forecast-centres-1`，生成日期 2026-11-29（北京时间）。34 个省级地区，498 个下级选项。选项覆盖全部地级市、自治州、地区、盟、省直管县级单位；直辖市列区县；香港 18 区、澳门 7 堂区与路凼、台湾 22 县市。数据是本版本快照，不宣称实时区划。

## 大陆区划及中心

AreaCity-JsSpider-StatsGov，MIT，Copyright 2019 xiangyuecn。
- 源码固定提交 c6c6e35bea3066d674efe2cded189dc57a86e7d8。
- https://github.com/xiangyuecn/AreaCity-JsSpider-StatsGov/releases/tag/2025.251231.260403
- 发布数据 ok_geo.csv.7z / ok_geo.csv，原 geo 字段明确为高德 GCJ-02。本仓库保留无边界几何的中心点事实摘录 `mainland-centres-gcj02.json`，其坐标尚未转换；仅供构建，不能直接送给天气 API。
- `build_catalog.py` 使用 GCJ-02 正向偏移的迭代逆解，12 次迭代后四舍五入到 4 位小数，输出近似 WGS84。没有 BD-09 路径。转换只作用于此源，港澳台补充点不会重复转换。逆解与原始源精度存在米级误差，天气网格使用足够；不用于测绘/导航。
- 宁波 330200 使用任务中明确提供的既有 WGS84 代表点 29.8683,121.544，保留项目配置约定。安装不会把此点写成用户默认位置。
- 重庆新版为 37 个区县，包含两江区；不沿用此前 38 区县的旧断言。

## 香港

Paulkit/HKMap，MIT，Copyright 2018 PaulKit；GeoJSON 明确 CRS84（WGS84 经度/纬度）。各区取最大多边形的面积中心，输出纬度/经度，不转换 GCJ-02。
https://github.com/Paulkit/HKMap/tree/b9bc4dee0eddab95292c3607880e035fbd839d47/json
区码/简体名称来自 uiwjs/province-city-china（固定提交 a708f0df0ebdb68f09f5fcf6345367f7d5e9a7dc），MIT，Copyright 2019 wabg（随附许可证）。

## 台湾

g0v/twgeojson，Chia-liang Kao，CC0 1.0 Universal；取得自 codeforgermany/click_that_hood 的 taiwan.geojson（MIT 集合；原数据 CC0），原始县市边界为 WGS84。取最大多边形面积中心，无 GCJ 转换。原 2014 边界快照的桃园县显示名更新为桃园市；22 县市均保留。边界中心适合作为天气代表点，可能远离市政机关。
https://github.com/codeforgermany/click_that_hood/blob/48ba05ad4c6969e3b3c25735492169227ae411f1/public/data/taiwan.geojson
https://github.com/g0v/twgeojson#cc0-10-universal
台湾六位代码为目录兼容码，不声明为官方现行区划码：沿 AreaCity 71xx00，金门/连江补充为 713000/713100。禁止将这些码用于身份/法务业务。

## 澳门

名称/目录兼容码来自 uiwjs/province-city-china（MIT），包括 7 堂区和路凼。`supplement-wgs84.json` 的澳门中心为本项目整理的粗略 WGS84 代表点（CC0），保留至约 0.001 度；不是实测设备定位，不是官方政府坐标数据，不是 GCJ/BD 数据。参考地理范围：Macao Online Map https://webmap.gis.gov.mo/ 。代表点适用于天气网格查询，不保证位于政府驻地，也不用于导航。原始政府地图及未授许可的第三方边界没有打包或再分发。

港澳六位区码是数据源的目录兼容编码，不宣称官方法定编码。省级名/码保持34项惯例。

## 可复现性

`python3 tools/regions/build_catalog.py` 完全离线，输入的摘录与 WGS84 补充点随源码提供。最终 assets/china_regions.json 为应用运行时唯一目录；运行时不会下载行政数据。licenses 随本目录提供，APK assets 内亦保留归属说明和许可证。源快照散列见 source-inputs.sha256。
