package com.naozho.wakeprobe;

import android.os.Debug;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Fixed, read-only Binder dump into a bounded RAM pipe. The caller is an I/O worker. */
final class PowerRead {
    private final ExecutorService binder = Executors.newSingleThreadExecutor();
    private final AtomicBoolean occupied = new AtomicBoolean();

    PowerEvidence read() {
        if (!occupied.compareAndSet(false, true)) return PowerEvidence.unknown("binder_busy");
        boolean submitted = false;
        try {
            ParcelFileDescriptor[] pair = ParcelFileDescriptor.createPipe();
            try (InputStream in = new ParcelFileDescriptor.AutoCloseInputStream(pair[0])) {
                Future<Boolean> sent;
                try {
                    sent = binder.submit(() -> {
                        try (ParcelFileDescriptor out = pair[1]) {
                            return Debug.dumpService("power", out.getFileDescriptor(), new String[0]);
                        } finally {
                            occupied.set(false);
                        }
                    });
                    submitted = true;
                } catch (RejectedExecutionException closed) {
                    pair[1].close();
                    throw closed;
                }
                long deadline = SystemClock.elapsedRealtime() + 950;
                StructPollfd poll = new StructPollfd();
                poll.fd = pair[0].getFileDescriptor();
                poll.events = (short)OsConstants.POLLIN;
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] chunk = new byte[4096];
                while (true) {
                    long remaining = deadline - SystemClock.elapsedRealtime();
                    if (remaining <= 0 || Os.poll(new StructPollfd[]{poll}, (int)remaining) == 0)
                        return PowerEvidence.unknown("power_timeout");
                    int n = in.read(chunk);
                    if (n < 0) break;
                    if (buffer.size() + n > 256 * 1024) return PowerEvidence.unknown("power_size_limit");
                    buffer.write(chunk, 0, n);
                }
                if (!sent.get(Math.max(1, deadline - SystemClock.elapsedRealtime()), TimeUnit.MILLISECONDS))
                    return PowerEvidence.unknown("power_dump_denied");
                return PowerEvidence.parse(buffer.toString(StandardCharsets.UTF_8.name()));
            }
        } catch (Exception unavailable) {
            return PowerEvidence.unknown("power_read_failed");
        } finally {
            if (!submitted) occupied.set(false);
        }
    }
    void close() { binder.shutdown(); }
}
