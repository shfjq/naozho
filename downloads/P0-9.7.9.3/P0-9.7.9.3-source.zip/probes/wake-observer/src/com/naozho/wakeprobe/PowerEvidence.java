package com.naozho.wakeprobe;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Only retain these power-service fields. Never log the raw dump. */
final class PowerEvidence {
    final String wakefulness;
    final boolean changing;
    final long sleep, wake;
    final String error;

    private PowerEvidence(String state, boolean changing, long sleep, long wake, String error) {
        this.wakefulness = state;
        this.changing = changing;
        this.sleep = sleep;
        this.wake = wake;
        this.error = error;
    }

    static PowerEvidence unknown(String reason) {
        return new PowerEvidence("UNKNOWN", true, -1, -1, reason);
    }

    private static String field(String text, String key, String value) {
        Matcher m = Pattern.compile("(?m)^ *" + key + "=(" + value + ") *\\r?$").matcher(text);
        if (!m.find()) return null;
        String first = m.group(1);
        return m.find() ? null : first;
    }

    static PowerEvidence parse(String text) {
        String group = field(text, "displayGroupId", "[0-9]+");
        String state = field(text, "mWakefulness", "[A-Za-z]+");
        String change = field(text, "mWakefulnessChanging", "true|false");
        if (!"0".equals(group)) return unknown("default_group_unconfirmed");
        if (!("Awake".equals(state) || "Asleep".equals(state) || "Dreaming".equals(state)
                || "Dozing".equals(state)) || change == null) return unknown("power_fields_unconfirmed");
        String time = "[0-9]{1,16}(?: \\([^\\r\\n)]*\\))?";
        String sleep = field(text, "mLastSleepTime", time);
        String wake = field(text, "mLastWakeTime", time);
        if (sleep == null || wake == null) return unknown("power_history_unconfirmed");
        return new PowerEvidence(state, Boolean.parseBoolean(change),
                Long.parseLong(sleep.split(" ", 2)[0]), Long.parseLong(wake.split(" ", 2)[0]), null);
    }
}
