package com.naozho.power;

import android.content.Context;
import android.os.SystemClock;
import com.naozho.power.TrialChecks.Refused;
import com.naozho.wakeprobe.WakeEpochManager;
import com.naozho.wakeprobe.WakePowerReader;
import java.nio.file.*;
import java.util.UUID;

final class WakeBoard {
    static final Path DIR = Paths.get("/data/adb/modules/naozho_wake");
    static final String PKG = "com.naozho.clock";
    static final String PREFIX = PKG + ".action.WAKE_EPOCH_";
    static final String MODE = "shared_prefs/desktop_mode.xml";
    static final Path DE = Paths.get("/data/user_de/0/" + PKG + "/shared_prefs");
    final DailyBoard daily = new DailyBoard();
    private final DailyBoard warmIdentity = new DailyBoard();
    final WakePowerReader powerReader = new WakePowerReader(WakeBoard::power);
    private WakeSystemFacts facts;
    void attach(Context context) { facts = new WakeSystemFacts(context); }

    String generation, bootId, apk;
    volatile String published;
    int boot;
    volatile int uid;

    static boolean deploymentHint() throws Exception {
        String text = Board.text(DE.resolve("primary_home_display.xml"), 4096);
        return "true".equals(TrialChecks.one(text, "^ *<boolean name=\"armed\" value=\"(true|false)\" */> *$",
                "deployment_hint_unknown"));
    }

    void enabled() throws Exception {
        if (!SessionLease.enabled(DIR, generation) || Files.exists(DailyBoard.DIR.resolve("armed")) ||
                Files.exists(Board.MODULE.resolve("module.prop"))) throw new Refused("observer_disabled_or_conflict");
    }

    void init() throws Exception {
        generation = Board.text(DIR.resolve("armed"), 64).trim();
        enabled();
        if (android.os.Process.myUid() != 0 || android.os.Build.VERSION.SDK_INT != 36 ||
                !"CPDAY10".equals(DailyBoard.cmd("/system/bin/getprop", "ro.product.device")) ||
                !"Enforcing".equals(DailyBoard.cmd("/system/bin/getenforce"))) throw new Refused("unsupported_runtime");
        Board.verifyFramework();
        boot = Board.boot();
        bootId = Board.text(Paths.get("/proc/sys/kernel/random/boot_id"), 64).trim();
        if (!UUID.fromString(bootId).toString().equals(bootId)) throw new Refused("boot_uuid");
        apk = Board.text(DIR.resolve("clock.sha256"), 80).trim();
        if (!apk.matches("[0-9a-f]{64}")) throw new Refused("apk_pin");
        daily.clockIdentity(apk);
    }

    static String power() throws Exception {
        String dump = Board.command(950, 256 * 1024, Board.DS, "power");
        if (dump.contains("Permission Denial") || dump.contains("SecurityException"))
            throw new Refused("power_dump_denied");
        return dump;
    }

    void androidMode(long dark) throws Exception {
        facts.ownerUser();
        if (!deploymentHint()) throw new Refused("maintenance_paused");
        String rows = DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/grep", "-E",
                "^ *<(boolean|long|string) name=\"(managed_lock|managed_home|android|mode_since|wake_focused)\"", MODE);
        // A dead clock task may leave desired CLOCK, yet a safe Android page in NONE.
        // Require a well-formed persisted mode; guardedForeground independently checks both.
        Foreground.wakeMode(rows, dark);
    }
    private static String appFile(String file) throws Exception {
        return DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/cat", "files/" + file);
    }
    static void clear() throws Exception {
        DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/rm", "-f", "files/wake-epoch.proof");
    }
    static void revoke(String receipt) throws Exception {
        // A delayed invalidation may arrive after a new wake. Remove only its own receipt.
        DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/sh", "-c",
                "if [ -f files/wake-epoch.proof ] && [ \"$(cat files/wake-epoch.proof)\" = \"$1\" ]; " +
                "then rm -f files/wake-epoch.proof; fi", "wake-revoke", receipt);
    }
    interface Live { void check() throws Exception; }

    void prewarm(long dark, Live darkScreen) throws Exception {
        enabled(); darkScreen.check();
        facts.ownerUser();
        if (!deploymentHint()) throw new Refused("maintenance_paused");
        DailyBoard.androidMode(dark);
        facts.clockIdentity(warmIdentity, apk);
        String id = "warm." + boot + "." + dark;
        String action = PKG + ".action.WAKE_DARK_PREWARM";
        darkScreen.check();
        WakeDaemon.record("PREWARM_START_AT boot=" + boot + " dark=" + dark);
        Board.dispatch(DeliveryProof.envelope(action, id, "--ei", "boot_count", Integer.toString(boot),
            "--el", "dark_elapsed", Long.toString(dark)));
        if (uid < 0) {
            int actual = Board.verifiedSender(action, id, false, true);
            if (actual != 0 && actual != 2000) throw new Refused("prewarm_sender_unsupported");
            uid = actual;
        }
    }

    String dispatch(WakeEpochManager.Epoch epoch, Live live) throws Exception {
        String id = UUID.randomUUID().toString();
        WakeWire wire = new WakeWire(boot, bootId, epoch.dark, epoch.sequence, epoch.event, uid, id);
        long expires = wire.expires;
        String receipt = wire.receipt();
        class Request implements WakeDispatch.PipelinedPorts {
            int guards;
            String page;
            android.os.FileObserver acknowledgment;
            final java.util.concurrent.Semaphore writes = new java.util.concurrent.Semaphore(0);
            void fresh() throws Exception {
                enabled(); live.check();
                if (SystemClock.elapsedRealtime() >= expires || !powerReader.read().stillAwake(epoch))
                    throw new Refused("wake_expired_or_changed");
            }
            public void guard() throws Exception {
                String now = daily.guardedForeground(this::fresh, () -> androidMode(epoch.dark), () -> facts.clockIdentity(daily, apk));
                if (focusId != null && !focusId.equals(daily.guardedFocusId)) throw new Refused("foreground_changed");
                focusId = daily.guardedFocusId;
                if (page != null && !page.equals(now)) throw new Refused("foreground_changed");
                page = now;
                guards++;
                stage(guards == 1 ? "GUARD1_READY_AT" : guards == 2 ? "GUARD2_READY_AT" : "GUARD2_REFRESH_AT");
            }
            void stage(String name) {
                WakeDaemon.record(name + " boot=" + boot + " dark=" + epoch.dark + " request=" + id);
            }
            public void dispatchFormal() throws Exception {
                attempt();
                dispatchEnvelope("RETURN");
            }
            public int proveFormal() throws Exception {
                return proveDelivery("RETURN");
            }
            public void publishReceipt() throws Exception {
                published = receipt;
                enabled(); live.check();
                DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/sh", "-c",
                    "umask 077; mkdir -p files && printf %s \"$1\" > files/wake-proof.tmp && mv -f files/wake-proof.tmp files/wake-epoch.proof",
                    "wake-proof", receipt);
            }
            public int confirmOnce() throws Exception {
                // Independent Binder snapshots can overlap, but COMMIT waits for all three.
                java.util.concurrent.ExecutorService checks = java.util.concurrent.Executors.newFixedThreadPool(2);
                try {
                    java.util.concurrent.Future<?> awake = checks.submit(() -> { fresh(); return null; });
                    java.util.concurrent.Future<?> mode = checks.submit(() -> { androidMode(epoch.dark); return null; });
                    Foreground.confirmFocus(page, focusId, DailyBoard.displayFocus());
                    awake.get();
                    mode.get();
                } catch (java.util.concurrent.ExecutionException e) {
                    if (e.getCause() instanceof Exception) throw (Exception)e.getCause();
                    throw new Refused("commit_readback_failed");
                } finally { checks.shutdownNow(); }
                enabled(); live.check();
                if (SystemClock.elapsedRealtime() >= expires) throw new Refused("wake_expired");
                // The watch only expedites readback. The actual receipt, focus and system lock
                // are always read, including when the OEM does not expose this file watch.
                try {
                    acknowledgment = new android.os.FileObserver(new java.io.File("/data/user/0/" + PKG + "/files"),
                            android.os.FileObserver.CLOSE_WRITE | android.os.FileObserver.MOVED_TO) {
                        @Override public void onEvent(int event, String path) {
                            if ("wake-epoch.locked".equals(path)) writes.release();
                        }
                    };
                    acknowledgment.startWatching();
                } catch (RuntimeException unavailable) { acknowledgment = null; }
                dispatchEnvelope("COMMIT");
                return proveDelivery("COMMIT");
            }
            void dispatchEnvelope(String verb) throws Exception {
                String[] envelope = DeliveryProof.envelope(PREFIX + verb, wire.trace(verb), wire.extras());
                stage(verb + "_SEND_AT");
                Board.dispatch(envelope);
            }
            int proveDelivery(String verb) throws Exception {
                int actual = Board.verifiedSender(PREFIX + verb,wire.trace(verb),false,true);
                if (actual == uid) WakeDaemon.record(verb + "_DELIVERED_AT boot=" + boot + " dark=" + epoch.dark +
                        " request=" + id + " uid=" + actual);
                return actual;
            }
            String focusId;
            public boolean clockFocusedAndLocked() throws Exception {
                for (int i = 0; i < 5; i++) {
                    enabled(); live.check();
                    if (!deploymentHint()) return false;
                    try {
                        if (id.equals(appFile("wake-epoch.locked"))) {
                            if (WakeLockReadback.focused(DailyBoard.displayFocus()) && WakeLockReadback.locked()) {
                                saveBudget(0); return true;
                            }
                        }
                    } catch (Refused | java.io.IOException noAckYet) { /* bounded readback only */ }
                    if (i < 4) writes.tryAcquire(200L << i, java.util.concurrent.TimeUnit.MILLISECONDS);
                }
                return false;
            }
            public void clearReceipt() throws Exception {
                if (acknowledgment != null) acknowledgment.stopWatching();
                try { revoke(receipt); } finally { published = null; }
            }
        }
        Request request = new Request();
        if (budget() >= 3) return "REFUSED_CRASH_BUDGET";
        return WakeDispatch.run(request, uid);
    }
    int budget() throws Exception {
        Path p = DIR.resolve("attempts");
        if (!Files.exists(p)) return 0;
        String[] values = Board.text(p, 128).trim().split(" ");
        if (values.length != 2) throw new Refused("attempt_store_invalid");
        return values[0].equals(bootId) ? Board.number(values[1], 0, 3, "attempt_store_invalid") : 0;
    }
    private void saveBudget(int count) throws Exception {
        Path tmp = DIR.resolve("attempts.tmp");
        Files.write(tmp, (bootId + " " + count).getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        Files.move(tmp, DIR.resolve("attempts"), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    }
    private void attempt() throws Exception {
        int count = budget();
        if (count >= 3) throw new Refused("crash_budget");
        saveBudget(count + 1);
    }
}
