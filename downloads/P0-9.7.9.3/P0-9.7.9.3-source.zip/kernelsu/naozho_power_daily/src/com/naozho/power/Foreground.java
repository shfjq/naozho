package com.naozho.power;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.naozho.power.TrialChecks.Refused;

/** API 36 WindowState.dump and RootWindowContainer.dumpWindowsNoHeader. No UI text or view tree. */
final class Foreground {
    static final String SETTINGS = "com.android.settings";
    static final String CALC = "com.darkempire78.opencalculator";
    static final String CALC_PAGE = CALC + "/" + CALC + ".activities.MainActivity";
    static final String CALC_SHA = "43b6befd1fecc686ba1611bbda18896cc26d966047e788be995def569a4510f3";
    static final String NAME = "[a-zA-Z][a-zA-Z0-9_.$]*";
    private static final Pattern HEADER = Pattern.compile("(?m)^  Window #(\\d+) Window\\{([0-9a-fA-F]+) u(\\d+) ([^\\r\\n{}]+)\\}: *$");
    static String canonical(String c) throws Refused {
        if (!c.matches(NAME + "/" + NAME + "|" + NAME + "/\\." + NAME)) throw new Refused("unclassified_window");
        int sep=c.indexOf('/');
        return c.charAt(sep+1)=='.' ? c.substring(0,sep+1)+c.substring(0,sep)+c.substring(sep+1) : c;
    }

    static String focus(String display) throws Refused {
        String target=canonical(TrialChecks.focus(display));
        String resumed=TrialChecks.one(display,"^ *mFocusedApp=ActivityRecord\\{[^\\s{}]+ u0 ([^\\s{}]+) t[0-9]+[^{}]*\\} *$", "focused_app_unknown");
        if (!target.equals(canonical(resumed))) throw new Refused("focus_transition");
        return target;
    }

    static boolean settingsHome(String c) {
        return c.equals(SETTINGS + "/" + SETTINGS + ".Settings") ||
                c.equals(SETTINGS + "/" + SETTINGS + ".homepage.SettingsHomepageActivity");
    }

    static String settingsRouteFilter(String display) throws Refused {
        String id=TrialChecks.one(display,"^ *mFocusedApp=ActivityRecord\\{([0-9a-fA-F]+) u0 [^{}]+\\} *$","activity_identity_unknown");
        // Only classification bits leave the producer. Shared Settings containers may host
        // security fragments, so reject deep links, extras, dialogs and non-root routes.
        String token="(flg=0x[0-9a-fA-F]+|xflg=0x[0-9a-fA-F]+|pkg=com[.]android[.]settings"
                +"|cat=\\[android[.]intent[.]category[.]LAUNCHER\\]"
                +"|cmp=com[.]android[.]settings\\/(com[.]android[.]settings)?[.](Settings|homepage[.]SettingsHomepageActivity))";
        return "/^[ ]*[*] Hist #[0-9]+: ActivityRecord\\{"+id+" u0 /,/^[ ]*rootOfTask=/ { "
                +"/^[ ]*Intent \\{ act=(android[.]settings[.]SETTINGS|android[.]intent[.]action[.]MAIN)( "+token+")* \\}$/s/.*/ordinary/p; "
                +"/^[ ]*rootOfTask=true /s/.*/root/p; }";
    }

    static void callsIdle(String states) throws Refused {
        if (!states.matches("0(?:\\n0)*")) throw new Refused("call_or_unknown");
    }

    static void lockAndKeyguard(String states) throws Refused {
        if (!TrialChecks.one(states,"^mLockTaskModeState=(?:LOCK_TASK_MODE_)?(\\w+)$","lock_state_unknown").equals("NONE"))
            throw new Refused("task_already_locked");
        boolean known=false;
        for (String line:states.split("\n")) {
            if (line.startsWith("isKeyguardShowing=") || line.startsWith("mKeyguardShowing=")) {
                if (!line.equals("isKeyguardShowing=false") && !line.equals("mKeyguardShowing=false")) throw new Refused("keyguard");
                known=true;
            }
        }
        if (!known) throw new Refused("keyguard_unknown");
    }

    static String focusId(String display) throws Refused {
        return TrialChecks.one(display,"^ *mCurrentFocus=Window\\{([0-9a-fA-F]+) u0 [^\\s{}]+\\} *$","focus_id_unknown");
    }

    static void mode(String rows, long first) throws Refused {
        deploymentMode(rows, first, true);
    }
    static void wakeMode(String rows, long first) throws Refused {
        deploymentMode(rows, first, false);
    }
    private static void deploymentMode(String rows, long first, boolean requireAndroid) throws Refused {
        String android = TrialChecks.one(rows, "^ *<boolean name=\"android\" value=\"(true|false)\" */> *$", "mode_unknown");
        if ((requireAndroid && !android.equals("true")) ||
                !TrialChecks.one(rows,"^ *<boolean name=\"managed_lock\" value=\"(true|false)\" */> *$", "lock_unknown").equals("true") ||
                !TrialChecks.one(rows,"^ *<boolean name=\"managed_home\" value=\"(true|false)\" */> *$", "home_unknown").equals("false") ||
                first <= Long.parseLong(TrialChecks.one(rows,"^ *<long name=\"mode_since\" value=\"([0-9]{1,15})\" */> *$", "generation_unknown")))
            throw new Refused("mode_ineligible");
    }

    static String rawFocusId(String display) throws Refused {
        return TrialChecks.one(display,"^ *mCurrentFocus=Window\\{([0-9a-fA-F]+) u0 [^{}\\r\\n]+\\} *$","focus_id_unknown");
    }

    static final class Windows {
        VisibleWindowDump snapshot;
        int extras=-1, visibleCount, decorCount, interactiveCount, blockingCount, unknownCount, omitted;
        final java.util.List<String> bars=new java.util.ArrayList<>(2);
        final java.util.List<String> rows=new java.util.ArrayList<>();
        String focused="unknown", veto;
        void reject(String reason) { if (veto==null) veto=reason; }
        String totals() {
            String meta=snapshot==null?"":" "+snapshot.diagnostic();
            if (extras<0) return " visible_window_count=-1 decorative_window_count=-1 interactive_window_count=-1"+
                    " blocking_window_count=-1 unknown_window_count=-1 omitted_rows=0"+meta;
            return " visible_window_count="+visibleCount+" decorative_window_count="+decorCount+
                    " interactive_window_count="+interactiveCount+" blocking_window_count="+blockingCount+
                    " unknown_window_count="+unknownCount+" omitted_rows="+omitted+meta;
        }
        void record(String row,boolean blocker) {
            if (rows.size()<24) { rows.add(row); return; }
            omitted++;
            if (blocker) {
                for (int i=rows.size()-1;i>=0;i--) if (rows.get(i).endsWith("actual_blocker=false")) {
                    rows.set(i,row); break;
                }
            }
        }
    }

    private static String field(String body,String regex) {
        try { return TrialChecks.one(body,regex,"missing"); }
        catch (Refused unknown) { return "unknown"; }
    }
    private static String bit(String body,String key) {
        return field(body,"(?:^| )"+key+"=(true|false)(?= |$)");
    }
    private static boolean bar(String name,String type) {
        return type.equals("STATUS_BAR") && name.equals("StatusBar") ||
                type.equals("NAVIGATION_BAR") && name.matches("Nav(?:igation)?Bar0?") ||
                (type.equals("NAVIGATION_BAR_PANEL") || type.equals("NAVIGATION_BAR")) && name.equals("SecondaryHomeHandle0");
    }

    static Windows inspectSnapshot(String dump,String focusId) {
        String end="\nWMS_WINDOWS_END";
        int i=dump.indexOf(end);
        if (i<0 || !dump.substring(i).trim().equals("WMS_WINDOWS_END")) {
            Windows failed=new Windows(); failed.reject("window_snapshot_incomplete"); return failed;
        }
        return inspect(dump.substring(0,i),focusId);
    }

    static Windows inspect(String dump,String focusId) {
        Windows result=new Windows();
        if (!dump.startsWith("WINDOW MANAGER WINDOWS") || dump.contains("Hiding System Alert Windows:") ||
                dump.contains("Windows force removing:")) result.reject("windows_unconfirmed");
        Matcher header=HEADER.matcher(dump);
        boolean seen=false;
        int n=0;
        result.extras=0;
        java.util.Set<String> ids=new java.util.HashSet<>();
        while (header.find()) {
            boolean identity=Integer.toString(n++).equals(header.group(1)) && "0".equals(header.group(3)) && ids.add(header.group(2));
            int stop=dump.indexOf("\n  Window #",header.end());
            String body=dump.substring(header.end(),stop<0?dump.length():stop);
            boolean focused=header.group(2).equals(focusId);
            String name=header.group(4);
            String owner=field(body,"^ *mOwnerUid=\\d+ showForAllUsers=(?:true|false) package=([a-zA-Z0-9_.]{1,160})(?: .*)?$");
            WindowAttributes attrs=WindowAttributes.parse(body);
            String type=attrs.type;
            String display=field(body,"^ *mDisplayId=(-?\\d+)(?: .*)?$");
            String visible=bit(body,"isVisible"),onScreen=bit(body,"isOnScreen"),surface=bit(body,"mHasSurface"),covered=bit(body,"mObscured");
            WindowGeometry geom=WindowGeometry.parse(body);
            String canFocus=attrs.focusable(), canTouch=attrs.touchable();
            boolean sysUi=owner.equals("com.android.systemui");
            if (sysUi && (type.equals("STATUS_BAR") || type.equals("NAVIGATION_BAR")) && result.bars.size()<3) {
                result.bars.add("bar="+type+" source="+attrs.source+" status="+attrs.status+" flags="+attrs.publicValue+
                        " region="+geom.region);
            }
            boolean platform=owner.equals("android") && body.matches("(?s).*\n *mOwnerUid=1000 .*");
            boolean panelDecor=type.equals("NAVIGATION_BAR_PANEL") && sysUi &&
                    (name.equals("ScreenDecorOverlay") || name.equals("ScreenDecorOverlayBottom"));
            boolean oldDecor=(sysUi || platform) && (type.equals("DISPLAY_OVERLAY") || type.equals("SYSTEM_OVERLAY")) &&
                    (name.equals("SysDecor") || name.matches("ScreenDecorOverlay[A-Za-z0-9]*"));
            boolean systemBar=sysUi && bar(name,type);
            boolean active=visible.equals("true") && onScreen.equals("true") && surface.equals("true");
            boolean appIdentity=focused && !seen && type.equals("BASE_APPLICATION") && name.startsWith(owner+"/") &&
                    active && geom.valid && covered.equals("false");
            String missing="";
            String[][] required={{"owner",owner},{"type",type},{"display",display},{"visible",visible},{"onscreen",onScreen},
                    {"surface",surface},{"obscured",covered}};
            for (String[] pair:required) if (pair[1].equals("unknown")) missing+=pair[0]+"+";
            if (attrs.status.startsWith("missing")) missing+="flags+";
            if ((systemBar || panelDecor || oldDecor) && !body.contains("Frames: parent=")) missing+="geometry+";
            if (geom.region.equals("missing")) missing+="region+";
            String kind="unknown", reason, deny=null;
            if (!identity || !display.equals("0")) {
                reason="user_display_or_order"; deny="unexpected_window";
            } else if (!missing.isEmpty() || !attrs.known()) {
                if (appIdentity && missing.equals("flags+")) {
                    // Identify the focused app, but keep the security decision closed when public flags are missing.
                    try { result.focused=canonical(name); kind="app"; }
                    catch (Refused invalid) { kind="unknown"; }
                }
                reason=!attrs.known()?attrs.status:"missing_metadata"; deny="window_metadata_unknown";
            } else if (!focused && visible.equals("false") && onScreen.equals("false") &&
                    (surface.equals("false") || body.matches("(?s).* mViewVisibility=0x[48] .*"))) {
                kind="inactive"; reason="not_on_display";
            } else if (attrs.secure()) {
                kind="secure"; reason="secure_flag"; deny="secure_window";
            } else if (type.contains("INPUT_METHOD") || type.contains("NOTIFICATION_SHADE") ||
                    name.equals("ControlCenter") || name.equals("NotificationShade")) {
                kind="panel_or_ime"; reason="active_panel_or_ime"; deny=reason;
            } else if (type.contains("KEYGUARD") || type.contains("ERROR")) {
                kind="protected"; reason="protected_system_window"; deny=reason;
            } else if (appIdentity && canFocus.equals("true") && canTouch.equals("true")) {
                kind="app"; reason="focused_application";
                try { result.focused=canonical(name); } catch (Refused ambiguous) { deny="focus_identity_unknown"; }
            } else if (!focused && seen && type.equals("WALLPAPER")) {
                kind="wallpaper"; reason="below_foreground";
            } else if (panelDecor || oldDecor || systemBar) {
                if (focused || !canFocus.equals("false") || !systemBar && !canTouch.equals("false"))
                    reason="decor_input_capability";
                else if (!active || !covered.equals("false")) reason="decor_visibility";
                else if (!geom.valid || !geom.edge) reason="decor_geometry";
                else if (!geom.boundedRegion()) reason="decor_touch_region";
                else { kind="decor"; reason=systemBar?"verified_edge_bar":"verified_passive_decor"; }
                if (!kind.equals("decor")) deny=reason;
            } else {
                kind=type.contains("DIALOG")?"dialog":"unclassified";
                reason=type.equals("NAVIGATION_BAR_PANEL")?"unrecognized_nav_panel":"unreviewed_overlay";
                deny="additional_visible_window";
            }
            if (focused) {
                if (seen || !kind.equals("app")) { if (deny==null) deny="non_app_focus"; }
                seen=true;
            } else result.extras++;
            if (deny!=null) { result.reject(deny); result.blockingCount++; }
            if (visible.equals("true")) result.visibleCount++;
            if (kind.equals("decor")) result.decorCount++;
            if (active && !kind.equals("wallpaper") && !kind.equals("decor") && (focused || canFocus.equals("true") || canTouch.equals("true"))) result.interactiveCount++;
            if (kind.equals("unknown") || kind.equals("unclassified")) result.unknownCount++;
            String parserError=!identity?"window_block_boundary":!attrs.known()?attrs.status:"none";
            result.record("type="+type+" owner="+owner+" visible="+visible+" onscreen="+onScreen+" surface="+surface+
                    " focus="+focused+" focusable="+canFocus+" touchable="+canTouch+" obscured="+covered+" edge="+geom.edge+
                    " class="+kind+" class_reason="+reason+" parser_source="+attrs.source+
                    " field_missing="+(missing.isEmpty()?"none":missing.substring(0,missing.length()-1))+
                    " focusable_parse_status="+attrs.status+" touchable_parse_status="+attrs.status+
                    " geometry_valid="+geom.valid+" touch_region="+geom.region+
                    " collector_command=dumpsys_window_-a_visible collector_source=wms_visible window_block_index="+(n-1)+
                    " flags_line_found="+attrs.found+" flags_parse_status="+attrs.status+" flags_source="+attrs.source+
                    " flags_value_count="+attrs.valueCount+" flags_line_number="+attrs.lineNumber+
                    " attrs_brace_depth="+attrs.depth+" attrs_parse_status="+attrs.structure+" parser_error="+parserError+" actual_blocker="+(deny!=null),deny!=null);
        }
        if (result.omitted>0) result.reject("window_diagnostics_limit");
        if (!seen || dump.split("(?m)^  Window #",-1).length-1!=n) result.reject("window_set_incomplete");
        return result;
    }
    static void visible(String dump,String target,String focusId) throws Refused { verify(inspect(dump,focusId),target); }
    static void confirmFocus(String page,String id,String after) throws Refused {
        if (!page.equals(focus(after)) || !id.equals(focusId(after))) throw new Refused("focus_transition");
    }
    static void verify(Windows value,String page) throws Refused {
        if (value.veto!=null) throw new Refused(value.veto);
        if (!value.focused.equals(page)) throw new Refused("window_set_incomplete");
    }
    private Foreground() {}
}
