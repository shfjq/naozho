package com.naozho.clock

import android.Manifest
import android.app.ActivityManager
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.UserManager
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.edit
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.naozho.clock.alarm.AlarmAlerts
import com.naozho.clock.alarm.AlarmRingService
import com.naozho.clock.alarm.AlarmRuntime
import com.naozho.clock.alarm.AndroidAlarmScheduler
import com.naozho.clock.alarm.Recovery
import com.naozho.clock.device.AndroidClockSource
import com.naozho.clock.display.DisplayPreferences
import com.naozho.clock.display.ScreenCapabilities
import com.naozho.clock.display.ScreenControls
import com.naozho.clock.display.alarmPreventsSleep
import com.naozho.clock.isolation.IsolationPhase
import com.naozho.clock.isolation.IsolationSettingsActivity
import com.naozho.clock.mode.AdminRecoveryActivity
import com.naozho.clock.mode.AdminOperation
import com.naozho.clock.mode.CredentialResult
import com.naozho.clock.mode.DesktopMode
import com.naozho.clock.mode.DesktopPolicyUpdates
import com.naozho.clock.mode.DesktopResult
import com.naozho.clock.mode.HiddenEntryGesture
import com.naozho.clock.mode.INDEPENDENT_BOOT_ACTION
import com.naozho.clock.mode.EXTRA_BOOT_COUNT
import com.naozho.clock.mode.ManagedDeployment
import com.naozho.clock.mode.ManagedDesktop
import com.naozho.clock.mode.ModeCredentials
import com.naozho.clock.mode.PowerDelivery
import com.naozho.clock.mode.WakeTicket
import com.naozho.clock.mode.ClockPowerReturn
import com.naozho.clock.mode.ModeState
import com.naozho.clock.mode.bootCount
import com.naozho.clock.mode.NativeDesktop
import com.naozho.clock.mode.SystemCredentialGate
import com.naozho.clock.mode.isDevelopmentBuild
import com.naozho.clock.mode.credentialFeedback
import com.naozho.clock.ui.AlarmHub
import com.naozho.clock.ui.AlarmPermissions
import com.naozho.clock.ui.ClockPermission
import com.naozho.clock.ui.ClockScreen
import com.naozho.clock.ui.DesktopUnavailableScreen
import com.naozho.clock.ui.DisplaySettingsScreen
import com.naozho.clock.ui.ModeEntryScreen
import com.naozho.clock.ui.PermissionSetupScreen
import com.naozho.clock.ui.parseMinutes
import com.naozho.clock.ui.permissionSetupStatus
import com.naozho.clock.ui.upcomingStatus
import com.naozho.clock.weather.OpenMeteoSource
import com.naozho.clock.weather.PreferenceWeatherCache
import com.naozho.clock.weather.WeatherRepository
import com.naozho.clock.weather.weatherConnectivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : ComponentActivity() {
    private val runtime get() = application as AlarmRuntime
    private val scheduler by lazy { AndroidAlarmScheduler(this) }
    private val clock by lazy { AndroidClockSource(applicationContext) }
    private val controls by lazy { ScreenControls(this) }
    private val display by lazy { DisplayPreferences(getSharedPreferences("clock_display", MODE_PRIVATE)) }
    private val modeState by lazy { ModeState(this) }
    private val credentials by lazy { ModeCredentials(this) }
    private val credentialGate by lazy { SystemCredentialGate(this) }
    private val development by lazy { isDevelopmentBuild }
    private val nativeDesktop by lazy { NativeDesktop(this) }
    private val managedDesktop by lazy { ManagedDesktop(this) }
    private val deployment by lazy { ManagedDeployment(this) }
    private val hiddenEntry = HiddenEntryGesture()
    private val weather by lazy {
        WeatherRepository(OpenMeteoSource(), PreferenceWeatherCache(getSharedPreferences("clock_weather", MODE_PRIVATE)))
    }
    private val refreshWeather = MutableSharedFlow<Boolean>(extraBufferCapacity = 1)
    private val permissionSetup by lazy { getSharedPreferences("permission_setup", MODE_PRIVATE) }
    private var permissions by mutableStateOf(AlarmPermissions())
    private var dndGranted by mutableStateOf(false)
    private var isolationEnabled by mutableStateOf(false)
    private var capabilities by mutableStateOf(ScreenCapabilities())
    private var route by mutableStateOf(Page.CLOCK)
    // Only an already displayed clock can be retained. Never restore this across process death.
    private var retainClockOnDesktop by mutableStateOf(false)
    private var pinError by mutableStateOf<String?>(null)
    private var confirmDevelopmentExit by mutableStateOf(false)
    private var checkingPin by mutableStateOf(false)
    private var configured by mutableStateOf(false)
    @Volatile private var resumed = false
    private var idleJob: Job? = null
    private var desktopJob: Job? = null
    private var lockJob: Job? = null
    private var awaitingPowerFocus: Intent? = null
    private var frameTicket by mutableStateOf<WakeTicket?>(null)
    private var drawnWake: String? = null
    private var focusedWake: String? = null
    private var wakeForLock: WakeTicket? = null
    private var primaryPolicyAttempted = false
    private var requestedSwipeDismissal = false
    private var forwardingJob: Job? = null
    private var capturingTouch = false
    private var forwardedDesktop = false
    private var presentedRing: Pair<String, Long>? = null
    private val managedClock: Boolean
        get() = (development || configured) && modeState.managedLock() && managedDesktop.dedicatedReady &&
            (modeState.independentLock() || (modeState.managesHome() && capabilities.defaultHome && managedDesktop.receiptMatches(managedDesktop.clockHome) &&
                nativeDesktop.target(modeState.selectedHome()) != null))
    private val screenEvents = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    requestedSwipeDismissal = false
                    confirmDevelopmentExit = false
                    // Keep the clock eligible to show on the next wake, even if editing at sleep.
                    if (route == Page.ALARMS || route == Page.DISPLAY || route == Page.AUTH ||
                        route == Page.PERMISSIONS) show(Page.CLOCK)
                }
                Intent.ACTION_USER_PRESENT -> if (resumed) {
                    refreshDisplayCapabilities()
                    resumeMode()
                }
            }
        }
    }
    private val adminRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        refreshDisplayCapabilities()
    }
    private val notificationRequest = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshRegistration()
    }

    private var unlockReceiver: BroadcastReceiver? = null
    private var screenEventsRegistered = false
    private var waitingForBootCredential = false
    private var restartingAfterUnlock = false

    private fun resumeAfterFirstUnlock() {
        if (Build.VERSION.SDK_INT >= 24 && !restartingAfterUnlock && !isFinishing &&
            getSystemService(UserManager::class.java).isUserUnlocked
        ) {
            restartingAfterUnlock = true
            Log.i("NaozhoMode", "Direct Boot clock received first user unlock; restoring clock UI")
            recreate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val startedAt = android.os.SystemClock.elapsedRealtime()
        super.onCreate(savedInstanceState)
        logClockEntry(intent, "create")
        if (!acceptClockEntry(intent, savedInstanceState, startedAt, "on_create")) {
            finish()
            return
        }
        // HOME can be resolved before credential-encrypted preferences are available.
        if (Build.VERSION.SDK_INT >= 24 && !getSystemService(UserManager::class.java).isUserUnlocked) {
            Log.i("NaozhoMode", "Direct Boot clock waiting for first user unlock; foreground lock not requested")
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    if (intent.action == Intent.ACTION_USER_UNLOCKED) resumeAfterFirstUnlock()
                }
            }
            unlockReceiver = receiver
            ContextCompat.registerReceiver(this, receiver, IntentFilter(Intent.ACTION_USER_UNLOCKED),
                ContextCompat.RECEIVER_NOT_EXPORTED)
            val productHome = development && managedDesktop.isPrimaryClockEntry(intent)
            val showEarlyClock = productHome && createDeviceProtectedStorageContext()
                .getSharedPreferences("primary_home_display", MODE_PRIVATE).getBoolean("armed", false) &&
                managedDesktop.dedicatedReady && !getSystemService(KeyguardManager::class.java).isDeviceSecure
            if (productHome && !showEarlyClock) {
                setContentView(android.widget.TextView(this).apply {
                    text = getString(R.string.primary_home_wait)
                    gravity = Gravity.CENTER
                })
            } else setContentView(TextClock(this).apply {
                format12Hour = "HH:mm"
                format24Hour = "HH:mm"
                gravity = Gravity.CENTER
                textSize = 52f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.BLACK)
                if (showEarlyClock) {
                    isFocusable = true
                    contentDescription = getString(R.string.primary_home_show_date)
                    setOnClickListener {
                        val showDate = format24Hour == "HH:mm"
                        val format = if (showDate) "MM-dd EEE" else "HH:mm"
                        format12Hour = format
                        format24Hour = format
                        contentDescription = getString(if (showDate) R.string.primary_home_show_time else R.string.primary_home_show_date)
                    }
                }
            })
            resumeAfterFirstUnlock()
            return
        }
        modeState.syncEarlyDisplay()
        runtime.ringControls.attach(window)
        val restored = Page.entries.firstOrNull { it.name == savedInstanceState?.getString("clockPage") }
        if (awaitingPowerFocus != null || savedInstanceState == null || savedInstanceState.getBoolean("waitingForFirstUnlock") ||
            modeState.useClockEntryOnRestore(intent, savedInstanceState.getInt("clockPageBoot", -1))
        ) handleEntry(intent)
        else route = when {
            modeState.current() == DesktopMode.ANDROID -> Page.NATIVE
            !controls.isKeyguardLocked() &&
                (restored == Page.ALARMS || restored == Page.DISPLAY || restored == Page.PERMISSIONS) -> restored
            else -> Page.CLOCK
        }
        updateLockScreen()
        ContextCompat.registerReceiver(this, screenEvents, IntentFilter(Intent.ACTION_SCREEN_OFF).apply {
            addAction(Intent.ACTION_USER_PRESENT)
        },
            ContextCompat.RECEIVER_NOT_EXPORTED)
        screenEventsRegistered = true
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                runtime.ringControls.ringing.collect { presentRingingAlarm() }
            }
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )

        val updates = clock.observe()
        val initial = clock.snapshot()
        observeWeather()
        setContent {
            val snapshot by updates.collectAsStateWithLifecycle(initialValue = initial)
            val plans by runtime.repository.plans.collectAsStateWithLifecycle(initialValue = emptyList())
            val settings by display.state.collectAsStateWithLifecycle()
            val conditions by weather.state.collectAsStateWithLifecycle()
            LaunchedEffect(snapshot.time, settings) {
                if (resumed) updateBrightness(snapshot.time)
            }
            LaunchedEffect(Unit) {
                combine(runtime.isolation.status, DesktopPolicyUpdates.revision) { _, _ -> Unit }
                    .collect { if (resumed) updateImmersive() }
            }
            MaterialTheme(colorScheme = darkColorScheme()) {
                BackHandler(route == Page.CLOCK) {}
                BackHandler(route == Page.ALARMS || route == Page.DISPLAY || route == Page.AUTH) { show(Page.CLOCK) }
                BackHandler(route == Page.PERMISSIONS, onBack = ::finishPermissionSetup)
                LaunchedEffect(route) {
                    if (route == Page.AUTH) {
                        delay(60_000L)
                        show(Page.CLOCK)
                    }
                }
                when (route) {
                    Page.CLOCK, Page.NATIVE -> if (route == Page.CLOCK || retainClockOnDesktop) ClockScreen(
                        parked = route == Page.NATIVE,
                        returnPending = frameTicket != null,
                        onClockDrawn = frameTicket?.let { ticket -> { clockDrawn(ticket) } },
                        snapshot = snapshot,
                        alarmStatus = upcomingStatus(plans, permissions),
                        weather = conditions,
                        openAlarms = { if (acceptsClockControl()) afterUnlock { show(Page.ALARMS) } },
                        openWeather = openWeather@{
                            if (!acceptsClockControl()) return@openWeather
                            if (settings.weatherLocation == null) afterUnlock { show(Page.DISPLAY) }
                            else refreshWeather.tryEmit(true)
                        },
                        openSettings = { if (acceptsClockControl()) afterUnlock { show(Page.DISPLAY) } },
                        exitDevelopmentMode = if (development) ::requestDevelopmentExit else null,
                    ) else Surface(Modifier.fillMaxSize()) {}
                    Page.ALARMS -> AlarmHub(runtime.repository, plans, permissions, !managedClock, ::requestPermission) {
                        show(Page.CLOCK)
                    }
                    Page.DISPLAY -> DisplaySettingsScreen(
                        settings = settings,
                        capabilities = capabilities,
                        systemUiAvailable = !managedClock,
                        close = { show(Page.CLOCK) },
                        save = {
                            display.save(it)
                            updateBrightness(clock.snapshot().time)
                            show(Page.CLOCK)
                        },
                        chooseHome = ::chooseHome,
                        openPermissions = { show(Page.PERMISSIONS) },
                        systemSettings = { launchSettings(Intent(Settings.ACTION_SETTINGS)) },
                        admin = ::toggleAdmin,
                        lockNow = ::lockFromSettings,
                        recovery = ::openRecovery,
                        notificationSettings = ::openNotificationSettings,
                    )
                    Page.AUTH -> ModeEntryScreen(configured, checkingPin || credentialGate.waiting, pinError, ::verifyPin) { show(Page.CLOCK) }
                    Page.PERMISSIONS -> PermissionSetupScreen(
                        currentPermissionSetup(), ::requestPermission, ::finishPermissionSetup,
                    )
                    Page.UNAVAILABLE -> DesktopUnavailableScreen({ enterClock() }, ::openRecovery)
                }
                if (development && route == Page.CLOCK && confirmDevelopmentExit) {
                    AlertDialog(
                        onDismissRequest = { confirmDevelopmentExit = false },
                        title = { Text("退出专机锁定？") },
                        text = { Text("确认后返回原桌面。") },
                        confirmButton = {
                            TextButton({
                                confirmDevelopmentExit = false
                                exitDevelopmentMode()
                            }) { Text("确认退出") }
                        },
                        dismissButton = {
                            TextButton({ confirmDevelopmentExit = false }) { Text("取消") }
                        },
                    )
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (unlockReceiver == null) {
            outState.putString("clockPage", route.name)
            outState.putInt("clockPageBoot", bootCount(this))
        } else outState.putBoolean("waitingForFirstUnlock", true)
        if (!isFinishing && awaitingPowerFocus == null && ClockPowerReturn.isPrivateTarget(this, intent)) {
            outState.putBoolean("powerClockAccepted", true)
        }
        super.onSaveInstanceState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        val startedAt = android.os.SystemClock.elapsedRealtime()
        super.onNewIntent(intent)
        logClockEntry(intent, "newIntent")
        if (!acceptClockEntry(intent, null, startedAt, "on_new_intent")) return
        setIntent(intent)
        if (unlockReceiver == null) handleEntry(intent)
    }

    override fun onResume() {
        super.onResume()
        if (isFinishing) return
        if (unlockReceiver != null) {
            resumeAfterFirstUnlock()
            return
        }
        resumed = true
        if (!development) configured = credentials.configured()
        refreshDisplayCapabilities()
        updateBrightness(clock.snapshot().time)
        refreshRegistration()
        if (route != Page.NATIVE) refreshIsolation()
        resumeMode()
        offerPermissionSetup()
    }

    override fun onPause() {
        resumed = false
        confirmDevelopmentExit = false
        idleJob?.cancel()
        hiddenEntry.reset()
        forwardedDesktop = false
        if (route == Page.AUTH && !credentialGate.waiting) show(Page.CLOCK)
        applyBrightness(WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE)
        super.onPause()
    }

    override fun onDestroy() {
        unlockReceiver?.let { unregisterReceiver(it) }
        if (screenEventsRegistered) unregisterReceiver(screenEvents)
        super.onDestroy()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (unlockReceiver == null) restartIdle()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (isFinishing || unlockReceiver != null) return
        if (modeState.managedLock() || managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED) {
            Log.i("NaozhoMode", "Clock window focused=$hasFocus page=$route lockTask=${managedDesktop.stateName()}")
        }
        if (hasFocus) {
            if (development) logStationPhase()
            updateImmersive()
            restartIdle()
            resumeMode()
            presentRingingAlarm()
            offerPermissionSetup()
        } else {
            idleJob?.cancel()
            hiddenEntry.reset()
        }
    }

    private fun presentRingingAlarm() {
        val plan = runtime.ringControls.ringing.value
        val at = plan?.activeAt
        if (plan == null || at == null) {
            presentedRing = null
            return
        }
        if (!resumed || !hasWindowFocus() || isFinishing || route == Page.NATIVE) return
        val occurrence = plan.id to at
        if (presentedRing == occurrence) return
        try {
            // Android can show only a heads-up notification when the display is interactive.
            // In managed Lock Task, keep the foreground ringing window in the locked task.
            val locked = managedClock && managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED
            startActivity(runtime.alerts.ringIntent(inCurrentTask = locked))
            presentedRing = occurrence
        } catch (error: ActivityNotFoundException) {
            Log.w("NaozhoAlarm", "Foreground ringing window unavailable", error)
        } catch (error: SecurityException) {
            Log.w("NaozhoAlarm", "Foreground ringing window rejected", error)
        }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (development) return super.dispatchTouchEvent(event)
        if (route != Page.CLOCK || !resumed || !hasWindowFocus()) {
            hiddenEntry.reset()
            return super.dispatchTouchEvent(event)
        }
        if (event.actionMasked == MotionEvent.ACTION_DOWN) capturingTouch = false
        if (event.actionMasked == MotionEvent.ACTION_CANCEL) {
            hiddenEntry.reset()
            if (!capturingTouch) return super.dispatchTouchEvent(event)
            capturingTouch = false
            return true
        }
        val action = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> HiddenEntryGesture.Action.DOWN
            MotionEvent.ACTION_POINTER_DOWN -> HiddenEntryGesture.Action.POINTER_DOWN
            MotionEvent.ACTION_MOVE -> HiddenEntryGesture.Action.MOVE
            MotionEvent.ACTION_POINTER_UP -> HiddenEntryGesture.Action.POINTER_UP
            MotionEvent.ACTION_UP -> HiddenEntryGesture.Action.UP
            else -> return super.dispatchTouchEvent(event)
        }
        val width = window.decorView.width.toFloat()
        val height = window.decorView.height.toFloat()
        if (width <= 0 || height <= 0) return super.dispatchTouchEvent(event)
        val corner = minOf(76 * resources.displayMetrics.density, minOf(width, height) / 4)
        val id = event.getPointerId(event.actionIndex)
        fun sample(index: Int) = hiddenEntry.accept(
            action,
            if (index < 0) event.eventTime else event.getHistoricalEventTime(index),
            id,
            List(event.pointerCount) { pointer ->
                val x = if (index < 0) event.getX(pointer) else event.getHistoricalX(pointer, index)
                val y = if (index < 0) event.getY(pointer) else event.getHistoricalY(pointer, index)
                HiddenEntryGesture.Finger(event.getPointerId(pointer), x / width, y / height)
            },
            corner / width,
            corner / height,
        )
        val historyCaptured = (0 until event.historySize).fold(false) { captured, index ->
            (sample(index) != HiddenEntryGesture.Result.PASS) || captured
        }
        val result = sample(-1)
        if (result == HiddenEntryGesture.Result.PASS && !historyCaptured && !capturingTouch) {
            return super.dispatchTouchEvent(event)
        }
        if (!capturingTouch && action != HiddenEntryGesture.Action.DOWN) {
            val cancel = MotionEvent.obtain(event).apply { this.action = MotionEvent.ACTION_CANCEL }
            super.dispatchTouchEvent(cancel)
            cancel.recycle()
        }
        capturingTouch = action != HiddenEntryGesture.Action.UP
        restartIdle()
        if (result == HiddenEntryGesture.Result.COMPLETE) afterUnlock { show(Page.AUTH) }
        return true
    }

    private fun show(page: Page) {
        if (route != page) {
            confirmDevelopmentExit = false
            hiddenEntry.reset()
            if (!development) credentialGate.cancel()
        }
        if (page == Page.AUTH) {
            pinError = null
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        if (page != Page.NATIVE) retainClockOnDesktop = false
        route = page
        updateLockScreen()
        restartIdle()
        updateImmersive()
        if (page == Page.CLOCK || page == Page.NATIVE) resumeMode()
    }

    private fun refreshDisplayCapabilities() {
        capabilities = controls.capabilities()
        isolationEnabled = runtime.isolation.status.value.enabled
        dndGranted = Build.VERSION.SDK_INT >= 24 &&
            getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        // When locked, HOME can show the clock but cannot expose an open settings page.
        if (route == Page.ALARMS || route == Page.DISPLAY || route == Page.AUTH || route == Page.PERMISSIONS) {
            if (controls.isKeyguardLocked() || (route == Page.PERMISSIONS && managedClock)) show(Page.CLOCK)
        }
        updateLockScreen()
        updateImmersive()
        restartIdle()
    }

    private fun updateLockScreen() {
        val deployedClock = development && modeState.managedLock() && modeState.current() == DesktopMode.CLOCK
        val keyguard = getSystemService(KeyguardManager::class.java)
        if (waitingForBootCredential && !keyguard.isKeyguardLocked) waitingForBootCredential = false
        allowLockScreen(route == Page.CLOCK && !waitingForBootCredential && (display.state.value.showOnLockScreen || deployedClock))
    }

    private fun allowLockScreen(allow: Boolean) {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(allow)
        } else {
            @Suppress("DEPRECATION")
            if (allow) window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
    }

    private fun acceptClockEntry(intent: Intent, restored: Bundle?, startedAt: Long, entry: String): Boolean {
        if (ClockPowerReturn.isEntry(this, intent)) {
            if (!ClockPowerReturn.isPrivateTarget(this, intent) || !development || Build.VERSION.SDK_INT < 28) return false
            if (restored?.getBoolean("powerClockAccepted") == true &&
                getSystemService(UserManager::class.java).isUserUnlocked &&
                modeState.current() == DesktopMode.CLOCK && modeState.independentLock() &&
                intent.getIntExtra(EXTRA_BOOT_COUNT, -1) == bootCount(this) &&
                (intent.action != WakeTicket.RETURN || (managedDesktop.dedicatedReady &&
                    managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED))) return true
            if (!ClockPowerReturn.accept(this, intent, PowerDelivery.CHECK)) return false
            if (intent.action == WakeTicket.RETURN) {
                frameTicket = WakeTicket.read(intent)
                frameTicket?.let { ticket ->
                    ticket.trace("ACTIVITY_START_AT", startedAt, " entry=$entry retained_clock=$retainClockOnDesktop")
                    val remaining = (ticket.expires - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0)
                    window.decorView.postDelayed({
                        if (frameTicket?.id == ticket.id && !isFinishing && !isDestroyed) {
                            frameTicket = null
                            awaitingPowerFocus = null
                            finish()
                        }
                    }, remaining + 1)
                }
            }
            awaitingPowerFocus = intent
            return true
        }
        if (intent.action != INDEPENDENT_BOOT_ACTION) {
            frameTicket = null
            awaitingPowerFocus = null
            return true
        }
        val boot = intent.getIntExtra(EXTRA_BOOT_COUNT, -1)
        val accepted = Build.VERSION.SDK_INT >= 28 && getSystemService(UserManager::class.java).isUserUnlocked &&
            modeState.acceptsBootLaunch(boot) && managedDesktop.owner && managedDesktop.dedicatedReady
        Log.i("NaozhoMode", "Independent boot Activity boot=$boot accepted=$accepted elapsedMs=${android.os.SystemClock.elapsedRealtime()}")
        if (accepted) {
            val keyguard = getSystemService(KeyguardManager::class.java)
            waitingForBootCredential = keyguard.isDeviceSecure && keyguard.isKeyguardLocked
        }
        return accepted
    }

    private fun handleEntry(intent: Intent) {
        if (intent.action == INDEPENDENT_BOOT_ACTION || ClockPowerReturn.isPrivateTarget(this, intent)) {
            show(Page.CLOCK)
            return
        }
        val appIcon = intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_LAUNCHER)
        // Existing AlarmClockInfo show intents open MainActivity explicitly without an action.
        val alarmDetails = intent.action == null && intent.component?.className == MainActivity::class.java.name
        if (!intent.hasCategory(Intent.CATEGORY_HOME) && (appIcon || alarmDetails)) {
            enterClock()
        } else if (modeState.current() == DesktopMode.ANDROID) {
            forwardedDesktop = false
            show(Page.NATIVE)
        } else if (intent.hasCategory(Intent.CATEGORY_HOME) && route != Page.PERMISSIONS) {
            show(Page.CLOCK)
        }
    }

    private fun enterClock() {
        val updateIndependentPolicy = modeState.independentLock() && managedDesktop.state == ActivityManager.LOCK_TASK_MODE_NONE &&
            !managedDesktop.dedicatedReady
        if (modeState.managesHome() || updateIndependentPolicy) {
            if (desktopJob?.isActive == true) return
            desktopJob = lifecycleScope.launch {
                val result = deployment.switchTo(DesktopMode.CLOCK)
                desktopJob = null
                if (result == DesktopResult.Applied) {
                    show(Page.CLOCK)
                    if (resumed) {
                        refreshDisplayCapabilities()
                        resumeMode()
                        refreshIsolation()
                    }
                } else if (result is DesktopResult.Rejected) {
                    message(result.message)
                    show(Page.UNAVAILABLE)
                }
            }
            return
        }
        if (modeState.current() == DesktopMode.CLOCK || modeState.set(DesktopMode.CLOCK)) {
            show(Page.CLOCK)
            if (resumed) refreshIsolation()
        } else message("未能保存闹钟模式，请重试。")
    }

    private fun refreshIsolation() {
        lifecycleScope.launch { runtime.isolation.reconcile() }
    }

    private fun openRecovery() = afterUnlock {
        startActivity(Intent(this, AdminRecoveryActivity::class.java))
    }

    private fun openNotificationSettings() = afterUnlock {
        if (!managedClock) startActivity(Intent(this, IsolationSettingsActivity::class.java))
    }

    private fun verifyPin(pin: String) {
        if (checkingPin || desktopJob?.isActive == true || !canLeaveClock()) return
        pinError = null
        credentialGate.request(AdminOperation.SWITCH_TO_ANDROID, { pinError = it }) { approval ->
            finishAndroidHandoff(
                allowed = { canLeaveClock() && approval.permits(AdminOperation.SWITCH_TO_ANDROID) },
                verify = { credentials.verifyPin(pin, approval) },
                completed = approval::revoke,
            )
        }
    }

    private fun acceptsClockControl(): Boolean = route == Page.CLOCK && awaitingPowerFocus == null && !isFinishing

    private fun requestDevelopmentExit() {
        if (!development || !acceptsClockControl() || !resumed) return
        if (managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED) confirmDevelopmentExit = true
        else exitDevelopmentMode()
    }

    private fun exitDevelopmentMode() {
        if (!development || route != Page.CLOCK || !resumed) return
        if (controls.isKeyguardLocked()) {
            message("Android 系统锁屏仍在生效。时钟可在锁屏上显示。")
            return
        }
        finishAndroidHandoff(
            allowed = { development && route == Page.CLOCK && resumed && !controls.isKeyguardLocked() },
            continueAfterUnlock = { development && route == Page.CLOCK && !isDestroyed && !controls.isKeyguardLocked() },
        )
    }

    private fun handoffError(text: String) {
        if (development) message(text) else pinError = text
    }

    private fun finishAndroidHandoff(
        allowed: () -> Boolean,
        verify: suspend () -> CredentialResult = { CredentialResult.Accepted },
        completed: () -> Unit = {},
        continueAfterUnlock: () -> Boolean = allowed,
    ) {
        if (desktopJob?.isActive == true || !allowed()) return
        checkingPin = true
        desktopJob = lifecycleScope.launch {
            var leavingManaged = false
            try {
                val result = verify()
                if (!allowed()) return@launch
                if (result != CredentialResult.Accepted) {
                    handoffError(credentialFeedback(result))
                    return@launch
                }
                val selected = modeState.selectedHome()
                val validation = if (development && (selected != null || modeState.managesHome())) {
                    nativeDesktop.validateSavedHome(selected)
                } else null
                if (validation is DesktopResult.Rejected) {
                    handoffError(validation.message)
                    return@launch
                }
                if (nativeDesktop.target(selected) == null) {
                    handoffError("没有已选定的可用原生桌面，请打开恢复设置。")
                    return@launch
                }
                var failure: String? = null
                val saved = runtime.isolation.handOffToAndroid(allowed) {
                    lockJob?.join()
                    if (!allowed()) return@handOffToAndroid false
                    leavingManaged = managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED
                    if (!managedDesktop.leave(this@MainActivity)) {
                        failure = "退出受管锁定：系统当前为 ${managedDesktop.stateName()}。请通过恢复设置暂停专机。"
                        return@handOffToAndroid false
                    }
                    if (!continueAfterUnlock()) return@handOffToAndroid false
                    when (val handoff = deployment.switchTo(DesktopMode.ANDROID, continueAfterUnlock)) {
                        DesktopResult.Applied -> true
                        is DesktopResult.Rejected -> {
                            failure = handoff.message
                            false
                        }
                    }
                }
                if (!saved) {
                    if (allowed()) handoffError(failure ?: "未能完成安卓模式切换，请重试。")
                    return@launch
                }
                retainClockOnDesktop = development && route == Page.CLOCK && modeState.independentLock() &&
                    modeState.current() == DesktopMode.ANDROID
                show(Page.NATIVE)
                forwardDesktop()
            } finally {
                completed()
                checkingPin = false
                desktopJob = null
                // If the handoff was interrupted after stopping Lock Task, restore the clock task.
                if (leavingManaged && modeState.current() == DesktopMode.CLOCK &&
                    managedDesktop.state == ActivityManager.LOCK_TASK_MODE_NONE && !isDestroyed
                ) show(Page.CLOCK)
                if (route == Page.CLOCK) resumeMode()
            }
        }
    }

    private fun canLeaveClock(): Boolean = route == Page.AUTH && resumed && !controls.isKeyguardLocked()

    private fun clockDrawn(ticket: WakeTicket) {
        if (frameTicket?.id != ticket.id || drawnWake == ticket.id || route != Page.CLOCK) return
        drawnWake = ticket.id
        ticket.trace("ACTIVITY_READY_AT")
        window.decorView.post { if (!isDestroyed && !isFinishing && frameTicket?.id == ticket.id) resumeMode() }
    }

    private fun resumeMode() {
        if (!resumed || desktopJob?.isActive == true) return
        awaitingPowerFocus?.let { pending ->
            if (!hasWindowFocus()) return
            if (pending.action == WakeTicket.RETURN) {
                val ticket = frameTicket ?: return
                if (focusedWake != ticket.id) { focusedWake = ticket.id; ticket.trace("CLOCK_FOCUSED_AT") }
                if (drawnWake != ticket.id) return
                frameTicket = null
            }
            awaitingPowerFocus = null
            if (!ClockPowerReturn.accept(this, pending, PowerDelivery.CONSUME)) {
                Log.i("NaozhoPowerReturn", "Return expired or became ineligible before focus")
                // Leave the foreground handoff uncommitted. Do not launch the desktop over a call.
                finish()
                return
            }
            wakeForLock = if (pending.action == WakeTicket.RETURN) WakeTicket.read(pending) else null
            Log.i("NaozhoPowerReturn", "Return committed on foreground focus")
        }
        when (route) {
            Page.NATIVE -> if (!controls.isKeyguardLocked()) forwardDesktop()
            Page.CLOCK -> {
                if (!hasWindowFocus()) return
                if (!primaryPolicyAttempted && modeState.independentLock() && modeState.current() == DesktopMode.CLOCK &&
                    managedDesktop.state == ActivityManager.LOCK_TASK_MODE_NONE &&
                    !managedDesktop.dedicatedReady && managedDesktop.isPrimaryClockEntry(intent)
                ) {
                    primaryPolicyAttempted = true
                    desktopJob = lifecycleScope.launch {
                        val result = deployment.preparePrimaryClock()
                        desktopJob = null
                        if (result is DesktopResult.Rejected) {
                            DesktopPolicyUpdates.recordLockResult(result)
                            if (resumed) message(result.message)
                        } else if (resumed && !isFinishing) resumeMode()
                    }
                    return
                }
                if (managedClock && modeState.current() == DesktopMode.CLOCK) {
                    if (managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED || lockJob?.isActive == true) return
                    if (controls.isKeyguardLocked()) {
                        dismissSwipeKeyguardForClock()
                        return
                    }
                    lockJob = lifecycleScope.launch {
                        if (!resumed || !hasWindowFocus() || isFinishing || route != Page.CLOCK ||
                            modeState.current() != DesktopMode.CLOCK || !modeState.managedLock()) return@launch
                        val ticket = wakeForLock
                        wakeForLock = null
                        if (ticket != null && (!ticket.fresh(android.os.SystemClock.elapsedRealtime()) ||
                            !ticket.attested(this@MainActivity) || controls.isKeyguardLocked() ||
                            getSystemService(android.media.AudioManager::class.java).mode != android.media.AudioManager.MODE_NORMAL ||
                            !getSystemService(android.os.PowerManager::class.java).isInteractive)) {
                            modeState.releaseFailedWake(ticket.id)
                            return@launch
                        }
                        val result = managedDesktop.start(this@MainActivity)
                        if (ticket != null) {
                            if (resumed && hasWindowFocus() && route == Page.CLOCK &&
                                managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED &&
                                managedDesktop.dedicatedReady && modeState.independentLock()) {
                                ticket.trace("LOCKED_CONFIRMED_AT")
                                modeState.confirmWake(ticket.id)
                                runCatching { java.io.File(filesDir, "wake-epoch.locked").writeText(ticket.id) }
                            } else if (managedDesktop.state == ActivityManager.LOCK_TASK_MODE_NONE) {
                                modeState.releaseFailedWake(ticket.id)
                            }
                        }
                        updateImmersive()
                        if (development) {
                            logStationPhase()
                            DesktopPolicyUpdates.recordLockResult(result)
                            if (resumed && result is DesktopResult.Rejected) message(result.message)
                        }
                    }
                }
            }
            else -> Unit
        }
    }

    private fun logStationPhase() {
        val confirmed = route == Page.CLOCK && resumed && hasWindowFocus() &&
            !controls.isKeyguardLocked() && managedDesktop.owner && managedClock &&
            managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED
        Log.i("NaozhoMode", "stationPhase=${modeState.stationPhase(confirmed)} boot=${bootCount(this)} page=$route")
    }

    private fun logClockEntry(intent: Intent, lifecycleEvent: String) {
        if (!development) return
        val entry = when {
            intent.action == INDEPENDENT_BOOT_ACTION -> "boot-request"
            intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME) -> "home-intent"
            intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_LAUNCHER) -> "launcher"
            else -> "other"
        }
        Log.i("NaozhoMode", "clockEntry=$entry lifecycle=$lifecycleEvent boot=${bootCount(this)}")
    }

    private fun dismissSwipeKeyguardForClock() {
        if (!development || Build.VERSION.SDK_INT < 26 || requestedSwipeDismissal) return
        val keyguard = getSystemService(KeyguardManager::class.java)
        if (keyguard.isDeviceSecure) return
        requestedSwipeDismissal = true
        try {
            keyguard.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    if (!isDestroyed && !controls.isKeyguardLocked()) resumeMode()
                }

                override fun onDismissError() {
                    Log.w("NaozhoMode", "Unable to dismiss swipe Keyguard before clock Lock Task")
                }
            })
        } catch (error: RuntimeException) {
            Log.w("NaozhoMode", "Swipe Keyguard dismissal rejected before clock Lock Task", error)
        }
    }

    private fun forwardDesktop() {
        if (forwardedDesktop || forwardingJob?.isActive == true || route != Page.NATIVE ||
            !resumed || controls.isKeyguardLocked()
        ) return
        forwardedDesktop = true
        forwardingJob = lifecycleScope.launch {
            val status = runtime.isolation.reconcile()
            val homeRestored = deployment.reconcileHome()
            if (route != Page.NATIVE || !resumed || controls.isKeyguardLocked()) {
                forwardedDesktop = false
                return@launch
            }
            if (modeState.current() != DesktopMode.ANDROID) {
                show(Page.CLOCK)
                return@launch
            }
            if (status.phase == IsolationPhase.RELEASE_UNCERTAIN) {
                message("未能确认勿扰规则已暂停，请在系统勿扰设置中核对。")
            }
            val home = modeState.selectedHome()
            if (homeRestored is DesktopResult.Rejected) {
                message(homeRestored.message)
                show(Page.UNAVAILABLE)
            } else {
                val launch = nativeDesktop.open(home)
                if (launch is DesktopResult.Rejected) {
                    if (development) message(launch.message)
                    show(Page.UNAVAILABLE)
                }
            }
        }
    }

    private fun updateImmersive() {
        val insets = WindowCompat.getInsetsController(window, window.decorView)
        insets.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
        if (managedDesktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED || (route == Page.CLOCK && managedClock)) {
            // Lock Task owns navigation and notification restrictions. The window must not request swipe-to-reveal bars.
            insets.show(WindowInsetsCompat.Type.systemBars())
            return
        }
        val isolation = runtime.isolation.status.value
        val hideForIsolation = Build.VERSION.SDK_INT >= 24 && isolation.enabled && isolation.hasAccess
        if (route == Page.CLOCK && ((configured || development) && capabilities.defaultHome || hideForIsolation)) {
            insets.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insets.hide(WindowInsetsCompat.Type.systemBars())
        } else insets.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun afterUnlock(action: () -> Unit) {
        if (!controls.isKeyguardLocked()) {
            action()
        } else if (Build.VERSION.SDK_INT >= 26) {
            val requestedFrom = route
            val keyguard = getSystemService(KeyguardManager::class.java)
            keyguard.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    if (route == requestedFrom && !controls.isKeyguardLocked() && !isFinishing && !isDestroyed) action()
                }

                override fun onDismissError() {
                    message("请先通过系统锁屏解锁。")
                }
            })
        } else {
            allowLockScreen(false)
            message("请先通过系统锁屏解锁。")
        }
    }

    private fun updateBrightness(time: String) {
        val minute = parseMinutes(time) ?: return
        val brightness = if (route == Page.NATIVE || route == Page.UNAVAILABLE) {
            WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        } else display.state.value.brightness(minute)
        applyBrightness(brightness)
    }

    private fun applyBrightness(value: Float) {
        val attrs = window.attributes
        if (attrs.screenBrightness != value) {
            attrs.screenBrightness = value
            window.attributes = attrs
        }
    }

    private fun restartIdle() {
        idleJob?.cancel()
        val seconds = display.state.value.idleSeconds
        if (!resumed || !hasWindowFocus() || route != Page.CLOCK ||
            !capabilities.activeAdmin || seconds == 0
        ) return
        idleJob = lifecycleScope.launch {
            delay(seconds * 1000L)
            while (resumed && hasWindowFocus() && route == Page.CLOCK) {
                if (maySleep()) {
                    controls.lock()
                    break
                }
                delay(3_000L)
            }
        }
    }

    private suspend fun maySleep(): Boolean {
        val plans = withTimeoutOrNull(1_500L) { runtime.repository.plans.first() } ?: return false
        return !alarmPreventsSleep(plans, System.currentTimeMillis())
    }

    private fun lockFromSettings() {
        show(Page.CLOCK)
        lifecycleScope.launch {
            if (!maySleep()) {
                message("有闹铃正在响铃或即将触发，暂缓息屏。")
            } else if (!controls.lock()) {
                message("息屏未执行，请核对应用锁屏授权。")
            }
        }
    }

    private fun toggleAdmin() {
        val requestedPage = route
        val wasActive = capabilities.activeAdmin
        if (managedDesktop.owner) return
        fun update() {
            if (route != requestedPage || managedDesktop.owner || managedDesktop.activeAdmin != wasActive) return
            if (wasActive) {
                controls.revokeAdmin()
                refreshDisplayCapabilities()
            } else {
                try { adminRequest.launch(controls.requestAdmin()) }
                catch (_: ActivityNotFoundException) { message("设备未提供锁屏授权界面。") }
            }
        }
        if (development) {
            update()
            return
        }
        credentialGate.request(AdminOperation.DEVICE_ADMIN, ::message) { approval ->
            try {
                update()
            } finally {
                approval.revoke()
            }
        }
    }

    private fun currentPermissionSetup() = permissionSetupStatus(permissions, capabilities, dndGranted, isolationEnabled)

    private fun offerPermissionSetup() {
        if (!resumed || route != Page.CLOCK || managedClock || controls.isKeyguardLocked() ||
            permissionSetup.getBoolean("completed", false) || runtime.ringControls.ringing.value != null
        ) return
        // An enrolled primary HOME can get focus before DPM has restored its lock policy.
        if (modeState.independentLock() && modeState.current() == DesktopMode.CLOCK &&
            managedDesktop.isPrimaryClockEntry(intent)) return
        if (currentPermissionSetup().hasRequests) {
            show(Page.PERMISSIONS)
        } else permissionSetup.edit { putBoolean("completed", true) }
    }

    private fun finishPermissionSetup() {
        permissionSetup.edit { putBoolean("completed", true) }
        show(Page.CLOCK)
    }

    private fun requestPermission(permission: ClockPermission) {
        if (managedClock || controls.isKeyguardLocked()) return
        val appPackage = Uri.fromParts("package", packageName, null)
        val appSettings = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, appPackage)
        when (permission) {
            ClockPermission.NOTIFICATIONS -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED &&
                    (!permissionSetup.getBoolean("notification_requested", false) ||
                        shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS))
                ) {
                    permissionSetup.edit { putBoolean("notification_requested", true) }
                    notificationRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else if (Build.VERSION.SDK_INT >= 26) {
                    val settings = if (NotificationManagerCompat.from(this).areNotificationsEnabled()) {
                        Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_CHANNEL_ID, AlarmAlerts.RING_CHANNEL)
                    } else Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    launchSettings(settings.putExtra(Settings.EXTRA_APP_PACKAGE, packageName), appSettings)
                } else launchSettings(appSettings)
            }
            ClockPermission.EXACT_ALARM ->
                launchSettings(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, appPackage), appSettings)
            ClockPermission.FULL_SCREEN ->
                launchSettings(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, appPackage), appSettings)
            ClockPermission.DO_NOT_DISTURB ->
                launchSettings(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            ClockPermission.AUTO_LOCK -> if (!capabilities.activeAdmin) toggleAdmin()
            ClockPermission.HOME -> chooseHome()
        }
    }

    private fun chooseHome() {
        val fallback = if (Build.VERSION.SDK_INT >= 24) {
            Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS
        } else {
            Settings.ACTION_SETTINGS
        }
        launchSettings(controls.homeSettings(), Intent(fallback))
    }

    private fun launchSettings(intent: Intent, fallback: Intent? = null) {
        if (managedClock) return
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            if (fallback == null) message("系统设置不可用。")
            else launchSettings(fallback)
        } catch (_: SecurityException) {
            if (fallback == null) message("系统限制此入口，请从 Android 设置中确认。")
            else launchSettings(fallback)
        }
    }

    private fun message(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun observeWeather() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                val locations = display.state.map { it.weatherLocation }.distinctUntilChanged()
                combine(locations, weatherConnectivity(applicationContext)) { location, online -> location to online }
                    .collectLatest { (location, online) ->
                        weather.display(location, online)
                        if (location != null && online) {
                            val periodic = flow {
                                while (true) {
                                    emit(false)
                                    delay(WeatherRepository.REFRESH_INTERVAL)
                                }
                            }
                            merge(periodic, refreshWeather).collect { weather.refresh(force = it) }
                        }
                    }
            }
        }
    }

    private fun refreshRegistration() {
        permissions = AlarmPermissions(scheduler.canSchedule(), runtime.alerts.canNotify(), runtime.alerts.canFullScreen())
        lifecycleScope.launch {
            runtime.repository.recover(Recovery.RESTORE)
            val row = runtime.repository.active.first().firstOrNull()
            if (row != null && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                try {
                    ContextCompat.startForegroundService(this@MainActivity,
                        Intent(this@MainActivity, AlarmRingService::class.java))
                } catch (_: IllegalStateException) {
                    row.activeAt?.let { runtime.repository.audit(row.id, "playback_blocked", it) }
                } catch (_: SecurityException) {
                    row.activeAt?.let { runtime.repository.audit(row.id, "playback_blocked", it) }
                }
            }
        }
    }

    private enum class Page { CLOCK, ALARMS, DISPLAY, AUTH, NATIVE, UNAVAILABLE, PERMISSIONS }
}
