Use a copy of this source tree. Run git apply rollback/1f1c809.patch to restore the verified 0.6.15-dev/30 + 1.1.0 source.
The paired rollback APK distributed here is built from those sources with only versionCode = 31 in app/build.gradle.kts, and its accompanying 1.1.0 module pins that APK. Use the original signing identity.
