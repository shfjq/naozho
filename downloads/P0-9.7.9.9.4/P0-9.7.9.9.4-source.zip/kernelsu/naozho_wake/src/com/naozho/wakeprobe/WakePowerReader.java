package com.naozho.wakeprobe;

/** Fixed PMS service, read-only Binder transaction; use the board's bounded dumpsys if unavailable. */
public final class WakePowerReader implements AutoCloseable {
    @FunctionalInterface
    public interface Fallback {
        String read() throws Exception;
    }

    private final PowerRead binder = new PowerRead();
    private final WakeEpochManager.PowerSources sources;

    public WakePowerReader(Fallback fallback) {
        WakeEpochManager.PowerSources text = new WakeEpochManager.PowerSources(
            () -> WakeEpochManager.Sample.binder(binder.read()),
            () -> WakeEpochManager.Sample.parse(fallback.read()));
        sources = new WakeEpochManager.PowerSources(
            () -> WakeEpochManager.Sample.proto(binder.read(new String[]{"--proto"}, PowerProto::parse)),
            text::read);
    }

    public WakeEpochManager.Sample read() throws Exception { return sources.read(); }
    @Override public void close() { binder.close(); }
}
