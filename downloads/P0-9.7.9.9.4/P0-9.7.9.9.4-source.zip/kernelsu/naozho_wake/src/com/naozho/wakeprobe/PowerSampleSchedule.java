package com.naozho.wakeprobe;

/** Bounded attempts on one real ON edge, anchored to that edge's elapsed time.
 * A slow previous dump consumes time in the schedule instead of adding fixed sleeps. */
public final class PowerSampleSchedule {
    private static final int[] OFFSETS_MS = {0, 60, 180, 400, 800, 1550, 2500};

    public static int dueAttempt(int minimum, long elapsed) {
        int index = minimum;
        while (!last(index) && elapsed >= OFFSETS_MS[index + 1]) index++;
        return index;
    }
    public static boolean last(int attempt) { return attempt >= OFFSETS_MS.length - 1; }
    public static long nextDelay(int attempt, long elapsed) {
        if (last(attempt)) throw new IllegalArgumentException("last_power_attempt");
        return Math.max(0, OFFSETS_MS[attempt + 1] - elapsed);
    }
    private PowerSampleSchedule() {}
}
