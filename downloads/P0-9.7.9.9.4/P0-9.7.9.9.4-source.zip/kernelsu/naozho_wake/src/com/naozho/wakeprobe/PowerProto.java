package com.naozho.wakeprobe;

/** PowerManagerService.dumpProto in this board's pinned services/classes2.dex.
 * Decoded only after the fixed-service Binder call succeeds and its bounded pipe reaches EOF. */
final class PowerProto {
    private static final String[] STATES = {"Asleep", "Awake", "Dreaming", "Dozing"};
    static PowerEvidence parse(byte[] bytes) {
        if (bytes.length > 256 * 1024) return PowerEvidence.unknown("power_size_limit");
        try {
            Cursor data = new Cursor(bytes, 0, bytes.length);
            // ProtoOutputStream omits singular defaults. In this schema they mean
            // ASLEEP=0, changing=false and groupId=0 inside a present group message.
            long state=0, wake=-1, sleep=-1;
            boolean changing=false, seenState=false, seenChanging=false, group=false, looper=false;
            while (data.pos < data.end) {
                int key = data.key();
                switch (key >>> 3) {
                    case 3:
                        if (seenState) throw new IllegalArgumentException();
                        state = data.scalar(key); seenState = true;
                        break;
                    case 4:
                        if (seenChanging) throw new IllegalArgumentException();
                        long flag = data.scalar(key);
                        if (flag != 0 && flag != 1) throw new IllegalArgumentException();
                        changing = flag == 1; seenChanging = true;
                        break;
                    case 20:
                        if (group || !isDefaultGroup(data.message(key)))
                            return PowerEvidence.unknown("unsupported_power_groups");
                        group = true;
                        break;
                    case 29:
                        if (wake >= 0) throw new IllegalArgumentException();
                        wake = data.uptime(key);
                        break;
                    case 30:
                        if (sleep >= 0) throw new IllegalArgumentException();
                        sleep = data.uptime(key);
                        break;
                    case 46:
                        // PMS unconditionally dumps its handler Looper after power history.
                        Cursor handler = data.message(key);
                        if (looper || handler.pos == handler.end) throw new IllegalArgumentException();
                        while (handler.pos < handler.end) handler.skip(handler.key());
                        looper = true;
                        break;
                    default:
                        data.skip(key);
                }
            }
            if (!group || !looper || wake < 0 || sleep < 0 || state < 0 || state >= STATES.length)
                return PowerEvidence.unknown("power_proto_incomplete");
            return new PowerEvidence(STATES[(int)state], changing, sleep, wake, null);
        } catch (IllegalArgumentException malformed) {
            return PowerEvidence.unknown("power_proto_malformed");
        }
    }

    private static boolean isDefaultGroup(Cursor group) {
        boolean seenId = false;
        while (group.pos < group.end) {
            int key = group.key();
            if ((key >>> 3) == 6) {
                if (seenId) throw new IllegalArgumentException();
                if (group.scalar(key) != 0) return false;
                seenId = true;
            } else group.skip(key);
        }
        return true;
    }

    /** No recursion and no allocation based on untrusted lengths. */
    private static final class Cursor {
        final byte[] bytes;
        int pos;
        final int end;
        Cursor(byte[] bytes, int pos, int end) { this.bytes=bytes; this.pos=pos; this.end=end; }
        long varint() {
            long value = 0;
            for (int shift=0; shift<=63 && pos<end; shift+=7) {
                int next = bytes[pos++] & 255;
                if (shift == 63 && next > 1) throw new IllegalArgumentException();
                value |= (long)(next & 127) << shift;
                if (next < 128) return value;
            }
            throw new IllegalArgumentException();
        }
        int key() {
            long key = varint();
            if (key < 8 || key > 0xffffffffL) throw new IllegalArgumentException();
            return (int)key;
        }
        long scalar(int key) {
            if ((key & 7) != 0) throw new IllegalArgumentException();
            return varint();
        }
        long uptime(int key) {
            long v = scalar(key);
            if (v < 0) throw new IllegalArgumentException();
            return v;
        }
        int length() {
            long length = varint();
            if (length < 0 || length > end - pos) throw new IllegalArgumentException();
            return (int)length;
        }
        Cursor message(int key) {
            if ((key & 7) != 2) throw new IllegalArgumentException();
            int n = length();
            Cursor part = new Cursor(bytes, pos, pos + n);
            pos += n;
            return part;
        }
        void skip(int key) {
            int n;
            switch (key & 7) {
                case 0: varint(); return;
                case 1: n=8; break;
                case 2: n=length(); break;
                case 5: n=4; break;
                default: throw new IllegalArgumentException();
            }
            if (n > end-pos) throw new IllegalArgumentException();
            pos += n;
        }
    }
}
