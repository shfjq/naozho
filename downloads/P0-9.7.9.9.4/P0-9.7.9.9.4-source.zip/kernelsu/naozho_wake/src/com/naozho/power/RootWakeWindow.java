package com.naozho.power;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.Process;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Read-only capability probe in the pinned CPDAY10 KSU process. WMS LocalService has a trusted
 * task overlay, but stock IWindowManager/IWindowSession have no corresponding source-window
 * attach endpoint. A display-level system-alert window would also cover application-level
 * credential or call activities. Never add one merely because a coarse permission is granted.
 */
final class RootWakeWindow {
    private final Context system;
    private String reason;

    RootWakeWindow(Context system) { this.system = system; }

    /** Called only on a worker. Never delays formal wake, never accumulates binder probes. */
    synchronized String unavailableReason() {
        if (reason != null) return reason;
        FutureTask<RootWakeWindowFacts> probe = new FutureTask<>(this::inspect);
        Thread thread = new Thread(probe, "wake-mask-capability");
        thread.setDaemon(true);
        thread.start();
        try {
            RootWakeWindowFacts facts = probe.get(350, TimeUnit.MILLISECONDS);
            WakeDaemon.record(facts.diagnostic());
            reason = facts.reason();
        } catch (InterruptedException stopped) {
            Thread.currentThread().interrupt();
            reason = "window_probe_interrupted";
        } catch (TimeoutException stalled) {
            reason = "window_probe_timeout";
        } catch (ExecutionException unavailable) {
            reason = "window_probe_unavailable";
        } finally {
            probe.cancel(true);
        }
        return reason;
    }

    private RootWakeWindowFacts inspect() {
        return new RootWakeWindowFacts(Process.myUid() == 0,
                binder("window", "android.view.IWindowManager"),
                binder("SurfaceFlinger", "android.ui.ISurfaceComposer"),
                binder("SurfaceFlingerAIDL", "android.gui.ISurfaceComposer"),
                permission("android.permission.INTERNAL_SYSTEM_WINDOW"),
                permission("android.permission.SYSTEM_ALERT_WINDOW"));
    }

    // Binder liveness/descriptor and checkSelfPermission are independent diagnostics. None opens a
    // Session, obtains a foreign app's token, claims ownership of a task, or sends a compositor command.
    private RootWakeWindowFacts.Status binder(String name, String descriptor) {
        try {
            Class<?> manager = Class.forName("android.os.ServiceManager");
            Method check = manager.getMethod("checkService",String.class);
            IBinder remote = (IBinder) check.invoke(null, name);
            if (remote == null) return RootWakeWindowFacts.Status.ABSENT;
            if (!remote.pingBinder()) return RootWakeWindowFacts.Status.DEAD;
            return descriptor.equals(remote.getInterfaceDescriptor())
                    ? RootWakeWindowFacts.Status.REACHED : RootWakeWindowFacts.Status.MISMATCH;
        } catch (SecurityException denied) {
            return RootWakeWindowFacts.Status.DENIED;
        } catch (InvocationTargetException wrapped) {
            return wrapped.getCause() instanceof SecurityException
                    ? RootWakeWindowFacts.Status.DENIED : RootWakeWindowFacts.Status.UNKNOWN;
        } catch (ReflectiveOperationException | android.os.RemoteException | LinkageError unavailable) {
            return RootWakeWindowFacts.Status.UNKNOWN;
        }
    }

    private RootWakeWindowFacts.Status permission(String p) {
        try {
            return system.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
                    ? RootWakeWindowFacts.Status.GRANTED : RootWakeWindowFacts.Status.DENIED;
        } catch (RuntimeException unavailable) {
            return RootWakeWindowFacts.Status.UNKNOWN;
        }
    }
}
