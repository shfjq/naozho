package com.naozho.power;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.UserManager;

import com.naozho.power.TrialChecks.Refused;

import java.util.List;
import java.security.MessageDigest;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** Read-only replacements for pm path, dpm list-owners and am get-current-user in the wake daemon. */
final class WakeSystemFacts {
    private static final String CLOCK = WakeBoard.PKG;
    private static final String ADMIN_CLASS = CLOCK + ".display.ClockDeviceAdmin";
    private final Context context;
    // A stalled OEM Binder must not stall the wake or create unbounded blocked threads.
    private final ThreadPoolExecutor binders = new ThreadPoolExecutor(0, 2, 2, TimeUnit.SECONDS,
            new SynchronousQueue<>(), task -> {
                Thread t = new Thread(task, "wake-identity");
                t.setDaemon(true);
                return t;
            });

    WakeSystemFacts(Context context) {
        this.context = context;
    }

    void ownerUser() throws Exception {
        Boolean owner = read(() -> {
            UserManager users = context.getSystemService(UserManager.class);
            if (users == null) return null;
            return users.isSystemUser() && users.isUserForeground();
        });
        if (owner == null) Board.ownerUser();
        else if (!owner) throw new Refused("not_owner_user");
    }

    WakeApkIdentity.Installed clockIdentity(WakeApkIdentity verifier) throws Exception {
        WakeApkIdentity.Installed apk = liveClock();
        verifier.verify(apk);
        // PackageManager may have changed the code path while the hash was read.
        apk.requireSame(liveClock());
        return apk;
    }

    private WakeApkIdentity.Installed liveClock() throws Exception {
        WakeApkIdentity.Installed apk = read(this::managedClock);
        if (apk == null) throw new Refused("apk_identity_unavailable");
        return apk;
    }

    private WakeApkIdentity.Installed managedClock() throws Exception {
        // This Context must describe the system user, as in pm --user 0 and list-owners User 0.
        UserManager users = context.getSystemService(UserManager.class);
        if (users == null || !users.isSystemUser()) return null;
        DevicePolicyManager policy = context.getSystemService(DevicePolicyManager.class);
        if (policy == null) return null;
        if (!policy.isDeviceOwnerApp(CLOCK)) throw new Refused("owner_unconfirmed");
        // isDeviceOwnerApp() alone verifies a package, not its admin component. With ambiguous
        // active admins use the exact user/component result of the existing command.
        List<ComponentName> admins = policy.getActiveAdmins();
        if (admins == null) return null;
        int samePackage = 0;
        boolean exact = false;
        for (ComponentName admin : admins) {
            if (CLOCK.equals(admin.getPackageName())) {
                ++samePackage;
                exact |= ADMIN_CLASS.equals(admin.getClassName());
            }
        }
        if (!uniqueExactAdmin(samePackage, exact) && !DailyBoard.cmd("/system/bin/dpm", "list-owners")
                .matches("(?s).*User\\s+0:\\s+admin=com\\.naozho\\.clock/\\.display\\.ClockDeviceAdmin,DeviceOwner(?:,|\\s|$).*"))
            throw new Refused("owner_unconfirmed");
        PackageManager pm = context.getPackageManager();
        PackageInfo pkg;
        try {
            pkg = pm.getPackageInfo(CLOCK, PackageManager.GET_SIGNING_CERTIFICATES);
        } catch (PackageManager.NameNotFoundException absent) {
            throw new Refused("apk_missing");
        }
        ApplicationInfo info = pkg.applicationInfo;
        if (info == null || !CLOCK.equals(pkg.packageName) || !CLOCK.equals(info.packageName) || !info.enabled ||
                (info.flags & ApplicationInfo.FLAG_INSTALLED) == 0) throw new Refused("apk_unconfirmed");
        if ((info.splitSourceDirs != null && info.splitSourceDirs.length != 0) ||
                (pkg.splitNames != null && pkg.splitNames.length != 0)) throw new Refused("split_apk_unreviewed");
        WakeApkIdentity.checkUid(info.uid, pm.getPackageUid(CLOCK, 0));
        checkReceiver(pm, new ComponentName(CLOCK, ADMIN_CLASS), info.uid,
                "android.permission.BIND_DEVICE_ADMIN", "apk_admin_mismatch");
        checkReceiver(pm, ComponentName.unflattenFromString(TrialChecks.RECEIVER), info.uid,
                "android.permission.STATUS_BAR_SERVICE", "apk_receiver_mismatch");
        Signature[] signers = pkg.signingInfo == null ? null : pkg.signingInfo.getApkContentsSigners();
        if (signers == null || signers.length != 1) throw new Refused("apk_signer_unconfirmed");
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(signers[0].toByteArray());
        StringBuilder cert = new StringBuilder(64);
        for (byte value : hash) cert.append(String.format(java.util.Locale.ROOT, "%02x", value));
        return new WakeApkIdentity.Installed(pkg.packageName, pkg.getLongVersionCode(), pkg.versionName,
                info.sourceDir, cert.toString(), info.uid);
    }

    private static void checkReceiver(PackageManager pm, ComponentName name, int uid, String permission,
            String error) throws Exception {
        ActivityInfo info;
        try {
            info = pm.getReceiverInfo(name, PackageManager.MATCH_DISABLED_COMPONENTS);
        } catch (PackageManager.NameNotFoundException missing) {
            throw new Refused(error);
        }
        int state = pm.getComponentEnabledSetting(name);
        boolean enabled = state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && info.enabled);
        if (!enabled || !info.exported || !CLOCK.equals(info.packageName) || !name.getClassName().equals(info.name) ||
                !permission.equals(info.permission) || info.applicationInfo == null)
            throw new Refused(error);
        WakeApkIdentity.checkUid(uid, info.applicationInfo.uid);
    }

    static boolean uniqueExactAdmin(int samePackage, boolean exact) throws Refused {
        if (!exact || samePackage < 1) throw new Refused("owner_unconfirmed");
        return samePackage == 1;
    }

    // null means the framework read was unavailable. It is never APK identity evidence.
    <T> T read(Callable<T> query) throws Exception {
        Future<T> result;
        try {
            result = binders.submit(query);
        } catch (RejectedExecutionException busy) {
            return null;
        }
        try {
            return result.get(250, TimeUnit.MILLISECONDS);
        } catch (TimeoutException stalled) {
            return null;
        } catch (ExecutionException failed) {
            Throwable cause = failed.getCause();
            if (cause instanceof RuntimeException || cause instanceof PackageManager.NameNotFoundException) return null;
            if (cause instanceof Exception) throw (Exception)cause;
            throw new Refused("identity_read_failed");
        } finally {
            result.cancel(true);
        }
    }
}
