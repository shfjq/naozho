package com.naozho.power;

/** Report observations separately from availability of a safely scoped input+display integration. */
final class RootWakeWindowFacts {
    enum Status { REACHED, ABSENT, DEAD, MISMATCH, UNKNOWN, GRANTED, DENIED }
    private final boolean root;
    private final Status wm, composer, aidl, internal, alert;
    RootWakeWindowFacts(boolean root, Status wm, Status composer, Status aidl, Status internal, Status alert) {
        this.root = root; this.wm = wm; this.composer = composer; this.aidl = aidl;
        this.internal = internal; this.alert = alert;
    }

    String diagnostic() {
        return "WINDOW_CAPABILITY uid=" + (root ? "root" : "other") + " wm=" + wm +
                " sf=" + composer + " sf_aidl=" + aidl + " internal_perm=" + internal + " alert_perm=" + alert;
    }

    String reason() {
        if (!root) return "window_not_root";
        if (wm != Status.REACHED) return "window_binder_unconfirmed";
        if (composer != Status.REACHED && aidl != Status.REACHED) return "composer_binder_unconfirmed";
        return "stock_no_source_window_attachment";
    }
}
