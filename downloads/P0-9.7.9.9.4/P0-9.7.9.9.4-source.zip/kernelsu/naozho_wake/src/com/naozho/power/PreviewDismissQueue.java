package com.naozho.power;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Best-effort removal of a launcher-hosted preview. This path can only hide pixels. */
final class PreviewDismissQueue implements AutoCloseable {
    private static final String ACTION = "com.naozho.clock.action.WAKE_PREVIEW_DISMISS";
    private static final Path BOUND = Paths.get("/data/user_de/0/com.naozho.clock/files/wake-preview-widget.present");

    interface Sender { void hide(int boot, long dark) throws Exception; }

    private final ExecutorService worker = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "wake-preview-dismiss");
        thread.setDaemon(true);
        return thread;
    });
    private final Sender sender;
    private int pendingBoot = -1;
    private long pendingDark = -1;
    private long latestDark = -1;
    private boolean running;
    private boolean closed;

    PreviewDismissQueue() {
        this((boot, dark) -> {
            // An absent launcher widget cannot receive a new preview. App-side expiry,
            // screen-off and mode listeners are independent of this optional transport.
            if (!Files.isRegularFile(BOUND)) return;
            Board.dispatch(envelope(boot, dark));
        });
    }

    PreviewDismissQueue(Sender sender) { this.sender = sender; }

    static String[] envelope(int boot, long dark) {
        return DeliveryProof.envelope(ACTION, "dismiss." + boot + "." + dark,
                "--ei", "boot_count", Integer.toString(boot),
                "--el", "dark_elapsed", Long.toString(dark));
    }

    void afterReturn(int boot, long dark, String outcome) {
        // This process proves foreground focus and device policy. Only the
        // Activity's renderer knows whether its content frame has been committed.
        if (!"CLOCK_FOCUSED".equals(outcome)) dismiss(boot, dark);
    }

    /** Enables stop.sh to revoke the last arm even after a daemon crash. Never grants a return. */
    static void remember(Path directory, int boot, long dark) {
        if (boot < 0 || dark < 0 || !Files.isRegularFile(BOUND)) return;
        try {
            Path tmp = directory.resolve("preview-dark.tmp");
            Files.write(tmp, (boot + " " + dark + "\n").getBytes(StandardCharsets.US_ASCII));
            Files.move(tmp, directory.resolve("preview-dark"), StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            WakeDaemon.record("PREVIEW_STOP_MARKER_UNAVAILABLE");
        }
    }

    synchronized void dismiss(int boot, long dark) {
        // A daemon has exactly one boot. Older callbacks cannot cancel a newer preview.
        if (closed || boot < 0 || dark < 0 || dark <= latestDark) return;
        latestDark = dark;
        pendingBoot = boot;
        pendingDark = dark;
        if (!running) {
            running = true;
            worker.execute(this::drain);
        }
    }

    private void drain() {
        while (true) {
            int boot;
            long dark;
            synchronized (this) {
                if (pendingDark < 0) { running = false; return; }
                boot = pendingBoot;
                dark = pendingDark;
                pendingDark = -1;
            }
            try { sender.hide(boot, dark); }
            catch (Exception e) {
                WakeDaemon.record("PREVIEW_DISMISS_UNCONFIRMED boot=" + boot + " dark=" + dark);
            }
        }
    }

    @Override public void close() {
        synchronized (this) { closed = true; worker.shutdown(); }
        // Only shutdown waits. Display callbacks and the formal return never wait on am.
        try {
            if (!worker.awaitTermination(800, TimeUnit.MILLISECONDS)) worker.shutdownNow();
        } catch (InterruptedException e) {
            worker.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
