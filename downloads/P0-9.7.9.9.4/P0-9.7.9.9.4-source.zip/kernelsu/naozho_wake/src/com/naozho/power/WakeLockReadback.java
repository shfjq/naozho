package com.naozho.power;

/** A private alias may label the ActivityRecord while WMS labels the window with its target. */
final class WakeLockReadback {
    private static boolean clock(String component) throws TrialChecks.Refused {
        String canonical = Foreground.canonical(component);
        return canonical.equals("com.naozho.clock/com.naozho.clock.MainActivity") ||
                canonical.equals("com.naozho.clock/com.naozho.clock.mode.PowerClockEntry");
    }
    static boolean focused(String display) throws TrialChecks.Refused {
        String window = TrialChecks.focus(display);
        String activity = TrialChecks.one(display,
                "^ *mFocusedApp=ActivityRecord\\{[^\\s{}]+ u0 ([^\\s{}]+) t[0-9]+[^{}]*\\} *$", "focused_app_unknown");
        return clock(window) && clock(activity);
    }
    static boolean locked() throws Exception {
        return "LOCKED".equals(DailyBoard.filtered(
                "dumpsys activity activities | sed -nE 's/^ *mLockTaskModeState=(LOCK_TASK_MODE_)?([A-Z]+)$/\\2/p'"));
    }
}
