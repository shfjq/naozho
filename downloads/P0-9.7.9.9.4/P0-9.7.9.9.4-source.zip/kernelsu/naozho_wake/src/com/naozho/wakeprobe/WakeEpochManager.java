package com.naozho.wakeprobe;

/** Display callbacks own this state on a single Looper. Uptime and elapsed time serve different clocks. */
public final class WakeEpochManager {
    private final WakeCycle cycle;
    private final String bootId;
    private String classification = "INITIAL";
    public String classification() { return classification; }
    private long darkElapsed = -1;
    public WakeEpochManager(int count, String bootId) {
        this.bootId = bootId;
        cycle = new WakeCycle(count, bootId);
    }

    public String observe(int state, boolean interactive, long uptime, long elapsed) {
        boolean started = cycle.darkStart < 0;
        String event = cycle.observe(state, interactive, uptime);
        if (started && cycle.darkStart >= 0) darkElapsed = elapsed;
        return event;
    }

    public static final class Epoch {
        public final long dark, sequence, event, wakeUptime;
        public final String id;
        Epoch(String boot, long dark, long sequence, long event, long wakeUptime) {
            this.dark = dark; this.sequence = sequence; this.event = event; this.wakeUptime = wakeUptime;
            id = boot + "/" + dark + "/" + sequence;
        }
    }

    /** Preserve the exact same evidence fields and parser for both transports. */
    public static final class Sample {
        final PowerEvidence evidence;
        public final String source;
        private Sample(PowerEvidence evidence, String source) {
            this.evidence = evidence;
            this.source = source;
        }
        static Sample proto(PowerEvidence evidence) { return new Sample(evidence, "binder_proto"); }
        static Sample binder(PowerEvidence evidence) { return new Sample(evidence, "binder"); }
        public static Sample parse(String dump) { return new Sample(PowerEvidence.parse(dump), "dumpsys"); }
        public static Sample unavailable(String reason) { return new Sample(PowerEvidence.unknown(reason), "unavailable"); }
        public boolean stillAwake(Epoch epoch) {
            return evidence.error == null && !evidence.changing && "Awake".equals(evidence.wakefulness)
                    && evidence.wake == epoch.wakeUptime && evidence.sleep < evidence.wake;
        }
    }

    @FunctionalInterface
    interface SampleSource { Sample read() throws Exception; }

    static final class PowerSources {
        private final SampleSource binder, fallback;
        private volatile boolean tryBinder = true;
        PowerSources(SampleSource binder, SampleSource fallback) {
            this.binder = binder;
            this.fallback = fallback;
        }
        Sample read() throws Exception {
            if (tryBinder) {
                Sample sample = binder.read();
                if (sample.evidence.error == null || "unsupported_power_groups".equals(sample.evidence.error)) return sample;
                // Two legitimate consumers can briefly overlap. The busy caller uses its
                // own fresh diagnostic, while a platform denial/timeout selects the old
                // transport for the rest of this process. Never reuse an earlier sample.
                if (!"binder_busy".equals(sample.evidence.error)) tryBinder = false;
            }
            return fallback.read();
        }
    }

    /** Owner is the display Looper. A previous request must finish (including receipt
     * cleanup) before another can send. At most one still-current successor is retained. */
    public static final class Handoffs {
        private boolean active;
        private long lastSequence;
        private int pendingRevision;
        private Epoch pending;
        public Epoch offer(Epoch epoch, int revision) {
            if (epoch.sequence <= lastSequence) return null;
            lastSequence = epoch.sequence;
            if (active) {
                pending = epoch;
                pendingRevision = revision;
                return null;
            }
            active = true;
            return epoch;
        }
        public Epoch completed(int currentRevision) {
            Epoch next = pendingRevision == currentRevision ? pending : null;
            pending = null;
            active = next != null;
            return next;
        }
    }

    public Epoch settle(String powerDump, long up, long elapsed, boolean last) {
        return settle(Sample.parse(powerDump), up, elapsed, last, elapsed);
    }

    public Epoch settle(Sample sample, long up, long elapsed, boolean last, long onEdgeElapsed) {
        boolean expired = onEdgeElapsed < 0 || elapsed < onEdgeElapsed || elapsed - onEdgeElapsed > 3000;
        PowerEvidence evidence = expired ? PowerEvidence.unknown("sample_expired") : sample.evidence;
        classification = cycle.verify(evidence, up, last || expired);
        if (!"FULL_WAKE".equals(classification)) return null;
        return new Epoch(bootId, darkElapsed, cycle.count, elapsed, evidence.wake);
    }
    public long darkElapsed() { return cycle.darkStart >= 0 ? darkElapsed : -1; }
    public boolean waiting() { return cycle.waiting; }
    public int revision() { return cycle.revision; }
    public int display() { return cycle.display; }
    public String phase() { return cycle.phase; }
    public void reset() { cycle.invalidate(); darkElapsed = -1; }

    public static boolean stillAwake(String dump, Epoch epoch) {
        return Sample.parse(dump).stillAwake(epoch);
    }
}
