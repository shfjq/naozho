package com.naozho.power;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.function.LongSupplier;

/** One read-only leading focus sample. The window inventory and trailing focus are always live. */
final class WakeFocusSeed {
    private static final long MAX_AGE_MS = 200;
    private final LongSupplier clock;
    private long dark = -1;
    private long started;
    private FutureTask<String> task;

    WakeFocusSeed(LongSupplier clock) { this.clock = clock; }

    synchronized void prepare(long edge, Callable<String> read) {
        if (edge < 0 || dark == edge) return;
        cancel();
        dark = edge;
        started = clock.getAsLong();
        task = new FutureTask<>(read);
        Thread worker = new Thread(task, "wake-leading-focus");
        worker.setDaemon(true);
        worker.start();
    }

    private boolean recent(long now) { return now >= started && now - started <= MAX_AGE_MS; }

    synchronized String take(long edge) throws InterruptedException {
        if (edge != dark || task == null) return null;
        try {
            // A seed is an optimization only. Do not wait for a busy WMS, and never
            // reuse a prewake or previous-epoch sample just because focus looks similar.
            if (!task.isDone() || !recent(clock.getAsLong()) || task.isCancelled()) return null;
            try { return task.get(); }
            catch (java.util.concurrent.ExecutionException | java.util.concurrent.CancellationException unavailable) {
                return null;
            }
        } finally { cancel(); }
    }

    synchronized void cancel() {
        if (task != null) task.cancel(true);
        dark = -1;
        task = null;
    }
}
