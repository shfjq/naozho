package com.naozho.power;

import com.naozho.power.TrialChecks.Refused;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/** Streaming equivalent of the existing focus-field projection; only matching complete rows escape. */
final class WakeFocusProjection {
    private final ByteArrayOutputStream line = new ByteArrayOutputStream(256);
    private final StringBuilder rows = new StringBuilder();

    void append(byte[] bytes, int count) throws Refused {
        for (int i = 0, start = 0; i <= count; i++) {
            if (i != count && bytes[i] != '\n') continue;
            if (i - start + line.size() > 64*1024) throw new Refused("window_binder_line_size");
            line.write(bytes,start,i-start);
            if (i == count) break;
            flush();
            start = i+1;
        }
    }

    private void flush() throws Refused {
        String text = new String(line.toByteArray(), StandardCharsets.UTF_8).trim();
        line.reset();
        if (text.startsWith("Permission Denial") || text.startsWith("DUMP TIMEOUT") || text.startsWith("DUMP FAILED"))
            throw new Refused("window_binder_incomplete");
        if (text.startsWith("mCurrentFocus=") || text.startsWith("mFocusedApp=")) {
            if (text.length() + rows.length() > 8192) throw new Refused("window_binder_focus_size");
            rows.append(text).append('\n');
        }
    }

    String finish() throws Refused { if (line.size() > 0) flush(); return rows.toString().trim(); }
}
