package com.naozho.power;

import static com.naozho.power.RootWakeWindowFacts.Status.*;

public class RootWakeWindowFactsTest {
    static void expect(String want, String got) {
        if (!want.equals(got)) throw new AssertionError(got);
    }
    public static void main(String[] args) {
        expect("window_not_root", new RootWakeWindowFacts(false, REACHED, REACHED, REACHED, GRANTED, GRANTED).reason());
        for (RootWakeWindowFacts.Status missing : new RootWakeWindowFacts.Status[]{ABSENT, DEAD, MISMATCH, UNKNOWN, DENIED}) {
            expect("window_binder_unconfirmed", new RootWakeWindowFacts(true,missing,REACHED,REACHED,GRANTED,GRANTED).reason());
            expect("composer_binder_unconfirmed", new RootWakeWindowFacts(true,REACHED,missing,ABSENT,DENIED,DENIED).reason());
        }
        for (RootWakeWindowFacts.Status coarse : new RootWakeWindowFacts.Status[]{GRANTED,DENIED,UNKNOWN}) {
            expect("stock_no_source_window_attachment", new RootWakeWindowFacts(true,REACHED,REACHED,ABSENT,coarse,coarse).reason());
            expect("stock_no_source_window_attachment", new RootWakeWindowFacts(true,REACHED,MISMATCH,REACHED,coarse,coarse).reason());
        }
        expect("WINDOW_CAPABILITY uid=root wm=REACHED sf=ABSENT sf_aidl=REACHED internal_perm=GRANTED alert_perm=DENIED",
                new RootWakeWindowFacts(true,REACHED,ABSENT,REACHED,GRANTED,DENIED).diagnostic());
        System.out.println("RootWakeWindowFactsTest: 18 capability assertions passed");
    }
}
