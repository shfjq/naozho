package com.naozho.wakeprobe;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.Objects;

public final class PowerFastPathTest {
    private static int assertions;
    private static void equal(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError(expected + " != " + actual);
        assertions++;
    }
    // Independent wire fixture builder. Same numeric tags as the verified firmware DEX.
    private static byte[] bytes(int... values) {
        byte[] result = new byte[values.length];
        for (int i=0;i<values.length;i++) result[i] = (byte)values[i];
        return result;
    }
    private static byte[] concat(byte[]... pieces) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (byte[] part:pieces) out.write(part,0,part.length);
        return out.toByteArray();
    }
    private static byte[] wake = bytes(0x18,1), changing = bytes(0x20,1);
    // Repeated group message has groupId=0 omitted by ProtoOutputStream. Last user interaction=19.
    private static byte[] group = bytes(0xa2,1,2,0x20,19), history=bytes(0xe8,1,100,0xf0,1,90);
    private static byte[] tail=bytes(0xf2,2,2,0x10,7);
    private static byte[] sample(byte[] state, byte[] groups, byte[] times) {
        return concat(state,groups,times,tail);
    }
    private static WakeEpochManager.Epoch epoch() {
        WakeEpochManager manager = new WakeEpochManager(4, "boot");
        manager.observe(2,true,70,70); manager.observe(1,false,95,95); manager.observe(2,true,110,110);
        return manager.settle(WakeEpochManager.Sample.proto(PowerProto.parse(sample(wake,group,history))),
                              111,111,true,110);
    }
    private static void power() throws Exception {
        byte[] full = sample(wake,group,history);
        PowerEvidence fast = PowerProto.parse(full);
        PowerEvidence text = PowerEvidence.parse("mWakefulness=Awake\nmWakefulnessChanging=false\n"+
            "displayGroupId=0\nmLastWakeTime=100\nmLastSleepTime=90");
        equal(null, fast.error); equal(text.wakefulness,fast.wakefulness);
        equal(text.changing,fast.changing); equal(text.wake,fast.wake); equal(text.sleep,fast.sleep);
        WakeEpochManager.Epoch epoch=epoch();
        equal(true, epoch != null);
        equal(true, WakeEpochManager.Sample.proto(fast).stillAwake(epoch));
        for (byte[] state : new byte[][]{bytes(),bytes(0x18,2),bytes(0x18,3),concat(wake,changing)}) {
            PowerEvidence stateProof=PowerProto.parse(sample(state,group,history));
            equal(null,stateProof.error);
            equal(false,WakeEpochManager.Sample.proto(stateProof).stillAwake(epoch));
        }
        for (byte[] bad : new byte[][]{bytes(),Arrays.copyOf(full,full.length-1),
                concat(wake,group,history),sample(wake,group,bytes()),sample(wake,bytes(),history),
                sample(concat(wake,wake),group,history),sample(wake,group,concat(history,history)),
                sample(bytes(0x18,4),group,history),sample(bytes(0x20,2),group,history),
                concat(full,bytes(0x92,3,0x85,1,0)), concat(full,bytes(0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xfe)),
                concat(full,bytes(0)), new byte[256*1024+1]}) {
            equal(true,PowerProto.parse(bad).error!=null);
        }
        for(byte[] groups : new byte[][]{concat(group,group),bytes(0xa2,1,2,0x30,1)}) {
            WakeEpochManager.PowerSources sources=new WakeEpochManager.PowerSources(
                ()->WakeEpochManager.Sample.proto(PowerProto.parse(sample(wake,groups,history))),
                ()->{throw new AssertionError("must not retry valid nondefault/multiple groups");});
            equal(false,sources.read().stillAwake(epoch));
        }
        // Textual fallback is independent and parsed normally if the source does not implement
        // this proto contract. A contradictory fresh text sample cannot manufacture a return.
        WakeEpochManager.PowerSources fallback=new WakeEpochManager.PowerSources(
            ()->WakeEpochManager.Sample.proto(PowerProto.parse(bytes(0xf2,2))),
            ()->WakeEpochManager.Sample.binder(PowerEvidence.parse("mWakefulness=Dreaming\nmWakefulnessChanging=false\n"+
                "displayGroupId=0\nmLastWakeTime=100\nmLastSleepTime=90")));
        equal(false,fallback.read().stillAwake(epoch));
    }
    private static void schedule() {
        equal(0, PowerSampleSchedule.dueAttempt(0,0));
        equal(35L, PowerSampleSchedule.nextDelay(0,25));
        equal(0L, PowerSampleSchedule.nextDelay(0,350));
        equal(2, PowerSampleSchedule.dueAttempt(1,350));
        equal(5L, PowerSampleSchedule.nextDelay(2,395));
        equal(4, PowerSampleSchedule.dueAttempt(1,849));
        equal(false, PowerSampleSchedule.last(4));
        equal(true, PowerSampleSchedule.last(PowerSampleSchedule.dueAttempt(1,6000)));
    }
    public static void main(String[] args) throws Exception {
        power(); schedule();
        System.out.println("wake power proto and edge-relative sampling assertions passed=" + assertions);
    }
}
