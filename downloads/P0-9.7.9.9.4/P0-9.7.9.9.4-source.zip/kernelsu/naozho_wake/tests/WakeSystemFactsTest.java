package com.naozho.power;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;

public final class WakeSystemFactsTest {
    private static void require(boolean ok) {
        if (!ok) throw new AssertionError();
    }
    private static void refuses(String why, DailyBoard.Check action) throws Exception {
        try { action.run(); } catch (TrialChecks.Refused refusal) {
            require(why.equals(refusal.getMessage()));
            return;
        }
        throw new AssertionError("expected " + why);
    }

    public static void main(String[] args) throws Exception {
        WakeSystemFacts facts = new WakeSystemFacts(null);
        require(Boolean.TRUE.equals(facts.read(() -> true)));
        require(Boolean.FALSE.equals(facts.read(() -> false))); // definite negative remains negative
        require(facts.read(() -> { throw new SecurityException("OEM denial"); }) == null);
        CountDownLatch neverReleased = new CountDownLatch(1);
        require(facts.read(() -> { neverReleased.await(); return true; }) == null); // timeout selects fallback
        refuses("owner_unconfirmed", () -> facts.read(() -> { throw new TrialChecks.Refused("owner_unconfirmed"); }));
        require(WakeSystemFacts.uniqueExactAdmin(1, true));
        require(!WakeSystemFacts.uniqueExactAdmin(2, true)); // query exact Owner component via dpm
        refuses("owner_unconfirmed", () -> WakeSystemFacts.uniqueExactAdmin(1, false));

        DailyBoard board = new DailyBoard();
        Path dir = Files.createTempDirectory("wake-apk-pin");
        Path base = dir.resolve("base.apk");
        try {
            Files.write(base, "sample".getBytes(StandardCharsets.UTF_8));
            String pinned = DailyBoard.sha(base);
            board.verifyBase(WakeBoard.PKG, base.toString(), pinned);
            refuses("apk_changed", () -> board.verifyBase(WakeBoard.PKG, base.toString(), "0".repeat(64)));
            refuses("apk_unconfirmed", () -> board.verifyBase(WakeBoard.PKG, "relative/base.apk", pinned));
        } finally {
            Files.deleteIfExists(base);
            Files.delete(dir);
        }
        System.out.println("WakeSystemFacts: bounded reads, definitive refusal, component identity and APK pin passed");
    }
}
