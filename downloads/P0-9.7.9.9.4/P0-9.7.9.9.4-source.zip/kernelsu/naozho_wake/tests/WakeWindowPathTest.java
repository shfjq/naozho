package com.naozho.power;

import com.naozho.power.TrialChecks.Refused;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public final class WakeWindowPathTest {
    private static final String APP = "com.droiclaw.launcher3/com.freeme.launcher.FreemeLauncher";
    private static final String ROWS = "mCurrentFocus=Window{a12 u0 " + APP +
        "}\nmFocusedApp=ActivityRecord{b177 u0 " + APP + " t7}";
    private static int count;
    private static void check(boolean value) { if (!value) throw new AssertionError(); count++; }
    private interface Action { void run() throws Exception; }
    private static void veto(Action action, String reason) throws Exception {
        try { action.run(); throw new AssertionError("missing refusal " + reason); }
        catch (Refused refused) { check(reason.equals(refused.getMessage())); }
    }

    private static String project(String input, int chunk) throws Exception {
        WakeFocusProjection filter = new WakeFocusProjection();
        byte[] bytes = input.getBytes(StandardCharsets.UTF_8);
        for (int i = 0; i < bytes.length ; i += chunk) {
            byte[] part = java.util.Arrays.copyOfRange(bytes, i, Math.min(i+chunk,bytes.length));
            filter.append(part,part.length);
        }
        return filter.finish();
    }
    static void prepared(WakeFocusSeed seed, long dark, Callable<String> sample) throws Exception {
        AtomicReference<Thread> worker = new AtomicReference<>();
        CountDownLatch started = new CountDownLatch(1);
        seed.prepare(dark, () -> {
            worker.set(Thread.currentThread()); started.countDown(); return sample.call();
        });
        check(started.await(2,TimeUnit.SECONDS));
        worker.get().join(2000);
        check(!worker.get().isAlive());
    }
    public static void main(String[] args) throws Exception {
        String input = "dump header\r\n  private field=secret\r\n  " +
                ROWS.replace("\n", "\r\n\t") + "\r\nother text";
        for (int chunk : new int[]{1,2,5,32,4096}) check(ROWS.equals(project(input,chunk)));
        check("".equals(project("      irrelevant mCurrentFocus=no\n", 2)));
        check(Foreground.focus(project(input,2)).equals(APP));
        veto(() -> Foreground.focus(project(input+"\n"+ROWS,5)), "foreground_unknown");
        veto(() -> Foreground.confirmFocus(APP,"a12",project(input.replace("a12","b19"),17)), "focus_transition");
        veto(() -> project(input+"\nDUMP FAILED after partial valid rows",2), "window_binder_incomplete");
        veto(() -> project("Permission Denial: DUMP restricted",2), "window_binder_incomplete");
        veto(() -> project("x".repeat(65537),4096), "window_binder_line_size");
        WakeFocusSeed seed;
        AtomicLong now = new AtomicLong(10);
        seed = new WakeFocusSeed(now::get);
        prepared(seed, 1, () -> ROWS);
        check(seed.take(0)==null);
        now.addAndGet(200);
        check(ROWS.equals(seed.take(1))); check(seed.take(1)==null);
        prepared(seed,2,() -> ROWS);
        now.addAndGet(201); check(seed.take(2)==null);
        prepared(seed,3,() -> ROWS); seed.cancel(); check(seed.take(3)==null);
        prepared(seed,4,() -> { throw new Refused("focus_transition"); }); check(seed.take(4)==null);
        prepared(seed,5,() -> ROWS); now.decrementAndGet(); check(seed.take(5)==null);
        CountDownLatch active = new CountDownLatch(1), stopped = new CountDownLatch(1);
        seed.prepare(6,() -> {
            active.countDown();
            try { new CountDownLatch(1).await(); return ROWS; }
            finally { stopped.countDown(); }
        });
        check(active.await(2,TimeUnit.SECONDS));
        // The real wake continues immediately and cancels an unfinished read.
        check(seed.take(6)==null); check(stopped.await(2,TimeUnit.SECONDS));
        int[] lookups = {0,0}, fallbacks = {0,0};
        DailyBoard.WindowSource shell = new DailyBoard.WindowSource() {
            public String focus() { fallbacks[0]++; return ROWS; }
            public Foreground.Windows visible(String id) { fallbacks[1]++; return VisibleWindowDump.readFailure("shell_called"); }
        };
        WakeWindowReader reader = new WakeWindowReader(focus -> {
            if (focus) { lookups[0]++; return null; }
            lookups[1]++;
            return "WINDOW MANAGER WINDOWS (dumpsys window windows)\nDUMP FAILED";
        }, shell);
        check(ROWS.equals(reader.focus()));
        check(ROWS.equals(reader.focus()) && lookups[0]==1 && fallbacks[0]==2);
        check("window_command_incomplete".equals(reader.visible("a12").veto));
        check("window_command_incomplete".equals(reader.visible("a12").veto));
        check(lookups[1]==2 && fallbacks[1]==0);
        check(reader.guardSources().equals(" wm_focus=shell wm_visible=binder"));
        WakeWindowReader denied = new WakeWindowReader(focus -> {throw new Refused("policy_denial");}, shell);
        veto(denied::focus,"policy_denial");
        check(fallbacks[0]==2);
        WakeWindowReader direct = new WakeWindowReader(focus -> focus ? ROWS : null,shell);
        check(ROWS.equals(direct.focus()));
        check("shell_called".equals(direct.visible("a12").veto));
        check(direct.guardSources().equals(" wm_focus=binder wm_visible=shell"));
        System.out.println("Wake window transport/projection/lease assertions passed="+count);
    }
}
