package com.naozho.power;

import java.util.ArrayList;
import java.util.List;

public final class WakePresentationTest {
    static void check(boolean expected) { if (!expected) throw new AssertionError(); }
    public static void main(String[] args) {
        List<String> events = new ArrayList<>();
        WakePresentationAudit trace = new WakePresentationAudit(37, events::add);
        trace.verified(10, "unobserved");
        trace.edge(10, "off");
        trace.edge(10, "full");
        trace.capability("wm_no_safe_source_parent");
        trace.verified(10, "first");
        trace.verified(10, "duplicate");
        trace.edge(12, "full"); // FULL_WAKE from DOZE may lack an OFF preflight.
        trace.edge(11, "off");
        trace.verified(10, "obsolete");
        trace.verified(12, "second");
        trace.capability("denied for private package");
        check(events.size() == 6);
        check(events.get(0).contains("reason=mask_probe_pending"));
        check(events.get(2).equals("HANDOFF_COMPLETE boot=37 dark=10 request=first mask=not_submitted"));
        check(events.get(3).equals("MASK_REFUSED_AT boot=37 dark=12 phase=full reason=wm_no_safe_source_parent"));
        check(events.get(4).contains("request=second mask=not_submitted"));
        check(events.get(5).endsWith("reason=mask_probe_unavailable"));
        check(events.stream().noneMatch(s -> s.contains("MASK_VISIBLE") || s.contains("MASK_RELEASED") || s.contains("private")));
        System.out.println("PASS window capability / formal handoff separation, deduplication, stale generations and fail-open diagnostics");
    }
}
