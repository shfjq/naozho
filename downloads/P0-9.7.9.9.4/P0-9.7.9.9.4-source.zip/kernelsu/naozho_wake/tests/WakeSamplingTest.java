package com.naozho.wakeprobe;

import java.util.Objects;

/** Deterministic timing, transport and handoff tests against the production epoch manager. */
public final class WakeSamplingTest {
    private static int checks;
    private static void expect(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError(actual + " expected " + expected);
        checks++;
    }

    private static String dump(String state, boolean changing, int wake) {
        return "mWakefulness=" + state + "\nmWakefulnessChanging=" + changing +
            "\ndisplayGroupId=0\nmLastSleepTime=150\nmLastWakeTime=" + wake + "\n";
    }

    private static WakeEpochManager candidate() {
        WakeEpochManager manager = new WakeEpochManager(38, "boot");
        manager.observe(2, true, 100, 100);
        manager.observe(1, false, 160, 160);
        manager.observe(2, true, 200, 201);
        return manager;
    }
    private static WakeEpochManager.Epoch handoff(long n) {
        return new WakeEpochManager.Epoch("boot", 1000*n, n, 1000*n+300, 300);
    }

    private static void transportTests() throws Exception {
        int[] calls = {0, 0};
        WakeEpochManager.PowerSources denied = new WakeEpochManager.PowerSources(
            () -> { calls[0]++; return WakeEpochManager.Sample.unavailable("power_dump_denied"); },
            () -> WakeEpochManager.Sample.parse(dump(++calls[1]==1 ? "Awake" : "Asleep", false, 190)));
        WakeEpochManager.Sample fallback = denied.read();
        WakeEpochManager.Epoch first = candidate().settle(fallback, 201, 201, true, 201);
        expect("dumpsys", fallback.source);
        expect(true, first != null);
        expect(false, denied.read().stillAwake(first));
        expect(1, calls[0]);
        expect(2, calls[1]);

        int[] reads = {0};
        WakeEpochManager.PowerSources busy = new WakeEpochManager.PowerSources(
            () -> ++reads[0]==1 ? WakeEpochManager.Sample.unavailable("binder_busy") :
                WakeEpochManager.Sample.binder(PowerEvidence.parse(dump("Awake", false, 190))),
            () -> WakeEpochManager.Sample.unavailable("power_read_failed"));
        expect(false, busy.read().stillAwake(first));
        expect("binder", busy.read().source);
        expect(2, reads[0]);
        // A complete negative sample must never get another chance via the fallback.
        for (String state : new String[]{"Asleep", "Dreaming", "Dozing", "Awake"}) {
            WakeEpochManager.PowerSources changing = new WakeEpochManager.PowerSources(
                () -> WakeEpochManager.Sample.binder(PowerEvidence.parse(dump(state, state.equals("Awake"), 190))),
                () -> { throw new AssertionError("retried valid power state"); });
            expect(false, changing.read().stillAwake(first));
        }
        WakeEpochManager.PowerSources invalid = new WakeEpochManager.PowerSources(
            () -> WakeEpochManager.Sample.binder(PowerEvidence.parse("power service unavailable")),
            () -> WakeEpochManager.Sample.parse("power service unavailable"));
        expect(null, candidate().settle(invalid.read(), 202, 202, true, 201));
    }

    private static void deadlineTests() {
        WakeEpochManager.Sample proof = WakeEpochManager.Sample.parse(dump("Awake", false, 190));
        expect(true, candidate().settle(proof,3201,3201,false,201) != null);
        WakeEpochManager late = candidate();
        expect(null, late.settle(proof,3202,3202,false,201));
        expect("REFUSED_sample_expired",late.classification());
        expect(false, late.waiting());
        expect(null,candidate().settle(proof,200,200,false,201));
        expect(null,candidate().settle(proof,201,201,false,-1));
    }

    private static void serialHandoffs() {
        WakeEpochManager.Handoffs handoffs = new WakeEpochManager.Handoffs();
        WakeEpochManager.Epoch a=handoff(1), b=handoff(2), c=handoff(3), d=handoff(4), e=handoff(5);
        expect(a, handoffs.offer(a,1));
        expect(null, handoffs.offer(b,2));
        expect(null, handoffs.offer(c,3));
        expect(null, handoffs.offer(b,2));
        expect(c, handoffs.completed(3));
        expect(null, handoffs.offer(c,3));
        expect(null, handoffs.offer(d,4));
        // Pause, display removal or another OFF invalidates the waiting generation.
        expect(null, handoffs.completed(5));
        expect(null, handoffs.offer(d,4));
        expect(e, handoffs.offer(e,7));
        expect(null, handoffs.completed(7));
    }
    public static void main(String[] args) throws Exception {
        transportTests();
        deadlineTests();
        serialHandoffs();
        System.out.println("wake sampling and supersession assertions passed=" + checks);
    }
}
