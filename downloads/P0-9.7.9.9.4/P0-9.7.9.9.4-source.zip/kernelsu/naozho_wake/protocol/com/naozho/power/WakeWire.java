package com.naozho.power;

import java.util.Arrays;

/** User-zero, elapsed-realtime wire schema. The formal and commit traces are independently provable. */
public final class WakeWire {
    private final int boot, uid;
    private final long dark, sequence, event;
    public final long expires;
    private final String bootId, id;

    public WakeWire(int boot, String bootId, long dark, long sequence, long event, int uid, String id) {
        this.boot = boot; this.bootId = bootId; this.dark = dark; this.sequence = sequence;
        this.event = event; this.expires = event + 12_000; this.uid = uid; this.id = id;
    }
    private String epoch() { return bootId + "/" + dark + "/" + sequence; }
    public String receipt() { return id + "|" + boot + "|" + epoch() + "|" + event + "|" + expires + "|" + uid; }
    public String trace(String verb) {
        if ("RETURN".equals(verb)) return id;
        if ("COMMIT".equals(verb)) return id + ".commit";
        throw new IllegalArgumentException("unsupported wake verb");
    }
    // Linux uid 0 issues a normal ATM request. The existing non-exported alias belongs only
    // to the clock task. No caller-supplied destination, force-stop, clear-task or input command.
    public String[] startCommand() {
        String[] prefix = {"/system/bin/cmd", "activity", "start-activity", "--user", "0",
                "-a", "com.naozho.clock.action.WAKE_EPOCH_RETURN",
                "-n", "com.naozho.clock/.mode.PowerClockEntry", "-f", "0x10010000"};
        String[] fields = extras();
        String[] cmd = Arrays.copyOf(prefix, prefix.length + fields.length);
        System.arraycopy(fields, 0, cmd, prefix.length, fields.length);
        return cmd;
    }

    /** The Android command sometimes reports a start error on stdout with exit code zero. */
    public static boolean startReported(String output) {
        String[] lines = output.trim().split("\\R");
        if (lines.length == 0 || !lines[0].startsWith("Starting: Intent { ") ||
                !lines[0].contains("act=com.naozho.clock.action.WAKE_EPOCH_RETURN ") ||
                !(lines[0].contains("cmp=com.naozho.clock/.mode.PowerClockEntry ") ||
                  lines[0].contains("cmp=com.naozho.clock/com.naozho.clock.mode.PowerClockEntry "))) return false;
        return lines.length == 1 || (lines.length == 2 &&
                (lines[1].equals("Warning: Activity not started, intent has been delivered to currently running top-most instance.") ||
                 lines[1].equals("Warning: Activity not started, its current task has been brought to the front")));
    }

    public String[] extras() {
        return new String[]{"--ei","boot_count",Integer.toString(boot),"--es","boot_id",bootId,
                "--el","dark_elapsed",Long.toString(dark),"--el","event_timestamp",Long.toString(event),
                "--el","expiry",Long.toString(expires),"--el","sequence",Long.toString(sequence),
                "--es","request_id",id,"--ei","sender_uid",Integer.toString(uid),
                "--es","source","DISPLAY_FULL_WAKE","--es","wake_epoch_id",epoch()};
    }
}
