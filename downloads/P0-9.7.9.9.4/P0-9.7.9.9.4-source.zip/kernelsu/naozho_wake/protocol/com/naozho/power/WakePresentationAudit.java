package com.naozho.power;

import java.util.function.Consumer;

/** Reports the CPDAY10 visual capability separately from a verified formal handoff.
 * An ATM starting window belongs to Android. No independent overlay can be marked shown or removed. */
final class WakePresentationAudit {
    private final int boot;
    private final Consumer<String> journal;
    private volatile String reason = "mask_probe_pending";
    private long recent = -1;
    private long completed = -1;

    WakePresentationAudit(int boot, Consumer<String> journal) {
        this.boot = boot;
        this.journal = journal;
    }
    void capability(String result) {
        reason = result != null && result.matches("[a-z_]{1,60}") ? result : "mask_probe_unavailable";
        journal.accept("ROOT_MASK_CAPABILITY boot=" + boot + " available=false reason=" + reason);
    }
    void edge(long dark, String phase) {
        if (dark < 0 || dark <= recent) return;
        recent = dark;
        journal.accept("MASK_REFUSED_AT boot=" + boot + " dark=" + dark + " phase=" + phase + " reason=" + reason);
    }
    // Called only on the live daemon generation after both delivery proofs, the clock's frame
    // receipt and independent WMS/LockTask readback all succeeded.
    void verified(long dark, String request) {
        if (dark < 0 || dark != recent || dark <= completed || request == null) return;
        completed = dark;
        journal.accept("HANDOFF_COMPLETE boot=" + boot + " dark=" + dark + " request=" + request + " mask=not_submitted");
    }
}
