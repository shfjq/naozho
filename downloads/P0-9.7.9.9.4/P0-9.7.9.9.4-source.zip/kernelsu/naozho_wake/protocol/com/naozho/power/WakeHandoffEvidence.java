package com.naozho.power;

/** Exact, request-bound evidence in app-private storage, read after the COMMIT delivery proof. */
final class WakeHandoffEvidence {
    static boolean matches(String request, String receipt, String evidence) {
        return (request + "\n" + receipt).equals(evidence);
    }
}
