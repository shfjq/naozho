package com.naozho.power;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/** One non-launching formal envelope, one proved sender, at most one launch commit per epoch. */
public final class WakeDispatch {
    public interface Ports {
        void guard() throws Exception;
        int sendFormal() throws Exception;
        void publishReceipt() throws Exception;
        int confirmOnce() throws Exception;
        void launchReservedClock() throws Exception;
        boolean clockFocusedAndLocked() throws Exception;
        void clearReceipt() throws Exception;
    }

    /** Allows the ordered send to finish before the independent, read-only work overlaps. */
    public interface PipelinedPorts extends Ports {
        void dispatchFormal() throws Exception;
        int proveFormal() throws Exception;
        @Override default int sendFormal() throws Exception {
            dispatchFormal();
            return proveFormal();
        }
    }

    interface Guard { void check() throws Exception; }

    // Also used after the ordered COMMIT reservation: the actual origin/safety checks
    // and AMS delivery proof are independent, and only the subsequent ATM start is visible.
    static int readProofWhileGuarded(Callable<Integer> readProof, Guard guard, int expectedUid) throws Exception {
        FutureTask<Integer> proof = new FutureTask<>(readProof);
        Thread reader = new Thread(proof, "wake-delivery-proof");
        reader.setDaemon(true);
        reader.start();
        try {
            guard.check();
            // A slow/retried AMS history read cannot extend the validity of the window
            // snapshot. If the guard finished first, perform a new full guard after proof.
            boolean finishedDuringGuard = proof.isDone();
            int actual = proof.get();
            if (actual == expectedUid && !finishedDuringGuard) guard.check();
            return actual;
        } catch (ExecutionException failed) {
            Throwable why = failed.getCause();
            if (why instanceof Exception) throw (Exception) why;
            if (why instanceof Error) throw (Error) why;
            throw new IllegalStateException("wake_proof_worker_failed", why);
        } finally {
            // This worker only reads AMS; cancellation cannot submit or repeat a broadcast.
            proof.cancel(true);
        }
    }

    public static String run(Ports ports, int expectedUid) throws Exception {
        try {
            if (expectedUid != 0 && expectedUid != 2000) return "REFUSED_FORMAL_UID";
            ports.guard();
            if (ports instanceof PipelinedPorts) {
                PipelinedPorts pipelined = (PipelinedPorts)ports;
                pipelined.dispatchFormal();
                if (readProofWhileGuarded(pipelined::proveFormal, ports::guard, expectedUid) != expectedUid)
                    return "REFUSED_FORMAL_UID";
            } else {
                if (ports.sendFormal() != expectedUid) return "REFUSED_FORMAL_UID";
                ports.guard();
            }
            ports.publishReceipt();
            if (ports.confirmOnce() != expectedUid) return "REFUSED_COMMIT_UID";
            ports.launchReservedClock();
            return ports.clockFocusedAndLocked() ? "CLOCK_FOCUSED" : "REFUSED_LOCK_OR_FOCUS_UNCONFIRMED";
        } finally { ports.clearReceipt(); }
    }
}
