#!/system/bin/sh
set -eu
umask 077
mod=/data/adb/modules/naozho_wake
if [ -e "$mod/armed" ]; then exec /system/bin/sh "$mod/stop.sh"; fi
[ ! -e "$mod/disable" ] && [ ! -e "$mod/remove" ] && [ ! -e /data/adb/modules/naozho_power_daily/armed ] || exit 1
rm -f "$mod/attempts" "$mod/STOP"
cat /proc/sys/kernel/random/uuid > "$mod/arm.$$"
mv "$mod/arm.$$" "$mod/armed"
/system/bin/sh "$mod/start.sh" </dev/null >/dev/null 2>&1 &
echo "Requested. Check events for observer_ready."
