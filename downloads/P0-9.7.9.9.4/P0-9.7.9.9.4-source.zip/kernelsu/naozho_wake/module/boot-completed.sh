#!/system/bin/sh
/system/bin/sh /data/adb/modules/naozho_wake/start.sh </dev/null >/dev/null 2>&1 &
/system/bin/sh /data/adb/modules/naozho_wake/weather.sh </dev/null >/dev/null 2>&1 &
