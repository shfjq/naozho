[ "$KSU" = true ] && [ "$API" = 36 ] && [ "$ARCH" = arm64 ] && [ "$(getprop ro.product.device)" = CPDAY10 ] || abort "CPDAY10 API 36 arm64 KernelSU required"
[ ! -e /data/adb/modules/naozho_power_daily/armed ] || abort "Disarm the daily power shortcut first"
set_perm_recursive "$MODPATH" 0 0 0700 0600
for f in action.sh stop.sh boot-completed.sh start.sh uninstall.sh; do set_perm "$MODPATH/$f" 0 0 0700; done
ui_print "- Installed OFF. Review the clock APK and use Action to enable."
set_perm "$MODPATH/wake.jar" 0 0 0400
set_perm "$MODPATH/clock-identities.tsv" 0 0 0400
