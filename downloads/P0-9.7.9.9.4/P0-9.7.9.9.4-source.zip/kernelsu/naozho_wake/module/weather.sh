#!/system/bin/sh
# naozho_wake root weather dispatcher (P0-9.7.9.9.3)
#
# The Freeme "Atlas" component firewall blocks the clock app's own
# AlarmManager -> WeatherUpdateReceiver delivery, so hourly background
# refresh never runs while the screen is off. Root-originated broadcasts
# are not filtered by Atlas, so this dispatcher owns the hourly schedule
# and only ever DOES the scheduling: the Open-Meteo request, JSON parsing,
# city cache and SharedPreferences write stay inside the clock app.
#
# Rules:
#   next = last forecast_cache_success.updatedAt + 3600 s
#   trigger only when due, once per cycle, with a persisted task id
#   success is only recorded when the app wrote a newer updatedAt
#   a CPU wakelock is held so the loop survives screen-off / suspend

mod=/data/adb/modules/naozho_wake
wd="$mod/weather"
prefs=/data/data/com.naozho.clock/shared_prefs/clock_weather.xml
disp=/data/data/com.naozho.clock/shared_prefs/clock_display.xml
events="$wd/events"
INTERVAL_MS=3600000
RETRY_DELAY_S=600
WAIT_AFTER_TRIGGER_S=90

mkdir -p "$wd"
chmod 700 "$wd" 2>/dev/null
umask 077

log() {
  echo "$*" >> "$events"
}

now_ms() {
  echo $(( $(date +%s) * 1000 ))
}

# --- single instance -------------------------------------------------------
mypid=$$
if [ -r "$wd/pid" ]; then
  old=$(cat "$wd/pid" 2>/dev/null)
  case "$old" in
    ''|*[!0-9]*) old= ;;
  esac
  if [ -n "$old" ] && [ "$old" != "$mypid" ] && [ -d "/proc/$old" ] &&
      tr '\0' ' ' < "/proc/$old/cmdline" 2>/dev/null | grep -q 'weather\.sh'; then
    exit 0
  fi
fi
echo "$mypid" > "$wd/pid"

# --- cgroup/state guards ---------------------------------------------------
if [ -e "$mod/disable" ] || [ -e "$mod/remove" ]; then
  rm -f "$wd/pid"
  exit 0
fi

hold_wakelock() {
  if [ -w /sys/power/wake_lock ]; then
    echo naozho_weather > /sys/power/wake_lock 2>/dev/null
  fi
}

read_updated_at() {
  raw=$(cat "$prefs" 2>/dev/null)
  case "$raw" in
    *updatedAt*) ;;
    *) echo 0; return ;;
  esac
  value=$(echo "$raw" | sed -n 's/.*updatedAt[^0-9]*\([0-9][0-9]*\).*/\1/p' | head -1)
  case "$value" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$value" ;;
  esac
}

has_location() {
  raw=$(cat "$disp" 2>/dev/null)
  case "$raw" in
    *'name="weatherLat"'*) : ;;
    *) return 1 ;;
  esac
  case "$raw" in
    *'name="weatherLat"></string>'*) return 1 ;;
  esac
  return 0
}

trigger_refresh() {
  task=$1
  # `am` hands its stdout fd to system_server; a file under /data/adb/modules
  # (label system_file) is not appendable from u:r:system_server:s0 and makes the
  # whole binder transaction fail with "Failed transaction (2147483646)".
  # /dev/null is always safe and the result is verified through updatedAt anyway.
  /system/bin/am broadcast --user 0 \
    -a com.naozho.clock.weather.REFRESH --es task_id "$task" \
    -n com.naozho.clock/.weather.WeatherUpdateReceiver \
    > /dev/null 2>&1
  rc=$?
  log "ROOT_WEATHER_TRIGGER task=$task am_rc=$rc at=$(date '+%Y-%m-%d %H:%M:%S')"
}

hold_wakelock
last=$(read_updated_at)
log "ROOT_WEATHER_START pid=$mypid boot=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null) last=$last"

retry_after=0

while :; do
  if [ -e "$mod/disable" ] || [ -e "$mod/remove" ]; then
    log "ROOT_WEATHER_STOP reason=module_disabled"
    rm -f "$wd/pid" "$wd/task"
    exit 0
  fi

  hold_wakelock

  if ! has_location; then
    log "ROOT_WEATHER_IDLE reason=no_location"
    sleep 120
    continue
  fi

  last=$(read_updated_at)
  now=$(now_ms)

  if [ "$last" -le 0 ]; then
    sleep 60
    continue
  fi

  due=$(( last + INTERVAL_MS ))
  if [ "$now" -lt "$retry_after" ]; then
    sleep 30
    continue
  fi

  if [ "$now" -lt "$due" ]; then
    remain=$(( (due - now) / 1000 + 1 ))
    if [ "$remain" -gt 60 ]; then
      remain=60
    fi
    sleep "$remain"
    continue
  fi

  # --- due: run exactly one task -----------------------------------------
  task=$(cat /proc/sys/kernel/random/uuid 2>/dev/null)
  case "$task" in
    ????????????????*) : ;;
    *) task="local-$(date +%s)" ;;
  esac
  printf 'task=%s\nstarted=%s\nseen=%s\n' "$task" "$(date +%s)" "$last" > "$wd/task"
  log "ROOT_WEATHER_DUE task=$task due=$due last=$last now=$now gap=$(( now - due ))"

  attempt=1
  ok=0
  while [ "$attempt" -le 3 ]; do
    trigger_refresh "$task"
    waited=0
    while [ "$waited" -lt "$WAIT_AFTER_TRIGGER_S" ]; do
      sleep 5
      waited=$(( waited + 5 ))
      now_last=$(read_updated_at)
      if [ "$now_last" -gt "$last" ]; then
        ok=1
        break
      fi
    done
    [ "$ok" -eq 1 ] && break
    log "ROOT_WEATHER_RETRY task=$task attempt=$attempt no_new_updatedAt"
    attempt=$(( attempt + 1 ))
    sleep 10
  done

  if [ "$ok" -eq 1 ]; then
    log "ROOT_WEATHER_SUCCESS task=$task updatedAt=$now_last delta_ms=$(( now_last - last )) at=$(date '+%Y-%m-%d %H:%M:%S')"
    rm -f "$wd/task"
    retry_after=0
  else
    log "ROOT_WEATHER_FAILED task=$task after_attempts=$attempt retry_in=${RETRY_DELAY_S}s"
    rm -f "$wd/task"
    retry_after=$(( $(now_ms) + RETRY_DELAY_S * 1000 ))
  fi
  sleep 30
done
