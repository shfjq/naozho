#!/system/bin/sh
/system/bin/sh "${0%/*}/stop.sh"
/system/bin/run-as com.naozho.clock /system/bin/rm -f files/wake-epoch.locked
wd=/data/adb/modules/naozho_wake/weather
if [ -r "$wd/pid" ]; then
  p=$(cat "$wd/pid" 2>/dev/null)
  case "$p" in ''|*[!0-9]*) p= ;; esac
  [ -n "$p" ] && kill "$p" 2>/dev/null
fi
if [ -w /sys/power/wake_unlock ]; then echo naozho_weather > /sys/power/wake_unlock 2>/dev/null; fi
