#!/system/bin/sh
mod=/data/adb/modules/naozho_wake
umask 077
token=$(cat "$mod/armed" 2>/dev/null) || exit 0
# The observer claims an OS FileLock before any framework or display registration.
for wait in 0 2 8; do
  [ "$wait" = 0 ] || sleep "$wait"
  [ -n "$token" ] && [ "$(cat "$mod/armed" 2>/dev/null)" = "$token" ] &&
    [ ! -e "$mod/disable" ] && [ ! -e "$mod/remove" ] && [ ! -e "$mod/STOP" ] || exit 0
  CLASSPATH="$mod/wake.jar" /system/bin/app_process /system/bin --nice-name=naozho_wake com.naozho.power.WakeDaemon && exit 0
done
