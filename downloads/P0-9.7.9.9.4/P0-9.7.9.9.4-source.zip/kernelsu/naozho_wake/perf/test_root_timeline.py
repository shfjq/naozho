import unittest
from test_timeline import rows
from timeline import read_cycles

ROOT_ID = "a5a5a5a5-1234-5678-abcd-0123456789ab"
BOOT_ID = "02697316-12a4-5ffa-abcd-112233445566"


def sample():
    stages = rows()
    changes = dict(COMMIT_DELIVERED_AT=5219)
    for i, line in enumerate(stages):
        at, stage, data = line.split(" ", 2)
        data = data.replace("req1.100", ROOT_ID).replace("epoch-1-100", BOOT_ID + "/100/1")
        if stage in ("RETURN_DELIVERED_AT", "COMMIT_DELIVERED_AT"): data += " uid=2000"
        if stage == "CLOCK_FOCUSED": data += " request=" + ROOT_ID
        stages[i] = f"{changes.get(stage,at)} {stage} {data}"
    for t,stage in [(5215,"ATM_GUARD_READY_AT"), (5245,"ROOT_ATM_ACCEPTED_AT"), (5320,"CLOCK_FRAME_COMMITTED_AT"),
                    (5390,"CLOCK_FRAME_ACK_AT"),(5415,"CLOCK_FOCUS_LOCK_VERIFIED_AT"),(5430,"HANDOFF_COMPLETE")]:
        stages.append(f"{t} {stage} boot=1 dark=100 request={ROOT_ID}" + (" mask=not_submitted" if stage=="HANDOFF_COMPLETE" else ""))
    return ["56 ROOT_MASK_CAPABILITY boot=1 available=false reason=permission_unavailable",
            "66 ROOT_MASK_CAPABILITY boot=2 available=true reason=x",
            "6000 ROOT_MASK_CAPABILITY boot=1 available=true reason=late",
            "102 MASK_REFUSED_AT boot=1 dark=100 phase=off reason=wm_requires_token", *stages]


def measured(lines):
    return list(read_cycles("\n".join(lines), require_atm=True))[0]


class RootTimelineTest(unittest.TestCase):
    def test_formal_return_with_refused_early_mask_is_recorded_separately(self):
        report = measured(sample())
        self.assertTrue(report["global_return"]["formal_handoff_confirmed"])
        mask = report["independent_early_mask"]
        self.assertEqual(mask["submitted"],False)
        self.assertEqual(mask["refusal_phase"],"off")
        self.assertEqual(mask["prior_runtime_probe"],dict(elapsed_ms=56,available=False,reason="permission_unavailable"))
        self.assertNotIn("physical_observation",report)

    def test_missing_duplicate_foreign_or_unproven_atm_request_fails(self):
        for stage in ("ATM_GUARD_READY_AT","ROOT_ATM_ACCEPTED_AT","CLOCK_FOCUS_LOCK_VERIFIED_AT","ACTIVITY_REQUEST_AT"):
            base = sample()
            entry = next(line for line in base if " "+stage+" " in line)
            bad = [i for i in base if i != entry]
            for altered in (bad, base+[entry], bad+[entry.replace(ROOT_ID, BOOT_ID)]):
                self.assertFalse(measured(altered)["global_return"]["formal_handoff_confirmed"],stage)
        for altered in (
            [x.replace("uid=2000","uid=0") if " COMMIT_DELIVERED_AT " in x else x for x in sample()],
            [x.replace("epoch="+BOOT_ID+"/100", "epoch="+BOOT_ID+"/99") for x in sample()],
            [x.replace("5245 ROOT_ATM", "5211 ROOT_ATM") for x in sample()]):
            self.assertFalse(measured(altered)["global_return"]["formal_handoff_confirmed"])

    def test_root_mode_never_falls_back_to_legacy_ack_when_root_rows_lost(self):
        old=[l for l in sample() if " ATM_GUARD_READY" not in l and " ROOT_ATM_ACCEPTED" not in l
             and " CLOCK_FOCUS_LOCK_VERIFIED" not in l and "MASK_" not in l]
        old=[l.replace(" mask=not_submitted","") for l in old]
        self.assertFalse(measured(old)["global_return"]["formal_handoff_confirmed"])
        self.assertNotIn("root_activity_start",next(read_cycles("\n".join(old))))
