# CPDAY10 亮屏取证

上一版记录的一个亮屏候选到完整唤醒间隔为 847 ms。1.2.0 在读完一次 Power 快照后，可能再等 200 或 400 ms 才开始下一次读取。同一个区间也包含 Android 自身的 wakefulness 转换、Binder 往返及 Looper 等待。已有终点时间无法分摊这 847 ms。

## 固件核对

使用本地已归档的原厂 services.jar，SHA-256 为 `70fa04e1e51c4008078cdc7fd6c1cc041769e39bd3cce99712ce1d374d81f468`。本轮从 JAR 重新提取的 classes2.dex 与用于反汇编的文件逐字节校验一致，SHA-256 为 `113041258d67a89a7229e268f305b07cd02b25d7f4c8e3a424cf5015eddd082a`。

`PowerManagerService$BinderService.dump` 在方法内偏移 0x19 识别 `--proto`，0x23 进入 `PowerManagerService.dumpProto`。下表偏移为后者的 DEX code unit。该方法在 PMS 锁下从与文本 dump 相同的系统状态取值。

| 证据 | 偏移 | protobuf 字段 |
| --- | --- | --- |
| getGlobalWakefulnessLocked | 0x1b | 3 |
| mWakefulnessChanging | 0x27 | 4 |
| 遍历 mPowerGroups、getGroupId | 0x17f、0x198 | 重复消息 20，组内 ID 为 6 |
| mLastGlobalWakeTime、mLastGlobalSleepTime | 0x26b、0x275 | 29、30，单位为系统 uptime 毫秒 |
| PMS 主 Handler 的 Looper.dumpDebug | 0x53f | 46，作为完整性检查之一 |
| ProtoOutputStream.flush | 0x58f | 完成本次输出 |

模块使用原来的只读 Binder 入口，固定服务 power。先尝试紧凑格式，读取上限 256 KiB，单次 Binder 时间上限 950 ms。解析器按固件的 ProtoOutputStream 默认值编码处理缺省字段。正常接受取证要求观察到唯一电源组、两条时间和后段 Looper 消息，读取到 EOF，并收到服务成功返回。多组或非默认组直接拒绝。未知格式回到已有的文本 Binder 和有界 dumpsys。格式不支持的路径只探测一次，短暂的 Binder 占用允许稍后重用快速路径。每次证据都重新读取。仅记录下表的元数据。

## 调度及实测

默认内屏状态回调在真实 ON 边沿立即发起读取。若 PMS 尚未收敛，下一次查询以边沿为起点安排在 60、180、400、800、1550、2500 ms。慢读取错过多个时间点时直接合并。三秒证据上限继续生效。稳定状态、持续息屏和未发生唤醒时均无周期查询。单次 AOD、DREAMING、配对时间异常和暂停不能产生正式请求。

同一 boot 与 dark 下的 `PMS_SAMPLE` 行包含 `slot`、计划时刻 `due`、读取开始 `start`、读取结束 `end`、判定时刻 `decision_at`、传输途径 `via` 和判定 `result`。时刻使用 elapsedRealtime 毫秒。由 `start-due` 看排队延迟，由 `end-start` 看取证耗时，由 `decision_at-end` 看结果回到 Looper 的耗时。失败的取证时间点与成功时间点一起保留，如 `WAKING_transition` 和随后出现的 `FULL_WAKE`，用于判断系统状态是否仍在过渡。

候选时段只可投机读取前台焦点标识。窗口分类、模式校验、正式请求和锁定仍要求本次有效 FULL_WAKE。任何身份、显示状态、暂停或周期变化都使旧结果失效。PMS 耗时、总用时和用户看到的首屏仍需同一台 CPDAY10 实测。
