package com.naozho.power;

import java.util.Locale;

/** Replays a filtered summary with an immediately available terminal full history. Real waits. */
public final class ProofBenchmark {
    public static void main(String[] args) throws Exception {
        for (int round = 0; round < 3; round++) {
            for (boolean fast : new boolean[]{false, true}) {
                long start = System.nanoTime();
                final int[] reads = {0};
                int uid = DeliveryProof.verify(DeliveryProofTest.ACTION, DeliveryProofTest.ID, new DeliveryProof.History() {
                    public String read(boolean full) {
                        reads[0]++;
                        return full ? DeliveryProofTest.DUMP : "    Historical broadcasts summary:\n    #0: " + DeliveryProofTest.INTENT;
                    }
                    public void waitMs(int ms) throws Exception { Thread.sleep(ms); }
                    public void report(String message) {}
                }, fast);
                if (uid != 0) throw new AssertionError("unconfirmed");
                System.out.printf(Locale.ROOT,"%s round=%d reads=%d elapsed_ms=%.2f%n",
                        fast ? "fast" : "baseline", round+1, reads[0], (System.nanoTime()-start)/1e6);
            }
        }
    }
}
