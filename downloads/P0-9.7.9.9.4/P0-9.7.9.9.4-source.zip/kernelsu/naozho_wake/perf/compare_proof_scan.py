"""Compile the baseline and working-tree proof parser, then time the same generated history."""
import argparse
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[3]
baseline = "1f1c809aae5dd57cc20377a8679cb7851e3f2750"
power = Path("kernelsu/naozho_power")
files = [power / "src/com/naozho/power" / n for n in ("TrialChecks.java", "DeliveryProof.java")]
files.append(power / "tests/com/naozho/power/DeliveryProofTest.java")
harness = Path(__file__).with_name("ProofScanBenchmark.java")
options = argparse.ArgumentParser(description=__doc__)
options.add_argument("--baseline-root", type=Path, help="extracted P0-9.7.9.2 source (without Git history)")
baseline_root = options.parse_args().baseline_root
with tempfile.TemporaryDirectory() as tmp:
    for label in ("baseline", "candidate"):
        tree = Path(tmp, label)
        tree.mkdir()
        sources = []
        for f in files:
            copied = tree / f.name
            if label == "candidate":
                data = (root/f).read_bytes()
            elif baseline_root:
                data = (baseline_root/f).read_bytes()
            else:
                data = subprocess.check_output(["git", "show", f"{baseline}:{f}"], cwd=root)
            copied.write_bytes(data)
            sources.append(copied)
        subprocess.run(["javac", "--release", "11", "-d", tree, *sources, harness], check=True)
        print(label, subprocess.check_output(["java", "-Xms128m", "-Xmx128m", "-cp", tree,
                                             "com.naozho.power.ProofScanBenchmark"], text=True).strip())
