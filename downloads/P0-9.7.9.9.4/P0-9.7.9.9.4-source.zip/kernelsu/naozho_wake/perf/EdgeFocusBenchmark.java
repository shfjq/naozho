package com.naozho.power;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/** Host-controlled initial focus read overlapping an independent power read. No Android timing is inferred. */
public final class EdgeFocusBenchmark {
    static long millis() { return TimeUnit.NANOSECONDS.toMillis(System.nanoTime()); }
    static String read() throws InterruptedException { Thread.sleep(35); return "sample"; }
    public static void main(String[] args) throws Exception {
        long[][] results = new long[2][9];
        int used=0;
        for (int i=0; i<results[0].length; i++) {
            for (int j=0;j<2;j++) {
                int seeded=(i+j)%2;
                WakeFocusSeed seed = new WakeFocusSeed(EdgeFocusBenchmark::millis);
                if (seeded==1) seed.prepare(i,EdgeFocusBenchmark::read);
                Thread.sleep(70);
                long start=System.nanoTime();
                String value=seed.take(i);
                if (value==null) value=read(); else used++;
                if (!"sample".equals(value)) throw new AssertionError();
                results[seeded][i] = (System.nanoTime()-start)/1000;
            }
        }
        Arrays.sort(results[0]); Arrays.sort(results[1]);
        System.out.println("pairs=9 controlled_power_ms=70 controlled_initial_focus_ms=35 seed_hits="+used+
            " post_proof_leading_focus_us serial_median="+results[0][4]+" seeded_median="+results[1][4]);
    }
}
