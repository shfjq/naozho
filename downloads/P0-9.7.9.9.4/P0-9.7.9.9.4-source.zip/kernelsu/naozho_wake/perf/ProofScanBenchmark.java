package com.naozho.power;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Compare production parser versions on identical generated AMS records; no device evidence needed. */
public final class ProofScanBenchmark {
    public static void main(String[] args) {
        int records = 100;
        StringBuilder history = new StringBuilder("    Historical broadcasts:\n");
        for (int i = 0; i < records - 1; i++) {
            String background = DeliveryProofTest.DETAIL.replace(DeliveryProofTest.ACTION, "android.intent.action.local." + i)
                    .replace(DeliveryProofTest.ID, "other." + i)
                    .replace(TrialChecks.RECEIVER, "other.app/.Receiver")
                    .replace("Historical Broadcast #0", "Historical Broadcast #" + i);
            history.append(background);
        }
        String dump = history.append(DeliveryProofTest.DETAIL.replace("Historical Broadcast #0", "Historical Broadcast #99"))
                .toString();
        int warm = 50;
        long[] sample = new long[150];
        for (int i = -warm; i < sample.length; i++) {
            long start = System.nanoTime();
            DeliveryProof.Sample result = DeliveryProof.inspect(dump, DeliveryProofTest.ACTION, DeliveryProofTest.ID);
            long elapsed = System.nanoTime() - start;
            if (result.uid != 0 || result.records != records || result.matches != 1 || result.invalid)
                throw new AssertionError("fixture not verified");
            if (i >= 0) sample[i] = elapsed;
        }
        Arrays.sort(sample);
        System.out.println("history_records=" + records + " bytes=" + dump.getBytes(StandardCharsets.UTF_8).length
                + " repetitions=" + sample.length + " median_us=" + sample[sample.length/2]/1000
                + " p90_us=" + sample[9*sample.length/10]/1000);
    }
}
