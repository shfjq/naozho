from contextlib import redirect_stdout
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
from zipfile import ZipFile
import wake97_dsh as tool


class ReleaseTest(unittest.TestCase):
    def setUp(self):
        work = TemporaryDirectory(); self.addCleanup(work.cleanup)
        self.work = Path(work.name)
        self.entries = {}
        for v, (apk, item, code) in tool.PAIRS.items():
            f = self.work / apk
            f.write_bytes(("signed-test-bytes" + v).encode())
            self.entries[apk] = tool.sha(f)
            with ZipFile(self.work / item, "w") as z:
                z.writestr("clock.sha256", self.entries[apk])
                z.writestr("module.prop", f"id=naozho_wake\nversion={v}\nversionCode={code}\n")
            self.entries[item] = tool.sha(self.work / item)
        (self.work / "SHA256SUMS.txt").write_text("".join(f"{h}  {n}\n" for n,h in self.entries.items()))
        for name in ("signer", "signed"):
            m = patch.object(tool, name, return_value=tool.CERT)
            m.start(); self.addCleanup(m.stop)
        device = patch.object(tool, "Device", autospec=True)
        self.factory = device.start(); self.addCleanup(device.stop); self.dev=self.factory.return_value
        self.save = self.work / "before.json"
        self.snap = dict(device="CPDAY10",api=36,abi="arm64-v8a",fingerprint="f",device_binding="b",uid=10003,
                         owner=True,certificate=tool.CERT,ksu="ksud v3.3.1 (uapi: 1)",lock="NONE",observer_count=0, markers=[],
                         module_id="naozho_wake")
        self.baseline(next(iter(tool.KNOWN)))

    def baseline(self, key):
        v=tool.KNOWN[key]; n,c,d=key
        self.snap.update(name=n,code=c,apk_sha256=d,module_pin=d,module_version=v,module_code=tool.PAIRS[v][2])
        self.save.write_text(json.dumps(self.snap))
        self.dev.snapshot.return_value = self.snap.copy()

    def call(self, action, *more):
        with redirect_stdout(io.StringIO()):
            tool.main([action, "--serial","test", "--files",str(self.work),"--before",str(self.save),*more])

    def test_default_verify_no_adb(self):
        with redirect_stdout(io.StringIO()): tool.main(["--files",str(self.work)])
        self.factory.assert_not_called()

    def test_unapproved_write_never_invokes_adb(self):
        for action in ("install","rollback","start","stop","uninstall"):
            with self.assertRaisesRegex(ValueError,"explicit --apply"): self.call(action)
        self.factory.assert_not_called()

    def test_recognizes_three_released_baselines_and_selects_rollback_pair(self):
        for key, old in tool.KNOWN.items():
            self.baseline(key)
            apk,mod,_ = tool.PAIRS[old]
            cand = self.snap.copy()
            cand["apk_sha256"] = self.entries[tool.PAIRS["1.5.0"][0]]
            post = dict(cand,apk_sha256=self.entries[apk])
            self.dev.snapshot.side_effect=[cand,post]
            self.dev.root.return_value=self.entries[apk]
            self.call("rollback","--apply")
            self.dev.install.assert_called_with(self.work/apk,self.work/mod,self.entries[mod])

    def test_reports_changed_device_or_unknown_baseline_before_install(self):
        for changes in [{"device_binding":"another"},{"owner":False},{"apk_sha256":"wrong"},{"markers":["pending"]}]:
            self.dev.snapshot.return_value=dict(self.snap,**changes)
            with self.assertRaises(ValueError): self.call("install","--apply")
        self.dev.install.assert_not_called()

    def test_manual_stop_and_preflight_allow_no_write_or_overwrite(self):
        self.call("status","--save",str(self.work/"actual.json"))
        with self.assertRaises(FileExistsError): self.call("status","--save",str(self.save))
        self.dev.install.assert_not_called()
        self.dev.root.assert_not_called()

    def test_hash_corruption_halts_before_write(self):
        (self.work/tool.PAIRS["1.5.0"][1]).write_bytes(b"damaged")
        with self.assertRaisesRegex(ValueError,"digest mismatch"):self.call("install","--apply")
        self.dev.install.assert_not_called()

    def test_readback_check_detects_phase_one_only(self):
        self.dev.snapshot.side_effect=[self.snap.copy(),self.snap.copy()]
        with self.assertRaisesRegex(ValueError,"installed APK differs"):self.call("install","--apply")
        self.dev.install.assert_called_once()

    def test_matching_clock_policy_and_focus_fields(self):
        raw = "Local Policies:\n  User 0:\n    LockTaskPolicy {mPackages= com.naozho.clock; mFlags=80}\n  User 10:\n    LockTaskPolicy {mPackages= other; mFlags=0}"
        self.assertEqual(tool.lock_policy(raw),{"clock_only":True,"flags":80})
        self.assertEqual(tool.lock_policy("unknown"),{"clock_only":None,"flags":None})
        self.assertTrue(tool.focus_summary("mCurrentFocus=Window{a u0 com.naozho.clock/.MainActivity}\nmFocusedApp=ActivityRecord{b u0 com.naozho.clock/.mode.PowerClockEntry t57}") == {"foreground":"clock","task":57})
        self.assertEqual(tool.focus_summary("mCurrentFocus=null")["foreground"],"unknown")

    def test_maintenance_no_double_toggle(self):
        apk=tool.PAIRS["1.5.0"][0]
        self.dev.snapshot.return_value=dict(self.snap,apk_sha256=self.entries[apk],module_version="1.5.0", module_code="7",
                                            module_pin=self.entries[apk],markers=["armed"],observer_count=1)
        self.call("start","--apply")
        self.dev.root.assert_not_called()

    def test_read_only_focus_does_not_join_different_ordinary_activities(self):
        rows = " mCurrentFocus=Window{1a u0 demo.browser/.Browse}\n mFocusedApp=ActivityRecord{1b u0 demo.video/.Play t17}\n"
        self.assertEqual({"foreground":"unstable", "task":None}, tool.focus_summary(rows))
        self.assertEqual({"foreground":"other", "task":17},
                         tool.focus_summary(rows.replace("demo.video/.Play", "demo.browser/demo.browser.Browse")))

    def test_manifest_traversal_duplicate_rejected(self):
        p=self.work/"SHA256SUMS.txt"
        row=p.read_text().splitlines()[0]
        for bad in ("a"*64+"  ../outside\n",row+"\n"+row):
            p.write_text(bad)
            with self.assertRaises(ValueError): tool.checksums(self.work)
