#!/usr/bin/env python3
from pathlib import Path
import subprocess
import tempfile

root=Path(__file__).resolve().parent
probe=root.parents[1]/"probes/wake-observer"
with tempfile.TemporaryDirectory() as tmp:
    src=[probe/"src/com/naozho/wakeprobe"/name for name in ("WakeCycle.java","PowerEvidence.java")]
    src.extend([root/"src/com/naozho/wakeprobe/WakeEpochManager.java", root/"protocol/com/naozho/power/WakeDispatch.java",
                root/"src/com/naozho/wakeprobe/PowerSampleSchedule.java", root/"src/com/naozho/wakeprobe/PowerProto.java",
                root/"protocol/com/naozho/power/WakeWire.java", root/"protocol/com/naozho/power/WakeHandoffEvidence.java",
                root/"protocol/com/naozho/power/WakePresentationAudit.java", root/"tests/WakePresentationTest.java",
                root/"src/com/naozho/power/RootWakeWindowFacts.java", root/"tests/RootWakeWindowFactsTest.java",
                root/"tests/PowerFastPathTest.java", root/"tests/WakeFlowTest.java", root/"tests/WakeSamplingTest.java", root/"tests/WakePipelineTest.java",
                probe/"tests/WakeTests.java"])
    subprocess.run(["javac","--release","11","-d",tmp,*src],check=True)
    for name in ("com.naozho.wakeprobe.WakeTests","com.naozho.power.WakeFlowTest",
                 "com.naozho.wakeprobe.WakeSamplingTest","com.naozho.wakeprobe.PowerFastPathTest","com.naozho.power.WakePipelineTest","com.naozho.power.WakePresentationTest","com.naozho.power.RootWakeWindowFactsTest"):
        subprocess.run(["java","-cp",tmp,name],check=True)
for script in (root/"module").glob("*.sh"):
    subprocess.run(["sh","-n",script],check=True)
