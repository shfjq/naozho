#!/usr/bin/env python3
"""Build a code-only KernelSU trial for Android 16 with JDK 17, Android SDK 36 and D8."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

def pack(path, entries):
    with ZipFile(path, "w") as archive:
        for name, data in sorted(entries.items()):
            item = ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            item.create_system = 3
            item.external_attr = (0o100755 if name.endswith(".sh") else 0o100644) << 16
            archive.writestr(item, data, compress_type=ZIP_DEFLATED)

def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--android-jar", type=Path, required=True)
    cli.add_argument("--d8", type=Path, required=True)
    cli.add_argument("--out", type=Path, required=True)
    args = cli.parse_args()
    root = Path(__file__).resolve().parent
    station = root.parents[1] / "platform/station"
    sources = sorted(p for d in [root/"src", station/"src", station/"android"] for p in d.rglob("*.java"))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        classes = work / "classes"
        dex = work / "dex"
        classes.mkdir()
        dex.mkdir()
        java_home = Path(os.environ["JAVA_HOME"])
        subprocess.run([java_home/"bin/javac", "--release", "11", "-Xlint:all", "-Werror", "-classpath",
                        args.android_jar, "-d", classes, *sources], check=True)
        intermediate = work/"classes.jar"
        pack(intermediate, {p.relative_to(classes).as_posix():p.read_bytes() for p in classes.rglob("*.class")})
        subprocess.run([args.d8, "--release", "--min-api", "34", "--lib", args.android_jar,
                        "--output", dex, intermediate], check=True)
        jar = work/"power-trial.jar"
        pack(jar, {"classes.dex": (dex/"classes.dex").read_bytes()})
        entries = {p.name:p.read_bytes() for p in (root/"module").iterdir() if p.is_file()}
        entries[jar.name] = jar.read_bytes()
        pack(args.out, entries)
    print(args.out)

if __name__ == "__main__":
    main()
