package com.naozho.power;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.naozho.power.TrialChecks.Refused;

/** Android 16 ActivityManager terminal history for this explicit, user-zero delivery. */
final class DeliveryProof {
    static final String PROBE = "com.naozho.clock.action.P095_PERMISSION_PROBE.";
    static final String PERMISSION = "android.permission.STATUS_BAR_SERVICE";
    private static final Pattern HEADER = Pattern.compile("Historical Broadcast #[0-9]+:");
    private static final Pattern PENDING_HEADER = Pattern.compile("(?:Pending|Frozen)\\s+broadcast #[0-9]+:");
    private static final Pattern LINES = Pattern.compile("\\r?\\n");
    private static final Pattern USER = Pattern.compile("BroadcastRecord\\{[^{}]+\\} to user ([0-9]{1,9})");
    private static final Pattern TARGET = Pattern.compile("([A-Z_]+) .*?#([0-9]+): (.+)");
    private static final Pattern UID = Pattern.compile("(?:^|\\s)uid=([0-9]{1,9})(?=$|\\s)");
    private static final String LONG_COMPONENT = "com.naozho.clock/com.naozho.clock.mode.ConfirmedPowerReceiver";

    static String[] envelope(String action, String id, String... extras) {
        List<String> args = new ArrayList<>(Arrays.asList("/system/bin/am", "broadcast", "--user", "0",
                "--receiver-foreground", "--exclude-stopped-packages", "-n", TrialChecks.RECEIVER,
                "-a", action, "-i", id));
        args.addAll(Arrays.asList(extras));
        return args.toArray(new String[0]);
    }

    static final class Sample {
        int records, actionRecords, identifiedActions, matches;
        String observedUser = "unknown", component = "unknown";
        int observedUid = -1;
        boolean mentioned, pending, summary, isolatedIntent;
        int uid = -1;
        boolean invalid;
        String reason = "no_record";
        String missing = "record";
        String state = "unknown";

        String describe() {
            return "records=" + records + " action_records=" + actionRecords + " with_identifier=" + identifiedActions
                    + " matched=" + matches + " mention=" + mentioned + " pending=" + pending
                    + " summary=" + summary + " isolated_intent=" + isolatedIntent + " user=" + observedUser + " component=" + component
                    + " state=" + state + " sender_uid=" + observedUid
                    + " missing=" + missing + " check=" + reason;
        }

        void reject(String why) {
            invalid = true;
            uid = -1;
            reason = why;
        }
    }

    private static int indent(String line) {
        int i = 0;
        while (i < line.length() && (line.charAt(i) == ' ' || line.charAt(i) == '\t')) i++;
        return i;
    }

    // Return values are deliberately never copied into diagnostics. An empty result is missing,
    // and a repeated field is a conflict even when both values agree.
    private static String field(String line, String prefix) {
        String value = "";
        for (String token : line.split("\\s+")) {
            if (token.startsWith(prefix)) {
                if (!value.isEmpty()) return "!duplicate";
                value = token.substring(prefix.length());
            }
        }
        return value;
    }

    private static void readRecord(String[] lines, int start, int end, String action, String id, Sample s) {
        int base = indent(lines[start]);
        String envelope = lines[start].trim();
        Matcher user = USER.matcher(envelope);
        String userId = user.matches() ? user.group(1) : "";
        String intent = "", caller = "", targetState = "", actualTarget = "";
        int intents = 0, callers = 0, targets = 0, envelopes = 1;
        boolean denied = false, oemBlocked = false, tupleMatches = false, actionMatches = false;
        for (int i = start + 1; i < end; i++) {
            String text = lines[i].trim();
            if (indent(lines[i]) > base && text.startsWith("reason: ")) {
                denied |= text.contains("Permission Denial") && text.contains(PERMISSION);
                oemBlocked |= text.contains("Autostart blocked: broadcasting from ");
            }
            if (indent(lines[i]) != base) continue;
            if (text.startsWith("Intent {") && text.endsWith("}")) {
                intents++;
                intent = text.substring(8, text.length() - 1).trim();
                tupleMatches |= id.equals(field(intent, "id="));
                actionMatches |= action.equals(field(intent, "act="));
            } else if (text.startsWith("caller=")) {
                callers++;
                caller = text;
            } else if (text.startsWith("BroadcastRecord{")) {
                envelopes++;
            } else {
                Matcher row = TARGET.matcher(text);
                if (row.matches()) {
                    targets++;
                    targetState = row.group(1);
                    actualTarget = row.group(2) + ":" + row.group(3);
                }
            }
        }
        if (actionMatches) {
            s.actionRecords++;
            if (!field(intent, "id=").isEmpty()) s.identifiedActions++;
        }
        if (!tupleMatches) return;
        if (++s.matches > 1 || envelopes != 1 || intents != 1) {
            s.reject("delivery_record_mismatch");
            return;
        }
        List<String> absent = new ArrayList<>();
        String cmp = field(intent, "cmp=");
        Matcher sender = UID.matcher(caller);
        int uid = sender.find() ? Integer.parseInt(sender.group(1)) : -1;
        s.observedUid = uid;
        s.observedUser = userId.isEmpty() ? "unknown" : userId;
        s.component = cmp.isEmpty() ? "missing" :
                (TrialChecks.RECEIVER.equals(cmp) || LONG_COMPONENT.equals(cmp) ? "clock_receiver" : "other");
        if (userId.isEmpty()) absent.add("user");
        if (cmp.isEmpty()) absent.add("component");
        if (uid < 0) absent.add("sender_uid");
        if (targets == 0) absent.add("receiver_state");
        if (field(intent,"act=").isEmpty()) absent.add("action");
        s.missing = absent.isEmpty() ? "none" : String.join(",", absent);
        s.state = targetState.matches("DELIVERED|SKIPPED|FAILURE|TIMEOUT|PENDING|DEFERRED|SCHEDULED")
                ? targetState : "unknown";
        if (targets > 1 || (targets == 1 && !"0:(manifest)".equals(actualTarget))) {
            s.reject("delivery_receiver_ambiguous");
        } else if (callers > 1 || (uid >= 0 && sender.find())) {
            s.reject("sender_uid_conflict");
        } else if (!userId.isEmpty() && !"0".equals(userId)) {
            s.reject("wrong_user");
        } else if (!field(intent, "act=").isEmpty() && !actionMatches) {
            s.reject("wrong_action");
        } else if (!cmp.isEmpty() && !TrialChecks.RECEIVER.equals(cmp) && !LONG_COMPONENT.equals(cmp)) {
            s.reject("wrong_component");
        } else if (targetState.matches("SKIPPED|FAILURE|TIMEOUT")) {
            s.reject(denied ? "delivery_denied_STATUS_BAR_SERVICE" : oemBlocked
                    ? "delivery_autostart_policy_blocked" : "delivery_" + targetState);
        } else if (!absent.isEmpty()) {
            s.reason = "incomplete_receipt";
        } else if (!"DELIVERED".equals(targetState)) {
            s.reason = s.state.equals("unknown") ? "unsupported_state_format" : "not_terminal";
        } else {
            s.uid = uid;
            s.reason = "verified";
        }
    }

    // Structural boundaries use relative indentation. BroadcastQueueImpl wraps BroadcastHistory
    // in an IndentingPrintWriter; spacing literals from BroadcastHistory alone are insufficient.
    static Sample inspect(String dump, String action, String id) {
        Sample s = new Sample();
        String[] lines = LINES.split(dump);
        String section = "";
        for (int i = 0; i < lines.length; i++) {
            String text = lines[i].trim();
            if (text.endsWith("broadcasts:") || text.endsWith("broadcasts summary:")) section = text;
            if (text.contains(action)) {
                s.mentioned = true;
                if (section.equals("Pending broadcasts:") || section.equals("Frozen broadcasts:")) s.pending = true;
                if (section.equals("Historical broadcasts summary:")) s.summary = true;
            }
            // Filtered field excerpts can retain the exact intent but omit its history boundary.
            // Describe that observation without borrowing surrounding caller or receiver lines.
            if (text.startsWith("Intent { ") && text.endsWith("}") && text.contains(id) && text.contains(action)) {
                String fields = text.substring(8, text.length() - 1);
                if (action.equals(field(fields, "act=")) && id.equals(field(fields, "id=")))
                    s.isolatedIntent = true;
            }
            if (!text.startsWith("Historical Broadcast #") || !HEADER.matcher(text).matches()) continue;
            s.records++;
            int headerIndent = indent(lines[i]);
            int first = i + 1;
            while (first < lines.length && lines[first].trim().isEmpty()) first++;
            if (first >= lines.length || indent(lines[first]) <= headerIndent
                    || !lines[first].trim().startsWith("BroadcastRecord{")) continue;
            int end = first + 1;
            boolean relevant = false;
            while (end < lines.length) {
                String next = lines[end].trim();
                if (!next.isEmpty() && (indent(lines[end]) <= headerIndent ||
                        (next.startsWith("Historical Broadcast #") && HEADER.matcher(next).matches())
                        || next.startsWith("BroadcastRecord{") || next.endsWith("broadcasts:") || next.endsWith("broadcasts summary:")
                        || ((next.startsWith("Pending") || next.startsWith("Frozen")) &&
                            PENDING_HEADER.matcher(next).matches()))) break;
                // A matching id (even with a different action) or any same-action intent
                // must go through the exact, unchanged structural validation below.
                if (next.startsWith("Intent {") && (next.contains(id) || next.contains(action))) relevant = true;
                end++;
            }
            if (relevant) readRecord(lines, first, end, action, id, s);
            i = end - 1;
        }
        s.mentioned |= s.actionRecords > 0 || dump.contains(action);
        if (s.matches == 0) {
            if (s.actionRecords > 0) {
                s.reason = s.identifiedActions == 0 ? "identifier_missing" : "no_matching_identifier";
                s.missing = "matching_id";
            } else if (s.pending) {
                s.reason = "pending_or_frozen";
            } else if (s.summary) {
                s.reason = "summary_only";
            } else if (s.isolatedIntent) {
                s.reason = "matching_intent_outside_terminal_record";
                s.missing = "history_boundary,linked_sender_uid,linked_manifest_state";
            } else if (s.mentioned) {
                s.reason = "unparsed_related_record";
            }
        }
        return s;
    }

    interface History {
        String read(boolean all) throws Exception;
        void waitMs(int millis) throws Exception;
        void report(String text);
    }

    static int verify(String action, String id, History history) throws Exception {
        return verify(action, id, history, false);
    }

    static int verify(String action, String id, History history, boolean fast) throws Exception {
        return verify(action, id, history, fast, null);
    }

    // Learning only changes which independent, complete AMS view is consulted first.
    // Every send still verifies its own id/action/user/component/UID/terminal status.
    static final class ViewHint {
        volatile boolean fullFirst;
    }

    static int verify(String action, String id, History history, boolean fast, ViewHint hint) throws Exception {
        boolean fullFirst = fast && hint != null && hint.fullFirst;
        // Only reads are retried. The final broad terminal-history read handles OEM filters
        // that show a summary or no records. Each sample must independently prove the delivery.
        int[] delays = fast ? new int[]{0, 0, 200, 600, 1000} : new int[]{0, 200, 600, 1000};
        String previous = "initial";
        long startNs = System.nanoTime();
        for (int i = 0; i < delays.length; i++) {
            if (delays[i] > 0) history.waitMs(delays[i]);
            boolean earlyHistory = fast && i == (fullFirst ? 0 : 1);
            boolean all = earlyHistory || i == delays.length - 1;
            String info = "stage=" + (action.startsWith(PROBE) ? "probe" : "return")
                    + " trace=" + id + " sample=" + (i + 1) + " source=" + (all ? "history" : "filter")
                    + " previous=" + previous;
            String dump;
            try {
                dump = history.read(all);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                throw interrupted;
            } catch (Exception error) {
                String why = error instanceof Refused ? error.getMessage() : error.getClass().getSimpleName();
                history.report(info + " check=read_failed detail=" + why);
                // The additional early broad read is opportunistic. A large history or an
                // unavailable view must not discard the existing later filtered-read path.
                if (earlyHistory) { previous = "early_history_unavailable"; continue; }
                throw new Refused("history_read_failed_" + why);
            }
            Sample sample = inspect(dump, action, id);
            history.report(info + " elapsed_ms=" + (System.nanoTime() - startNs) / 1_000_000 + " " + sample.describe());
            if (sample.invalid) throw new Refused(sample.reason);
            if (sample.uid >= 0) {
                if (hint != null) hint.fullFirst = all;
                return sample.uid;
            }
            previous = sample.reason;
        }
        throw new Refused("history_unconfirmed_" + previous);
    }

    private DeliveryProof() {}
}
