package com.naozho.power;

import com.naozho.power.TrialChecks.Refused;

/** This irreversible boundary is shared by both trial modes. One qualified sequence ends the trial. */
final class TrialHandoff {
    interface Environment {
        boolean unchanged(long serial) throws Exception;
        void proveForeground(long firstUptime) throws Exception;
        long elapsed();
        void send(int boot, long firstElapsed, long releasedElapsed) throws Exception;
    }

    private boolean used;

    synchronized String finish(boolean live, int boot, long serial, long firstUptime, long firstElapsed,
            long releasedElapsed, Environment env) throws Exception {
        if (used) throw new Refused("trial_already_used");
        used = true; // Even an ambiguous shell result or revoked permission must not cause a retry.
        if (!env.unchanged(serial)) throw new Refused("input_or_trial_changed");
        env.proveForeground(firstUptime);
        long age = env.elapsed() - releasedElapsed;
        if (age < 0 || age >= 1500) throw new Refused("proof_too_slow_for_app_receipt");
        if (!env.unchanged(serial)) throw new Refused("input_or_trial_changed");
        if (!live) return "observed_qualified_double_no_request";
        env.send(boot, firstElapsed, releasedElapsed);
        return "request_submitted_verify_app_focus_and_lock";
    }
}
