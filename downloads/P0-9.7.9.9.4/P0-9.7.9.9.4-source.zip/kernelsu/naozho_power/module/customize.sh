[ "$KSU" = true ] || abort "KernelSU Manager required"
[ "$API" = 36 ] || abort "This trial targets API 36"
[ "$(getprop ro.product.device)" = CPDAY10 ] || abort "This trial targets CPDAY10"
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/trial.sh" 0 0 0755
set_perm "$MODPATH/power-trial.jar" 0 0 0644
ui_print "- No boot job or mount. Action only reads source inventory."
