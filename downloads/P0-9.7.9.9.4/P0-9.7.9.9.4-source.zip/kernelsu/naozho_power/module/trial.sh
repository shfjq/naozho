#!/system/bin/sh
set -eu
umask 077
mod=/data/adb/modules/naozho_power_trial
[ "$#" = 1 ] || exit 2
case "$1" in inventory|observe|return) ;; *) exit 2 ;; esac
[ "$(id -u)" = 0 ] && [ ! -e "$mod/disable" ] && [ ! -e "$mod/remove" ] && [ ! -e "$mod/STOP" ] || exit 1
# Use this root-owned, read-only DEX only. No user-selected class, shell or destination.
export CLASSPATH="$mod/power-trial.jar"
exec /system/bin/app_process /system/bin com.naozho.power.PowerTrial "$1"
