#!/system/bin/sh
exec /system/bin/sh /data/adb/modules/naozho_power_trial/trial.sh inventory
