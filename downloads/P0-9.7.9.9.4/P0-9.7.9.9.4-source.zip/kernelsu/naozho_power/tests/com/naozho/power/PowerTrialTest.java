package com.naozho.power;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Objects;

public final class PowerTrialTest {
    interface Test { void run() throws Exception; }
    private static int count;
    private static void test(String name, Test t) throws Exception {
        t.run(); count++; System.out.println("PASS " + name);
    }
    private static void eq(Object expected, Object value) {
        if (!Objects.equals(expected,value)) throw new AssertionError(expected + " != " + value);
    }
    private static void blocked(String why, Test t) throws Exception {
        try { t.run(); }
        catch (TrialChecks.Refused e) { eq(why,e.getMessage()); return; }
        throw new AssertionError("expected " + why);
    }
    static final class Fake implements TrialHandoff.Environment {
        long now=1500, serial=7;
        boolean change, awake=true;
        int sends;
        String focus=TrialChecks.FREEME;
        @Override public boolean unchanged(long id) { return serial == id; }
        @Override public long elapsed() { return now; }
        @Override public void proveForeground(long first) throws Exception {
            if (change) serial++;
            if (!awake) throw new TrialChecks.Refused("display_not_stably_awake");
            if (!focus.equals(TrialChecks.FREEME)) throw new TrialChecks.Refused("freeme_not_focused");
        }
        @Override public void send(int boot,long first,long up) {
            eq(13,boot);eq(1000L,first);eq(1120L,up);sends++;
        }
    }
    static final String POWER = "displayGroupId=0\n mWakefulness=Awake\n mWakefulnessChanging=false\n" +
        " mLastWakeTime=710 (300 ms ago)\n mLastSleepTime=400 (610 ms ago)\n";
    static final String NODE="/dev/input/event3";
    static final String DEVICE="    8: platform keypad\n      Path: "+NODE+"\n      Enabled: true\n"+
        "      KeyLayoutFile: /vendor/usr/keylayout/keypad.kl\n      KeyCharacterMapFile: \n";
    static final String HUB="Event Hub State:\n  Devices:\n"+DEVICE;
    static int sender(String dump, String action, String id) throws Exception {
        DeliveryProof.Sample result = DeliveryProof.inspect(dump, action, id);
        if (result.invalid) throw new TrialChecks.Refused(result.reason);
        return result.uid;
    }

    public static void main(String[] args) throws Exception {
        test("physical power and volume allowed",()->eq(true,TrialChecks.dedicatedKeys("1c000000000000 0","0019")));
        test("keyboard input rejected",()->eq(false,TrialChecks.dedicatedKeys("10000000000000 2","0019")));
        test("USB input rejected",()->eq(false,TrialChecks.dedicatedKeys("10000000000000 0","0003")));
        test("odd capability mask rejected",()->eq(false,TrialChecks.dedicatedKeys("1?00 0","0019")));
        test("no power bit rejected",()->eq(false,TrialChecks.dedicatedKeys(BigInteger.TEN.toString(16),"0019")));
        test("layout scoped to Event Hub device",()->eq("/vendor/usr/keylayout/keypad.kl",TrialChecks.layout(HUB+"Input Reader State:\n"+DEVICE,NODE).kl));
        test("duplicate node rejected",()->blocked("eventhub_evidence_ambiguous",()->TrialChecks.layout(HUB+DEVICE,NODE)));
        test("absent node rejected",()->blocked("eventhub_node_missing",()->TrialChecks.layout(HUB,"/dev/input/event5")));
        test("disabled node rejected",()->blocked("eventhub_evidence_ambiguous",()->TrialChecks.layout(HUB.replace("Enabled: true","Enabled: false"),NODE)));
        test("generic layout maps 116",()->eq(true,TrialChecks.powerMapping("key 116 POWER WAKE\nkey usage 0x1 SLEEP","")));
        test("hexadecimal mapping",()->eq(true,TrialChecks.powerMapping("key 0x74 POWER  # stock","map key 1 HOME")));
        test("ambiguous mapping rejected",()->eq(false,TrialChecks.powerMapping("key 116 POWER\nkey 116 HOME","")));
        test("volume-only map rejected",()->eq(false,TrialChecks.powerMapping("key 115 VOLUME_UP","")));
        test("KCM override rejected",()->eq(false,TrialChecks.powerMapping("key 116 POWER","map key 0x74 HOME")));
        test("raw event uses kernel monotonic time",()->{
            TrialChecks.Edge e=TrialChecks.parse("[     182.123456] 0001 0074 00000001");
            eq(182123L,e.ms);eq(116,e.code);eq(1,e.value);
        });
        test("dropped events preserved",()->eq(3,TrialChecks.parse("[  182.123456] 0000 0003 00000000").code));
        test("press release and repeat preserved",()->{for(int v=0;v<=2;v++)eq(v,new TrialChecks.Edge(100,1,116,v).powerValue(104));});
        test("SYN_REPORT ignored",()->eq(-1,new TrialChecks.Edge(100,0,0,0).powerValue(104)));
        test("overrun ends trial",()->blocked("input_sync_dropped",()->new TrialChecks.Edge(100,0,3,0).powerValue(104)));
        test("modifier cancels trial",()->blocked("volume_or_chord_observed",()->new TrialChecks.Edge(100,1,115,1).powerValue(104)));
        test("HID usage ends trial",()->blocked("unexpected_event_or_usage_mapping",()->new TrialChecks.Edge(100,4,4,23).powerValue(104)));
        test("invalid value ends trial",()->blocked("unknown_key_transition",()->new TrialChecks.Edge(100,1,116,-1).powerValue(104)));
        test("kernel delivery lag rejected",()->blocked("kernel_time_unusable_or_input_delayed",()->new TrialChecks.Edge(100,1,116,1).powerValue(205)));
        test("wrong time base rejected",()->blocked("kernel_time_unusable_or_input_delayed",()->new TrialChecks.Edge(10000,1,116,1).powerValue(105)));
        test("failed clock ioctl rejected",()->blocked("kernel_monotonic_clock_unavailable",()->TrialChecks.parse("Can't enable monotonic clock reporting: denied")));
        test("input permission failure reported",()->blocked("power_node_open_denied_or_gone",()->TrialChecks.parse("could not open /dev/input/event3, Permission denied")));
        test("awake throughout accepted",()->TrialChecks.awakeSince(POWER,1000));
        test("woke after first down rejected",()->blocked("sleep_or_wake_since_first_down",()->TrialChecks.awakeSince(POWER,700)));
        test("went to sleep after first down rejected",()->blocked("sleep_or_wake_since_first_down",()->TrialChecks.awakeSince(POWER.replace("=400 ", "=1010 "),1000)));
        test("transition in progress rejected",()->blocked("display_not_stably_awake",()->TrialChecks.awakeSince(POWER.replace("Changing=false","Changing=true"),1000)));
        test("duplicate power group rejected",()->blocked("display_groups_unconfirmed",()->TrialChecks.awakeSince(POWER+" displayGroupId=1\n",1000)));
        test("missing timestamp rejected",()->blocked("power_history_unknown",()->TrialChecks.awakeSince(POWER.replace("mLastWakeTime","oldWakeTime"),1000)));
        String focused="  mCurrentFocus=Window{a34 u0 "+TrialChecks.FREEME+"}";
        test("known user-zero launcher",()->eq(TrialChecks.FREEME,TrialChecks.focus(focused)));
        test("other user rejected",()->blocked("foreground_unknown",()->TrialChecks.focus(focused.replace("u0","u10"))));
        test("duplicate windows rejected",()->blocked("foreground_unknown",()->TrialChecks.focus(focused+"\n"+focused)));
        test("fixed protected broadcast only",()->eq(Arrays.asList("/system/bin/am","broadcast","--user","0","--receiver-foreground","--exclude-stopped-packages","-n","com.naozho.clock/.mode.ConfirmedPowerReceiver","-a","com.naozho.clock.action.CONFIRMED_POWER_DOUBLE","-i","naozho.return.13.1000","--ei","boot_count","13","--el","first_elapsed","1000","--el","released_elapsed","1120"),Arrays.asList(TrialChecks.broadcast(13,1000,1120))));
        test("observation cannot submit",()->{Fake f=new Fake();eq("observed_qualified_double_no_request",new TrialHandoff().finish(false,13,7,1000,1000,1120,f));eq(0,f.sends);});
        test("one live submit even on redelivery",()->{Fake f=new Fake();TrialHandoff gate=new TrialHandoff();gate.finish(true,13,7,1000,1000,1120,f);blocked("trial_already_used",()->gate.finish(true,13,7,1000,1000,1120,f));eq(1,f.sends);});
        test("input or disable during proof",()->{Fake f=new Fake();f.change=true;blocked("input_or_trial_changed",()->new TrialHandoff().finish(true,13,7,1000,1000,1120,f));eq(0,f.sends);});
        test("expired proof suppressed",()->{Fake f=new Fake();f.now=2620;blocked("proof_too_slow_for_app_receipt",()->new TrialHandoff().finish(true,13,7,1000,1000,1120,f));eq(0,f.sends);});
        test("dialer stays foreground",()->{Fake f=new Fake();f.focus="dialer";blocked("freeme_not_focused",()->new TrialHandoff().finish(true,13,7,1000,1000,1120,f));eq(0,f.sends);});
        test("any observed sleep suppresses handoff",()->{Fake f=new Fake();f.awake=false;blocked("display_not_stably_awake",()->new TrialHandoff().finish(true,13,7,1000,1000,1120,f));eq(0,f.sends);});
        String id = "trace-01";
        String action = DeliveryProof.PROBE + id;
        String rec = "  Historical Broadcast #2:\n    BroadcastRecord{abc u0 " + action + "} to user 0\n"
                + "    Intent { act=" + action + " id=" + id + " flg=0x10000010 cmp=" + TrialChecks.RECEIVER + " }\n"
                + "    caller=com.android.shell null pid=321 uid=2000\n    terminalCount=1\n"
                + "    DELIVERED scheduled +1ms terminal +4ms (0) #0: (manifest)\n";
        test("same transport grants privilege only on terminal manifest dispatch", ()->eq(2000,sender(rec,action,id)));
        test("actual framework uid is retained", ()->eq(0,sender(rec.replace("uid=2000","uid=0"),action,id)));
        test("command completion is insufficient", ()->eq(-1,sender("Broadcast completed: result=0",action,id)));
        test("stale or unrelated receipt ignored", ()->eq(-1,sender(rec,action,"other")));
        test("missing uid fails closed", ()->eq("sender_uid", DeliveryProof.inspect(rec.replace(" uid=", " no_uid="),action,id).missing));
        test("skipped for platform permission", ()->blocked("delivery_denied_STATUS_BAR_SERVICE",()->sender(rec.replace("DELIVERED","SKIPPED")+"      reason: Permission Denial requires android.permission.STATUS_BAR_SERVICE\n",action,id)));
        test("explicit OEM autostart denial is distinguished", ()->blocked("delivery_autostart_policy_blocked",()->sender(rec.replace("DELIVERED","SKIPPED")+"      reason: Autostart blocked: broadcasting from test\n",action,id)));
        test("firewall skip remains distinct", ()->blocked("delivery_SKIPPED",()->sender(rec.replace("DELIVERED","SKIPPED"),action,id)));
        test("wrong user rejected", ()->blocked("wrong_user",()->sender(rec.replace("to user 0","to user 10"),action,id)));
        test("wrong receiver rejected", ()->blocked("wrong_component",()->sender(rec.replace(TrialChecks.RECEIVER,"other/.Receiver"),action,id)));
        test("runtime receiver not proof", ()->blocked("delivery_receiver_ambiguous",()->sender(rec.replace("(manifest)","BroadcastFilter{abc}"),action,id)));
        test("duplicate proof rejected", ()->blocked("delivery_record_mismatch",()->sender(rec+rec,action,id)));
        test("no valid gesture in permission probe", ()->eq(false,Arrays.asList(DeliveryProof.envelope(action,id)).contains("--el")));
        System.out.println("passed=" + count);
    }
}
