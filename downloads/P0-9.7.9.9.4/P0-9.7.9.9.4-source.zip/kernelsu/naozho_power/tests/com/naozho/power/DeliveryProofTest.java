package com.naozho.power;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Model the actual CP DEX print calls, including BroadcastQueueImpl.increaseIndent(). */
public final class DeliveryProofTest {
    static final String ID = "dec00000-0000-4000-8000-000000000096";
    static final String ACTION = DeliveryProof.PROBE + ID;
    static final String INTENT = "Intent { act=" + ACTION + " id=" + ID + " cmp=" + TrialChecks.RECEIVER + " }";
    static final String ROW = "DELIVERED scheduled +21ms terminal +7ms (0) #0: (manifest)";
    static final String DETAIL = "    Historical Broadcast #0:\n"
            + "      BroadcastRecord{abc " + ACTION + "/u0} to user 0\n"
            + "      " + INTENT + "\n      caller=null null pid=12 uid=0\n      terminalCount=1\n      " + ROW + "\n";
    static final String DUMP = "ACTIVITY MANAGER BROADCAST STATE (dumpsys activity broadcasts)\n"
            + "    Pending broadcasts:\n      <empty>\n    Historical broadcasts:\n" + DETAIL;
    static int count;

    static DeliveryProof.Sample parse(String s) { return DeliveryProof.inspect(s, ACTION, ID); }

    static void check(String label, boolean result) {
        if (!result) throw new AssertionError(label);
        count++;
        System.out.println("PASS " + label);
    }

    static final class Reads implements DeliveryProof.History {
        final List<String> samples, reports = new ArrayList<>();
        final List<Boolean> views = new ArrayList<>();
        int sleep;
        Reads(String... input) { samples = Arrays.asList(input); }
        @Override public String read(boolean all) {
            views.add(all);
            return samples.get(views.size()-1);
        }
        @Override public void waitMs(int ms) { sleep += ms; }
        @Override public void report(String text) { reports.add(text); }
    }

    public static void main(String[] args) throws Exception {
        check("firmware queue wrapper with extra indent", parse(DUMP).uid == 0);
        check("trimmed first header and CRLF", parse(DETAIL.trim().replace("\n","\r\n")).uid == 0);
        check("blank record line is harmless", parse(DUMP.replace("      caller=", "\n      caller=")).uid == 0);
        check("canonical long component spelling", parse(DUMP.replace(TrialChecks.RECEIVER,
                "com.naozho.clock/com.naozho.clock.mode.ConfirmedPowerReceiver")).uid == 0);
        String noId = DUMP.replace(" id=" + ID, "");
        check("UUID in action does not replace identifier", parse(noId).uid < 0 && parse(noId).reason.equals("identifier_missing"));
        String stale = DUMP.replace(" id=" + ID, " id=" + ID + "1");
        check("other identifier distinguished", parse(stale).reason.equals("no_matching_identifier"));
        String partial = DUMP.replace(" pid=12 uid=0"," pid=12").replace(ROW,"");
        check("reports both missing fields", parse(partial).missing.equals("sender_uid,receiver_state"));
        check("another record cannot supply uid or row", parse(partial + DETAIL.replace(ID,"unrelated")).uid < 0);
        check("nested caller is not the sender", parse(DUMP.replace("      caller=", "        caller=")).uid < 0);
        check("duplicate sender rejected", parse(DUMP.replace("uid=0", "uid=0 uid=23")).invalid);
        check("different user cannot pass", parse(DUMP.replace("to user 0", "to user 10")).invalid);
        check("duplicate terminal records rejected", parse(DUMP + DETAIL).invalid);
        check("second receiver rejects whole record", parse(DUMP + "      " + ROW.replace("#0:", "#1:")).invalid);
        check("other stage or target refused", parse(DUMP.replace("act="+ACTION, "act=other")).invalid);
        check("non-manifest delivery refused", parse(DUMP.replace("(manifest)", "BroadcastFilter{a}")).invalid);
        check("wrong component retained as explicit failure", parse(DUMP.replace(TrialChecks.RECEIVER, "other/.R")).reason.equals("wrong_component"));
        check("unsupported receiver state cannot pass", parse(DUMP.replace("DELIVERED","NEW_STATE")).reason.equals("unsupported_state_format"));
        String pending = "    Pending broadcasts:\n  Pending  broadcast #0:\n" + DETAIL.substring(DETAIL.indexOf("      BroadcastRecord"));
        check("pending cannot prove historical delivery", parse(pending).pending && parse(pending).uid < 0);
        String brief = "    Historical broadcasts summary:\n    #0: " + INTENT;
        check("summary cannot prove delivery", parse(brief).summary && parse(brief).uid < 0);
        String excerpt = "      BroadcastRecord{abc " + ACTION + "/u0} to user 0\n      " + INTENT
                + "\n          name=com.naozho.clock.mode.ConfirmedPowerReceiver\n"
                + "      Intent { act=other cmp=other/.Receiver }\n"
                + "      DELIVERED scheduled 0 terminal +1ms (-1) #0: BroadcastFilter{unrelated}\n"
                + "    #1: act=" + ACTION + " id=" + ID + " cmp=" + TrialChecks.RECEIVER;
        check("redacted device excerpt: exact intent is diagnostic only",
                parse(excerpt).uid < 0 && parse(excerpt).reason.equals("matching_intent_outside_terminal_record")
                && parse(excerpt).missing.equals("history_boundary,linked_sender_uid,linked_manifest_state"));
        String log = "Broadcast completed: result=0\nDouble rejected at receiver; no activity requested";
        check("command and app log do not prove delivery", parse(log).uid < 0 && parse(log).records == 0);
        Reads late = new Reads(pending, partial, DUMP);
        check("wait for independently complete later sample", DeliveryProof.verify(ACTION, ID, late) == 0
                && late.views.equals(Arrays.asList(false,false,false)) && late.sleep == 800);
        Reads fallback = new Reads(brief,brief,brief,DUMP);
        check("bounded full-history fallback", DeliveryProof.verify(ACTION, ID, fallback) == 0
                && fallback.views.equals(Arrays.asList(false,false,false,true)) && fallback.sleep == 1800);
        Reads quick = new Reads(brief, DUMP);
        check("wake obtains the same terminal UID without fixed waiting", DeliveryProof.verify(ACTION, ID, quick, true) == 0
                && quick.views.equals(Arrays.asList(false,true)) && quick.sleep == 0);
        DeliveryProof.ViewHint hint = new DeliveryProof.ViewHint();
        Reads learn = new Reads(brief, DUMP);
        check("successful terminal history learns preferred view only", DeliveryProof.verify(ACTION, ID, learn, true, hint)==0
                && hint.fullFirst && learn.views.equals(Arrays.asList(false,true)));
        Reads next = new Reads(DUMP.replace("uid=0","uid=2000"));
        check("learned view verifies next sender independently", DeliveryProof.verify(ACTION, ID, next, true, hint)==2000
                && next.views.equals(Arrays.asList(true)));
        Reads changedView = new Reads(brief, DUMP);
        check("filtered view can still supply the only complete new proof", DeliveryProof.verify(ACTION, ID, changedView, true, hint)==0
                && !hint.fullFirst && changedView.views.equals(Arrays.asList(true,false)));
        hint.fullFirst = true;
        Reads conflict = new Reads(DUMP.replace("act="+ACTION, "act=another"));
        try { DeliveryProof.verify(ACTION, ID, conflict, true, hint); throw new AssertionError("ignored duplicate id action"); }
        catch (TrialChecks.Refused e) {
            check("same id wrong action is final even in preferred full view", e.getMessage().equals("wrong_action")
                    && conflict.views.equals(Arrays.asList(true)));
        }
        String unrelated = DETAIL.replace(ID, "unrelated");
        check("unrelated entries do not hide conflict across records", parse(DUMP+unrelated+DETAIL).invalid);
        Reads slow = new Reads(brief, pending, partial, noId, DUMP);
        check("wake waits for slow terminal record and never joins partial evidence",
                DeliveryProof.verify(ACTION, ID, slow, true) == 0 && slow.sleep == 1800);
        int[] recoveryReads = {0};
        check("unavailable early broad history retains later strict filtered proof",
                DeliveryProof.verify(ACTION, ID, new DeliveryProof.History() {
                    public String read(boolean all) throws Exception {
                        ++recoveryReads[0];
                        if (all) throw new Exception("broad size limit");
                        return recoveryReads[0] == 1 ? brief : DUMP;
                    }
                    public void waitMs(int ms) {}
                    public void report(String message) {}
                }, true) == 0 && recoveryReads[0] == 3);
        Reads split = new Reads(partial, DUMP.replace(INTENT,""), noId, brief);
        try { DeliveryProof.verify(ACTION, ID, split); throw new AssertionError("merged samples"); }
        catch (TrialChecks.Refused e) {
            check("unconfirmed after four reads without redelivery", e.getMessage().equals("history_unconfirmed_summary_only")
                    && split.reports.size() == 4 && split.reports.get(0).contains("sender_uid,receiver_state"));
        }
        Reads denied = new Reads(DUMP.replace("DELIVERED","SKIPPED") + "        reason: Permission Denial requires " + DeliveryProof.PERMISSION);
        try { DeliveryProof.verify(ACTION, ID, denied); throw new AssertionError("accepted denial"); }
        catch (TrialChecks.Refused e) {
            check("denial is immediate and specific", e.getMessage().equals("delivery_denied_STATUS_BAR_SERVICE") && denied.views.size() == 1);
        }
        String returnHistory = DUMP.replace(ACTION,TrialChecks.ACTION).replace(" id="+ID," id=naozho.return.36.12500");
        check("real return uses same strict proof", DeliveryProof.inspect(returnHistory,TrialChecks.ACTION,"naozho.return.36.12500").uid == 0
                && DeliveryProof.inspect(returnHistory,TrialChecks.ACTION,"naozho.return.36.12501").uid < 0);
    }
}
