package com.naozho.power;

import android.os.Build;
import java.nio.file.*;

public final class TimingSetup {
    static final Path DATA=Paths.get("/data/adb/naozho_power_daily_timing");
    static final String KEY="multi_press_timeout";
    static String current() throws Exception {
        return DailyBoard.cmd("/system/bin/settings","--user","0","get","secure",KEY);
    }
    public static void main(String[] args) {
        try {
            if (android.os.Process.myUid()!=0 || Build.VERSION.SDK_INT!=36 ||
                !"CPDAY10".equals(DailyBoard.cmd("/system/bin/getprop","ro.product.device")) ||
                !"0".equals(DailyBoard.cmd("/system/bin/am","get-current-user"))) throw new TrialChecks.Refused("wrong_device_or_user");
            if (args.length==1 && args[0].equals("status")) {
                String value=current();
                if (!value.matches("null|[0-9]{1,9}")) throw new TrialChecks.Refused("timing_value_unknown");
                System.out.println("setting="+value+" lease="+(Files.exists(DATA.resolve("lease"))?
                        String.join("/",TimingLease.lease(DATA.resolve("lease"))):"none"));
                return;
            }
            boolean restore=args.length==1 && args[0].equals("restore");
            if (!restore && !(args.length==2 && args[0].equals("prepare") && args[1].matches(TimingLease.PRESETS)))
                throw new TrialChecks.Refused("timing_arguments");
            boolean armed=Files.exists(DailyBoard.DIR.resolve("armed"));
            boolean disabled=Files.exists(DailyBoard.DIR.resolve("disable")) || Files.exists(DailyBoard.DIR.resolve("remove")) || Files.exists(DailyBoard.DIR.resolve("STOP"));
            if (armed && !(restore && disabled)) throw new TrialChecks.Refused("disarm_first");
            TimingLease.change(DATA,new TimingLease.Setting() {
                public String read() throws Exception { return current(); }
                public void write(String value) throws Exception {
                    if (value.equals("null")) DailyBoard.cmd("/system/bin/settings","--user","0","delete","secure",KEY);
                    else DailyBoard.cmd("/system/bin/settings","--user","0","put","secure",KEY,value);
                }
            },restore?null:args[1]);
            System.out.println("timing_readback_verified; normal reboot may be needed for policy cache");
        } catch (Exception e) { System.err.println("STOP "+DailyPower.reason(e)); System.exit(1); }
    }
}
