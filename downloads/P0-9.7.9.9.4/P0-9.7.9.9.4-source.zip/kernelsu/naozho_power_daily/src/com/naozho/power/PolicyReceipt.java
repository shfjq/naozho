package com.naozho.power;

import java.util.regex.*;

/** CPDAY10 system_server's WindowManager.powerPress trace. Match the second physical DOWN
 * on the same uptime clock; a setting readback alone cannot prove the cached policy changed. */
final class PolicyReceipt {
    private static final Pattern PRESS=Pattern.compile("^powerPress: eventTime=(\\d+) interactive=(true|false) count=(\\d+) mShortPressOnPowerBehavior=(\\d+)$");
    static void confirm(String rows,long first,long second) throws TrialChecks.Refused {
        int matched=0;
        for (String row:rows.split("\n")) {
            Matcher m=PRESS.matcher(row.trim());
            if (!m.matches()) continue;
            String at=m.group(1);
            if (at.equals(Long.toString(first))) throw new TrialChecks.Refused("policy_first_press_dispatched");
            if (!at.equals(Long.toString(second))) continue;
            if (!m.group(2).equals("true") || !m.group(3).equals("2")) throw new TrialChecks.Refused("policy_not_awake_double");
            matched++;
        }
        if (matched!=1) throw new TrialChecks.Refused(matched==0?"policy_double_unconfirmed":"policy_double_ambiguous");
    }
    private PolicyReceipt() {}
}
