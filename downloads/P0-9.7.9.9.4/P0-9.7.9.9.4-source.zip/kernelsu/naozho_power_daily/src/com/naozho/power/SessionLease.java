package com.naozho.power;

import java.io.IOException;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/** An arm token identifies one explicit enable, including across boots. */
final class SessionLease {
    static String token(Path path) {
        try {
            if (!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS) || Files.size(path)>64) return "";
            String t=new String(Files.readAllBytes(path),StandardCharsets.US_ASCII).trim();
            return t.matches("[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}") ? t : "";
        } catch (IOException e) { return ""; }
    }
    static boolean enabled(Path dir,String expected) {
        return expected!=null && !expected.isEmpty() && expected.equals(token(dir.resolve("armed")))
                && Files.isRegularFile(dir.resolve("module.prop")) && !Files.exists(dir.resolve("disable"))
                && !Files.exists(dir.resolve("remove")) && !Files.exists(dir.resolve("STOP"));
    }
    static FileLock claim(FileChannel channel, Path dir,String expected) throws Exception {
        // A new explicit enable may arrive while the previous token is shutting down.
        for (int retry=0; retry<12 && enabled(dir,expected); retry++) {
            FileLock got=channel.tryLock();
            if (got!=null) return got;
            if (expected.equals(token(dir.resolve("running")))) return null;
            Thread.sleep(200);
        }
        return null;
    }
    private SessionLease() {}
}
