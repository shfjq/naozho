package com.naozho.power;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/** Optional one-shot measurement for DSH. Never decides, delays or submits a return. */
final class TimingSample {
    private final Path dir;
    private String ticket;
    private long start, firstUp=-1, next=-1, expiry, suspendOffset;
    TimingSample(Path dir) { this.dir=dir; }
    void edge(int edge,long uptime,long now,long currentUptime,int boot) throws IOException {
        Path request=dir.resolve("sample-request");
        if (ticket==null) {
            if (edge!=1 || !Files.isRegularFile(request) || Files.size(request)>72) return;
            String line=new String(Files.readAllBytes(request),StandardCharsets.US_ASCII).trim();
            Files.deleteIfExists(request);
            if (!line.matches("[a-f0-9]{16} [0-9]{1,9} [0-9]{1,15}")) return;
            String[] fields=line.split(" ");
            expiry=Long.parseLong(fields[2]);
            if (Integer.parseInt(fields[1])!=boot || expiry<=now || expiry-now>31000) return;
            ticket=fields[0]; start=uptime; firstUp=next=-1; suspendOffset=now-currentUptime;
        } else if (now>expiry || uptime<start || uptime-start>4000 || edge==2) {
            finish("invalid_or_expired");
        } else if (firstUp<0 && edge==0) {
            firstUp=uptime;
        } else if (firstUp>=0 && next<0 && edge==1) {
            next=uptime;
        } else if (next>=0 && edge==0) {
            finish("gap_ms="+(next-start)+" hold1_ms="+(firstUp-start)+" hold2_ms="+(uptime-next)+
                    " suspend_suspected="+(Math.abs(now-currentUptime-suspendOffset)>25));
        } else finish("invalid_sequence");
    }
    private void finish(String result) throws IOException {
        Path tmp=dir.resolve("sample.tmp");
        Files.write(tmp,(ticket+" "+result+"\n").getBytes(StandardCharsets.US_ASCII));
        Files.move(tmp,dir.resolve("sample-result"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
        ticket=null;
    }
}
