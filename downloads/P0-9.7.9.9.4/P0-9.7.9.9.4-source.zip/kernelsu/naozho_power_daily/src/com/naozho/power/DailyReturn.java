package com.naozho.power;

/** One distinct physical sequence per attempt; successful independent gestures can recur.
 * Ambiguous dispatch or failed identity proof stops this session until explicitly re-armed. */
final class DailyReturn {
    interface Device {
        boolean fresh(long serial,long released);
        void identity() throws Exception;
        String foreground(long uptime,long elapsed) throws Exception;
        int probe() throws Exception;
        boolean send(long first,long released,int uid) throws Exception;
        void veto(String reason) throws Exception;
    }
    private long lastFirst=-1;
    private int uid=-1;
    private boolean failed;

    void prove(Device device) throws Exception {
        uid=device.probe();
        if (uid<0) throw new TrialChecks.Refused("sender_unconfirmed");
    }
    private String page(Device d,long up,long first) throws Exception {
        try { return d.foreground(up,first); }
        catch (Exception unavailable) {
            d.veto(unavailable instanceof TrialChecks.Refused?unavailable.getMessage():"context_unavailable");
            return null;
        }
    }
    boolean finish(Device d,long serial,long uptime,long first,long released) throws Exception {
        if (failed || first<=lastFirst || !d.fresh(serial,released)) return false;
        lastFirst=first;
        try {
            d.identity();
            String initial=page(d,uptime,first);
            if (initial==null) return false;
            if (uid<0) {
                prove(d);
                if (!initial.equals(page(d,uptime,first))) { d.veto("context_changed"); return false; }
            }
            if (!d.fresh(serial,released)) { d.veto("stale_or_cancelled"); return false; }
            return d.send(first,released,uid);
        } catch (Exception uncertain) {
            failed=true;
            throw uncertain;
        }
    }
}
