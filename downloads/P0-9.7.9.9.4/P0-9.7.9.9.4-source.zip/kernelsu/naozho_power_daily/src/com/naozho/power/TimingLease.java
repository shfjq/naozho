package com.naozho.power;

import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.ByteBuffer;

/** Journal one user-0 SettingsProvider value. Keep the original across retries and updates. */
final class TimingLease {
    static final int DEFAULT=600;
    static final String PRESETS="400|500|600|700|800|1000";
    interface Setting {
        String read() throws Exception;
        void write(String value) throws Exception;
    }
    static String[] lease(Path file) throws Exception {
        if (!Files.isRegularFile(file) || Files.size(file)>64) throw new TrialChecks.Refused("timing_not_prepared");
        String row=new String(Files.readAllBytes(file),StandardCharsets.US_ASCII);
        if (!row.matches("(null|[0-9]{1,9}) ("+PRESETS+")")) throw new TrialChecks.Refused("timing_journal_invalid");
        return row.split(" ");
    }
    static int active(Path file, String current) throws Exception {
        String target=lease(file)[1];
        if (!target.equals(current)) throw new TrialChecks.Refused("timing_setting_changed");
        return Integer.parseInt(target);
    }
    static void change(Path dir, Setting setting, String target) throws Exception {
        Files.createDirectories(dir);
        try (FileChannel ch=FileChannel.open(dir.resolve("lock"),StandardOpenOption.WRITE,StandardOpenOption.CREATE);
             FileLock lock=ch.tryLock()) {
            if (lock==null) throw new TrialChecks.Refused("timing_busy");
            Path file=dir.resolve("lease");
            String current=setting.read();
            if (!current.matches("null|[0-9]{1,9}")) throw new TrialChecks.Refused("timing_value_unknown");
            if (target==null && !Files.exists(file)) return;
            if (target!=null && !target.matches(PRESETS)) throw new TrialChecks.Refused("timing_preset_unknown");
            String[] row=Files.exists(file)?lease(file):new String[]{current,target};
            if (!current.equals(row[0]) && !current.equals(row[1])) throw new TrialChecks.Refused("timing_external_change");
            if (target!=null && !target.equals(row[1])) throw new TrialChecks.Refused("restore_before_new_preset");
            if (!Files.exists(file)) {
                Path tmp=dir.resolve("lease.tmp");
                try (FileChannel out=FileChannel.open(tmp,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING,StandardOpenOption.WRITE)) {
                    ByteBuffer bytes=ByteBuffer.wrap((row[0]+" "+target).getBytes(StandardCharsets.US_ASCII));
                    while (bytes.hasRemaining()) out.write(bytes);
                    out.force(true);
                }
                Files.move(tmp,file,StandardCopyOption.ATOMIC_MOVE);
                // Commit the rollback record before changing SettingsProvider.
                try (FileChannel directory=FileChannel.open(dir,StandardOpenOption.READ)) { directory.force(true); }
            }
            String desired=target==null?row[0]:target;
            if (!desired.equals(current)) setting.write(desired);
            if (!desired.equals(setting.read())) throw new TrialChecks.Refused("timing_readback_mismatch");
            if (target==null) Files.delete(file);
        }
    }
    private TimingLease() {}
}
