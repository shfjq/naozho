package com.naozho.power;

final class DailyInput {
    static native int openPower(int major, int minor, boolean hasUsageMappings);
    static native int watch();
    static native long next(int descriptor, int watch);
    static native void closePower(int descriptor);
    private DailyInput() {}
}
