package com.naozho.power;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** WindowFrames are in display coordinates, as is WindowState.getTouchableRegion(). */
final class WindowGeometry {
    private static final String N="(-?\\d{1,6})";
    private static final String RECT="\\["+N+","+N+"\\]\\["+N+","+N+"\\]";
    private static final Pattern FRAMES=Pattern.compile("(?m)^[ \\t]*Frames: parent=[^\\r\\n]+? display="+RECT+" frame="+RECT+"(?: |$)");
    private static final Pattern REGION=Pattern.compile("(?m)^[ \\t]*touchable region=(.*)$");
    private static final Pattern PIECE=Pattern.compile("\\("+N+", *"+N+", *"+N+", *"+N+"\\)");
    final boolean valid,edge;
    final String region;
    private WindowGeometry(boolean valid,boolean edge,String region) { this.valid=valid; this.edge=edge; this.region=region; }
    static WindowGeometry parse(String body) {
        Matcher m=FRAMES.matcher(body);
        if (!m.find()) return new WindowGeometry(false,false,"unknown");
        int[] p=new int[8];
        for (int i=0;i<8;i++) p[i]=Integer.parseInt(m.group(i+1));
        boolean valid=!m.find() && p[0]<=p[4] && p[1]<=p[5] && p[2]>=p[6] && p[3]>=p[7] && p[4]<p[6] && p[5]<p[7];
        boolean edge=valid && ((p[4]==p[0] || p[6]==p[2]) && 6*(p[6]-p[4])<=p[2]-p[0] ||
                    (p[5]==p[1] || p[7]==p[3]) && 6*(p[7]-p[5])<=p[3]-p[1]);
        return new WindowGeometry(valid,edge,region(body,p));
    }
    private static String region(String body,int[] p) {
        Matcher insets=Pattern.compile("(?m)^[ \\t]*mTouchableInsets=(\\d+) mGivenInsetsPending=(true|false)[ \\t]*$").matcher(body);
        boolean custom=false;
        if (body.contains("mTouchableInsets=")) {
            if (!insets.find() || !insets.group(1).matches("[0-3]") || insets.group(2).equals("true")) return "unknown";
            custom=!insets.group(1).equals("0");
            if (insets.find()) return "unknown";
        }
        Matcher field=REGION.matcher(body);
        if (!field.find()) return custom?"missing":"default_frame";
        String text=field.group(1).trim();
        if (field.find() || !text.startsWith("SkRegion(") || !text.endsWith(")")) return "unknown";
        String list=text.substring(9,text.length()-1);
        if (list.isEmpty()) return "empty";
        Matcher piece=PIECE.matcher(list);
        int pos=0;
        while (pos<list.length()) {
            if (!piece.region(pos,list.length()).lookingAt()) return "unknown";
            int l=Integer.parseInt(piece.group(1)), t=Integer.parseInt(piece.group(2)),
                r=Integer.parseInt(piece.group(3)), b=Integer.parseInt(piece.group(4));
            if (r<=l || b<=t) return "unknown";
            if (l<p[4] || t<p[5] || r>p[6] || b>p[7]) return "outside";
            pos=piece.end();
        }
        return "in_frame";
    }
    boolean boundedRegion() { return region.equals("default_frame") || region.equals("in_frame") || region.equals("empty"); }
}
