// CPDAY10 arm64: one read-only evdev file description, per-client filters only.
#include <jni.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <poll.h>
#include <sys/inotify.h>

static int has(const uint8_t *bytes, unsigned bit) {
    return (bytes[bit / 8] >> (bit % 8)) & 1;
}

static int configure(int fd, unsigned expected_major, unsigned expected_minor, int usage_map) {
    struct stat st;
    uint8_t keys[KEY_CNT/8] = {0}, types[(EV_CNT+7)/8] = {0};
    if (fstat(fd, &st) || !S_ISCHR(st.st_mode) ||
        major(st.st_rdev) != expected_major || minor(st.st_rdev) != expected_minor ||
        ioctl(fd, EVIOCGBIT(0, sizeof types), types) < 0 ||
        ioctl(fd, EVIOCGBIT(EV_KEY, sizeof keys), keys) < 0 || !has(keys, KEY_POWER)) return -1;
    for (unsigned k=0; k<KEY_CNT; ++k)
        if (has(keys,k) && k != KEY_POWER && k != KEY_VOLUMEUP && k != KEY_VOLUMEDOWN) return -1;
    // No scan-to-usage override may alter scan 116. If the layout has usage overrides,
    // a source capable of MSC_SCAN is ambiguous even though our own fd masks MSC.
    if (has(types,EV_MSC) && usage_map) return -1;
    // Exclude touch, joystick, switches, LEDs and unrelated peripherals.
    for (unsigned t=0; t<EV_CNT; ++t)
        if (has(types,t) && t != EV_SYN && t != EV_KEY && t != EV_REP && t != EV_MSC) return -1;

    memset(keys,0,sizeof keys);
    keys[KEY_POWER/8] = 1U << (KEY_POWER%8);
    struct input_mask key_mask = { .type=EV_KEY, .codes_size=sizeof keys, .codes_ptr=(uintptr_t)keys };
    if (ioctl(fd, EVIOCSMASK, &key_mask) < 0) return -1;
    uint8_t check[sizeof keys] = {0};
    key_mask.codes_ptr=(uintptr_t)check;
    if (ioctl(fd, EVIOCGMASK, &key_mask) < 0 || memcmp(keys,check,sizeof keys)) return -1;

    uint8_t kept[sizeof(unsigned long)] = {0};
    kept[EV_KEY/8] = 1U << (EV_KEY%8); // EV_SYN mask indexes event TYPES in evdev.
    struct input_mask kinds = {.type=EV_SYN, .codes_size=sizeof kept, .codes_ptr=(uintptr_t)kept};
    if (ioctl(fd, EVIOCSMASK, &kinds) < 0) return -1;
    uint8_t echo[sizeof kept] = {0};
    kinds.codes_ptr=(uintptr_t)echo;
    if (ioctl(fd, EVIOCGMASK, &kinds) < 0 || memcmp(kept,echo,sizeof echo)) return -1;
    int clock_id = CLOCK_MONOTONIC;
    return ioctl(fd, EVIOCSCLOCKID, &clock_id);
}

JNIEXPORT jint JNICALL Java_com_naozho_power_DailyInput_openPower(JNIEnv *env, jclass cls, jint maj, jint min, jboolean usage_map) {
    (void)env; (void)cls;
    int fd=open("/dev/input/event1", O_RDONLY|O_CLOEXEC|O_NOFOLLOW);
    if (fd >= 0 && configure(fd, (unsigned)maj, (unsigned)min, usage_map) < 0) { close(fd); return -1; }
    return fd;
}

#define MOD "/data/adb/modules/naozho_power_daily"

JNIEXPORT jint JNICALL Java_com_naozho_power_DailyInput_watch(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    int fd=inotify_init1(IN_CLOEXEC|IN_NONBLOCK);
    if (fd >= 0 && inotify_add_watch(fd, MOD, IN_CREATE|IN_DELETE|IN_MOVED_TO|IN_MOVED_FROM|
                                     IN_MOVE_SELF|IN_DELETE_SELF|IN_ATTRIB|IN_CLOSE_WRITE)<0) {
        close(fd); return -1;
    }
    return fd;
}

static int revoked(int wd) {
    union { struct inotify_event align; char bytes[4096]; } buffer;
    ssize_t n=read(wd,buffer.bytes,sizeof buffer.bytes);
    if (n<0) return errno!=EAGAIN && errno!=EINTR;
    for (size_t pos=0; pos<(size_t)n; ) {
        const struct inotify_event *e=(void *)(buffer.bytes+pos);
        if ((e->mask & (IN_IGNORED|IN_MOVE_SELF|IN_DELETE_SELF|IN_Q_OVERFLOW|IN_UNMOUNT)) ||
            (e->len && (!strcmp(e->name,"disable") || !strcmp(e->name,"remove") ||
                        !strcmp(e->name,"STOP") || !strcmp(e->name,"armed") ||
                        !strcmp(e->name,"module.prop")))) return 1;
        pos+=sizeof *e + e->len;
    }
    return 0;
}

// Return packed monotonic milliseconds and power edge. Never export arbitrary input data.
JNIEXPORT jlong JNICALL Java_com_naozho_power_DailyInput_next(JNIEnv *env, jclass cls, jint fd, jint wd) {
    (void)env; (void)cls;
    for (;;) {
        struct pollfd fds[]={{wd,POLLIN,0},{fd,POLLIN,0}};
        int count=poll(fds,2,-1);
        if (count<0 && errno==EINTR) continue;
        if (count<=0 || ((fds[0].revents|fds[1].revents)&(POLLERR|POLLHUP|POLLNVAL))) return -1;
        if ((fds[0].revents&POLLIN) && revoked(wd)) return -2;
        if (!(fds[1].revents&POLLIN)) continue;
        struct input_event event;
        ssize_t n=read(fd,&event,sizeof event);
        if (n<0 && errno==EINTR) continue;
        if (n!=sizeof event) return -1;
        if (event.type==EV_SYN && event.code==SYN_DROPPED) return -1;
        if (event.type==EV_SYN && event.code==SYN_REPORT) continue;
        if (event.type!=EV_KEY || event.code!=KEY_POWER || event.value<0 || event.value>2) return -1;
        return ((jlong)event.time.tv_sec*1000 + event.time.tv_usec/1000)*4 + event.value;
    }
}

JNIEXPORT void JNICALL Java_com_naozho_power_DailyInput_closePower(JNIEnv *env, jclass cls, jint fd) {
    (void)env; (void)cls;
    close(fd);
}
