#!/usr/bin/env python3
"""Build the API 36, arm64-only daily adapter. Requires NDK r27d (linux-x86_64)."""
import argparse
import io
import os
import subprocess
import tempfile
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
SHARED = ROOT.parent / 'naozho_power/src/com/naozho/power'
STATION = ROOT.parents[1] / 'platform/station'
def archive(entries):
    data = io.BytesIO()
    with ZipFile(data,'w') as z:
        for name, content in sorted(entries.items()):
            info=ZipInfo(name,(2026,1,1,0,0,0))
            info.create_system=3
            info.external_attr=(0o100755 if name.endswith(('.sh','.so')) else 0o100644)<<16
            z.writestr(info,content,compress_type=ZIP_DEFLATED)
    return data.getvalue()

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    for flag in ('ndk','android-jar','d8','out'):
        cli.add_argument('--'+flag,type=Path,required=True)
    args=cli.parse_args()
    if '27.3.13750724' not in (args.ndk/'source.properties').read_text():
        cli.error('expected Android NDK r27d')
    javac=Path(os.environ['JAVA_HOME'])/'bin/javac'
    clang=args.ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android35-clang'
    with tempfile.TemporaryDirectory() as tmp:
        work=Path(tmp); classes=work/'classes'; classes.mkdir()
        dex=work/'dex'; dex.mkdir()
        src=[*sorted((ROOT/'src').rglob('*.java')), *(SHARED/n for n in ('TrialChecks.java','DeliveryProof.java','Board.java')),
             *sorted((STATION/'src').rglob('*.java')),*sorted((STATION/'android').rglob('*.java'))]
        subprocess.run([javac,'--release','11','-Xlint:all','-Werror','-cp',args.android_jar,'-d',classes,*src],check=True)
        jar=work/'in.jar'
        jar.write_bytes(archive({p.relative_to(classes).as_posix():p.read_bytes() for p in classes.rglob('*.class')}))
        subprocess.run([args.d8,'--release','--min-api','34','--lib',args.android_jar,'--output',dex,jar],check=True)
        so=work/'libpowerinput.so'
        subprocess.run([clang,'-std=c17','-Os','-Wall','-Wextra','-Werror','-fPIC','-shared','-fvisibility=hidden',
                        '-Wl,-z,relro,-z,now,-z,noexecstack,-z,max-page-size=16384,--build-id=none','-s',
                        ROOT/'native/power_input.c','-o',so],check=True)
        entries={p.name:p.read_bytes() for p in (ROOT/'module').iterdir() if p.is_file()}
        entries.update({'power.jar':archive({'classes.dex':(dex/'classes.dex').read_bytes()}),'libpowerinput.so':so.read_bytes()})
        args.out.write_bytes(archive(entries))
if __name__=='__main__':
    main()
