#!/system/bin/sh
set -eu
umask 077
mod=/data/adb/modules/naozho_power_daily
[ ! -e "$mod/disable" ] && [ ! -e "$mod/remove" ] && [ ! -e "$mod/STOP" ] || { echo "Module disabled"; exit 1; }
if [ -e "$mod/armed" ]; then
  rm -f "$mod/armed"
  echo "Daily shortcut disarmed"
else
  cat /proc/sys/kernel/random/uuid > "$mod/arm.$$"
  mv -f "$mod/arm.$$" "$mod/armed"
  /system/bin/sh "$mod/start.sh" enable &
  echo "Daily shortcut requested; check status for listening"
fi
