#!/system/bin/sh
/system/bin/sh /data/adb/modules/naozho_power_daily/start.sh boot &
