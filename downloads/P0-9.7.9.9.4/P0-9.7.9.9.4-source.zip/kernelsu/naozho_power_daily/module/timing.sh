#!/system/bin/sh
set -eu
umask 077
export CLASSPATH="${0%/*}/power.jar"
exec /system/bin/app_process64 /system/bin com.naozho.power.TimingSetup "$@"
