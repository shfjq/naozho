#!/system/bin/sh
mod=/data/adb/modules/naozho_power_daily
rm -f "$mod/armed"
# If Android's settings service is unavailable, keep the rollback journal.
[ ! -f /data/adb/naozho_power_daily_timing/lease ] || /system/bin/sh "${0%/*}/timing.sh" restore
