#!/system/bin/sh
set -eu
umask 077
mod=/data/adb/modules/naozho_power_daily
[ -f "$mod/armed" ] && [ ! -e "$mod/disable" ] && [ ! -e "$mod/remove" ] && [ ! -e "$mod/STOP" ] || exit 0
[ "$#" = 1 ] || exit 1
case "$1" in boot|enable) ;; *) exit 1 ;; esac
export CLASSPATH="$mod/power.jar"
exec /system/bin/app_process64 /system/bin --nice-name=naozho.power.daily com.naozho.power.DailyPower "$1" </dev/null >/dev/null 2>&1
