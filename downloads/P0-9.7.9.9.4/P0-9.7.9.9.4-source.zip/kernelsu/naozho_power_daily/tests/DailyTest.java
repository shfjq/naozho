package com.naozho.power;

import java.nio.file.*;
import java.nio.channels.*;
import java.util.List;

public final class DailyTest {
    interface Checked { void run() throws Exception; }
    static int count;
    static void ok(String name,boolean yes) {
        if (!yes) throw new AssertionError(name);
        count++; System.out.println("PASS "+name);
    }
    static void reject(String name,Checked fn) throws Exception {
        try { fn.run(); } catch (TrialChecks.Refused expected) { ok(name,true); return; }
        throw new AssertionError(name);
    }
    static String window(int n,String id,String name,String owner,String type,String flags) {
        return "  Window #"+n+" Window{"+id+" u0 "+name+"}:\n    mDisplayId=0 taskId=3 mSession={}\n"
            +"    mOwnerUid=10001 showForAllUsers=false package="+owner+" appop=NONE\n"
            +"    mAttrs={(0,0)(fillxfill) ty="+type+" fmt=TRANSLUCENT\n      fl="+flags+"}\n"
            +"    isOnScreen=true\n    isVisible=true\n    mHasSurface=true isReadyForDisplay()=true\n"
            +"    mViewVisibility=0x0 mHaveFrame=true mObscured=false\n"
            +"    Frames: parent=[0,0][720,720] display=[0,0][720,720] frame=[0,0][720,35] last=[0,0][720,35] insetsChanged=false\n";
    }
    static final class Device implements DailyReturn.Device {
        int probes,sends,contexts; boolean paused,late,denied,change;
        String page="settings";
        public boolean fresh(long s,long r) { return !late; }
        public void identity() {}
        public String foreground(long u,long e) throws Exception {
            contexts++; if (paused) throw new TrialChecks.Refused("paused");
            return change && contexts>1?"other":page;
        }
        public int probe() throws Exception { probes++; if (denied) throw new TrialChecks.Refused("no_proof"); return 123; }
        public boolean send(long f,long r,int uid) throws Exception { sends++; if (uid!=123 || denied) throw new TrialChecks.Refused("unconfirmed"); return true; }
        public void veto(String s) {}
    }
    static void timing(Path dir) throws Exception {
        final class Value implements TimingLease.Setting {
            String value="null"; boolean drop;
            public String read(){return value;}
            public void write(String v){if(!drop)value=v;}
        }
        TimingSample sample=new TimingSample(dir);
        Path request=dir.resolve("sample-request"), result=dir.resolve("sample-result");
        sample.edge(1,1,1,1,38); ok("no diagnostic without explicit ticket",!Files.exists(result));
        Files.writeString(request,"0123456789abcdef 38 30000");
        sample.edge(1,1000,1000,1000,38); sample.edge(0,1100,1100,1100,38);
        sample.edge(1,1600,1600,1600,38); sample.edge(0,1665,1665,1665,38);
        ok("one shot measures exact rejected boundary without recording edges",Files.readString(result).trim().equals("0123456789abcdef gap_ms=600 hold1_ms=100 hold2_ms=65 suspend_suspected=false"));
        Files.delete(result);
        Files.writeString(request,"0123456789abcdef 37 30000"); sample.edge(1,1700,1700,1700,38);
        ok("sample ticket from previous boot ignored",!Files.exists(request) && !Files.exists(result));
        Value value=new Value();
        for (int ms:new int[]{400,500,600,700,800,1000}) {
            TimingLease.change(dir,value,Integer.toString(ms));
            ok("prepare "+ms,TimingLease.active(dir.resolve("lease"),value.read())==ms);
            TimingLease.change(dir,value,Integer.toString(ms));
            ok("idempotent original preserved "+ms,TimingLease.lease(dir.resolve("lease"))[0].equals("null"));
            TimingLease.change(dir,value,null);
            ok("restore absent "+ms,value.read().equals("null") && !Files.exists(dir.resolve("lease")));
        }
        value.value="300"; value.drop=true;
        reject("journal survives missing readback",()->TimingLease.change(dir,value,"600"));
        value.drop=false; TimingLease.change(dir,value,"600");
        value.value="900";
        reject("external timing preserved",()->TimingLease.change(dir,value,null));
        value.value="600";
        reject("restore before preset change",()->TimingLease.change(dir,value,"800"));
        TimingLease.change(dir,value,null);
        ok("restored previous numeric value",value.read().equals("300"));
        reject("unsupported preset",()->TimingLease.change(dir,value,"300"));
        String row="powerPress: eventTime=1599 interactive=true count=2 mShortPressOnPowerBehavior=1";
        PolicyReceipt.confirm(row,1000,1599); ok("real policy receipt shape",true);
        for(String bad:List.of("",row.replace("1599","1598"),row.replace("true","false"),row.replace("count=2","count=1"),
                               row+"\n"+row,row+"\n"+row.replace("1599","1000"))) {
            reject("no unique policy double "+count,()->PolicyReceipt.confirm(bad,1000,1599));
        }
        for (int w:new int[]{400,500,600,700,800,1000}) {
            for (int gap:new int[]{100,200,300,400,500,599,600,w-1,w,w+1}) {
                final int[] submitted={0};
                com.naozho.station.StationPowerArbiter keys=new com.naozho.station.StationPowerArbiter(
                    new com.naozho.station.StationPowerArbiter.Host(){
                        public long eligibleGeneration(){return 1;}
                        public boolean tryReturn(long gen,long down,long up){submitted[0]++;return true;}
                    },w,250,100);
                keys.firstDown(1,1000,true); keys.up(1,1060,false);
                keys.nextDown(1,1000+gap,false); keys.up(1,1060+gap,false);
                boolean success=keys.finish(1,1060+gap+w,true);
                ok("down gap "+gap+" at preset "+w,success==(gap<w) && submitted[0]==(gap<w?1:0));
            }
        }
    }
    public static void main(String[] args) throws Exception {
        if (args.length==2) {
            Path d=Path.of(args[0]);
            try (FileChannel ch=FileChannel.open(d.resolve("lock"),StandardOpenOption.WRITE);
                 FileLock lock=SessionLease.claim(ch,d,args[1])) { System.exit(lock==null?0:1); }
        }
        String prefix="WINDOW MANAGER WINDOWS (dumpsys window windows)\n";
        String cal=Foreground.CALC_PAGE;
        String bar=window(0,"a","StatusBar","com.android.systemui","STATUS_BAR","NOT_FOCUSABLE");
        String app=window(1,"b",cal,Foreground.CALC,"BASE_APPLICATION","HARDWARE_ACCELERATED");
        String dump=prefix+bar+app;
        Foreground.visible(dump,cal,"b"); ok("one ordinary calculator and passive bar",true);
        for (String page:List.of(TrialChecks.FREEME,"com.android.settings/com.android.settings.homepage.SettingsHomepageActivity")) {
            Foreground.visible(prefix+bar+window(1,"b",page,page.split("/")[0],"BASE_APPLICATION","HARDWARE_ACCELERATED"),page,"b");
            ok("ordinary page "+page,true);
        }
        for (String type:List.of("KEYGUARD_DIALOG","APPLICATION_OVERLAY","INPUT_METHOD","NOTIFICATION_SHADE","SYSTEM_ERROR","APPLICATION_ATTACHED_DIALOG"))
            reject("veto "+type,()->Foreground.visible(dump+window(2,"c","overlay","com.android.systemui",type,"NOT_FOCUSABLE"),cal,"b"));
        for (String changed:List.of(dump.replace("HARDWARE_ACCELERATED","SECURE"),dump.replace("HARDWARE_ACCELERATED","8192"),
                dump.replace("HARDWARE_ACCELERATED","FLAG_SECURE"),dump.replace("fl=HARDWARE","missing=HARDWARE"),
                dump.replace("ty=BASE_APPLICATION","ty=APPLICATION_STARTING"),dump.replace("u0 ","u10 "),dump.replace("Window #1","Window #3"),
                dump.replace("mDisplayId=0","mDisplayId=1"),dump.replace("StatusBar","emergency"),dump.replace("fl=NOT_FOCUSABLE","fl=0x80"),
                dump.replace("Window{b u0","Window{d u0"),dump+"  Window #malformed unknown\n",dump+"  Hiding System Alert Windows:\n")) {
            reject("unsafe or incomplete visible windows "+count,()->Foreground.visible(changed,cal,"b"));
        }
        for (String[] item:new String[][]{{"NavBar","NAVIGATION_BAR","NOT_FOCUSABLE"},
                {"SecondaryHomeHandle0","NAVIGATION_BAR_PANEL","NOT_FOCUSABLE"},
                {"SysDecor","DISPLAY_OVERLAY","NOT_FOCUSABLE NOT_TOUCHABLE"}}) {
            String chrome=window(0,"a",item[0],"com.android.systemui",item[1],item[2]);
            Foreground.visible(prefix+chrome+app,cal,"b"); ok("verified edge "+item[0],true);
            reject("fullscreen chrome "+item[0],()->Foreground.visible(prefix+chrome.replace(" frame=[0,0][720,35]"," frame=[0,0][720,720]")+app,cal,"b"));
            reject("wrong decor owner "+item[0],()->Foreground.visible(prefix+chrome.replace("com.android.systemui","demo.fake")+app,cal,"b"));
        }
        String drop=window(0,"a","ShellDropTarget","com.android.systemui","APPLICATION_OVERLAY","NOT_FOCUSABLE");
        String inactive=drop.replace("isOnScreen=true","isOnScreen=false").replace("isVisible=true","isVisible=false").replace("mViewVisibility=0x0","mViewVisibility=0x8");
        Foreground.visible(prefix+inactive+app,cal,"b"); ok("inactive drag surface",true);
        reject("visible drag overlay",()->Foreground.visible(prefix+drop+app,cal,"b"));
        reject("inconsistent inactive state",()->Foreground.visible(prefix+inactive.replace("isOnScreen=false","isOnScreen=true")+app,cal,"b"));
        String usb=window(0,"a","PRIVATE_TITLE","com.android.systemui","SYSTEM_DIALOG","0");
        Foreground.Windows diag=Foreground.inspect(prefix+usb+app,"b");
        ok("dialog and non-private evidence",diag.extras==1 && diag.veto.equals("additional_visible_window") &&
                diag.rows.get(0).contains("class=dialog") && !diag.rows.toString().contains("PRIVATE_TITLE"));
        reject("visible USB dialog",()->Foreground.verify(diag,cal));
        Foreground.visible(dump+window(2,"c","Wallpaper","vendor.wallpaper","WALLPAPER","NOT_FOCUSABLE"),cal,"b");
        ok("wallpaper behind focused window",true);
        String focus=" mCurrentFocus=Window{ab u0 "+cal+"}\n mFocusedApp=ActivityRecord{bb u0 "+cal+" t42}";
        ok("focus and activity",Foreground.focus(focus).equals(cal) && Foreground.focusId(focus).equals("ab"));
        reject("ambiguous focus",()->Foreground.focus(focus+"\n"+focus));
        reject("different focused activity",()->Foreground.focus(focus.replace("bb u0 "+cal,"bb u0 emergency/.Main")));
        ok("settings home not settings credentials",Foreground.settingsHome(Foreground.canonical("com.android.settings/.Settings")) &&
                !Foreground.settingsHome(Foreground.canonical("com.android.settings/.password.ConfirmLockPassword")));
        String filter=Foreground.settingsRouteFilter(focus);
        String record="  * Hist #0: ActivityRecord{bb u0 com.android.settings/.Settings t5}\n"
                +"    Intent { act=android.intent.action.MAIN cat=[android.intent.category.LAUNCHER] flg=0x1 cmp=com.android.settings/.Settings }\n"
                +"    rootOfTask=true task=Task{000}\n";
        for (String row:List.of(record,record.replace("flg=0x1","(has extras)"),record.replace("bb u0","cc u0"),
                record.replace("true","false"),record.replace("action.MAIN","action.CREDENTIAL"),record.replace(".Settings }",".SubSettings }"))) {
            Process probe=new ProcessBuilder("sed","-nE",filter).start();
            try(java.io.OutputStream output=probe.getOutputStream()) { output.write(row.getBytes(java.nio.charset.StandardCharsets.US_ASCII)); }
            String decoded=new String(probe.getInputStream().readAllBytes(),java.nio.charset.StandardCharsets.US_ASCII).trim();
            ok("settings launch route "+count,probe.waitFor()==0 && decoded.equals("ordinary\nroot")==row.equals(record));
        }
        String state="mLockTaskModeState=NONE\nisKeyguardShowing=false";
        Foreground.lockAndKeyguard(state); ok("unlocked and NONE",true);
        for (String bad:List.of(state.replace("NONE","LOCKED"),state.replace("NONE","PINNED"),state.replace("false","true"),"mLockTaskModeState=NONE"))
            reject("keyguard or task veto "+count,()->Foreground.lockAndKeyguard(bad));
        Foreground.callsIdle("0\n0"); ok("all slots idle",true);
        for (String bad:List.of("","0\n1","2","unknown")) reject("call gate "+count,()->Foreground.callsIdle(bad));
        String prefs="<boolean name=\"android\" value=\"true\" />\n<boolean name=\"managed_lock\" value=\"true\" />\n"
                +"<boolean name=\"managed_home\" value=\"false\" />\n<long name=\"mode_since\" value=\"51\" />";
        Foreground.mode(prefs,52); ok("new Android mode gesture",true);
        for (String bad:List.of(prefs.replace("51","52"),prefs.replace("51","55"),prefs.replace("true","false"),prefs.replace("false","true"),""))
            reject("app state veto "+count,()->Foreground.mode(bad,52));
        Device d=new Device(); DailyReturn handoff=new DailyReturn();
        for (int i=0;i<10;i++) ok("consecutive independent return "+i,handoff.finish(d,i,i,100+i,200+i));
        ok("one proved identity; ten distinct sends",d.probes==1 && d.sends==10);
        ok("duplicate refused",!handoff.finish(d,12,10,109,211)&&d.sends==10);
        d.paused=true; ok("paused",!handoff.finish(d,13,10,120,220)&&d.sends==10);
        d.paused=false; ok("queued before pause not replayed",!handoff.finish(d,14,10,120,220));
        ok("fresh after rearm",handoff.finish(d,15,10,121,221)&&d.sends==11);
        d.late=true; ok("stale",!handoff.finish(d,16,10,122,222)); d.late=false;
        d.denied=true; reject("ambiguous actual dispatch latches stop",()->handoff.finish(d,17,10,123,223));
        ok("no retry after ambiguity",!handoff.finish(d,18,10,124,224)&&d.sends==12);
        Device bad=new Device(); bad.denied=true;
        reject("no authenticated probe",()->new DailyReturn().finish(bad,1,1,1,1)); ok("no dispatch without proof",bad.sends==0);
        Device changed=new Device();changed.change=true;
        ok("context changed during lazy proof",!new DailyReturn().finish(changed,1,1,1,1) && changed.sends==0);
        Path dir=Files.createTempDirectory("daily-log");
        try {
            String token=java.util.UUID.randomUUID().toString();
            String newToken=java.util.UUID.randomUUID().toString();
            Files.writeString(dir.resolve("module.prop"),"version=1");
            ok("fresh install inactive",!SessionLease.enabled(dir,token));
            Files.writeString(dir.resolve("armed"),token);
            ok("explicit enable survives a new process",SessionLease.enabled(dir,token));
            for (String flag:List.of("disable","remove","STOP")) {
                Files.createFile(dir.resolve(flag));
                ok("revoked "+flag,!SessionLease.enabled(dir,token));
                Files.delete(dir.resolve(flag));
            }
            Files.writeString(dir.resolve("running"),token);
            try (FileChannel ch=FileChannel.open(dir.resolve("lock"),StandardOpenOption.CREATE,StandardOpenOption.WRITE);
                 FileLock lock=SessionLease.claim(ch,dir,token)) {
                ok("listener owns lifetime lock",lock!=null);
                Process second=new ProcessBuilder(Path.of(System.getProperty("java.home"),"bin/java").toString(),"-cp",
                        System.getProperty("java.class.path"),DailyTest.class.getName(),dir.toString(),token).start();
                ok("duplicate process returns without acquiring listener",second.waitFor()==0);
            }
            Files.writeString(dir.resolve("armed"),newToken);
            ok("rearm invalidates previous session",!SessionLease.enabled(dir,token) && SessionLease.enabled(dir,newToken));
            Files.writeString(dir.resolve("armed"),"");
            ok("partial token inactive",!SessionLease.enabled(dir,newToken));
            DailyLog log=new DailyLog(dir);
            for(int i=0;i<1200;i++) log.write("receiver_delivered");
            ok("two bounded log files",Files.size(dir.resolve("daily.log"))<=8192 && Files.size(dir.resolve("daily.log.1"))<=8192);
            byte[] prior=Files.readAllBytes(dir.resolve("daily.log"));
            Files.setLastModifiedTime(dir.resolve("daily.log"),java.nio.file.attribute.FileTime.fromMillis(1000));
            log.write("listening");
            ok("rotate on next event of a different UTC day",java.util.Arrays.equals(prior,Files.readAllBytes(dir.resolve("daily.log.1"))));
            log.veto("keyguard"); long size=Files.size(dir.resolve("daily.log")); log.veto("keyguard");
            ok("veto logs rate limited",Files.size(dir.resolve("daily.log"))==size);
            log.veto("active_panel_or_ime",diag,501);
            String meta=Files.readString(dir.resolve("last-veto"));
            ok("latest veto replaced within log limit",meta.contains("last_veto_reason=active_panel_or_ime") && meta.contains("extra_windows=1") && meta.contains("down_gap_ms=501") && !meta.contains("PRIVATE_TITLE"));
            timing(dir);
        } finally { for(String name:List.of("last-veto","daily.log","daily.log.1","status","armed","running","module.prop","lock"))Files.deleteIfExists(dir.resolve(name));Files.delete(dir); }
        System.out.println("Daily JVM cases "+count);
    }
}
