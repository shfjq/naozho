// Run the shipped read loop and driver-configuration code on Linux; the ioctl device
// response is simulated. Pipes and inotify are real. Never open a physical input node.
#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <pthread.h>
#include <dirent.h>
#include <sys/resource.h>
#include "../native/power_input.c"

static uint8_t stored[EV_CNT][KEY_CNT/8];
static int extra_key, extra_type, msc, corrupt, mask_calls, writes;
int __wrap_fstat(int fd,struct stat *s) {
    (void)fd; memset(s,0,sizeof *s); s->st_mode=S_IFCHR; s->st_rdev=makedev(13,65); return 0;
}
int __wrap_ioctl(int fd,unsigned long req,...) {
    (void)fd;
    va_list ap; va_start(ap,req); void *p=va_arg(ap,void*); va_end(ap);
    if(req==EVIOCGBIT(0,(EV_CNT+7)/8)) {
        uint8_t *b=p; b[0]=1|(1<<EV_KEY)|(msc?(1<<EV_MSC):0)|(extra_type?(1<<EV_ABS):0); return 0;
    }
    if(req==EVIOCGBIT(EV_KEY,KEY_CNT/8)) {
        uint8_t *b=p; b[KEY_POWER/8]|=1<<(KEY_POWER%8);b[KEY_VOLUMEUP/8]|=1<<(KEY_VOLUMEUP%8);
        if(extra_key)b[KEY_A/8]|=1<<(KEY_A%8);
        return 0;
    }
    if(req==EVIOCSMASK || req==EVIOCGMASK) {
        struct input_mask *m=p; assert(m->codes_size<=sizeof stored[0]);
        if(req==EVIOCSMASK){memcpy(stored[m->type],(void*)(uintptr_t)m->codes_ptr,m->codes_size);mask_calls++;}
        else {memcpy((void*)(uintptr_t)m->codes_ptr,stored[m->type],m->codes_size);if(corrupt)((uint8_t*)(uintptr_t)m->codes_ptr)[0]^=1;}
        return 0;
    }
    if(req==EVIOCSCLOCKID){assert(*(int*)p==CLOCK_MONOTONIC);return 0;}
    writes++;return -1;
}
static void event(int fd,int type,int code,int value) {
    struct input_event e={0}; e.time.tv_sec=5;e.time.tv_usec=100000;e.type=type;e.code=code;e.value=value;
    assert(write(fd,&e,sizeof e)==sizeof e);
}
struct fixture {char *dir;int pipe_out;};
static void* disarm(void* ctx) {
    struct fixture *f=ctx; usleep(250000);
    char path[256]; snprintf(path,sizeof path,"%s/disable",f->dir);
    close(open(path,O_CREAT|O_WRONLY,0600)); return NULL;
}
static unsigned fd_count(void) {
    unsigned n=0; DIR *d=opendir("/proc/self/fd"); assert(d);
    while (readdir(d)) ++n;
    closedir(d); return n;
}
#define CHECK(expr) do {assert(expr); n++;} while(0)
int main(void) {
    int n=0;
    CHECK(configure(123,13,65,0)==0 && mask_calls==2 && writes==0);
    CHECK(has(stored[EV_KEY],116) && !has(stored[EV_KEY],115) && !has(stored[EV_KEY],114));
    CHECK(configure(123,14,65,0)<0);extra_key=1;CHECK(configure(123,13,65,0)<0);extra_key=0;
    extra_type=1;CHECK(configure(123,13,65,0)<0);extra_type=0;
    msc=1;CHECK(configure(123,13,65,1)<0);CHECK(configure(123,13,65,0)==0);msc=0;
    corrupt=1;CHECK(configure(123,13,65,0)<0);
    char dir[]="/tmp/power-daily-native-XXXXXX";assert(mkdtemp(dir));
    int pipefd[2];assert(pipe(pipefd)==0);
    int wd=inotify_init1(IN_NONBLOCK);assert(wd>=0);assert(inotify_add_watch(wd,dir,IN_CREATE)>=0);
    event(pipefd[1],EV_SYN,SYN_REPORT,0);event(pipefd[1],EV_KEY,KEY_POWER,1);
    CHECK(Java_com_naozho_power_DailyInput_next(NULL,NULL,pipefd[0],wd)==5100*4+1);
    event(pipefd[1],EV_KEY,KEY_VOLUMEUP,1); CHECK(Java_com_naozho_power_DailyInput_next(NULL,NULL,pipefd[0],wd)==-1);
    event(pipefd[1],EV_SYN,SYN_DROPPED,0); CHECK(Java_com_naozho_power_DailyInput_next(NULL,NULL,pipefd[0],wd)==-1);
    char data[256];snprintf(data,sizeof data,"%s/status",dir);close(open(data,O_CREAT|O_WRONLY,0600));
    event(pipefd[1],EV_KEY,KEY_POWER,0); CHECK(Java_com_naozho_power_DailyInput_next(NULL,NULL,pipefd[0],wd)==5100*4);
    unsigned before=fd_count(); struct rusage previous,after; getrusage(RUSAGE_SELF,&previous);
    for(unsigned i=0;i<10000;i++) {
        event(pipefd[1],EV_KEY,KEY_POWER,i%2);
        assert(Java_com_naozho_power_DailyInput_next(NULL,NULL,pipefd[0],wd)==(long)(5100*4+i%2));
    }
    CHECK(before==fd_count());getrusage(RUSAGE_SELF,&after);
    printf("10000 pipe edges: fd delta 0; Linux maxrss delta %ld KiB\n",after.ru_maxrss-previous.ru_maxrss);
    struct fixture f={dir,pipefd[1]}; pthread_t t;assert(!pthread_create(&t,NULL,disarm,&f));
    struct timespec a,b;clock_gettime(CLOCK_THREAD_CPUTIME_ID,&a);
    CHECK(Java_com_naozho_power_DailyInput_next(NULL,NULL,pipefd[0],wd)==-2);
    clock_gettime(CLOCK_THREAD_CPUTIME_ID,&b);pthread_join(t,NULL);
    printf("blocking 250ms, Linux calling thread CPU %.3f ms\n",(b.tv_sec-a.tv_sec)*1000+(b.tv_nsec-a.tv_nsec)/1e6);
    unlink(data);snprintf(data,sizeof data,"%s/disable",dir);unlink(data);rmdir(dir);
    close(pipefd[0]);close(pipefd[1]);close(wd);
    printf("Native cases %d\n",n); return 0;
}
