package com.naozho.power;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.naozho.power.DailyTest.ok;

/** Optional offline regression using an extracted DSH capture. Never emit window tokens,
 * headers, arbitrary owner names, private flags or the raw environment report. */
public final class CapturedWindowsTest {
    private static final Pattern BLOCK=Pattern.compile("(?m)^  Window #(\\d+) Window\\{([^{}\\r\\n]+)\\}:\\r?\\n");
    private static final String SYS="com.android.systemui";
    private static final String[] TYPES={"NAVIGATION_BAR_PANEL","NAVIGATION_BAR_PANEL","NAVIGATION_BAR",
            "STATUS_BAR","BASE_APPLICATION","WALLPAPER"};
    private static final String[] ROLES={"bottom_decor","top_decor","navigation_bar","status_bar","launcher","wallpaper"};
    private static String input(Path dir,String name,String expected) throws Exception {
        byte[] data=Files.readAllBytes(dir.resolve(name));
        StringBuilder sha=new StringBuilder();
        for(byte b:MessageDigest.getInstance("SHA-256").digest(data)) sha.append(String.format("%02x",b));
        if (!sha.toString().equals(expected)) throw new AssertionError("capture digest mismatch");
        return new String(data,java.nio.charset.StandardCharsets.UTF_8);
    }

    // Compare the physical blocks independently of the production projection. Keep composite
    // Window identities private and cut the WMS summary off the end of the last window.
    private static Map<String,String> blocks(String raw) {
        int summary=raw.indexOf("\r\n  mGlobalConfiguration=");
        if (summary<0) throw new AssertionError("expected WMS summary");
        String list=raw.substring(0,summary);
        Matcher header=BLOCK.matcher(list);
        Map<String,String> out=new LinkedHashMap<>();
        String key=null; int start=0;
        while(header.find()) {
            if (key!=null) out.put(key,list.substring(start,header.start()).stripTrailing());
            key=header.group(2);
            if (out.containsKey(key)) throw new AssertionError("duplicate window");
            start=header.end();
        }
        if(key!=null) out.put(key,list.substring(start).stripTrailing());
        return out;
    }
    private static String focusRecord(String environment,String field) {
        Matcher m=Pattern.compile("(?m)^"+field+" *: *("+field+"=[^\\r\\n]+)\\r?$").matcher(environment);
        if (!m.find()) throw new AssertionError("focus metadata missing");
        return m.group(1);
    }
    private static void deny(String label,String raw,String focus) {
        Foreground.Windows w=VisibleWindowDump.inspect(raw,focus);
        ok(label,w.veto!=null && w.blockingCount>0);
    }
    public static void main(String[] args) throws Exception {
        Path dir=Path.of(args[0]);
        String visible=input(dir,"window-visible-raw.txt","ad1055999e0c458b867523956bffe396db8215a490cc91d72c1f3f5de01e7071");
        String windows=input(dir,"window-windows-raw.txt","0b8331033e8e7f1c03ae00068e62bd5c426f8c5e674e4cba19f3e1e8a303e52a");
        String env=input(dir,"采集环境与设备状态.txt","436898be3a977933fea5207173ff68f41f3cce8f83822e724881f83fd11be65b");
        String display=focusRecord(env,"mCurrentFocus")+"\n"+focusRecord(env,"mFocusedApp");
        String token=Foreground.rawFocusId(display),page=Foreground.focus(display);
        ok("recorded focus and focused activity agree",page.equals(TrialChecks.FREEME) && token.equals(Foreground.focusId(display)));
        Foreground.Windows active=VisibleWindowDump.inspect(visible,token),all=VisibleWindowDump.inspect(windows,token);
        Foreground.verify(active,page);
        ok("production decision on exact visible input",active.rows.size()==6 && active.visibleCount==6 && active.decorCount==4 &&
                active.interactiveCount==1 && active.blockingCount==0 && active.unknownCount==0);
        ok("exact 316 and 512 line inputs have independent boundaries",visible.lines().count()==316 && windows.lines().count()==512 &&
                active.totals().contains("footer_line_number=295 snapshot_parse_status=parsed window_block_count=6") &&
                all.totals().contains("footer_line_number=491 snapshot_parse_status=parsed window_block_count=13"));
        System.out.println("VISIBLE_RESULT "+active.totals().trim());
        Map<String,String> va=blocks(visible),wa=blocks(windows);
        List<String> allIds=new ArrayList<>(wa.keySet());
        ok("unique physical block identities",va.size()==6 && wa.size()==13 && wa.keySet().containsAll(va.keySet()));
        String[] projected=VisibleWindowDump.project(visible).split("(?m)^  Window #");
        List<String> sourceLines=List.of(visible.split("\\r\\n"));
        int i=0;
        for (Map.Entry<String,String> entry:va.entrySet()) {
            int index=allIds.indexOf(entry.getKey());
            String row=active.rows.get(i),owner=i==4?"com.droiclaw.launcher3":SYS;
            String kind=i<4?"decor":i==4?"app":"wallpaper";
            String reason=i<2?"verified_passive_decor":i<4?"verified_edge_bar":i==4?"focused_application":"below_foreground";
            ok("matching complete window body "+i,entry.getValue().equals(wa.get(entry.getKey())));
            ok("role and geometry "+i,row.startsWith("type="+TYPES[i]+" owner="+owner+" ") && row.contains(" class="+kind+" class_reason="+reason+" ") &&
                    row.contains(" field_missing=none ") && row.contains(" geometry_valid=true ") && row.endsWith("actual_blocker=false"));
            WindowAttributes attributes=WindowAttributes.parse(projected[i+1]);
            List<String> sourceFlags=List.of(sourceLines.get(attributes.lineNumber-1).trim().substring(3).split("\\s+"));
            ok("public values equal only the base fl field "+i,attributes.known() && attributes.source.equals("flags_line_names") &&
                    sourceFlags.equals(List.of(attributes.publicValue.split(","))) &&
                    row.contains("flags_value_count="+sourceFlags.size()+" "));
            // Both producers must agree independently apart from their per-command index/line.
            String expected=row.replaceAll("window_block_index=\\d+","window_block_index=X").replaceAll("flags_line_number=\\d+","flags_line_number=X");
            String actual=all.rows.get(index).replaceAll("window_block_index=\\d+","window_block_index=X").replaceAll("flags_line_number=\\d+","flags_line_number=X");
            ok("same production metadata in both commands "+i,actual.equals(expected));
            System.out.println("ROLE "+ROLES[i]+" all_index="+index+" "+row);
            i++;
        }
        int extra=0;
        for(i=0;i<allIds.size();i++) if(!va.containsKey(allIds.get(i))) {
            String row=all.rows.get(i);
            ok("all-only window lacks visibility and surface "+i,row.contains("visible=false onscreen=false surface=false"));
            System.out.println("ALL_ONLY index="+i+" visible=false onscreen=false surface=false");
            extra++;
        }
        ok("all-only count",extra==7 && all.visibleCount==6);

        Matcher rotation=Pattern.compile("(?m)^          fl=([^\\r\\n}]+)").matcher(visible);
        ok("eight physical rotation public fields",rotation.results().count()==8);
        String changed=rotation.replaceAll("          fl=SECURE NOT_TOUCHABLE");
        String namespaces=changed.replaceAll("(?m)^( +)(pfl|vsysui)=([^\\r\\n}]+)","$1$2=SECURE");
        ok("rotation/private/UI mutations do not change primary fields",VisibleWindowDump.inspect(namespaces,token).rows.equals(active.rows));
        deny("real baseline public SECURE must veto",visible.replaceFirst("(?m)^      fl=", "      fl=SECURE "),token);
        String obscured=visible.replace("mObscured=false","mObscured=true");
        deny("real baseline true occlusion must veto",obscured,token);
        int summary=visible.indexOf("  mGlobalConfiguration=");
        for(String[] test:new String[][]{{"NotificationShade","NOTIFICATION_SHADE"},{"ControlCenter","STATUS_BAR_SUB_PANEL"},
                {"keyboard","INPUT_METHOD"},{"USB","SYSTEM_DIALOG"},{"permission","APPLICATION_ATTACHED_DIALOG"},
                {"authentication","KEYGUARD_DIALOG"},{"emergency","BASE_APPLICATION"},{"unknown","SYSTEM_OVERLAY"}}) {
            String additional=DailyTest.window(6,"ff01",test[0],SYS,test[1],"0");
            deny("additional protected window "+test[1],visible.substring(0,summary)+additional+visible.substring(summary),token);
        }
        DailyTest.reject("focus change between observations",()->Foreground.confirmFocus(page,token,
                display.replace("Window{"+token+" ","Window{ff02 ")));
        System.out.println("Physical capture JVM cases "+DailyTest.count);
    }
}
