package com.naozho.power;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.naozho.power.DailyTest.ok;

/** Boundary positions below were reported by DSH. The window bodies in the format tests
 * are fixtures, not the private 316-line recording. Optional replay reads the original locally. */
public final class SnapshotBoundaryTest {
    static final String STAMP="Dump time : 2026-11-27 03:39:11.627\n";
    static final String FOOT="  mBlurEnabled=true\n";
    private static Foreground.Windows inspect(String raw) { return VisibleWindowDump.inspect(raw,"5"); }
    private static void deny(String name,String raw,String reason) {
        Foreground.Windows w=inspect(raw);
        ok(name,reason.equals(w.veto) && w.extras<0 && w.rows.isEmpty() && w.snapshot!=null);
    }
    private static int lines(String s) { return (int)s.lines().count(); }

    // No window titles, raw flag text or focus tokens leave this replay.
    private static void replay(Path file) throws Exception {
        byte[] data=Files.readAllBytes(file);
        String raw=new String(data,java.nio.charset.StandardCharsets.UTF_8);
        Matcher launcher=Pattern.compile("(?m)^  Window #\\d+ Window\\{([a-fA-F0-9]+) u0 "+
                Pattern.quote(TrialChecks.FREEME)+"\\}:[ \\t]*\\r?$").matcher(raw);
        String id=launcher.find()?launcher.group(1):"unavailable";
        if (launcher.find()) id="ambiguous";
        Foreground.Windows w=VisibleWindowDump.inspect(raw,id);
        System.out.println("lines="+lines(raw)+" focus_source=assumed_reported_freeme_for_replay");
        System.out.println("decision="+(w.veto==null?"ordinary_freeme":w.veto)+w.totals());
        for(String row:w.rows) System.out.println(row);
    }

    public static void main(String[] args) throws Exception {
        if (args.length==2 && args[0].equals("--replay")) { replay(Path.of(args[1])); return; }
        String[] rows=FreemeWindowsTest.records(Files.readString(Path.of(args[0])));
        String head=FreemeWindowsTest.HEAD;
        // Place the supplied delimiters at physical lines 2 and 295. Padding illustrates
        // the field layout only. It cannot substitute for a physical dump.
        String body=STAMP+head+String.join("",rows);
        String tail="SnapshotCache:\n"+"  display 0\n"+"  Animation state\n";
        String scene=body+"\n".repeat(294-lines(body))+FOOT+tail+"\n".repeat(18);
        Foreground.Windows sample=inspect(scene);
        ok("format reconstruction only: reported boundary positions",sample.veto==null && lines(scene)==316 &&
                sample.totals().contains("header_found=true header_line_number=2 footer_found=true footer_line_number=295") &&
                sample.totals().contains("window_block_count=6") && sample.visibleCount==6 && sample.decorCount==4 &&
                sample.interactiveCount==1 && sample.blockingCount==0 && sample.unknownCount==0);
        ok("private header-like trailing data excluded",inspect(scene+rows[0]).rows.equals(sample.rows));
        ok("legacy first-line heading",inspect(FreemeWindowsTest.scene(rows)).veto==null);
        for (String title:List.of("   WINDOW MANAGER WINDOWS (dumpsys window visible):  ","\tWINDOW MANAGER WINDOWS: ","WINDOW  MANAGER WINDOWS")) {
            Foreground.Windows w=inspect(scene.replace(head,title+"\n"));
            ok("whole-line heading variant",w.veto==null && w.snapshot.diagnostic().contains("header_line_number=2"));
        }
        Foreground.Windows other=inspect("private 123 unrelated diagnostics\n"+scene);
        ok("valid prefix retained only as category",other.veto==null && other.totals().contains("snapshot_first_line=redacted_prefix") && !other.totals().contains("private"));
        ok("CRLF",inspect(scene.replace("\n","\r\n")).veto==null);
        deny("missing heading",scene.replace(head,"WINDOW MANAGER HISTORY\n"),"window_snapshot_header");
        deny("title substring insufficient",scene.replace(head,"junk "+head),"window_snapshot_header");
        deny("truncated snapshot",scene.substring(0,scene.indexOf(FOOT)-3),"window_snapshot_footer");
        deny("misordered delimiters",FOOT+scene.replace(FOOT,""),"window_snapshot_order");
        deny("ambiguous repeated footer",scene+FOOT,"duplicate_snapshot_footer");
        deny("concatenated command results",scene+scene,"duplicate_snapshot_header");
        deny("missing footer followed by another service section",scene.replace(FOOT,"WINDOW MANAGER ANIMATOR\n"),"window_snapshot_interrupted");
        deny("new command banner before close",scene.replace(FOOT,STAMP+FOOT),"window_snapshot_interrupted");
        deny("dumpsys timeout marker",scene+"DUMP TIMEOUT: test", "window_command_incomplete");
        ok("command failure never classified",VisibleWindowDump.readFailure("system_command_timeout").totals().contains("snapshot_first_line=unavailable") &&
                VisibleWindowDump.readFailure("system_command_timeout").rows.isEmpty());
        deny("no current window section",STAMP+head+FOOT,"empty_window_block");
        deny("empty last window",scene.replace(FOOT,"  Window #6 Window{7 u0 private}:\n"+FOOT),"empty_window_block");
        deny("malformed adjacent window",scene.replace("  Window #2 Window{","  Window #2 broken{"),"window_block_boundary");
        deny("visible window listed after summary",scene.replace("  Window #2","  Windows waiting to resize:\n  Window #2"),"window_block_boundary");
        for(String summary:List.of("  Hiding System Alert Windows:","  Windows force removing:"))
            deny("protected WMS summary",scene.replace(FOOT,summary+"\n"+FOOT),"windows_unconfirmed");

        String base="    mAttrs={sim={adjust=pan} ty=STATUS_BAR fl=NOT_FOCUSABLE\n      paramsForRotation:";
        for(int degrees:new int[]{0,90,180,270})
            base+="\n        ROTATION_"+degrees+"={sim={adjust=nothing} ty=SYSTEM_ERROR\n          fl=SECURE NOT_TOUCHABLE\n          pfl=NOT_FOCUSABLE}";
        base+="}\n";
        String before="    mAttrs={(0,0)(fillxfill) ty=STATUS_BAR fmt=TRANSLUCENT\n      fl="+FreemeWindowsTest.FLAGS[3]+"}\n";
        String rotated=scene.replace(before,base);
        Foreground.Windows w=inspect(rotated);
        ok("four rotation objects isolated",w.veto==null && w.rows.get(3).contains("touchable=true") && w.rows.get(3).contains("flags_value_count=1"));
        ok("status bar without insets uses actual bounded frame",w.rows.get(3).contains("touch_region=default_frame") &&
                w.rows.get(3).contains("class_reason=verified_edge_bar"));
        ok("absolute base flag source line",w.rows.get(3).contains("flags_line_number="+(1+lines(rotated.substring(0,rotated.indexOf(base))))+" "));
        ok("base flags missing with rotation flags present",inspect(rotated.replace("ty=STATUS_BAR fl=NOT_FOCUSABLE","ty=STATUS_BAR")).rows.get(3).contains("parser_error=missing_flags"));
        String external=scene.replace(before,"    mAttrs={ty=STATUS_BAR sim={adjust=pan}}\n     fl = NOT_FOCUSABLE\n");
        ok("standalone adjacent base flag",inspect(external).rows.get(3).contains("flags_source=after_attrs_names") && inspect(external).veto==null);
        ok("outside line number",inspect(external).rows.get(3).contains("flags_line_number="+(1+lines(external.substring(0,external.indexOf("     fl ="))))+" "));
        ok("base plus adjacent flags ambiguous",inspect(external.replace("ty=STATUS_BAR sim=", "ty=STATUS_BAR fl=SECURE sim=")).rows.get(3).contains("parser_error=duplicate_flags"));
        ok("after another record field is orphan",inspect(external.replace("     fl =", "    nestedProperties:\n     fl =")).rows.get(3).contains("parser_error=flags_outside_attrs"));
        ok("unclosed attributes veto",inspect(rotated.replace("pfl=NOT_FOCUSABLE}}\n","pfl=NOT_FOCUSABLE}\n")).rows.get(3).contains("attrs_parse_status=unclosed"));
        ok("missing wallpaper flags recorded without borrowing",inspect(scene.replace(rows[5],rows[5].replace("fl=","pfl="))).rows.get(5).contains("parser_error=missing_flags"));
        for(String[] hazard:new String[][]{{"NotificationShade","NOTIFICATION_SHADE"},{"ControlCenter","STATUS_BAR_SUB_PANEL"},
                {"InputMethod","INPUT_METHOD"},{"USB test","SYSTEM_DIALOG"},{"permission","APPLICATION_ATTACHED_DIALOG"},
                {"credential","KEYGUARD_DIALOG"},{"emergency","BASE_APPLICATION"},{"recovery","SYSTEM_ERROR"},{"unreviewed","SYSTEM_OVERLAY"}}) {
            String extra=DailyTest.window(6,"7",hazard[0],FreemeWindowsTest.SYS,hazard[1],"0");
            ok("negative in prefixed snapshot "+hazard[1],inspect(scene.replace(FOOT,extra+FOOT)).blockingCount==1);
        }
        ok("covered foreground blocked",inspect(scene.replace(rows[4],rows[4].replace("mObscured=false","mObscured=true"))).veto!=null);
        ok("different focus token blocked",VisibleWindowDump.inspect(scene,"7").veto!=null);
        ok("unknown same-type panel blocked",inspect(scene.replace("ScreenDecorOverlayBottom","unreviewed")).blockingCount==1);
        System.out.println("Snapshot boundary JVM cases "+DailyTest.count);
    }
}
