import unittest
from unittest.mock import Mock
from cpday10_joint import Device, FREEME, PKG, PERM, log_stage, receiver_ok, stable


class Readback(unittest.TestCase):
    info = f"""1 receivers found:
      name={PKG}.mode.ConfirmedPowerReceiver
      packageName={PKG}
      enabled=true exported=true directBootAware=false
      permission={PERM}
    """
    def test_final_receiver(self):
        receiver_ok(self.info)

    def test_disabled_permission_wrong_or_ambiguous(self):
        for old, new in [("true", "false"), (PERM, PERM+".x"), ("1 receivers","2 receivers"),
                         ("ConfirmedPowerReceiver","Other")]:
            with self.subTest(new=new), self.assertRaises(RuntimeError):
                receiver_ok(self.info.replace(old,new))

    def test_focus_and_lock_from_separate_services(self):
        for component,expected in [(FREEME,"Freeme"),(PKG+"/.MainActivity","clock"),
                (PKG+"/.mode.PowerClockEntry","clock"),(PKG+"/.mode.AdminRecoveryActivity","other")]:
            d = Device("offline")
            d.shell = Mock(side_effect=["  mLockTaskModeState=LOCKED",
                                        " mCurrentFocus=Window{123 u0 "+component+"}"])
            self.assertEqual(("LOCKED",expected),d.state())

    def test_wireless_port_change_keeps_same_local_device(self):
        a, b = Device("host:123"), Device("host:456")
        a.shell = b.shell = Mock(return_value="f0123456789abcde")
        self.assertEqual(a.local_identity(), b.local_identity())
        b.shell = Mock(return_value="f0123456789abcdf")
        self.assertNotEqual(a.local_identity(), b.local_identity())

    def test_nested_focus_ambiguity(self):
        d=Device("offline")
        window=" mCurrentFocus=Window{123 u0 "+FREEME+"}"
        d.shell=Mock(side_effect=["mLockTaskModeState=NONE",window+"\n"+window])
        with self.assertRaises(RuntimeError): d.state()

    def test_no_stale_flags_or_extra_package(self):
        s="I/NaozhoMode: Lock Task after start: state=LOCKED independent=true flags=80 (X) allowlist=[com.naozho.clock]"
        self.assertEqual(1,log_stage(s)["lock80"])
        for invalid in [s.replace("=80 ","=800 "),s.replace("true","false"),s.replace("clock]","clock, pkg]")]:
            self.assertEqual(0,log_stage(invalid)["lock80"])

    def test_data_compare_preserves_absent_fields(self):
        self.assertNotEqual(stable({}),stable({"managed_lock":"false"}))
        self.assertEqual(stable({}),stable({"mode_since":"642","android":"true"}))

    def test_receipts_are_independent(self):
        self.assertEqual(0,log_stage("Broadcast completed: result=0")["app_requested"])
        lines="Double rejected at receiver; no activity requested\nDouble committed on foreground focus"
        self.assertEqual(1,log_stage(lines)["guard_rejected"])
        self.assertEqual(1,log_stage(lines)["focus_commit"])
        self.assertEqual(0,log_stage(lines)["lock80"])


if __name__ == "__main__":
    unittest.main()
