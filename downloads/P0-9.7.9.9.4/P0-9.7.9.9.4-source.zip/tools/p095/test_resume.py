import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

import cpday10_joint as joint


class ContinuedRound(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.folder = Path(temp.name)
        self.record = self.folder / "p096-local.json"
        self.prefs = {"managed_lock":"true", "managed_home":"false", "native_home":joint.FREEME,
                      "android":"true", "mode_since":"1234"}
        self.d = Mock()
        self.d.installed.return_value = joint.APP_UID
        self.d.state.return_value = ("NONE","Freeme")
        self.d.prefs.return_value = self.prefs
        self.d.shell.side_effect = ["Enforcing","  mWakefulness=Awake","36"] * 4
        self.d.local_identity.return_value = "test_device"
        self.current = joint.check_current(self.d, "test-apksigner")

    def test_28_initial_resume_and_approved_reboot(self):
        joint.baseline_phase("resume", self.record, self.current)
        stored = self.record.read_bytes()
        self.assertEqual(28, json.loads(stored)["versionCode"])
        with contextlib.redirect_stdout(io.StringIO()):
            joint.baseline_phase("verify", self.record, dict(self.current, boot_count=37))
        self.assertEqual(stored, self.record.read_bytes())

    def test_resume_never_overwrites_record_or_orphan_attempt(self):
        self.record.write_text("keep")
        with self.assertRaises(FileExistsError):
            joint.baseline_phase("resume", self.record, self.current)
        self.assertEqual("keep", self.record.read_text())
        alt = self.folder / "another"
        attempt = Path(str(alt) + ".attempt")
        attempt.write_text("kept")
        with self.assertRaises(RuntimeError):
            joint.baseline_phase("resume", alt, self.current)
        self.assertEqual("kept", attempt.read_text())
        self.assertFalse(alt.exists())

    def test_verify_rejects_previous_round_and_identity_drift(self):
        joint.baseline_phase("resume", self.record, self.current)
        for k,v in [("round","P0-9.5"),("device_hash","other"),("uid","123"),("configuration",{}),
                    ("sha256","changed"),("signer_sha256","other"),("versionCode",24)]:
            with self.subTest(k=k), self.assertRaisesRegex(RuntimeError,k):
                joint.baseline_phase("verify",self.record,dict(self.current, **{k:v}))

    def test_previous_pair_link_read_only(self):
        old = self.folder / "p095-local.json"
        old.write_text(json.dumps({k:self.current[k] for k in ("uid","device_hash","configuration")}))
        attempt = Path(str(old) + ".attempt")
        attempt.write_bytes(b"result=delivery_history_unconfirmed\r\n")
        original = (old.read_bytes(), attempt.read_bytes())
        hashes = joint.previous_record(old, self.current)
        self.assertEqual(64, len(hashes["attempt_sha256"]))
        self.assertEqual(original, (old.read_bytes(), attempt.read_bytes()))
        with self.assertRaisesRegex(RuntimeError, "uid"):
            joint.previous_record(old, dict(self.current,uid="other"))

    def test_maintenance_and_wrong_home_refused(self):
        for key,value in [("managed_lock","false"),("android","false"),("managed_home","true"),
                          ("native_home","other"),("mode_since","0")]:
            self.d.prefs.return_value = dict(self.prefs, **{key:value})
            with self.subTest(key=key), self.assertRaises(RuntimeError):
                joint.check_current(self.d,"signer")

    def test_resume_and_verify_never_invoke_return(self):
        for phase in ("resume", "verify"):
            with patch.object(sys,"argv",["joint",phase,"--serial","offline","--record",str(self.record)]), \
                    patch.object(joint,"check_current",return_value=self.current), \
                    patch.object(joint,"find_signer",return_value="signer"), \
                    patch.object(subprocess,"Popen") as proc, contextlib.redirect_stdout(io.StringIO()):
                joint.main()
                proc.assert_not_called()
        self.assertFalse(Path(str(self.record)+".attempt").exists())

    def test_failed_attempt_blocks_second_return(self):
        joint.baseline_phase("resume", self.record, self.current)
        attempt = Path(str(self.record)+".attempt")
        attempt.write_text("first")
        self.d.shell.side_effect = None
        self.d.shell.return_value = "id=naozho_power_trial\nversion=0.2.1\nversionCode=3"
        with patch.object(sys,"argv",["joint","return","--serial","offline","--record",str(self.record)]), \
                patch.object(joint,"check_current",return_value=self.current), patch.object(joint,"Device",return_value=self.d), \
                patch.object(joint,"find_signer"), patch.object(subprocess,"Popen") as proc, \
                contextlib.redirect_stdout(io.StringIO()), self.assertRaises(FileExistsError):
            joint.main()
        proc.assert_not_called()
        self.assertEqual("first", attempt.read_text())

    def test_receipt_trace_uid_order_and_duplicate_markers(self):
        def history(stage, trace):
            return f"history_check stage={stage} trace={trace} sample=2 sender_uid=1234 missing=none check=verified"
        steps = ["dispatch_attempt stage=probe trace=P", history("probe","P"),
                 "permission_probe=DELIVERED uid=1234 user=0 permission=" + joint.PERM, "ready=return_once",
                 "dispatch_attempt stage=return trace=R", history("return","R"), "return_receiver=DELIVERED uid=1234 user=0"]
        joint.verify_receipts(steps)
        for broken in (steps[:3]+steps[4:], steps+steps[4:5], steps[:5]+[history("return","P"), steps[-1]],
                       [steps[3],*steps[:3],*steps[4:]], steps[:-1]+["return_receiver=DELIVERED uid=999 user=0"]):
            with self.subTest(broken=broken), self.assertRaises(RuntimeError):
                joint.verify_receipts(broken)

    def test_signature_requires_exact_hash_one_signer_and_v2(self):
        apk = self.folder / "base.apk"
        apk.write_bytes(b"sample")
        with self.assertRaisesRegex(RuntimeError,"SHA-256"), patch.object(subprocess,"run") as call:
            joint.signed_candidate(apk,"signer")
        call.assert_not_called()
        line = "Signer #1 certificate SHA-256 digest: " + joint.CERT
        okay = "Verified using v2 scheme (APK Signature Scheme v2): true\n" + line
        with patch.object(joint,"CANDIDATE",joint.hashlib.sha256(apk.read_bytes()).hexdigest()):
            for stdout in (okay.replace("true","false"),okay.replace(joint.CERT,"a"*64), okay+"\n"+line):
                with self.subTest(stdout=stdout), patch.object(subprocess,"run",return_value=Mock(returncode=0,stdout=stdout)), \
                        self.assertRaisesRegex(RuntimeError,"signer"):
                    joint.signed_candidate(apk,"signer")

if __name__ == "__main__":
    unittest.main()
