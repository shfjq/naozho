#!/usr/bin/env python3
"""Offline assertions against the pinned CPDAY10 services.jar; no adb, no firmware distribution."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import tempfile
import zipfile

FIRMWARE="70fa04e1e51c4008078cdc7fd6c1cc041769e39bd3cce99712ce1d374d81f468"
# Exact offsets belong to this firmware only. Check branches as well as referenced APIs.
METHODS={
    "SingleKeyGestureDetector.<clinit>":[("0000","getMultiPressTimeout:"),("0005","sput-wide"),("0005","MULTI_PRESS_TIMEOUT")],
    "SingleKeyGestureDetector.interceptKeyDown":[("00c6","getDownTime:"),("00ca","mLastDownTime"),("00cc","sub-long"),("00d1","iput-wide"),("00d3","MULTI_PRESS_TIMEOUT"),("00d7","if-ltz v1, 00dc"),("00d9","mKeyPressCounter"),("00de","add-int")],
    "SingleKeyGestureDetector.interceptKeyUp":[("009c","getMaxMultiPressCount"),("00a1","if-ne v0, v2, 00dc"),("00d6","sendMessage:"),("00e0","getMaxMultiPressCount"),("00fe","MULTI_PRESS_TIMEOUT"),("0100","sendMessageDelayed")],
    "SingleKeyGestureDetector$KeyHandler.handleMessage":[("0092","mLastDownTime"),("0096","onMultiPress:"),("00da","onLongPress:")],
    "PhoneWindowManager$PowerKeyRule.onMultiPress":[(None,".powerPress:")],
    "PhoneWindowManager.powerPress":[("000e",'"WindowManager"'),("0022",".isAwake:"),("002b",'"powerPress: eventTime="'),("0034",'" interactive="'),("003c",'" count="'),("0052","Slog;.d:"),("0055","#int 2"),("005a","powerMultiPressAction:"),("0100","sleepDefaultDisplayFromPowerButton:")],
    "PhoneWindowManager.interceptPowerKeyDown":[("0069","if-nez"),("0074","wakeUpFromWakeKey:")],
}
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--firmware",required=True,type=Path); parser.add_argument("--dexdump",required=True)
    args=parser.parse_args()
    if hashlib.sha256(args.firmware.read_bytes()).hexdigest()!=FIRMWARE: raise SystemExit("different firmware")
    with tempfile.TemporaryDirectory() as temp, zipfile.ZipFile(args.firmware) as archive:
        dex=Path(temp)/"classes2.dex"; dex.write_bytes(archive.read(dex.name))
        bodies={}
        with subprocess.Popen([args.dexdump,"-d",dex],stdout=subprocess.PIPE) as proc:
            method=None
            for line in proc.stdout:
                if b"|[" in line:
                    title=line.split(b"] ",1)[-1].decode().partition(":")[0]
                    method=title.removeprefix("com.android.server.policy.")
                    if method in METHODS: bodies[method]=[]
                elif b"Class descriptor  :" in line: method=None
                elif method in METHODS and b"|" in line: bodies[method].append(line.split(b"|",1)[1].decode())
            if proc.wait(): raise SystemExit("dexdump failed")
        for name,checks in METHODS.items():
            for pc,token in checks:
                if not any((pc is None or row.startswith(pc+":")) and token in row for row in bodies.get(name,[])):
                    raise SystemExit("missing "+str((name,pc,token)))
            print("PASS firmware",name)
if __name__=="__main__": main()
