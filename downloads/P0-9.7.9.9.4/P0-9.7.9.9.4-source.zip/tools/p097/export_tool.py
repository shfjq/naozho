#!/usr/bin/env python3
"""Export a single DSH script with only the existing read-only APK/system helpers."""
import ast
import sys
from pathlib import Path

here=Path(__file__).resolve().parent
shared=(here.parent/'p095/cpday10_joint.py').read_text(encoding='utf-8')
daily=(here/'cpday10_daily.py').read_text(encoding='utf-8')
names=set('PKG RX ACTION ADMIN PERM FREEME CANDIDATE CERT APP_UID require one receiver_ok find_signer signed_candidate Device log_stage'.split())
parts=[]
for node in ast.parse(shared).body:
    if isinstance(node,(ast.Import,ast.ImportFrom)):
        parts.append(ast.get_source_segment(shared,node))
    elif isinstance(node,(ast.FunctionDef,ast.ClassDef,ast.Assign)):
        name=node.targets[0].id if isinstance(node,ast.Assign) else node.name
        if name in names:
            parts.append(ast.get_source_segment(shared,node))
            names.remove(name)
assert not names, names
dep=next(n for n in ast.parse(daily).body if isinstance(n,ast.ImportFrom) and n.module=='cpday10_joint')
start=daily.index("# Repository checkout (the release exporter")
end=daily.index(ast.get_source_segment(daily,dep))+len(ast.get_source_segment(daily,dep))
out=daily[:start]+'\n\n'.join(parts)+daily[end:]
compile(out,'cpday10_daily.py','exec')
Path(sys.argv[1]).write_text(out,encoding='utf-8')
