import contextlib
import copy
import io
import unittest
from cpday10_daily import assess,battery_values,get_policy,consumption,app_markers

class Readback(unittest.TestCase):
    def setUp(self):
        self.a=dict(device="x",boot=38,uptime_s=3,owner=True,enforcing=True,armed=True,listener_count=1,pid=7,
                    resource=dict(start_ticks=30,cpu_ticks=23),report=dict(probes=1,attempts=2,delivered=2),
                    epoch_us=3000000,markers=[],focus="other",lock="NONE",flags=80,allow_clock_only=True)
        self.b=copy.deepcopy(self.a);self.b.update(uptime_s=10,epoch_us=10000000,markers=[[4000000,"app_requested"],[4200000,"focus_commit"],[4300000,"lock80"]],focus="clock",lock="LOCKED",policy_return=dict(policy_count=2,delivered=3),report={"probes":1,"attempts":3,"delivered":3})
    def test_full_return(self):
        with contextlib.redirect_stdout(io.StringIO()):assess(self.a,self.b,"return",True)
    def test_return_negative(self):
        for change in ({"policy_return":None},{"policy_return":dict(policy_count=1,delivered=3)},{"flags":112},{"markers":[]},{"focus":"other"},{"allow_clock_only":False},{"pid":8},{"armed":False},{"listener_count":2},
                       {"owner":False},{"lock":"PINNED"},{"report":{"attempts":4,"delivered":3}},{"boot":39}):
            with self.subTest(change=change),self.assertRaises(RuntimeError):assess(self.a,dict(self.b,**change),"return",True)
    def test_touch_required(self):
        with self.assertRaises(RuntimeError):assess(self.a,self.b,"return",False)
    def test_no_return(self):
        with contextlib.redirect_stdout(io.StringIO()):assess(self.a,dict(self.a,uptime_s=10),"no-return",False)
        with self.assertRaises(RuntimeError):assess(self.a,self.b,"no-return",False)
    def test_scoped_dpm(self):
        src="  Local Policies:\n    User 0:\n        LockTaskPolicy {mPackages= com.naozho.clock; mFlags= 80 }\n"
        self.assertEqual(80,get_policy(src+src))
        for s in (src.replace("User 0","User 10"),src+src.replace("80","112"),src+src.replace("clock;","clock other;")):
            self.assertIsNone(get_policy(s))
    def test_markers(self):
        self.assertEqual([[1000001,"focus_commit"]],app_markers("1.000001 111 I NaozhoPowerReturn: Double committed on foreground focus"))
    def test_battery(self):
        self.assertEqual(battery_values("  level: 76\n  Charge counter: 1234\n  temperature: 251\n  AC powered: false\n  USB powered: false"),
                         dict(level=76,temperature_tenths_c=251,charge_uah=1234,plugged=False))
        self.assertIsNone(battery_values("")["plugged"])
    def test_measured_intervals(self):
        args=dict(clock_hz=100,log_bytes=135,sys_wakeup_count=12,battery=dict(level=76,charge_uah=40000,plugged=False))
        a=dict(self.a,**args); b=dict(self.a,**args,uptime_s=3603)
        with contextlib.redirect_stdout(io.StringIO()) as out:consumption(a,b)
        self.assertIn('"level_used_per_hour": 0.0',out.getvalue())
        with self.assertRaises(RuntimeError):consumption(a,dict(b,boot=99))

class DiagnosticTests(unittest.TestCase):
    def test_veto_privacy_boundary(self):
        from cpday10_daily import veto_details
        head="last_veto_reason=additional_visible_window last_veto_at=200 extra_windows=2 down_gap_ms=497"
        row="type=SYSTEM_DIALOG owner=com.android.systemui visible=true onscreen=true surface=true focus=false focusable=true touchable=true obscured=false edge=false class=dialog"
        self.assertEqual(veto_details(head+"\n"+row)["windows"][0]["class"],"dialog")
        with self.assertRaises(RuntimeError): veto_details(head+"\n"+row+" title=private")
    def test_native_receipt_edges(self):
        from cpday10_daily import policy_return
        row="window_ms=600 down_gap_ms=599 policy_count=2 delivered=2"
        self.assertEqual(policy_return(row)["down_gap_ms"],599)
        for invalid in (row.replace("599","600"),row.replace("count=2","count=1")):
            with self.assertRaises(RuntimeError): policy_return(invalid)

class WindowSchemaTests(unittest.TestCase):
    counts=" visible_window_count=6 decorative_window_count=4 interactive_window_count=3 blocking_window_count=0 unknown_window_count=0 omitted_rows=0"
    row=("type=NAVIGATION_BAR_PANEL owner=com.android.systemui visible=true onscreen=true surface=true focus=false focusable=false"
         " touchable=false obscured=false edge=true class=decor class_reason=verified_passive_decor parser_source=flags_line_names"
         " field_missing=none focusable_parse_status=parsed touchable_parse_status=parsed geometry_valid=true touch_region=default_frame actual_blocker=false")
    def test_both_diagnostic_consumers(self):
        from cpday10_daily import veto_details,check_details
        for make,prefix in [(veto_details,"last_veto_reason=focus_transition last_veto_at=9 extra_windows=5 down_gap_ms=282"),
                            (lambda s:check_details(s,True),"decision=ordinary_freeme"),
                            (lambda s:check_details(s,False),"checked_at=9 delivered=1")]:
            value=make(prefix+self.counts+"\n"+self.row)
            self.assertEqual(4,value["decorative_window_count"])
            self.assertEqual("false",value["windows"][0]["actual_blocker"])
            with self.assertRaises(RuntimeError): make(prefix+self.counts+"\n"+self.row+" title=invalid")
    def test_one_read_collector_with_actual_producer(self):
        from cpday10_daily import bar_sample,BAR_SLICE
        import subprocess
        class ReadOnly:
            def __init__(self): self.dumps=0
            def shell(self,*args):
                if args==("getprop","ro.product.device"): return "CPDAY10"
                if args==("am","get-current-user"): return "0"
                self.dumps+=1
                selftest.assertEqual(args,("/system/bin/sh","-c",BAR_SLICE))
                sed=BAR_SLICE.split("/system/bin/sed -nE '",1)[1][:-1]
                raw=("  Window #0 Window{000 u0 PRIVATE_TITLE}:\n    mOwnerUid=1 showForAllUsers=false package=com.android.systemui appop=NONE\n"
                     "    mAttrs={(0,0)(fillxfill) ty=NAVIGATION_BAR\n      fl=NOT_FOCUSABLE | VENDOR_PRIVATE}")
                raw+="\n"+raw.replace("NAVIGATION_BAR\n      fl=NOT_FOCUSABLE | VENDOR_PRIVATE","STATUS_BAR flags=0x8").replace("#0","#1")
                raw+="\n    mTouchableInsets=3 mGivenInsetsPending=false\n    touchable region=SkRegion((0,0,720,30))\n  mBlurEnabled=true\n"
                return subprocess.run(["sed","-nE",sed],input=raw,text=True,capture_output=True,check=True).stdout.strip()
        selftest=self; device=ReadOnly()
        result=bar_sample(device)
        self.assertEqual(1,device.dumps)
        self.assertEqual([["INLINE","0x8"]],result["bars"][1]["public_flags"])
        self.assertEqual([["LINE","NOT_FOCUSABLE | <unrecognized>"]],result["bars"][0]["public_flags"])
        self.assertNotIn("PRIVATE",str(result))

class SharedCollectorReadback(unittest.TestCase):
    def test_103_diagnostic(self):
        from cpday10_daily import check_details
        legacy=WindowSchemaTests.row
        suffix=(" collector_command=dumpsys_window_-a_visible collector_source=wms_visible window_block_index=1"
                " flags_line_found=true flags_parse_status=parsed flags_source=flags_line_names flags_value_count=2 parser_error=none")
        row=legacy.replace(" actual_blocker",suffix+" actual_blocker")
        sample="decision=ordinary_freeme"+WindowSchemaTests.counts+"\n"+row
        item=check_details(sample,True)["windows"][0]
        self.assertEqual(item["flags_value_count"],"2")
        self.assertEqual(item["flags_line_found"],"true")
        with self.assertRaises(RuntimeError): check_details(sample+" title=private",True)
    def test_compiled_collector_only(self):
        from cpday10_daily import module_bar_fields,WINDOW_CHECK
        class Device:
            def shell(self,*args):
                test.assertEqual(args,("su","-c",WINDOW_CHECK+" --bar-fields"))
                return ("bar=NAVIGATION_BAR source=flags_line_names status=parsed flags=NOT_FOCUSABLE,NOT_TOUCH_MODAL,WATCH_OUTSIDE_TOUCH region=default_frame\n"
                        "bar=STATUS_BAR source=flags_line_names status=parsed flags=NOT_FOCUSABLE,HARDWARE_ACCELERATED,DRAWS_SYSTEM_BAR_BACKGROUNDS region=in_frame")
        test=self
        data=module_bar_fields(Device())
        self.assertEqual(data["collector_source"],"wms_visible")
        self.assertEqual(len(data["bars"][1]["public_flags"]),3)

class BoundaryReadback(unittest.TestCase):
    meta=(" snapshot_command=dumpsys_window_-a_visible snapshot_first_line=Dump_time_:_2026-11-27_03:39:11.627"
          " header_found=true header_line_number=2 footer_found=true footer_line_number=295 snapshot_parse_status=parsed window_block_count=6")
    def test_boundary_and_source_metadata(self):
        from cpday10_daily import check_details
        row=WindowSchemaTests.row.replace(" actual_blocker", " collector_command=dumpsys_window_-a_visible collector_source=wms_visible window_block_index=0"
               " flags_line_found=true flags_parse_status=parsed flags_source=after_attrs_names flags_value_count=1 flags_line_number=15"
               " attrs_brace_depth=0 attrs_parse_status=balanced parser_error=none actual_blocker")
        value=check_details("decision=ordinary_freeme"+WindowSchemaTests.counts+self.meta+"\n"+row,True)
        self.assertEqual(value["snapshot_first_line"],"Dump time : 2026-11-27 03:39:11.627")
        self.assertEqual((value["header_line_number"],value["footer_line_number"]),(2,295))
        self.assertEqual(value["windows"][0]["flags_line_number"],"15")
    def test_unknown_first_line_never_exported(self):
        from cpday10_daily import check_details
        with self.assertRaises(RuntimeError):
            check_details("decision=window_snapshot_header"+WindowSchemaTests.counts+self.meta.replace("Dump_time_:_2026-11-27_03:39:11.627","private"),True)
    def test_veto_snapshot_metadata(self):
        from cpday10_daily import veto_details
        data=veto_details("last_veto_reason=missing_flags last_veto_at=100 extra_windows=5 down_gap_ms=282"+WindowSchemaTests.counts+self.meta)
        self.assertTrue(data["header_found"])
        self.assertEqual(data["window_block_count"],6)
