"""Compile the archived 1.0.3 production parser for two offline control runs."""
from pathlib import Path
from zipfile import ZipFile
import argparse
import hashlib
import os
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('source_zip', type=Path)
p.add_argument('capture_dir', type=Path)
a = p.parse_args()
jdk = Path(os.environ['JAVA_HOME']) / 'bin'
if hashlib.sha256(a.source_zip.read_bytes()).hexdigest() != 'fcb011e17a8db24bdfd4c233d0f865ebb7ddfe1c5a0a037fbdcbafe1f2f3f0cc':
    p.error('expected the published 1.0.3 source archive')
for name, digest in {
    'window-visible-raw.txt': 'ad1055999e0c458b867523956bffe396db8215a490cc91d72c1f3f5de01e7071',
    '采集环境与设备状态.txt': '436898be3a977933fea5207173ff68f41f3cce8f83822e724881f83fd11be65b',
}.items():
    if hashlib.sha256((a.capture_dir/name).read_bytes()).hexdigest() != digest:
        p.error('unexpected private capture')
with tempfile.TemporaryDirectory() as work, ZipFile(a.source_zip) as archive:
    dest = Path(work)
    files = []
    for module, classes in [
        ('naozho_power_daily', ('VisibleWindowDump', 'Foreground', 'WindowGeometry', 'WindowAttributes')),
        ('naozho_power', ('TrialChecks', 'DeliveryProof')),
    ]:
        for cls in classes:
            java = dest / (cls+'.java')
            java.write_bytes(archive.read(f'kernelsu/{module}/src/com/naozho/power/{java.name}'))
            files.append(java)
    subprocess.run([jdk/'javac', '--release', '11', '-d', dest, *files, Path(__file__).with_name('Replay103.java')], check=True)
    for mode in ('unmodified', 'without_banner'):
        print(mode, flush=True)
        subprocess.run([jdk/'java', '-cp', dest, 'com.naozho.power.Replay103', a.capture_dir, mode], check=True)
