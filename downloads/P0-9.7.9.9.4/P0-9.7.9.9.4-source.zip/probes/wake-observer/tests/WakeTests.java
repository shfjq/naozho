package com.naozho.wakeprobe;

import java.util.*;

public class WakeTests {
    static int passed;
    static void test(String name, Runnable body) {
        body.run();
        System.out.println("PASS " + name);
        passed++;
    }
    static void eq(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError(expected + " != " + actual);
    }
    static String dump(String state, long sleep, long wake) {
        return "POWER MANAGER (dumpsys power)\n  mWakefulness=" + state + "\n  mWakefulnessChanging=false\n"
                + "  mLastSleepTime=" + sleep + " (20 ms ago)\n  mLastWakeTime=" + wake
                + " (1 ms ago)\nDisplay Group User Activity:\n  displayGroupId=0\n";
    }
    static PowerEvidence awake(long sleep, long wake) { return PowerEvidence.parse(dump("Awake", sleep, wake)); }
    static WakeCycle on() {
        WakeCycle c = new WakeCycle(38, "test");
        c.observe(2, true, 100);
        return c;
    }
    static WakeCycle waking() {
        WakeCycle c = on();
        c.observe(1, false, 200);
        c.observe(2, true, 500);
        return c;
    }
    public static void main(String[] args) {
        test("complete OFF to ON", () -> {
            WakeCycle c = waking(); eq("FULL_WAKE", c.verify(awake(190, 490), 700, false));
            eq("38/test/1", c.epoch); eq("INTERACTIVE", c.phase);
        });
        test("initial ON only", () -> { WakeCycle c=on(); c.verify(awake(40,80),300,true); eq(null,c.epoch); });
        test("initial OFF without observed falling edge", () -> {
            WakeCycle c=new WakeCycle(38,"a"); c.observe(1,false,200); c.observe(2,true,500);
            c.verify(awake(190,490),700,true); eq(null,c.epoch);
        });
        test("AOD pulse and suspension", () -> {
            WakeCycle c=on(); c.observe(1,false,200); eq("AOD_ENTER",c.observe(3,false,260));
            eq("AOD_STATE_CHANGE",c.observe(4,false,300)); eq("AOD_EXIT_TO_DARK",c.observe(1,false,400)); eq(null,c.epoch);
        });
        test("interactive ambient pulse is insufficient", () -> {
            WakeCycle c=on(); c.observe(3,true,200); c.observe(2,true,500);
            eq("REFUSED_no_noninteractive_dark",c.verify(awake(190,490),700,true));
        });
        test("full wake directly out of noninteractive DOZE", () -> {
            WakeCycle c=on(); c.observe(4,false,200); eq("AOD_EXIT_TO_ON",c.observe(2,true,500));
            eq("FULL_WAKE",c.verify(awake(190,490),700,true));
        });
        test("ON pulse returns to DOZE before confirmation", () -> {
            WakeCycle c=waking(); eq("WAKING_REVERSED_TO_AOD",c.observe(3,false,530)); c.verify(awake(190,490),700,true); eq(null,c.epoch);
        });
        test("DREAMING with interactive true", () -> {
            WakeCycle c=waking(); eq("REFUSED_not_awake",c.verify(PowerEvidence.parse(dump("Dreaming",190,490)),700,true)); eq(null,c.epoch);
        });
        test("noninteractive ON", () -> {
            WakeCycle c=waking(); c.observe(2,false,505); eq("REFUSED_transition",c.verify(awake(190,490),700,true));
        });
        test("display ON before interactivity converges", () -> {
            WakeCycle c=on(); c.observe(1,false,200); c.observe(2,false,500);
            eq("WAKING_transition",c.verify(awake(190,490),600,false));
            c.observe(2,true,610); eq("FULL_WAKE",c.verify(awake(190,490),800,true));
        });
        test("power transition settles", () -> {
            WakeCycle c=waking(); eq("WAKING_transition",c.verify(PowerEvidence.parse(dump("Awake",190,490).replace("=false","=true")),650,false));
            eq("FULL_WAKE",c.verify(awake(190,490),900,true));
        });
        test("duplicate callbacks and duplicate proof", () -> {
            WakeCycle c=waking(); int rev=c.revision; eq("DUPLICATE",c.observe(2,true,502)); eq(1,c.duplicates); eq(rev,c.revision);
            c.verify(awake(190,490),700,false); c.verify(awake(190,490),702,false); eq(1L,c.count);
        });
        test("multi group and missing group", () -> {
            String line=dump("Awake",190,490); eq("default_group_unconfirmed",PowerEvidence.parse(line+"displayGroupId=1\n").error);
            eq("default_group_unconfirmed",PowerEvidence.parse(line.replace("displayGroupId=0","other")).error);
        });
        test("ambiguous power snapshot", () -> eq("power_fields_unconfirmed",PowerEvidence.parse(dump("Awake",190,490)+"mWakefulness=Awake\n").error));
        test("missing history", () -> eq("power_history_unconfirmed",PowerEvidence.parse(dump("Awake",190,490).replace("mLastSleepTime","other")).error));
        test("CRLF and bare uptime", () -> eq(null,PowerEvidence.parse(dump("Awake",190,490).replace(" (20 ms ago)","").replace("\n","\r\n")).error));
        test("future, reversed or unrelated history", () -> {
            for (long[] pair:new long[][]{{50,490},{201,490},{190,180},{190,720},{190,190}}) {
                eq("REFUSED_unpaired_power_history",waking().verify(awake(pair[0],pair[1]),700,true));
            }
        });
        test("missing boot ID", () -> {
            WakeCycle c=new WakeCycle(-1,"b"); c.observe(2,true,100); c.observe(1,false,200); c.observe(2,true,500);
            eq("REFUSED_boot_unknown",c.verify(awake(190,490),700,true)); eq(null,c.epoch);
        });
        test("loss of default display", () -> {
            WakeCycle c=waking(); c.observe(0,false,510); c.observe(2,true,520); c.verify(awake(190,490),700,true); eq(null,c.epoch);
        });
        test("readback gap cannot create epoch", () -> {
            WakeCycle c=waking(); c.invalidate(); c.observe(1,false,600); c.observe(2,true,800); c.verify(awake(590,790),900,true); eq(null,c.epoch);
        });
        test("inaccessible power is refused", () -> {
            WakeCycle c=waking(); eq("REFUSED_dump_permission_absent",c.verify(PowerEvidence.unknown("dump_permission_absent"),600,true)); eq(null,c.epoch);
        });
        test("multi-source alternating cycles and 8h uptime scale", () -> {
            WakeCycle c=on(); Set<String> epochs=new HashSet<>();
            for (int i=0;i<60;i++) {
                long t=200+i*28_800_000L; c.observe(1,false,t); c.observe(2,true,t+200);
                eq("FULL_WAKE",c.verify(awake(t-2,t+190),t+500,true)); epochs.add(c.epoch);
            }
            eq(60,epochs.size()); eq(60L,c.count);
        });
        test("dark to unsupported VR and ON_SUSPEND", () -> {
            for (int state:new int[]{5,6,0}) {
                WakeCycle c=waking(); c.observe(state,true,515); c.observe(2,true,550);
                c.verify(awake(190,490),700,true); eq(null,c.epoch);
            }
        });
        test("new process cannot inherit old cycle", () -> {
            WakeCycle old=waking(); old.verify(awake(190,490),700,true);
            WakeCycle next=new WakeCycle(38,"new"); next.observe(2,true,800);
            next.verify(awake(190,490),820,true); eq(null,next.epoch);
        });
        System.out.println("RESULT " + passed + " test groups passed");
    }
}
