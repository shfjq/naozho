import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from summarize import summarize


def row(i, event):
    return dict(session="s", session_row=i, event_classification=event, boot_id="boot_count:1",
                wake_epoch_id="id" if event == "FULL_WAKE" else None, observer_pid=123,
                wall_clock="example", elapsedRealtimeNanos=i*1_000_000_000, session_age_ms=i*1000,
                battery_pct=None, process_cpu_ms=i*2, previous_unclean_sessions=0)


class SummaryTest(unittest.TestCase):
    def test_rotations_and_gaps(self):
        first, last = row(1, "SESSION_START"), row(4, "SESSION_END")
        r = summarize([last, first, first])[0]
        self.assertEqual((r["unobserved_log_rows"], r["observed_duration_s"], r["process_cpu_delta_ms"]), (2, 3, 6))
        self.assertIsNone(r["cpu_wakeup_count"])

    def test_collisions_and_missing_end(self):
        r = summarize([row(5, "FULL_WAKE"), row(6, "FULL_WAKE")])[0]
        self.assertEqual(r["epoch_collisions"], 1)
        self.assertFalse(r["session_end_seen"])
        self.assertFalse(r["session_start_seen"])

    def test_conflicting_exports(self):
        with self.assertRaises(ValueError):
            summarize([row(1, "SESSION_START"), row(1, "SESSION_END")])


if __name__ == "__main__":
    unittest.main()
