"""Scan the packaged manifest and every DEX in the APK, offline."""
import os
import re
import sys
import tempfile
import subprocess
import zipfile
from pathlib import Path

apk = Path(sys.argv[1]).resolve()
bt = Path(os.environ["BUILD_TOOLS"]).resolve()
tree = subprocess.check_output([bt/"aapt2", "dump", "xmltree", apk, "--file", "AndroidManifest.xml"], text=True)
permissions = set(re.findall(r'"(android\.permission\.[A-Z_]+)"', tree))
assert permissions == {"android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
                       "android.permission.DUMP", "android.permission.POST_NOTIFICATIONS"}, permissions
for tag, count in [("activity", 1), ("service", 1), ("receiver", 0), ("provider", 0), ("activity-alias", 0)]:
    assert len(re.findall(r"^\s*E: "+tag+r" \(", tree, flags=re.M)) == count, tag
service = tree.split("E: service (", 1)[1]
assert re.search(r"android:exported[^\n]*=false", service)
assert "android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" in service
assert 'com.naozho.wakeprobe' in tree and 'com.naozho.clock' not in tree
with tempfile.TemporaryDirectory() as temp, zipfile.ZipFile(apk) as package:
    assert package.testzip() is None
    dex = [n for n in package.namelist() if re.fullmatch(r"classes\d*\.dex", n)]
    assert dex
    instructions = ""
    for name in dex:
        instructions += subprocess.check_output([bt/"dexdump", "-d", package.extract(name, temp)], text=True)
    calls = set(re.findall(r'invoke-[^\n]*?;\.([A-Za-z0-9_$]+):', instructions))
    expected = {"registerDisplayListener", "unregisterDisplayListener", "getState", "isInteractive",
                "isDeviceIdleMode", "dumpService", "startForeground"}
    forbidden = {"newWakeLock", "wakeUp", "goToSleep", "startLockTask", "stopLockTask", "startActivity",
                 "sendBroadcast", "sendOrderedBroadcast", "injectInputEvent", "acquireWakeLock", "exec",
                 "setAndAllowWhileIdle", "setAlarmClock", "setTurnScreenOn", "setWakeup", "putString"}
    assert expected <= calls, expected - calls
    assert not (forbidden & calls), forbidden & calls
    assert not re.search(r'invoke-[^\n]*Landroid/provider/Settings\$\w+;\.put', instructions)
    assert 'com.naozho.clock' not in instructions and '/dev/input' not in instructions
print("PASS APK CRC, manifest components/permissions, DEX observer calls and forbidden-call audit")
