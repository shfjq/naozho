#!/usr/bin/env bash
# No device, Gradle daemon or network required. The signing key stays outside the source tree.
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_JAR:?Set ANDROID_JAR to the API 36 android.jar}"
: "${BUILD_TOOLS:?Set BUILD_TOOLS to Android build-tools 35.0.0 or newer}"
: "${JAVA_HOME:?Set JAVA_HOME to JDK 17}"
: "${PROBE_KEYSTORE:?Set PROBE_KEYSTORE to an independent diagnostic PKCS12 file outside the tree}"
export PATH="$JAVA_HOME/bin:$PATH"
mkdir -p build
stage=$(mktemp -d "$PWD/build/compile.XXXXXX")
trap 'rm -rf -- "$stage"' EXIT
mkdir -p "$stage/classes" "$stage/dex" "$stage/tests"
javac -encoding UTF-8 --release 8 -cp "$ANDROID_JAR" -d "$stage/classes" src/com/naozho/wakeprobe/*.java
jar cf "$stage/app.jar" -C "$stage/classes" .
# Target an older supported DEX instruction floor; the final manifest requires API 36.
"$BUILD_TOOLS/d8" --min-api 34 --lib "$ANDROID_JAR" --output "$stage/dex" "$stage/app.jar"
"$BUILD_TOOLS/aapt2" link -I "$ANDROID_JAR" --manifest AndroidManifest.xml -o "$stage/base.apk"
(cd "$stage/dex" && zip -q -0 "$stage/base.apk" classes.dex)
"$BUILD_TOOLS/zipalign" -f 4 "$stage/base.apk" "$stage/aligned.apk"
if [[ ! -e "$PROBE_KEYSTORE" ]]; then
    keytool -genkeypair -alias wakeprobe -keyalg RSA -keysize 3072 -validity 3650 -storetype PKCS12 \
        -keystore "$PROBE_KEYSTORE" -storepass:env PROBE_STORE_PASS -dname 'CN=Wake Observer Diagnostics'
fi
"$BUILD_TOOLS/apksigner" sign --ks "$PROBE_KEYSTORE" --ks-key-alias wakeprobe --ks-pass env:PROBE_STORE_PASS \
    --out "$stage/probe.apk" "$stage/aligned.apk"
"$BUILD_TOOLS/apksigner" verify --verbose --print-certs "$stage/probe.apk"
javac -encoding UTF-8 --release 8 -cp "$stage/classes" -d "$stage/tests" tests/WakeTests.java
java -cp "$stage/classes:$stage/tests" com.naozho.wakeprobe.WakeTests
cp "$stage/probe.apk" build/cpday10-wake-observer-0.1.0.apk
sha256sum build/cpday10-wake-observer-0.1.0.apk
