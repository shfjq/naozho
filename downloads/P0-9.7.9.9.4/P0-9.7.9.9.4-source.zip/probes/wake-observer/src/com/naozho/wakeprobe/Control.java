package com.naozho.wakeprobe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.*;

public final class Control extends Activity {
    private TextView status;
    private LinearLayout layout;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(16 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        status = new TextView(this);
        layout.addView(status);
        button("开始观察", () -> {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            else start();
        });
        button("记录检查点", () -> {
            if (Observer.active) startService(new Intent(this, Observer.class).setAction(Observer.MARK));
            refresh();
        });
        button("刷新状态", this::refresh);
        button("停止观察", () -> { stopService(new Intent(this, Observer.class)); refresh(); });
        scroll.addView(layout);
        setContentView(scroll);
    }
    private void button(String text, Runnable action) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(v -> action.run());
        layout.addView(b);
    }
    private void start() {
        startForegroundService(new Intent(this, Observer.class));
        status.setText("正在申请开始观察，可点击刷新核对");
    }
    @Override public void onRequestPermissionsResult(int code, String[] names, int[] results) {
        super.onRequestPermissionsResult(code, names, results);
        if (code == 1 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) start();
        else status.setText("未启动。允许显示持续诊断通知后可开始。");
    }
    @Override protected void onResume() { super.onResume(); refresh(); }
    private void refresh() {
        boolean dump = checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED;
        status.setText(Observer.status + "\n电源状态读取：" + (dump ? "已授权" : "未授权，仅记录显示变化"));
    }
}
