package com.naozho.wakeprobe;

import android.content.Context;
import android.os.BatteryManager;
import android.os.Process;
import android.os.SystemClock;
import android.system.Os;
import android.os.PowerManager;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;

final class Journal {
    private final File current, previous;
    private final BatteryManager battery;
    private final PowerManager power;
    private final long start = SystemClock.elapsedRealtime();
    private long rows;
    Journal(Context context) {
        current = new File(context.getFilesDir(), "wake.jsonl");
        previous = new File(context.getFilesDir(), "wake.previous.jsonl");
        power = context.getSystemService(PowerManager.class);
        battery = context.getSystemService(BatteryManager.class);
    }
    void event(WakeCycle cycle, long callbackNs, String source, int id, int old, String event,
               PowerEvidence proof, boolean callbackDuplicate, int unclean) throws Exception {
        long now = SystemClock.elapsedRealtimeNanos();
        JSONObject row = new JSONObject();
        row.put("boot_id", cycle.boot < 0 ? JSONObject.NULL : "boot_count:" + cycle.boot);
        row.put("session", cycle.session);
        row.put("wake_epoch_id", cycle.epoch == null ? JSONObject.NULL : cycle.epoch);
        row.put("wall_clock", Instant.now().toString());
        row.put("elapsedRealtimeNanos", now);
        row.put("event_timestamp", callbackNs);
        row.put("callback_source", source);
        row.put("display_id", id);
        row.put("old_display_state", WakeCycle.name(old));
        row.put("new_display_state", WakeCycle.name(cycle.display));
        row.put("aod_transition", WakeCycle.ambient(old) == WakeCycle.ambient(cycle.display) ? "none" :
                WakeCycle.ambient(cycle.display) ? "enter" : "exit");
        row.put("device_idle", power.isDeviceIdleMode());
        row.put("observation_uptime_ms", SystemClock.uptimeMillis());
        row.put("isInteractive", cycle.display < 0 ? JSONObject.NULL : cycle.onInteractive);
        row.put("wakefulness", proof == null ? "UNKNOWN" : proof.wakefulness);
        row.put("power_status", proof == null ? "not_sampled" : proof.error == null ? "ok" : proof.error);
        if (proof != null && proof.error == null) {
            row.put("wakefulness_changing", proof.changing);
            row.put("last_sleep_uptime_ms", proof.sleep);
            row.put("last_wake_uptime_ms", proof.wake);
        }
        row.put("observer_pid", Process.myPid());
        row.put("event_classification", event);
        row.put("state", cycle.phase);
        row.put("duplicate_count", cycle.duplicates);
        row.put("duplicate_callback", callbackDuplicate);
        row.put("revision", cycle.revision);
        row.put("session_row", ++rows);
        row.put("session_age_ms", SystemClock.elapsedRealtime() - start);
        row.put("process_cpu_ms", Process.getElapsedCpuTime());
        row.put("previous_unclean_sessions", unclean);
        int pct = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        row.put("battery_pct", pct >= 0 && pct <= 100 ? pct : JSONObject.NULL);
        byte[] data = (row + "\n").getBytes(StandardCharsets.UTF_8);
        if (current.length() + data.length > 256 * 1024)
            Os.rename(current.getAbsolutePath(), previous.getAbsolutePath());
        try (FileOutputStream stream = new FileOutputStream(current, true)) { stream.write(data); }
    }
}
