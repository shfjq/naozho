package com.naozho.wakeprobe;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.hardware.display.DisplayManager;
import android.os.*;
import android.provider.Settings;
import android.view.Display;
import java.util.UUID;
import java.util.concurrent.*;

public final class Observer extends Service implements DisplayManager.DisplayListener {
    static volatile boolean active;
    static volatile String status = "未开始观察";
    static final String STOP = "stop", MARK = "mark";
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService reads = Executors.newSingleThreadExecutor();
    private final PowerRead powerRead = new PowerRead();
    private DisplayManager displays;
    private PowerManager power;
    private WakeCycle cycle;
    private Journal journal;
    private boolean running, busy, logFailed;
    private int unclean;
    private long edgeNs;
    private Runnable scheduled;
    private boolean deferred, deferredFinal;
    private boolean dumpAllowed() {
        return checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (STOP.equals(action)) { stopSelf(); return START_NOT_STICKY; }
        if (MARK.equals(action)) {
            if (running) log("manual_checkpoint", "CHECKPOINT", cycle.display, null, SystemClock.elapsedRealtimeNanos());
            else stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("observe", "息屏唤醒诊断", NotificationManager.IMPORTANCE_LOW));
            Intent stop = new Intent(this, Observer.class).setAction(STOP);
            Notification notification = new Notification.Builder(this, "observe")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details).setContentTitle("正在观察默认屏幕")
                    .setContentText("只读诊断 · 可随时停止").setOngoing(true)
                    .addAction(new Notification.Action.Builder(null, "停止观察", PendingIntent.getService(this, 1, stop,
                            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)).build()).build();
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            displays = getSystemService(DisplayManager.class);
            power = getSystemService(PowerManager.class);
            int boot = Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT, -1);
            cycle = new WakeCycle(boot, UUID.randomUUID().toString());
            SharedPreferences track = getSharedPreferences("sessions", MODE_PRIVATE);
            unclean = track.getInt("unclean", 0) + (track.getBoolean("open", false) ? 1 : 0);
            if (!track.edit().putBoolean("open", true).putInt("unclean", unclean).commit())
                throw new IllegalStateException("session store");
            journal = new Journal(this);
            displays.registerDisplayListener(getMainExecutor(), DisplayManager.EVENT_TYPE_DISPLAY_STATE
                    | DisplayManager.EVENT_TYPE_DISPLAY_REMOVED | DisplayManager.EVENT_TYPE_DISPLAY_ADDED, this);
            running = true;
            active = true;
            log("service", "SESSION_START", -1, null, SystemClock.elapsedRealtimeNanos());
            sample("registration", false);
        } catch (RuntimeException failed) {
            status = "观察启动失败：" + failed.getClass().getSimpleName();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private int displayState() {
        Display display = displays.getDisplay(Display.DEFAULT_DISPLAY);
        return display != null && display.isValid() ? display.getState() : Display.STATE_UNKNOWN;
    }
    private void sample(String source, boolean callback) {
        if (!running) return;
        int state = displayState(), old = cycle.display;
        boolean interactive = power.isInteractive();
        long now = SystemClock.elapsedRealtimeNanos();
        String event = cycle.observe(state, interactive, SystemClock.uptimeMillis());
        if (!"DUPLICATE".equals(event)) {
            if (state != WakeCycle.ON || old != WakeCycle.ON) edgeNs = now;
            cancelScheduled();
            log(source, event, old, null, now);
            schedule(state == Display.STATE_ON ? 200 : 0, false);
        } else if (callback) {
            log(source, event, old, null, now);
        }
    }
    @Override public void onDisplayChanged(int id) { if (id == 0) sample("display_state", true); }
    @Override public void onDisplayAdded(int id) { if (id == 0) sample("display_added", true); }
    @Override public void onDisplayRemoved(int id) {
        if (id != 0 || !running) return;
        int old = cycle.display;
        cycle.observe(WakeCycle.UNKNOWN, false, SystemClock.uptimeMillis());
        cancelScheduled();
        log("display_removed", "DEFAULT_DISPLAY_LOST", old, null, SystemClock.elapsedRealtimeNanos());
    }

    private void cancelScheduled() {
        if (scheduled != null) main.removeCallbacks(scheduled);
        deferred = false;
    }
    private void schedule(long delay, boolean last) {
        scheduled = () -> {
            if (!running) return;
            if (busy) { deferred = true; deferredFinal = last; return; }
            int rev = cycle.revision;
            long origin = edgeNs;
            busy = true;
            boolean permitted = dumpAllowed();
            reads.execute(() -> {
                PowerEvidence proof = permitted ? powerRead.read() : PowerEvidence.unknown("dump_permission_absent");
                main.post(() -> settled(rev, origin, last, proof));
            });
        };
        // Handler time uses uptime. A sleeping device need not wake for this check.
        main.postDelayed(scheduled, delay);
    }
    private void settled(int revision, long origin, boolean last, PowerEvidence proof) {
        busy = false;
        if (!running) return;
        if (revision != cycle.revision) {
            log("power_readback", "STALE_SAMPLE_DISCARDED", cycle.display, null, origin);
            if (deferred) { deferred = false; schedule(0, deferredFinal); }
            return;
        }
        if (displayState() != cycle.display) {
            cycle.invalidate();
            log("power_readback", "DISPLAY_CALLBACK_GAP", cycle.display, null, origin);
            sample("readback_baseline", false);
            return;
        }
        boolean expired = SystemClock.elapsedRealtimeNanos() - origin > 3_000_000_000L;
        boolean interactive = power.isInteractive();
        if (!expired && interactive != cycle.onInteractive) {
            // Interactivity can settle after the display callback without a second display edge.
            // Keep the witnessed ON edge and the original deadline.
            int state = cycle.display;
            String transition = cycle.observe(state, interactive, SystemClock.uptimeMillis());
            log("interactive_readback", transition, state, null, origin);
            if (!last) { schedule(200, true); return; }
        }
        if (cycle.display == WakeCycle.ON && expired) {
            proof = PowerEvidence.unknown("sample_expired");
            last = true;
        }
        boolean terminal = last || proof.error != null;
        String result = cycle.verify(proof, SystemClock.uptimeMillis(), terminal);
        log("power_readback", result, cycle.display, proof, origin);
        if (!terminal && cycle.waiting) schedule(400, true);
    }

    private void log(String source, String event, int old, PowerEvidence proof, long ns) {
        if (logFailed) return;
        try {
            journal.event(cycle, ns, source, 0, old, event, proof, "DUPLICATE".equals(event), unclean);
            status = "观察中 · " + cycle.phase + " · 已确认唤醒 " + cycle.count + " 次\n" + event;
        } catch (Exception error) {
            status = "写入诊断记录失败，已停止观察";
            logFailed = true;
            stopSelf();
        }
    }
    @Override public void onDestroy() {
        if (running) {
            running = false;
            active = false;
            cancelScheduled();
            displays.unregisterDisplayListener(this);
            log("service", "SESSION_END", cycle.display, null, SystemClock.elapsedRealtimeNanos());
            getSharedPreferences("sessions", MODE_PRIVATE).edit().putBoolean("open", logFailed).commit();
            if (!logFailed) status = "观察已停止";
        }
        reads.shutdownNow();
        powerRead.close();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
