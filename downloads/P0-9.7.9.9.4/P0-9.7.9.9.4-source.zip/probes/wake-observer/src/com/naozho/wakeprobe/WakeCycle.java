package com.naozho.wakeprobe;

/** Single-threaded. Times supplied to this class are uptime milliseconds, as in the PMS dump. */
final class WakeCycle {
    static final int UNKNOWN=0, OFF=1, ON=2, DOZE=3, DOZE_SUSPEND=4;
    final String session;
    final int boot;
    int display = -1, duplicates, revision;
    long onAnchor = -1, darkStart = -1, lastDark = -1, onEdge = -1, count;
    boolean waiting, onInteractive, darkWitness;
    String phase = "REFUSED", epoch;

    WakeCycle(int boot, String session) {
        this.boot = boot;
        this.session = session;
    }

    static boolean ambient(int state) { return state == DOZE || state == DOZE_SUSPEND; }
    static String name(int state) {
        switch (state) {
            case OFF: return "OFF";
            case ON: return "ON";
            case DOZE: return "DOZE";
            case DOZE_SUSPEND: return "DOZE_SUSPEND";
            case 5: return "VR";
            case 6: return "ON_SUSPEND";
            default: return "UNKNOWN";
        }
    }

    private void forgetDark() {
        darkStart = lastDark = -1;
        darkWitness = false;
        waiting = false;
    }

    void invalidate() {
        forgetDark();
        onAnchor = -1;
        epoch = null;
        display = -1;
        phase = "REFUSED";
        revision++;
    }

    String observe(int next, boolean interactive, long up) {
        int old = display;
        if (next == old && interactive == onInteractive) {
            duplicates++;
            return "DUPLICATE";
        }
        boolean sameDisplay = next == old;
        display = next;
        onInteractive = interactive;
        revision++;
        duplicates = 0;
        if (next == OFF || ambient(next)) {
            boolean reversed = waiting;
            epoch = null;
            waiting = false;
            if (old == ON && darkStart < 0 && onAnchor >= 0) darkStart = up;
            if (next == OFF || !interactive) darkWitness = true;
            lastDark = up;
            phase = next == OFF ? "DARK" : name(next);
            if (reversed) return next == OFF ? "WAKING_REVERSED_TO_DARK" : "WAKING_REVERSED_TO_AOD";
            if (sameDisplay) return "POWER_INTERACTIVITY_CHANGED";
            if (next == OFF) return ambient(old) ? "AOD_EXIT_TO_DARK" : "DARK_OBSERVED";
            return ambient(old) ? "AOD_STATE_CHANGE" : "AOD_ENTER";
        }
        if (next != ON) {
            forgetDark();
            onAnchor = -1;
            epoch = null;
            phase = "REFUSED";
            return "DISPLAY_UNKNOWN_OR_UNSUPPORTED";
        }
        if (!sameDisplay) onEdge = up;
        if (darkStart >= 0) {
            waiting = true;
            phase = "WAKING";
            return ambient(old) ? "AOD_EXIT_TO_ON" : "WAKE_CANDIDATE";
        }
        if (onAnchor < 0 && interactive) onAnchor = up;
        phase = epoch == null ? "WAKING" : "INTERACTIVE";
        return old < 0 ? "INITIAL_ON_BASELINE" : "ON_WITHOUT_DARK";
    }

    String verify(PowerEvidence power, long now, boolean finalCheck) {
        if (display != ON) return "DARK_OR_AMBIENT_SAMPLE";
        String problem = power.error;
        if (problem == null && (!onInteractive || power.changing)) problem = "transition";
        if (problem == null && !"Awake".equals(power.wakefulness)) problem = "not_awake";
        if (!waiting) {
            if (problem == null) {
                if (onAnchor < 0) onAnchor = now;
                phase = "INTERACTIVE";
            } else {
                phase = "REFUSED";
            }
            return problem == null ? "ON_BASELINE_CONFIRMED" : "ON_BASELINE_UNCONFIRMED";
        }
        if (!darkWitness) problem = "no_noninteractive_dark";
        if (boot < 0) problem = "boot_unknown";
        if (problem == null && (power.sleep < onAnchor || power.sleep > darkStart ||
                power.wake <= power.sleep || power.wake < lastDark || power.wake > now)) {
            problem = "unpaired_power_history";
        }
        if (problem != null) {
            if (finalCheck) {
                forgetDark();
                onAnchor = onInteractive ? now : -1;
                phase = "REFUSED";
            }
            return (finalCheck ? "REFUSED_" : "WAKING_") + problem;
        }
        epoch = boot + "/" + session + "/" + (++count);
        forgetDark();
        onAnchor = now;
        phase = "INTERACTIVE";
        return "FULL_WAKE";
    }
}
