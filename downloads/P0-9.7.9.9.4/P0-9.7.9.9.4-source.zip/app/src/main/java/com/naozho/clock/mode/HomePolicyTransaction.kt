package com.naozho.clock.mode

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyIdentifiers
import android.app.admin.PolicyUpdateResult
import android.app.admin.TargetUser
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import android.os.Build
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.util.UUID
import android.util.Log
import androidx.annotation.RequiresApi
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/** This app writes one HOME key. The initial target and package-wide clear scope require a DSH audit. */
@RequiresApi(34)
@SuppressLint("ApplySharedPref")
internal class HomePolicyTransaction(private val context: Context) {
    private val prefs = context.getSharedPreferences("managed_home_policy", Context.MODE_PRIVATE)

    fun prepareInspection(): Boolean {
        val nonce = UUID.randomUUID().toString()
        if (!prefs.edit().remove("target").remove("verified").putString("challenge", nonce).commit()) return false
        File(context.filesDir, "home-policy-challenge").writeText(nonce)
        return true
    }

    fun importInspection(native: ComponentName, clock: ComponentName): DesktopResult {
        val file = File(context.filesDir, "home-policy-audit.txt")
        if (file.length() !in 1L..4096L) return desktopFailure("读取 HOME 清单", "请运行 DSH 读取命令。")
        return try {
            val data = JSONObject(String(Base64.decode(file.readText().trim(), Base64.DEFAULT), Charsets.UTF_8))
            val raw = data.getString("previous")
            val target = if (raw.isEmpty()) null else requireNotNull(ComponentName.unflattenFromString(raw))
            val age = SystemClock.elapsedRealtime() - data.getLong("elapsed")
            if (data.getString("nonce") != prefs.getString("challenge", null) || data.getInt("user") != 0 ||
                data.getString("native") != native.flattenToString() || age !in 0L..300_000L ||
                (target != null && target != native && target != clock)) {
                desktopFailure("读取 HOME 清单", "清单已过期或用户、桌面、核对编号不符，请重新读取。")
            } else if (audit(native, target)) DesktopResult.Applied
            else desktopFailure("读取 HOME 清单", "无法保存核对结果。")
        } catch (e: Exception) {
            desktopFailure("读取 HOME 清单", "清单无法读取（${e.javaClass.simpleName}），请重新采集。")
        }
    }

    fun audit(native: ComponentName, previous: ComponentName?): Boolean =
        prefs.edit().putString("native", native.flattenToString())
            .putString("target", previous?.flattenToString() ?: "").remove("verified").remove("challenge").commit()

    fun hasKnownScope(native: ComponentName?): Boolean = native != null &&
        prefs.getString("native", null) == native.flattenToString() && prefs.contains("target")

    fun verified(target: ComponentName): Boolean = prefs.getString("verified", null) == target.flattenToString()
    fun verify(target: ComponentName): Boolean = prefs.edit().putString("verified", target.flattenToString()).commit()

    suspend fun apply(
        native: ComponentName?, clock: ComponentName, target: ComponentName?, trace: String,
        refreshExisting: Boolean = false,
        observed: () -> ComponentName?, clear: (String) -> Unit, set: (ComponentName) -> Unit,
    ): DesktopResult {
        val saved = prefs.getString("target", null)
        if (native == null || prefs.getString("native", null) != native.flattenToString() || saved == null) {
            return desktopFailure("核对持久 HOME 策略", "需要 DSH 核对当前用户的持久偏好范围，再在维护页登记核对结果。")
        }
        val previous = ComponentName.unflattenFromString(saved)
        if ((saved.isNotEmpty() && previous == null) || listOfNotNull(previous, target).any { it != clock && it != native }) {
            return desktopFailure("核对持久 HOME 策略", "目标组件超出已核对范围。")
        }
        if (previous != null && (previous != target || refreshExisting)) {
            val cleared = phase(previous, clearing = true, trace, observed) { clear(previous.packageName) }
            if (cleared is DesktopResult.Rejected) return cleared
        }
        if (target == null) return DesktopResult.Applied
        return phase(target, clearing = false, trace, observed) { set(target) }
    }

    private suspend fun phase(target: ComponentName, clearing: Boolean, trace: String,
        observed: () -> ComponentName?, write: () -> Unit): DesktopResult {
        val step = if (clearing) "清除旧 HOME 策略" else "写入 Home 策略"
        val expected = if (clearing) PolicyUpdateResult.RESULT_POLICY_CLEARED else PolicyUpdateResult.RESULT_POLICY_SET
        val before = observed()?.flattenToShortString()
        val request = HomePolicyResults.Request(expected,
            "$trace phase=${if (clearing) "clear" else "set"} phaseTarget=${target.flattenToShortString()} before=$before")
        if (!HomePolicyResults.begin(request)) return desktopFailure(step, "另一项 HOME 策略操作正在等待系统。")
        try {
            // Process death or a missing terminal result leaves the scope unknown on next entry.
            if (!prefs.edit().remove("target").remove("verified").remove("challenge").commit()) return desktopFailure(step, "无法保存操作起点。")
            Log.i("NaozhoMode", "${request.trace} call")
            write()
            val result = withTimeoutOrNull(8_000L) { request.result.await() }
            val after = observed()?.flattenToShortString()
            Log.i("NaozhoMode", "${request.trace} expected=$expected callback=$result after=$after")
            if (result != expected) return desktopFailure(step,
                "目标 ${target.flattenToShortString()}，期望回调 $expected，收到 ${result ?: "超时"}，当前 HOME=$after。请重新核对策略。")
            val saved = if (clearing) "" else target.flattenToString()
            if (!prefs.edit().putString("target", saved).commit()) return desktopFailure(step, "无法记录系统回调。")
            return DesktopResult.Applied
        } catch (e: RuntimeException) {
            return desktopFailure(step, "${request.trace} Android 调用失败（${e.javaClass.simpleName}），当前 HOME=${observed()}。", e)
        } finally {
            HomePolicyResults.end(request)
        }
    }
}

/** Framework results carry a policy key and relative user, but no client transaction ID or component. */
@RequiresApi(34)
internal object HomePolicyResults {
    class Request(val expected: Int, val trace: String) { val result = CompletableDeferred<Int>() }
    private var active: Request? = null
    @Synchronized fun begin(request: Request): Boolean {
        if (active != null) return false
        active = request
        return true
    }
    @Synchronized fun end(request: Request) { if (active === request) active = null }

    @Synchronized fun receive(event: String, policy: String, filter: IntentFilter?, user: TargetUser, result: Int): String {
        val pending = active ?: return "operation=unattributed"
        val exact = filter != null && filter.countActions() == 1 && filter.hasAction(Intent.ACTION_MAIN) &&
            filter.countCategories() == 2 && filter.hasCategory(Intent.CATEGORY_HOME) && filter.hasCategory(Intent.CATEGORY_DEFAULT) &&
            filter.countDataTypes() == 0 && filter.countDataSchemes() == 0 && filter.countDataPaths() == 0 &&
            filter.countDataAuthorities() == 0 && filter.countDataSchemeSpecificParts() == 0 &&
            (Build.VERSION.SDK_INT < 35 || filter.countUriRelativeFilterGroups() == 0)
        if (user != TargetUser.LOCAL_USER || policy != DevicePolicyIdentifiers.PERSISTENT_PREFERRED_ACTIVITY_POLICY ||
            !exact || event != "set-result") return "operation=unattributed active=[${pending.trace}]"
        val terminal = result == pending.expected ||
            (result != PolicyUpdateResult.RESULT_POLICY_CLEARED && result != PolicyUpdateResult.RESULT_POLICY_SET)
        return if (terminal && pending.result.complete(result)) "pending=[${pending.trace}]"
        else "operation=unattributed active=[${pending.trace}]"
    }
}
