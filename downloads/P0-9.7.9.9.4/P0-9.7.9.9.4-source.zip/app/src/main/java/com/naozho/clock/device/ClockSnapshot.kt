package com.naozho.clock.device

import java.util.Calendar
import java.util.Locale

internal data class ClockSnapshot(
    val time: String,
    val year: Int,
    val month: Int,
    val day: Int,
    val weekdayIndex: Int,
    val batteryPercent: Int?,
) {
    companion object {
        fun from(calendar: Calendar, batteryPercent: Int?): ClockSnapshot = ClockSnapshot(
            time = String.format(
                Locale.ROOT,
                "%02d:%02d",
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
            ),
            year = calendar.get(Calendar.YEAR),
            month = calendar.get(Calendar.MONTH) + 1,
            day = calendar.get(Calendar.DAY_OF_MONTH),
            weekdayIndex = calendar.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY,
            batteryPercent = batteryPercent,
        )
    }
}

internal fun batteryPercentage(level: Int, scale: Int): Int? {
    if (scale <= 0 || level !in 0..scale) return null
    return ((level.toLong() * 100 + scale / 2) / scale).toInt()
}
