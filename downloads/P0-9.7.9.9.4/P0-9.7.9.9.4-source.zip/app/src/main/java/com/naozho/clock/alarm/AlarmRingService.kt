package com.naozho.clock.alarm

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.PowerManager
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class AlarmRingService : Service() {
    private val app get() = application as AlarmRuntime
    private val sounds by lazy { AlarmSounds(this) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var observing = false
    private var latestStart = 0

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        latestStart = startId
        if (!observing) {
            app.alerts.createChannels()
            startForeground(AlarmAlerts.SERVICE_NOTIFICATION_ID, app.alerts.foreground())
            observing = true
            observeQueue()
        }
        val action = intent?.action
        if (action == "snoozed" || action == "stopped") {
            val path = intent.data?.takeIf { it.scheme == "naozho" && it.authority == "ring" }?.pathSegments
            val at = path?.getOrNull(1)?.toLongOrNull()
            if (path?.size == 2 && at != null) {
                scope.launch { app.repository.finish(path[0], at, action) }
            }
        }
        return START_STICKY
    }

    private fun observeQueue() {
        scope.launch {
            app.repository.active.map { it.firstOrNull() }
                .distinctUntilChangedBy { it?.let { plan -> plan.id to plan.activeAt } }
                .collectLatest { plan ->
                    val at = plan?.activeAt
                    if (plan == null || at == null) {
                        val start = latestStart
                        delay(250)
                        if (app.repository.active.first().isEmpty()) stopSelfResult(start)
                        return@collectLatest
                    }
                    val started = app.repository.begin(plan.id, at) ?: return@collectLatest
                    val remaining = AlarmTimes.RING_LIMIT -
                        (System.currentTimeMillis() - started).coerceAtLeast(0L)
                    if (remaining <= 0L) {
                        app.repository.finish(plan.id, at, "timed_out")
                        return@collectLatest
                    }
                    val wake = getSystemService(PowerManager::class.java)
                        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "naozho:alarm-playback")
                    wake.acquire(remaining + 15_000L)
                    try {
                        app.ringControls.show(plan)
                        app.alerts.show(plan)
                        var fallback = false
                        var player: MediaPlayer? = null
                        try {
                            withContext(Dispatchers.IO) {
                                player = sounds.prepare(plan) { fallback = true }
                            }
                            if (fallback) app.repository.audit(plan.id, "ringtone_fallback", at)
                            val end = android.os.SystemClock.elapsedRealtime() + remaining
                            val played = player?.let { play(it, plan.ramp, remaining) } ?: false
                            if (!played && plan.ringtone != null && !fallback) {
                                player?.release()
                                player = null
                                app.repository.audit(plan.id, "ringtone_fallback", at)
                                withContext(Dispatchers.IO) {
                                    player = sounds.prepare(plan.copy(ringtone = null)) {}
                                }
                                val left = (end - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0)
                                if (left > 0 && player?.let { play(it, plan.ramp, left) } != true) {
                                    app.repository.audit(plan.id, "audio_failed", at)
                                    delay((end - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0))
                                }
                            } else if (!played) {
                                app.repository.audit(plan.id, "audio_failed", at)
                                delay((end - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0))
                            }
                            app.repository.finish(plan.id, at, "timed_out")
                        } finally {
                            player?.release()
                        }
                    } finally {
                        app.ringControls.show(null)
                        app.alerts.clear()
                        if (wake.isHeld) wake.release()
                    }
                }
        }
    }

    /** Returns true when playback lasted until the ringing window expired. */
    private suspend fun play(player: MediaPlayer, ramp: Boolean, duration: Long): Boolean {
        val error = CompletableDeferred<Unit>()
        player.setOnErrorListener { _, _, _ -> error.complete(Unit); true }
        try {
            player.start()
        } catch (exception: RuntimeException) {
            Log.w("NaozhoAlarm", "Unable to start audio", exception)
            return false
        }
        return withTimeoutOrNull(duration) {
            coroutineScope {
                val volume = if (ramp) launch {
                    for (step in 1..25) {
                        delay(1_000)
                        val gain = AlarmSounds.START_VOLUME + (1f - AlarmSounds.START_VOLUME) * step / 25
                        runCatching { player.setVolume(gain, gain) }
                    }
                } else null
                try {
                    error.await()
                    false
                } finally {
                    volume?.cancel()
                }
            }
        } ?: true
    }

    override fun onDestroy() {
        scope.cancel()
        app.alerts.clear()
        super.onDestroy()
    }
}
