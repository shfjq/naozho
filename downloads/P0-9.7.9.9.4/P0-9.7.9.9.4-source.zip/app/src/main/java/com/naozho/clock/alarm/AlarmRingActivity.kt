package com.naozho.clock.alarm

import android.app.ActivityManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.naozho.clock.data.AlarmPlan
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class AlarmRingActivity : ComponentActivity() {
    private val controls get() = (application as AlarmRuntime).ringControls
    private var plan by mutableStateOf<AlarmPlan?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        controls.attach(window)
        if (Build.VERSION.SDK_INT < 27) {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                BackHandler(plan != null && getSystemService(ActivityManager::class.java).lockTaskModeState ==
                    ActivityManager.LOCK_TASK_MODE_LOCKED) {}
                Surface(Modifier.fillMaxSize()) {
                    plan?.let { alarm ->
                        Column(
                            modifier = Modifier.safeDrawingPadding().verticalScroll(rememberScrollState())
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically),
                        ) {
                            Text("正在响铃", style = MaterialTheme.typography.labelLarge)
                            Text(
                                String.format(Locale.ROOT, "%02d:%02d", alarm.hour, alarm.minute),
                                style = MaterialTheme.typography.displaySmall,
                            )
                            if (alarm.label.isNotBlank()) {
                                Text(alarm.label, textAlign = TextAlign.Center)
                            }
                            Button({ controls.request(alarm, "stopped") }, Modifier.fillMaxWidth()) {
                                Text("停止 · 音量加键")
                            }
                            OutlinedButton({ controls.request(alarm, "snoozed") }, Modifier.fillMaxWidth()) {
                                Text("贪睡 ${alarm.snoozeMinutes} 分钟 · 音量减键")
                            }
                        }
                    }
                }
            }
        }
        lifecycleScope.launch {
            controls.ringing.collectLatest { active ->
                plan = active
                if (active == null) {
                    // Leave time for the paired key-up and a queued alarm to reach this window.
                    delay(350)
                    withTimeoutOrNull(2_500) {
                        while (controls.hasCapturedVolumeKey) delay(50)
                    }
                    finish()
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        Log.i("NaozhoAlarm", "Ringing window focused=$hasFocus")
    }
}
