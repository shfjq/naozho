package com.naozho.clock.device

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.util.GregorianCalendar
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

internal class AndroidClockSource(private val context: Context) {
    fun snapshot(): ClockSnapshot {
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return ClockSnapshot.from(GregorianCalendar(), battery.batteryPercent())
    }

    fun observe(): Flow<ClockSnapshot> = callbackFlow {
        var batteryPercent: Int? = null
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == Intent.ACTION_BATTERY_CHANGED) {
                    batteryPercent = intent.batteryPercent()
                }
                trySend(ClockSnapshot.from(GregorianCalendar(), batteryPercent))
            }
        }

        // Every action in this filter is a protected Android system broadcast.
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        batteryPercent = context.registerReceiver(receiver, filter).batteryPercent()
        trySend(ClockSnapshot.from(GregorianCalendar(), batteryPercent))
        awaitClose { context.unregisterReceiver(receiver) }
    }

    private fun Intent?.batteryPercent(): Int? = this?.let {
        batteryPercentage(
            level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1),
            scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1),
        )
    }
}
