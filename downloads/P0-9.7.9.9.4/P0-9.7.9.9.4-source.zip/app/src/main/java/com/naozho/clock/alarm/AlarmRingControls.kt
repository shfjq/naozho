package com.naozho.clock.alarm

import android.view.KeyEvent
import android.view.Window
import com.naozho.clock.data.AlarmPlan
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Shared by the clock and ringing windows. All calls come from the main thread. */
internal class AlarmRingControls(private val finish: (String, Long, String) -> Unit) {
    private val current = MutableStateFlow<AlarmPlan?>(null)
    val ringing = current.asStateFlow()
    private val capturedDownTimes = mutableMapOf<Int, Long>()
    private var requested: Pair<String, Long>? = null
    private var lastVolumeActionAt: Long? = null
    val hasCapturedVolumeKey: Boolean get() = capturedDownTimes.isNotEmpty()

    fun attach(window: Window) {
        val callback = window.callback
        window.callback = object : Window.Callback by callback {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean =
                dispatch(event) || callback.dispatchKeyEvent(event)
        }
    }

    fun show(plan: AlarmPlan?) {
        current.value = plan
    }

    fun dispatch(event: KeyEvent): Boolean {
        val action = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> "stopped"
            KeyEvent.KEYCODE_VOLUME_DOWN -> "snoozed"
            else -> return false
        }
        val captured = capturedDownTimes[event.keyCode] == event.downTime
        if (event.action == KeyEvent.ACTION_UP) {
            if (captured) capturedDownTimes.remove(event.keyCode)
            return captured || current.value != null
        }
        if (event.action != KeyEvent.ACTION_DOWN) return false
        if (captured) return true
        val plan = current.value ?: return false
        capturedDownTimes[event.keyCode] = event.downTime
        if (event.repeatCount != 0 || event.isCanceled) return true
        // A double-press while the next queued alarm takes over must not silence it.
        val previous = lastVolumeActionAt
        if (previous != null && event.eventTime - previous in 0L until 350L) return true
        if (request(plan, action)) lastVolumeActionAt = event.eventTime
        return true
    }

    fun request(plan: AlarmPlan, action: String): Boolean {
        val at = plan.activeAt ?: return false
        val live = current.value
        val occurrence = plan.id to at
        if (live?.id != plan.id || live.activeAt != at || requested == occurrence) return false
        requested = occurrence
        finish(plan.id, at, action)
        return true
    }
}
