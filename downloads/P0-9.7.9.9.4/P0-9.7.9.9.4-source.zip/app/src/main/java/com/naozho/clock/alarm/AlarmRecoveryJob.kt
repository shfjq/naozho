package com.naozho.clock.alarm

import android.app.job.JobParameters
import android.app.job.JobService
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Recovery can outlive the short lifetime of a system broadcast. */
class AlarmRecoveryJob : JobService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val tasks = mutableMapOf<Int, Job>()

    override fun onStartJob(parameters: JobParameters): Boolean {
        val reason = Recovery.entries.firstOrNull { idFor(it) == parameters.jobId } ?: return false
        tasks.remove(parameters.jobId)?.cancel()
        tasks[parameters.jobId] = scope.launch {
            try {
                Log.i("NaozhoAlarm", "Recovery started reason=$reason")
                withContext(Dispatchers.IO) {
                    (application as AlarmRuntime).repository.recover(reason)
                }
                Log.i("NaozhoAlarm", "Recovery completed reason=$reason")
                jobFinished(parameters, false)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                Log.e("NaozhoAlarm", "Recovery failed reason=$reason", error)
                jobFinished(parameters, true)
            } finally {
                if (tasks[parameters.jobId] === coroutineContext[Job]) tasks.remove(parameters.jobId)
            }
        }
        return true
    }

    override fun onStopJob(parameters: JobParameters): Boolean {
        tasks.remove(parameters.jobId)?.cancel()
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        internal fun idFor(reason: Recovery): Int = when (reason) {
            Recovery.RESTORE -> 100
            Recovery.CLOCK_CHANGED -> 101
            Recovery.REBOOT -> 102
        }
    }
}
