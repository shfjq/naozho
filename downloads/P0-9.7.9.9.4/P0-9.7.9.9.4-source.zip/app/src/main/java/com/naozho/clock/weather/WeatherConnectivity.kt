package com.naozho.clock.weather

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

internal fun weatherConnectivity(context: Context): Flow<Boolean> = callbackFlow {
    val manager = context.getSystemService(ConnectivityManager::class.java)

    fun publish(excluding: Network? = null) {
        trySend(networkAvailable(manager, excluding))
    }

    val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = publish()
        override fun onLost(network: Network) = publish(excluding = network)
        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) = publish()
    }
    val registered = runCatching {
        if (Build.VERSION.SDK_INT >= 24) manager.registerDefaultNetworkCallback(callback)
        else manager.registerNetworkCallback(
            NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
            callback,
        )
    }.isSuccess
    publish()
    awaitClose { if (registered) manager.unregisterNetworkCallback(callback) }
}.distinctUntilChanged()

internal fun weatherNetworkAvailable(context: Context): Boolean =
    networkAvailable(context.getSystemService(ConnectivityManager::class.java))

private fun networkAvailable(manager: ConnectivityManager?, excluding: Network? = null): Boolean = runCatching {
    val active = manager?.activeNetwork ?: return false
    active != excluding &&
        manager.getNetworkCapabilities(active)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
}.getOrDefault(false)
