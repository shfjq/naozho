package com.naozho.clock.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.naozho.clock.alarm.AlarmRepository
import com.naozho.clock.alarm.AlarmRingActivity
import com.naozho.clock.alarm.AlarmSounds
import com.naozho.clock.data.AlarmPlan
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

internal data class AlarmPermissions(
    val exact: Boolean = false,
    val notifications: Boolean = false,
    val fullScreen: Boolean = false,
)

private val chineseDays = listOf("一", "二", "三", "四", "五", "六", "日")
private val dateAndTime = DateTimeFormatter.ofPattern("M月d日 HH:mm", Locale.SIMPLIFIED_CHINESE)

internal fun upcomingStatus(plans: List<AlarmPlan>, permissions: AlarmPermissions): ClockTile {
    if (plans.any { it.activeAt != null }) return ClockTile("正在响铃")
    val entries = plans.flatMap { plan ->
        listOfNotNull(plan.nextAt?.let { it to plan.nextRegistered },
            plan.snoozeAt?.let { it to plan.snoozeRegistered })
    }
    if (entries.isEmpty()) return ClockTile(if (plans.isNotEmpty()) "已关闭" else null)
    val registrationAllowed = permissions.exact && permissions.notifications
    val nextRegistered = entries.filter { registrationAllowed && it.second }.minOfOrNull { it.first }
    if (nextRegistered != null) return ClockTile(formatDate(nextRegistered), "已启用")
    return ClockTile(formatDate(entries.minOf { it.first }), "已启用 · 未登记")
}

@Composable
internal fun AlarmHub(
    repository: AlarmRepository,
    plans: List<AlarmPlan>,
    permissions: AlarmPermissions,
    systemUiAvailable: Boolean,
    requestPermission: (ClockPermission) -> Unit,
    close: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sounds = remember(context) { AlarmSounds(context.applicationContext) }
    var editId by rememberSaveable { mutableStateOf<String?>(null) }
    var removeId by rememberSaveable { mutableStateOf<String?>(null) }
    var showEvents by rememberSaveable { mutableStateOf(false) }

    BackHandler(editId != null || showEvents) {
        if (editId != null) editId = null else showEvents = false
    }

    Surface(Modifier.fillMaxSize()) {
        val selectedId = editId
        if (selectedId != null) {
            val existing = plans.firstOrNull { it.id == selectedId }
            val plan = existing ?: remember(selectedId) {
                val next = LocalTime.now().plusMinutes(1)
                AlarmPlan(selectedId, "", next.hour, next.minute, 0, true)
            }
            AlarmEditor(plan, sounds, systemUiAvailable, cancel = { editId = null }) { revised ->
                repository.save(revised)
                if (existing?.ringtone != revised.ringtone) sounds.remove(existing?.ringtone)
                editId = null
            }
        } else if (showEvents) {
            val events by repository.events.collectAsStateWithLifecycle(initialValue = emptyList())
            LazyColumn(
                Modifier.safeDrawingPadding().padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item { TextButton({ showEvents = false }) { Text("返回闹铃") } }
                if (events.isEmpty()) item { Text("暂无闹铃记录") }
                items(events, key = { it.id }) { event ->
                    Text("${formatDate(event.at)} · ${eventName(event.action)}")
                }
            }
        } else {
            LazyColumn(
                Modifier.safeDrawingPadding().padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    TextButton(close) { Text("返回时钟") }
                    Text("闹铃", style = MaterialTheme.typography.headlineMedium)
                    Button({ editId = UUID.randomUUID().toString() }, Modifier.fillMaxWidth()) {
                        Text("新建闹铃")
                    }
                }
                val missingPermissions = permissions.missingRequests()
                if (missingPermissions.isNotEmpty()) {
                    item {
                        if (systemUiAvailable) {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    PermissionActions(missingPermissions, requestPermission)
                                }
                            }
                        }
                        else Text("有闹铃权限需要确认。请先验证 PIN 进入安卓模式，再前往 Android 设置。")
                    }
                }
                if (plans.any { it.activeAt != null }) item {
                    OutlinedButton({ context.startActivity(Intent(context, AlarmRingActivity::class.java)) }) {
                        Text("打开响铃界面")
                    }
                }
                if (plans.isEmpty()) item { Text("还没有闹铃") }
                items(plans, key = { it.id }) { plan ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(clockTime(plan), Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                                Switch(
                                    plan.enabled || plan.snoozeAt != null || plan.activeAt != null,
                                    { checked -> scope.launch { repository.setEnabled(plan.id, checked) } },
                                    Modifier.semantics { contentDescription = "${clockTime(plan)} 闹铃开关" },
                                )
                            }
                            if (plan.label.isNotBlank()) Text(plan.label)
                            Text(repeatLabel(plan.weekdays))
                            Text(planStatus(plan, permissions), style = MaterialTheme.typography.bodySmall)
                            Row {
                                TextButton({ editId = plan.id }) { Text("编辑") }
                                TextButton({ removeId = plan.id }) { Text("删除") }
                            }
                        }
                    }
                }
                item { TextButton({ showEvents = true }) { Text("响铃与登记记录") } }
            }
        }
    }

    val deletion = removeId
    if (deletion != null) {
        AlertDialog(
            onDismissRequest = { removeId = null },
            title = { Text("删除此闹铃？") },
            text = { Text("同时取消该闹铃的计划和贪睡。") },
            confirmButton = {
                TextButton({
                    removeId = null
                    val sound = plans.firstOrNull { it.id == deletion }?.ringtone
                    scope.launch { repository.delete(deletion); sounds.remove(sound) }
                }) { Text("删除") }
            },
            dismissButton = { TextButton({ removeId = null }) { Text("取消") } },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AlarmEditor(
    plan: AlarmPlan,
    sounds: AlarmSounds,
    systemUiAvailable: Boolean,
    cancel: () -> Unit,
    save: suspend (AlarmPlan) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var hour by rememberSaveable(plan.id) { mutableStateOf(plan.hour.toString().padStart(2, '0')) }
    var minute by rememberSaveable(plan.id) { mutableStateOf(plan.minute.toString().padStart(2, '0')) }
    var name by rememberSaveable(plan.id) { mutableStateOf(plan.label) }
    var days by rememberSaveable(plan.id) { mutableIntStateOf(plan.weekdays) }
    var ramp by rememberSaveable(plan.id) { mutableStateOf(plan.ramp) }
    var snooze by rememberSaveable(plan.id) { mutableStateOf(plan.snoozeMinutes.toString()) }
    var sound by rememberSaveable(plan.id) { mutableStateOf(plan.ringtone) }
    var soundLabel by rememberSaveable(plan.id) { mutableStateOf(plan.ringtoneLabel) }
    var error by rememberSaveable(plan.id) { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val openSound = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            error = null
            try {
                val imported = sounds.import(uri)
                if (sound != plan.ringtone) sounds.remove(sound)
                sound = imported.key
                soundLabel = imported.label
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                error = "无法导入铃声，请选择可读的音频文件（最多 20 MB）。"
            } finally {
                busy = false
            }
        }
    }
    val cancelEdit = {
        if (!busy) scope.launch {
            if (sound != plan.ringtone) sounds.remove(sound)
            cancel()
        }
        Unit
    }
    BackHandler { cancelEdit() }

    Column(
        Modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("闹铃设置", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField(hour, { hour = it }, "小时", Modifier.weight(1f), 2)
            NumberField(minute, { minute = it }, "分钟", Modifier.weight(1f), 2)
        }
        OutlinedTextField(name, { name = it.take(60) }, Modifier.fillMaxWidth(), label = { Text("名称") }, singleLine = true)
        Text("重复")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(days == 0, { days = 0 }, { Text("一次") })
            FilterChip(days == 127, { days = 127 }, { Text("每天") })
            chineseDays.forEachIndexed { index, day ->
                val bit = 1 shl index
                FilterChip(days and bit != 0, { days = days xor bit }, { Text("周$day") })
            }
        }
        NumberField(snooze, { snooze = it }, "贪睡分钟（1–120）", Modifier.fillMaxWidth(), 3)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("渐强音量", Modifier.weight(1f))
            Switch(ramp, { ramp = it }, Modifier.semantics { contentDescription = "渐强音量" })
        }
        Text(soundLabel ?: "系统默认铃声")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (systemUiAvailable) {
                OutlinedButton({ openSound.launch(arrayOf("audio/*")) }, enabled = !busy) { Text("选择音频文件") }
            }
            if (sound != null) TextButton({
                scope.launch {
                    if (sound != plan.ringtone) sounds.remove(sound)
                    sound = null
                    soundLabel = null
                }
            }, enabled = !busy) { Text("使用默认铃声") }
        }
        if (!systemUiAvailable) Text("导入音频前，请在管理员恢复中停用受管锁定。")
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button({
            val h = hour.toIntOrNull()
            val m = minute.toIntOrNull()
            val s = snooze.toIntOrNull()
            if (h == null || h !in 0..23 || m == null || m !in 0..59 || s == null || s !in 1..120) {
                error = "请输入有效的时、分与贪睡时长。"
            } else scope.launch {
                busy = true
                try {
                    save(plan.copy(label = name.trim(), hour = h, minute = m, weekdays = days,
                        ringtone = sound, ringtoneLabel = soundLabel, ramp = ramp, snoozeMinutes = s))
                } finally {
                    busy = false
                }
            }
        }, Modifier.fillMaxWidth(), enabled = !busy) { Text("保存闹铃") }
        TextButton(cancelEdit, enabled = !busy) { Text("取消") }
    }
}

@Composable
private fun NumberField(value: String, change: (String) -> Unit, label: String, modifier: Modifier, digits: Int) {
    OutlinedTextField(value, { change(it.filter { ch -> ch in '0'..'9' }.take(digits)) }, modifier,
        label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
}

private fun planStatus(plan: AlarmPlan, permissions: AlarmPermissions): String {
    if (plan.activeAt != null) return "正在响铃或等待播放"
    val allowed = permissions.exact && permissions.notifications
    return listOfNotNull(
        plan.nextAt?.let { if (allowed && plan.nextRegistered) "已登记 ${formatDate(it)}" else "计划 ${formatDate(it)} · 未登记" },
        plan.snoozeAt?.let { if (allowed && plan.snoozeRegistered) "贪睡至 ${formatDate(it)}" else "贪睡 ${formatDate(it)} · 未登记" },
    ).joinToString("\n").ifBlank { "已关闭" }
}

private fun repeatLabel(days: Int) = when (days) {
    0 -> "一次"
    127 -> "每天"
    else -> chineseDays.filterIndexed { index, _ -> days and (1 shl index) != 0 }
        .joinToString("、") { "周$it" }
}

private fun clockTime(plan: AlarmPlan) = String.format(Locale.ROOT, "%02d:%02d", plan.hour, plan.minute)

private fun formatDate(ms: Long): String =
    dateAndTime.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

private fun eventName(action: String) = when (action) {
    "saved" -> "已保存"
    "registered" -> "已登记"
    "unregistered", "registration_blocked", "snooze_unregistered" -> "未登记"
    "triggered" -> "已触发"
    "snoozed" -> "请求贪睡"
    "stopped" -> "已停止"
    "enabled" -> "已启用"
    "disabled" -> "已关闭"
    "deleted" -> "已删除"
    "ringtone_fallback" -> "已切换默认铃声"
    "missed" -> "超过补响时限"
    "timed_out" -> "响铃超时停止"
    "overlap" -> "与本组响铃重叠"
    "interrupted_reboot" -> "重启中断响铃"
    "audio_failed" -> "铃声播放失败"
    "playback_blocked" -> "系统阻止播放服务"
    else -> action
}
