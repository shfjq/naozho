package com.naozho.clock.mode

import android.app.Activity
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

internal enum class AdminOperation(val label: String) {
    RESET_PIN("设置或重设时钟 PIN"),
    CHANGE_PIN("修改时钟 PIN"),
    USE_RECOVERY("使用一次性恢复码"),
    ROTATE_RECOVERY("重新生成恢复码"),
    SAVE_HOME("保存原生桌面"),
    ENABLE_KIOSK("启用专机"),
    PAUSE_KIOSK("暂停专机"),
    KEYGUARD_POLICY("修改系统锁屏策略"),
    SWITCH_TO_ANDROID("进入安卓模式"),
    DEVICE_ADMIN("修改应用设备管理员授权"),
}

/** In-memory, operation-bound authority. Revocation and a credential write cannot overlap. */
internal class CredentialApproval(private val operation: AdminOperation) {
    @Volatile private var active = true

    fun permits(action: AdminOperation): Boolean = active && action == operation

    @Synchronized fun <T> whileValid(action: AdminOperation, write: () -> T): T? =
        if (permits(action)) write() else null

    @Synchronized fun revoke() { active = false }
}

internal fun interface DeviceCredentialPrompt {
    fun launch(title: String, complete: (Boolean) -> Unit): () -> Unit
}

/** Owns one challenge at a time. Neither the challenge nor its result is restored from a Bundle. */
internal class SystemCredentialGate(
    private val activity: ComponentActivity,
    private val prompt: DeviceCredentialPrompt = PlatformCredentialPrompt(activity),
    private val onScreenOff: () -> Unit = {},
) : DefaultLifecycleObserver {
    private val keyguard get() = activity.getSystemService(KeyguardManager::class.java)
    private var pending: Attempt? = null
    private var approval: CredentialApproval? = null
    var waiting by mutableStateOf(false)
        private set

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            cancel()
            onScreenOff()
        }
    }

    init {
        ContextCompat.registerReceiver(activity, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF),
            ContextCompat.RECEIVER_NOT_EXPORTED)
        activity.lifecycle.addObserver(this)
    }

    fun request(action: AdminOperation, rejected: (String) -> Unit, verified: (CredentialApproval) -> Unit) {
        if (pending != null || !inForeground()) return
        approval?.revoke()
        approval = null
        if (!keyguard.isDeviceSecure) {
            rejected("请先在 Android 设置中设置系统 PIN、图案或密码。")
            return
        }
        val attempt = Attempt(action, rejected, verified)
        pending = attempt
        waiting = true
        try {
            attempt.cancelPrompt = prompt.launch(action.label) { ok ->
                if (pending === attempt && attempt.result == null) {
                    attempt.result = ok
                    deliver()
                }
            }
            if (pending === attempt) {
                attempt.timeout = activity.lifecycleScope.launch {
                    delay(60_000)
                    if (pending === attempt) {
                        cancel()
                        rejected("系统凭据验证超时，请重新发起。")
                    }
                }
            }
        } catch (_: RuntimeException) {
            if (pending === attempt) {
                cancel()
                rejected("无法打开 Android 系统凭据验证，操作已取消。")
            }
        }
    }

    private fun deliver() {
        val attempt = pending ?: return
        val verified = attempt.result ?: return
        if (!inForeground()) return
        pending = null
        waiting = false
        attempt.timeout?.cancel()
        if (!verified || !keyguard.isDeviceSecure || keyguard.isDeviceLocked) {
            attempt.rejected("Android 系统凭据验证失败或已取消。")
            return
        }
        val grant = CredentialApproval(attempt.action)
        approval = grant
        attempt.verified(grant)
    }

    private fun inForeground() = activity.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) &&
        !activity.isFinishing && !activity.isDestroyed && !activity.isChangingConfigurations

    fun cancel() {
        val attempt = pending
        pending = null
        waiting = false
        approval?.revoke()
        approval = null
        attempt?.timeout?.cancel()
        attempt?.cancelPrompt?.invoke()
    }

    override fun onResume(owner: LifecycleOwner) { deliver() }
    override fun onPause(owner: LifecycleOwner) { approval?.revoke() }
    override fun onDestroy(owner: LifecycleOwner) {
        cancel()
        activity.unregisterReceiver(screenOff)
        owner.lifecycle.removeObserver(this)
    }

    private class Attempt(
        val action: AdminOperation,
        val rejected: (String) -> Unit,
        val verified: (CredentialApproval) -> Unit,
    ) {
        var result: Boolean? = null
        var cancelPrompt: (() -> Unit)? = null
        var timeout: Job? = null
    }
}

private class PlatformCredentialPrompt(private val activity: ComponentActivity) : DeviceCredentialPrompt {
    override fun launch(title: String, complete: (Boolean) -> Unit): () -> Unit =
        if (Build.VERSION.SDK_INT >= 30) launchPrompt(title, complete) else launchKeyguard(title, complete)

    @RequiresApi(30)
    private fun launchPrompt(title: String, complete: (Boolean) -> Unit): () -> Unit {
        val cancellation = CancellationSignal()
        val prompt = BiometricPrompt.Builder(activity).setTitle(title)
            .setSubtitle("请验证 Android 系统屏幕锁")
            .setAllowedAuthenticators(DEVICE_CREDENTIAL).build()
        prompt.authenticate(cancellation, activity.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                complete(result.authenticationType == BiometricPrompt.AUTHENTICATION_RESULT_TYPE_DEVICE_CREDENTIAL)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { complete(false) }
            override fun onAuthenticationFailed() { complete(false) }
        })
        return cancellation::cancel
    }

    @Suppress("DEPRECATION")
    private fun launchKeyguard(title: String, complete: (Boolean) -> Unit): () -> Unit {
        val keyguard = activity.getSystemService(KeyguardManager::class.java)
        val intent = checkNotNull(keyguard.createConfirmDeviceCredentialIntent(title, "请验证 Android 系统屏幕锁"))
        check(intent.`package` != null || intent.component != null)
        // Use a fresh registry key for every request, so recreated Activities cannot receive an old result.
        val key = "device-credential:${UUID.randomUUID()}"
        lateinit var launcher: ActivityResultLauncher<Intent>
        launcher = activity.activityResultRegistry.register(key, ActivityResultContracts.StartActivityForResult()) {
            launcher.unregister()
            complete(it.resultCode == Activity.RESULT_OK)
        }
        try { launcher.launch(intent) }
        catch (error: RuntimeException) { launcher.unregister(); throw error }
        return launcher::unregister
    }
}
