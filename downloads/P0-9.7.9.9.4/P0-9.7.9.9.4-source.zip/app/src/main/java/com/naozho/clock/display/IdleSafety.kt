package com.naozho.clock.display

import com.naozho.clock.data.AlarmPlan

internal fun alarmPreventsSleep(plans: List<AlarmPlan>, now: Long): Boolean {
    val handoff = (now - 10_000L)..(now + 10_000L)
    return plans.any {
        it.activeAt != null || (it.nextRegistered && it.nextAt in handoff) ||
            (it.snoozeRegistered && it.snoozeAt in handoff)
    }
}
