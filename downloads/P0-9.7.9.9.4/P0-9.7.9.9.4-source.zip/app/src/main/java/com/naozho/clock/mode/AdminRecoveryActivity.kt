package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.KeyguardManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.graphics.Paint
import android.graphics.Typeface
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.naozho.clock.alarm.AlarmRuntime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AdminRecoveryActivity : ComponentActivity() {
    private val credentials by lazy { ModeCredentials(this) }
    private val modeState by lazy { ModeState(this) }
    private val native by lazy { NativeDesktop(this) }
    private val managed by lazy { ManagedDesktop(this) }
    private val deployment by lazy { ManagedDeployment(this) }
    private val gate by lazy { SystemCredentialGate(this, onScreenOff = ::clearSensitiveView) }
    private val development by lazy { isDevelopmentBuild }
    private var configured by mutableStateOf(false)
    private var form by mutableStateOf<Form?>(null)
    private var formApproval: CredentialApproval? = null
    private var revealedCode by mutableStateOf<String?>(null)
    private var feedback by mutableStateOf<String?>(null)
    private var working by mutableStateOf(false)
    private val homeSelection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        DesktopPolicyUpdates.refresh()
        val status = managed.diagnoseHome()
        feedback = if (managed.isHomeConfirmed(managed.clockHome) && !modeState.managedLock() &&
            !modeState.set(DesktopMode.CLOCK)
        ) "系统已选时钟为 Home，应用模式未能保存。$status" else status
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        if (!development) configured = credentials.configured()
        setContent {
            BackHandler(!development && (form != null || revealedCode != null || gate.waiting), onBack = ::cancelSensitiveView)
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.safeDrawingPadding().imePadding().verticalScroll(rememberScrollState()).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(if (development) "开发恢复与专机测试" else "管理员恢复", style = MaterialTheme.typography.headlineMedium)
                        val edit = form
                        val code = revealedCode
                        when {
                            development -> {
                                Text("先保存原桌面。可单独测试时钟锁定，或启用含默认桌面切换的完整专机模式。")
                                DesktopSettings()
                                feedback?.let { Text(it) }
                                OutlinedButton(::openClock, enabled = !working) { Text("返回时钟") }
                            }
                            code != null -> {
                                Text("新的一次性恢复码")
                                RecoveryCodeDisplay(code)
                                Text("请现在离线抄录并妥善保管。离开此页后将无法再次查看。旧恢复码已失效。")
                                Button(::cancelSensitiveView) { Text("已安全保存") }
                            }
                            edit != null -> {
                                CredentialForm(edit, working, feedback, ::saveCredential)
                                OutlinedButton(::cancelSensitiveView, enabled = !working) { Text("取消编辑") }
                            }
                            else -> {
                                Text("每项管理操作都需要先验证 Android 系统屏幕锁。")
                                val enabled = !working && !gate.waiting
                                Button({ requestForm(Form.SYSTEM_RESET) }, enabled = enabled) {
                                    Text(if (configured) "重设 PIN 和恢复码" else "设置 PIN 和恢复码")
                                }
                                if (configured) {
                                    OutlinedButton({ requestForm(Form.ROTATE) }, enabled = enabled) { Text("重新生成恢复码") }
                                    if (credentials.recoveryAvailable()) {
                                        OutlinedButton({ requestForm(Form.RECOVERY) }, enabled = enabled) { Text("使用一次性恢复码") }
                                    }
                                    OutlinedButton({ requestForm(Form.CHANGE) }, enabled = enabled) { Text("使用当前 PIN 修改") }
                                    DesktopSettings()
                                }
                                feedback?.let { Text(it) }
                                if (gate.waiting) OutlinedButton(::cancelSensitiveView) { Text("取消验证") }
                                OutlinedButton(::finish) { Text("返回") }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun DesktopSettings() {
        var selection by remember { mutableStateOf(modeState.selectedHome()) }
        val revision by DesktopPolicyUpdates.revision.collectAsStateWithLifecycle()
        val lockFailure by DesktopPolicyUpdates.lockFailure.collectAsStateWithLifecycle()
        val homes = remember(selection, revision) { native.candidates(selection) }
        var usesManaged by remember { mutableStateOf(modeState.managedLock()) }
        val policyBusy = working || (!development && gate.waiting)
        val effectiveHome = managed.effectiveHome()
        val defaultHome = effectiveHome == managed.clockHome && managed.isHomeConfirmed(managed.clockHome)
        HorizontalDivider()
        Text("原生桌面", style = MaterialTheme.typography.titleMedium)
        if (development && selection != null) {
            Text("已保存 ${selection?.flattenToShortString()}")
            Text(if (homes.any { it.component == selection }) "当前用户可解析原桌面 HOME" else "当前用户未找到可用的原桌面 HOME")
        }
        if (homes.isEmpty()) Text("没有可用的原生桌面。请先在系统设置中选回原桌面，然后在这里保存它。")
        homes.forEach { home ->
            OutlinedButton({
                changePolicy(AdminOperation.SAVE_HOME) { allowed ->
                    if (modeState.managedLock()) return@changePolicy "请先暂停专机再更换原桌面。"
                    if (allowed() && modeState.saveHome(home.component)) {
                        selection = home.component
                        "已选择 ${home.label}。"
                    } else "未能保存桌面选择。"
                }
            }, enabled = !usesManaged && !policyBusy) {
                val marker = if (selection == home.component || selection == null && homes.size == 1) "（当前）" else ""
                Text("${home.label}$marker")
            }
        }
        HorizontalDivider()
        Text("系统锁定", style = MaterialTheme.typography.titleMedium)
        Text("设备管理员 ${if (managed.activeAdmin) "已激活" else "未激活"}")
        Text("Device Owner ${if (managed.owner) "是" else "否"} · Profile Owner ${if (managed.profileOwner) "是" else "否"}")
        Text("Lock Task 允许名单 ${if (managed.permitted) "允许本应用" else "未允许本应用"}")
        Text(when (managed.state) {
            ActivityManager.LOCK_TASK_MODE_LOCKED -> "系统当前状态 LOCKED · 受管任务"
            ActivityManager.LOCK_TASK_MODE_PINNED -> "系统当前状态 PINNED · 屏幕固定"
            else -> "系统当前状态 NONE · 未锁定"
        })
        if (development) {
            val clockLock = when {
                managed.state == ActivityManager.LOCK_TASK_MODE_LOCKED && usesManaged -> "已启用（LOCKED）"
                managed.state == ActivityManager.LOCK_TASK_MODE_PINNED -> "屏幕固定（PINNED）"
                lockFailure != null -> "失败 · $lockFailure"
                usesManaged -> "已配置，等待时钟在前台锁定"
                else -> "未启用"
            }
            Text("当前时钟锁定：$clockLock")
            Text("默认桌面配置：${if (defaultHome) "系统已确认时钟" else "尚未确认时钟"}")
            Text("当前有效 HOME ${effectiveHome?.flattenToShortString() ?: "未解析"}")
            if (modeState.independentLock()) Text("独立专机已启用。重启后自动请求打开时钟，默认桌面保留。暂停专机可关闭开机恢复。")
        } else Text("小方块时钟 ${if (defaultHome) "是" else "尚未设为"}默认桌面")
        if (!development) Text("若要唤醒时直接进入时钟，请先核对 Android 屏幕锁定方式，并保留离线恢复码。")
        if (managed.supported) {
            Text("专机策略 ${if (managed.dedicatedReady) "允许名单及系统导航配置已确认" else "待配置"}")
            if (!development) Text("启用会将时钟设为受管默认桌面。验证系统凭据和时钟 PIN 后可恢复原桌面，Device Owner 保留。")
            val state = managed.state
            val canPrepare = state == ActivityManager.LOCK_TASK_MODE_NONE
            val canEnable = canPrepare && (development || (selection != null && native.target(selection) != null))
            val canPause = state != ActivityManager.LOCK_TASK_MODE_PINNED
            if (development) {
                OutlinedButton({
                    changePolicy(AdminOperation.ENABLE_KIOSK) {
                        withContext(Dispatchers.IO) { IndependentBootJob(this@AdminRecoveryActivity).describe() }
                    }
                }, enabled = !policyBusy) { Text("读取开机 Job 状态") }
                OutlinedButton({ registerJob(true) }, enabled = !policyBusy) { Text("登记仅观察任务") }
                if (modeState.independentLock()) {
                    OutlinedButton({ registerJob(false) }, enabled = !policyBusy) { Text("登记独立恢复任务") }
                }
            }
            val needsPause = usesManaged || (state == ActivityManager.LOCK_TASK_MODE_LOCKED && managed.permitted)
            if (Build.VERSION.SDK_INT >= 36 && canPrepare && selection != null) {
                var auditing by remember(selection) { mutableStateOf(false) }
                OutlinedButton({ auditing = !auditing }, enabled = !policyBusy) {
                    Text("登记 DSH 已核对的 HOME 策略")
                }
                if (auditing && development) {
                    Text("先准备读取编号，运行 DSH 手册中的 ADB 命令，再导入本机清单。")
                    for ((label, importSnapshot) in listOf("准备读取编号" to false, "导入设备策略清单" to true)) {
                        OutlinedButton({
                            changePolicy(AdminOperation.SAVE_HOME) { allowed ->
                                when (val result = deployment.inspectHome(importSnapshot, allowed)) {
                                    DesktopResult.Applied -> if (importSnapshot) "已核对本机 HOME 策略范围。"
                                        else "请在五分钟内读取并导入策略。"
                                    is DesktopResult.Rejected -> result.message
                                }
                            }
                        }, enabled = !policyBusy) { Text(label) }
                    }
                } else if (auditing) {
                    Text("请先按验收手册等待广播排空，核对本用户、本管理员指向两个桌面包的全部持久偏好。仅有标准 HOME 或均为空时，选择实际策略目标。有其他规则请停止。")
                    listOf("原桌面" to selection, "时钟" to managed.clockHome, "无策略" to null).forEach { (label, previous) ->
                        OutlinedButton({
                            auditing = false
                            changePolicy(AdminOperation.SAVE_HOME) { allowed ->
                                when (val result = deployment.auditHome(previous, allowed)) {
                                    DesktopResult.Applied -> "已记录 DSH 核对结果：$label。"
                                    is DesktopResult.Rejected -> result.message
                                }
                            }
                        }, enabled = !policyBusy) { Text("已核对：$label") }
                    }
                }
                if (development && !needsPause && !modeState.developmentRehearsal()) {
                    OutlinedButton({
                        changePolicy(AdminOperation.ENABLE_KIOSK) { allowed ->
                            when (val result = deployment.clearHomeForDiagnostic(allowed)) {
                                DesktopResult.Applied -> "清除阶段结束。当前 HOME=${managed.effectiveHome()?.flattenToShortString()}，Lock Task=${managed.stateName()}。请核对 dumpsys。"
                                is DesktopResult.Rejected -> result.message
                            }
                        }
                    }, enabled = !policyBusy) { Text("仅清除已核对的 HOME 策略（NONE）") }
                }
            }
            if (development && !needsPause) {
                OutlinedButton(::lockClock, enabled = !policyBusy && canPrepare) { Text("锁定当前时钟（开机自动恢复）") }
                OutlinedButton(::selectClockHome, enabled = !policyBusy && canPrepare && selection != null) {
                    Text("打开系统默认桌面选择")
                }
                if (modeState.developmentRehearsal()) Text("未锁定预演中。从时钟点「开发退出」，再从原桌面点时钟图标返回。")
                OutlinedButton(::rehearse, enabled = !policyBusy && canPrepare) { Text("开始退出预演（保持未锁定）") }
            }
            if (!needsPause) {
                OutlinedButton({ changeDeployment(true) { usesManaged = it } }, enabled = !policyBusy && canEnable) {
                    Text(if (development) "实验：接管 HOME 并锁定时钟" else "启用专机并进入时钟")
                }
            }
            if (development || needsPause) {
                OutlinedButton({ changeDeployment(false) { usesManaged = it } }, enabled = !policyBusy && canPause) {
                    Text("暂停专机并恢复原桌面")
                }
            }
            if (state == ActivityManager.LOCK_TASK_MODE_NONE) {
                if (development && !getSystemService(KeyguardManager::class.java).isDeviceSecure) {
                    OutlinedButton({ setKeyguardDisabled(true) }, enabled = !policyBusy) { Text("关闭无凭据的滑动锁屏") }
                }
                OutlinedButton({ setKeyguardDisabled(false) }, enabled = !policyBusy) { Text("恢复系统锁屏") }
            }
        } else {
            Text("本项目的受管锁定要求 Android 9 或更新版本及 Device Owner。普通桌面模式下系统导航仍可用。")
        }
        if (development) OutlinedButton({ feedback = managed.diagnoseHome() }, enabled = !working) { Text("记录 Home 诊断") }
    }

    private fun selectClockHome() {
        if (!development || modeState.managedLock() || managed.state != ActivityManager.LOCK_TASK_MODE_NONE) return
        if (native.target(modeState.selectedHome()) == null) {
            feedback = "请先保存可用的原桌面。"
            return
        }
        val settings = Intent(Settings.ACTION_HOME_SETTINGS)
        try {
            val request = managed.homeRoleRequest()
            if (request != null) {
                try {
                    homeSelection.launch(request)
                    return
                } catch (_: ActivityNotFoundException) {
                    // Some builds expose Home settings with no role request activity.
                }
            }
            homeSelection.launch(settings)
        } catch (_: ActivityNotFoundException) {
            feedback = "系统未提供默认桌面选择。${managed.diagnoseHome()}"
        } catch (error: SecurityException) {
            feedback = desktopFailure("打开系统默认桌面选择", "Android 拒绝启动系统页面。", error).message
        }
    }

    private fun changeDeployment(enable: Boolean, updateManaged: (Boolean) -> Unit) {
        val action = if (enable) AdminOperation.ENABLE_KIOSK else AdminOperation.PAUSE_KIOSK
        changePolicy(action) { allowed ->
            val result = if (enable) deployment.enable(allowed) else deployment.pause(allowed)
            if (development && result == DesktopResult.Applied) DesktopPolicyUpdates.recordLockResult(null)
            if (!enable) (application as AlarmRuntime).isolation.reconcile()
            updateManaged(modeState.managedLock())
            when {
                result is DesktopResult.Rejected -> result.message
                enable -> { openClock(); null }
                development -> when (val launch = native.open(modeState.selectedHome())) {
                    DesktopResult.Applied -> { finish(); null }
                    is DesktopResult.Rejected -> "锁定已暂停且 Home 已恢复。${launch.message} 请按 Home。"
                }
                else -> "已暂停受管锁定并恢复原桌面，Device Owner 保留。"
            }
        }
    }

    private fun registerJob(observeOnly: Boolean) = changePolicy(AdminOperation.ENABLE_KIOSK) {
        when (val result = deployment.registerBootJob(observeOnly)) {
            DesktopResult.Applied -> "系统已读回持久 Job。请点「读取开机 Job 状态」核对模式和执行记录。"
            is DesktopResult.Rejected -> result.message
        }
    }

    private fun lockClock() = changePolicy(AdminOperation.ENABLE_KIOSK) { allowed ->
        when (val result = deployment.lockCurrentClock(allowed)) {
            DesktopResult.Applied -> {
                if (Build.VERSION.SDK_INT >= 28 && !IndependentBootJob(this).recoveryRegistered()) {
                    android.widget.Toast.makeText(this, "独立锁定已启用，开机 Job 未确认登记。请在维护页核对。", android.widget.Toast.LENGTH_LONG).show()
                }
                DesktopPolicyUpdates.recordLockResult(null)
                openClock()
                null
            }
            is DesktopResult.Rejected -> {
                DesktopPolicyUpdates.recordLockResult(result)
                result.message
            }
        }
    }

    private fun rehearse() = changePolicy(AdminOperation.ENABLE_KIOSK) { allowed ->
        when (val result = deployment.rehearseDevelopment(allowed)) {
            DesktopResult.Applied -> { openClock(); null }
            is DesktopResult.Rejected -> result.message
        }
    }

    private fun openClock() {
        startActivity(clockLaunchIntent(this))
        finish()
    }

    private fun setKeyguardDisabled(disabled: Boolean) = changePolicy(AdminOperation.KEYGUARD_POLICY) { allowed ->
        if (withContext(Dispatchers.IO) {
            allowed() && managed.setUnsecuredKeyguardDisabled(disabled)
        }) {
            "系统接受锁屏策略。请用实体电源键核对实际行为。"
        } else "系统未接受锁屏策略。请检查系统凭据和当前管理状态。"
    }

    private fun changePolicy(action: AdminOperation, operation: suspend (() -> Boolean) -> String?) {
        if (working || form != null || revealedCode != null) return
        fun applyPolicy(grant: CredentialApproval?) {
            val allowed = { grant?.permits(action) ?: (development && !isDestroyed && !isFinishing) }
            working = true
            lifecycleScope.launch {
                try {
                    val result = operation(allowed)
                    if (allowed()) feedback = result
                } finally {
                    grant?.revoke()
                    working = false
                }
            }
        }
        if (development) applyPolicy(null)
        else gate.request(action, { feedback = it }, ::applyPolicy)
    }

    override fun onPause() {
        clearSensitiveView()
        super.onPause()
    }

    private fun clearSensitiveView() {
        formApproval?.revoke()
        formApproval = null
        form = null
        revealedCode = null
    }

    private fun cancelSensitiveView() {
        gate.cancel()
        clearSensitiveView()
        feedback = null
    }

    private fun requestForm(edit: Form) {
        if (working || form != null || revealedCode != null) return
        feedback = null
        gate.request(edit.operation, { feedback = it }) { grant ->
            formApproval = grant
            form = edit
        }
    }

    private fun saveCredential(proof: String, pin: String) {
        val edit = form ?: return
        val grant = formApproval ?: return
        if (working || !grant.permits(edit.operation)) return
        working = true
        lifecycleScope.launch {
            try {
                val result = when (edit) {
                    Form.SYSTEM_RESET -> credentials.resetPin(pin, grant)
                    Form.RECOVERY -> credentials.replacePinWithRecovery(pin, proof, grant)
                    Form.CHANGE -> credentials.changePin(proof, pin, grant)
                    Form.ROTATE -> credentials.rotateRecovery(grant)
                }
                configured = credentials.configured()
                if (formApproval !== grant || !grant.permits(edit.operation)) return@launch
                when (result) {
                    is CredentialResult.RecoveryIssued -> {
                        form = null
                        revealedCode = result.code
                    }
                    CredentialResult.Accepted -> cancelSensitiveView().also { feedback = "PIN 已修改。" }
                    else -> feedback = credentialFeedback(result)
                }
            } finally {
                working = false
            }
        }
    }

    private enum class Form(val operation: AdminOperation) {
        SYSTEM_RESET(AdminOperation.RESET_PIN), RECOVERY(AdminOperation.USE_RECOVERY),
        CHANGE(AdminOperation.CHANGE_PIN), ROTATE(AdminOperation.ROTATE_RECOVERY),
    }

    @Composable
    private fun CredentialForm(
        form: Form,
        working: Boolean,
        feedback: String?,
        save: (String, String) -> Unit,
    ) {
        var proof by remember(form) { mutableStateOf("") }
        var pin by remember(form) { mutableStateOf("") }
        var confirmation by remember(form) { mutableStateOf("") }
        if (form == Form.CHANGE) PinField(proof, { proof = it }, "当前 PIN", !working)
        if (form == Form.RECOVERY) {
            OutlinedTextField(
                value = proof, onValueChange = { proof = it.take(48) },
                modifier = Modifier.fillMaxWidth().clearAndSetSemantics { }, label = { Text("已有恢复码") },
                singleLine = true, enabled = !working, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            )
        }
        if (form != Form.ROTATE) {
            PinField(pin, { pin = it }, "新 PIN（6–12 位数字）", !working)
            PinField(confirmation, { confirmation = it }, "再次输入新 PIN", !working)
        }
        if (form != Form.CHANGE) {
            Text("保存后新恢复码只显示一次。请准备离线抄录。")
        }
        feedback?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = { save(proof, pin); proof = "" },
            enabled = !working && (form == Form.ROTATE || (ModeCredentials.validPin(pin) && pin == confirmation &&
                (proof.isNotBlank() || form == Form.SYSTEM_RESET))),
        ) {
            Text(when {
                working -> "正在验证…"
                form == Form.ROTATE -> "生成并仅显示一次"
                else -> "保存新 PIN"
            })
        }
    }
}

/** Draw the code without exposing its text to Compose semantics or the Android view hierarchy. */
@Composable
internal fun RecoveryCodeDisplay(code: String) {
    val color = MaterialTheme.colorScheme.onSurface.toArgb()
    Canvas(Modifier.fillMaxWidth().height(68.dp).clearAndSetSemantics { }) {
        val lines = code.split('-').chunked(4).map { it.joinToString("-") }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            typeface = Typeface.MONOSPACE
            textSize = 19.dp.toPx()
            val widest = lines.maxOf { measureText(it) }
            if (widest > size.width) textSize *= size.width / widest
        }
        lines.forEachIndexed { index, line ->
            drawContext.canvas.nativeCanvas.drawText(line, 0f, (index + 1) * 27.dp.toPx(), paint)
        }
    }
}

@Composable
internal fun PinField(value: String, change: (String) -> Unit, label: String, enabled: Boolean) {
    OutlinedTextField(
        value = value, onValueChange = { change(it.filter { digit -> digit in '0'..'9' }.take(12)) },
        modifier = Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, enabled = enabled,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
    )
}

internal fun credentialFeedback(result: CredentialResult): String = when (result) {
    CredentialResult.Accepted, is CredentialResult.RecoveryIssued -> ""
    CredentialResult.Rejected -> "验证失败，请检查输入。"
    CredentialResult.Unavailable -> "验证数据不可用，请使用管理员恢复。"
    is CredentialResult.Wait -> "尝试次数过多，约 ${result.seconds} 秒后可重试。"
}
