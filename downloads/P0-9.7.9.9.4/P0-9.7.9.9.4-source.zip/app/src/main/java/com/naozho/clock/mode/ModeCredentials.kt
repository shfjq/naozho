package com.naozho.clock.mode

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.GeneralSecurityException
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

internal sealed interface CredentialResult {
    data object Accepted : CredentialResult
    class RecoveryIssued(val code: String) : CredentialResult
    data object Rejected : CredentialResult
    data object Unavailable : CredentialResult
    data class Wait(val seconds: Long) : CredentialResult
}

internal class ModeCredentials(
    context: Context,
    private val now: () -> Long = SystemClock::elapsedRealtime,
    private val boot: () -> Int = { bootCount(context) },
    private val pepper: (ByteArray) -> ByteArray = ::keystoreMac,
) {
    private val prefs = context.getSharedPreferences("mode_credentials", Context.MODE_PRIVATE)
    private val random = SecureRandom()

    fun configured(): Boolean = prefs.contains("pin_hash")

    // Unversioned verifiers were issued by builds that exposed recovery codes before confirmation.
    fun recoveryAvailable(): Boolean = prefs.getInt("recovery_epoch", 0) == RECOVERY_EPOCH &&
        prefs.contains("recovery_hash") && prefs.contains("recovery_salt")

    suspend fun verifyPin(pin: String, approval: CredentialApproval): CredentialResult = runSafely {
        checkAttempt(PIN_ATTEMPTS, approval, AdminOperation.SWITCH_TO_ANDROID) { matchesPin(pin) }
    }

    suspend fun replacePinWithRecovery(pin: String, code: String, approval: CredentialApproval): CredentialResult = runSafely {
        if (!recoveryAvailable()) return@runSafely CredentialResult.Unavailable
        val result = checkAttempt(RECOVERY_ATTEMPTS, approval, AdminOperation.USE_RECOVERY, clearOnSuccess = false) {
            val hash = read("recovery_hash") ?: return@checkAttempt null
            val salt = read("recovery_salt") ?: return@checkAttempt null
            val normalized = normalizeCode(code)
            normalized.length == 32 && MessageDigest.isEqual(hash, deriveRecovery(normalized, salt))
        }
        if (result == CredentialResult.Accepted) save(pin, approval, AdminOperation.USE_RECOVERY) else result
    }

    suspend fun resetPin(pin: String, approval: CredentialApproval): CredentialResult =
        runSafely { save(pin, approval, AdminOperation.RESET_PIN) }

    suspend fun rotateRecovery(approval: CredentialApproval): CredentialResult = runSafely {
        if (!configured()) return@runSafely CredentialResult.Unavailable
        issueRecovery(prefs.edit(), approval, AdminOperation.ROTATE_RECOVERY)
    }

    suspend fun changePin(oldPin: String, newPin: String, approval: CredentialApproval): CredentialResult = runSafely {
        val action = AdminOperation.CHANGE_PIN
        val result = checkAttempt(PIN_ATTEMPTS, approval, action, clearOnSuccess = false) { matchesPin(oldPin) }
        if (result != CredentialResult.Accepted) return@runSafely result
        val editor = prefs.edit()
        writePin(editor, newPin)
        clearAttempts(editor, PIN_ATTEMPTS)
        if (approval.whileValid(action, editor::commit) == true) CredentialResult.Accepted else CredentialResult.Unavailable
    }

    private fun matchesPin(pin: String): Boolean? {
        val salt = read("pin_salt") ?: return null
        val hash = read("pin_hash") ?: return null
        val algorithm = PinAlgorithm.entries.firstOrNull { it.name == prefs.getString("algorithm", null) } ?: return null
        return validPin(pin) && MessageDigest.isEqual(hash, derivePin(pin, salt, algorithm))
    }

    private fun save(pin: String, approval: CredentialApproval, action: AdminOperation): CredentialResult {
        if (!approval.permits(action)) return CredentialResult.Unavailable
        val editor = prefs.edit()
        writePin(editor, pin)
        clearAttempts(editor, PIN_ATTEMPTS)
        return issueRecovery(editor, approval, action)
    }

    private fun issueRecovery(
        editor: SharedPreferences.Editor,
        approval: CredentialApproval,
        action: AdminOperation,
    ): CredentialResult {
        val code = approval.whileValid(action, ::newRecoveryCode) ?: return CredentialResult.Unavailable
        val salt = random.generateSeed(16)
        editor.putString("recovery_salt", encode(salt))
            .putString("recovery_hash", encode(deriveRecovery(normalizeCode(code), salt)))
            .putInt("recovery_epoch", RECOVERY_EPOCH)
        clearAttempts(editor, RECOVERY_ATTEMPTS)
        return if (approval.whileValid(action, editor::commit) == true) CredentialResult.RecoveryIssued(code)
        else CredentialResult.Unavailable
    }

    private fun writePin(editor: SharedPreferences.Editor, pin: String) {
        require(validPin(pin))
        val algorithm = if (Build.VERSION.SDK_INT >= 26) PinAlgorithm.SHA256 else PinAlgorithm.SHA1
        val salt = random.generateSeed(16)
        editor.putString("algorithm", algorithm.name)
            .putString("pin_salt", encode(salt))
            .putString("pin_hash", encode(derivePin(pin, salt, algorithm)))
    }

    private fun derivePin(pin: String, salt: ByteArray, algorithm: PinAlgorithm): ByteArray {
        val input = PBEKeySpec(pin.toCharArray(), salt, algorithm.iterations, 256)
        val derived = try {
            SecretKeyFactory.getInstance(algorithm.factory).generateSecret(input).encoded
        } finally {
            input.clearPassword()
        }
        return try { pepper(derived) } finally { derived.fill(0) }
    }

    private fun read(key: String): ByteArray? = prefs.getString(key, null)?.let { Base64.decode(it, Base64.NO_WRAP) }

    private fun checkAttempt(
        prefix: String,
        approval: CredentialApproval,
        action: AdminOperation,
        clearOnSuccess: Boolean = true,
        verify: () -> Boolean?,
    ): CredentialResult {
        if (approval.whileValid(action) { syncBoot() } == null) return CredentialResult.Unavailable
        val remaining = prefs.getLong("${prefix}_until", 0L) - now()
        if (remaining > 0) return CredentialResult.Wait((remaining + 999) / 1_000)
        val valid = verify() ?: return CredentialResult.Unavailable
        val editor = prefs.edit()
        if (valid) {
            if (!clearOnSuccess) return if (approval.permits(action)) CredentialResult.Accepted else CredentialResult.Unavailable
            clearAttempts(editor, prefix)
            return if (approval.whileValid(action, editor::commit) == true) CredentialResult.Accepted else CredentialResult.Unavailable
        }
        val previous = prefs.getInt("${prefix}_failures", 0)
        val failures = if (previous >= 20) 16 else previous + 1
        editor.putInt("${prefix}_failures", failures).remove("${prefix}_until")
        var delay = 0L
        if (failures % 5 == 0) {
            delay = penalty(failures)
            editor.putLong("${prefix}_until", now() + delay)
        }
        if (approval.whileValid(action, editor::commit) != true) return CredentialResult.Unavailable
        return if (delay > 0) CredentialResult.Wait(delay / 1_000) else CredentialResult.Rejected
    }

    // Store the boot epoch and lockout deadlines together before verifying an attempt.
    @SuppressLint("ApplySharedPref", "UseKtx")
    private fun syncBoot(force: Boolean = false) {
        val current = boot()
        if (current == prefs.getInt("attempt_boot", -1) && !force) return
        val editor = prefs.edit().putInt("attempt_boot", current)
        listOf(PIN_ATTEMPTS, RECOVERY_ATTEMPTS).forEach { prefix ->
            if (prefs.getLong("${prefix}_until", 0L) > 0L) {
                editor.putLong("${prefix}_until", now() + penalty(prefs.getInt("${prefix}_failures", 5)))
            }
        }
        editor.commit()
    }

    internal suspend fun onBootCompleted() = mutex.withLock { syncBoot(force = boot() < 0) }

    private suspend fun runSafely(block: () -> CredentialResult): CredentialResult =
        withContext(Dispatchers.IO) {
            mutex.withLock {
                try {
                    block()
                } catch (_: GeneralSecurityException) {
                    CredentialResult.Unavailable
                } catch (_: IllegalArgumentException) {
                    CredentialResult.Unavailable
                } catch (_: java.io.IOException) {
                    CredentialResult.Unavailable
                } catch (_: java.security.ProviderException) {
                    CredentialResult.Unavailable
                }
            }
        }

    private enum class PinAlgorithm(val factory: String, val iterations: Int) {
        SHA256("PBKDF2WithHmacSHA256", 600_000),
        SHA1("PBKDF2WithHmacSHA1", 1_300_000),
    }

    companion object {
        private const val PIN_ATTEMPTS = "pin"
        private const val RECOVERY_ATTEMPTS = "recovery"
        private const val RECOVERY_EPOCH = 2
        private val mutex = Mutex()

        fun validPin(pin: String): Boolean = pin.length in 6..12 && pin.all { it in '0'..'9' }

        private fun newRecoveryCode(): String {
            val bytes = ByteArray(16).also(SecureRandom()::nextBytes)
            return bytes.joinToString("") { "%02X".format(Locale.ROOT, it.toInt() and 0xff) }
                .chunked(4).joinToString("-")
        }

        private fun normalizeCode(code: String) = code.uppercase(Locale.ROOT).filter { it in '0'..'9' || it in 'A'..'F' }

        private fun deriveRecovery(code: String, salt: ByteArray): ByteArray =
            MessageDigest.getInstance("SHA-256").apply { update(salt) }.digest(code.toByteArray(Charsets.US_ASCII))

        private fun encode(value: ByteArray): String = Base64.encodeToString(value, Base64.NO_WRAP)

        private fun penalty(failures: Int): Long = when (failures / 5) {
            1 -> 30_000L
            2 -> 120_000L
            3 -> 600_000L
            else -> 1_800_000L
        }

        private fun clearAttempts(editor: SharedPreferences.Editor, prefix: String) {
            editor.remove("${prefix}_failures").remove("${prefix}_until")
        }
    }
}

private fun keystoreMac(input: ByteArray): ByteArray {
    val alias = "desktop_pin_v1"
    val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    val key = (store.getKey(alias, null) as? SecretKey) ?: KeyGenerator
        .getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore").run {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                .setDigests(KeyProperties.DIGEST_SHA256).build())
            generateKey()
        }
    return Mac.getInstance("HmacSHA256").apply { init(key) }.doFinal(input)
}
