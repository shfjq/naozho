package com.naozho.clock.mode

/** Coordinates are fractions of the current activity window. Times use MotionEvent uptime. */
internal class HiddenEntryGesture {
    data class Finger(val id: Int, val x: Float, val y: Float)
    enum class Action { DOWN, POINTER_DOWN, MOVE, POINTER_UP, UP }
    enum class Result { PASS, CAPTURE, COMPLETE }
    private enum class Phase { IDLE, FIRST, HOLD, RELEASE, READY, SWIPE, DISCARD }

    private var phase = Phase.IDLE
    private var started = 0L
    private var deadline = 0L
    private var firstId = 0
    private var secondId = 0
    private var firstCorner = 0

    fun reset() { phase = Phase.IDLE }

    fun accept(
        action: Action,
        at: Long,
        changedId: Int,
        fingers: List<Finger>,
        cornerWidth: Float,
        cornerHeight: Float,
    ): Result {
        if (action == Action.DOWN && phase != Phase.READY) reset()
        val point = fingers.firstOrNull { it.id == changedId }
        fun corner(p: Finger?): Int = when {
            p == null -> 0
            p.x in 0f..cornerWidth && p.y in 0f..cornerHeight -> 1
            p.x in (1f - cornerWidth)..1f && p.y in (1f - cornerHeight)..1f -> 2
            else -> 0
        }
        fun stillInCorner(id: Int, expected: Int) = corner(fingers.firstOrNull { it.id == id }) == expected
        fun discard(): Result {
            phase = if (action == Action.UP) Phase.IDLE else Phase.DISCARD
            return Result.CAPTURE
        }

        when (phase) {
            Phase.IDLE -> if (action == Action.DOWN && corner(point) != 0) {
                firstId = changedId
                firstCorner = corner(point)
                started = at
                phase = Phase.FIRST
            }
            Phase.FIRST -> when {
                action == Action.POINTER_DOWN && fingers.size == 2 &&
                    at - started <= START_GAP && stillInCorner(firstId, firstCorner) &&
                    corner(point) == 3 - firstCorner -> {
                    secondId = changedId
                    started = at
                    deadline = at + HOLD_MS + SECOND_STAGE_MS
                    phase = Phase.HOLD
                    return Result.CAPTURE
                }
                action != Action.MOVE || !stillInCorner(firstId, firstCorner) -> reset()
            }
            Phase.HOLD -> {
                if (at > deadline || fingers.size != 2 || !stillInCorner(firstId, firstCorner) ||
                    !stillInCorner(secondId, 3 - firstCorner) || action == Action.POINTER_DOWN
                ) return discard()
                if (action == Action.POINTER_UP) {
                    if (at - started < HOLD_MS) return discard()
                    firstId = if (changedId == firstId) secondId else firstId
                    firstCorner = if (firstId == secondId) 3 - firstCorner else firstCorner
                    phase = Phase.RELEASE
                }
                return Result.CAPTURE
            }
            Phase.RELEASE -> {
                if (at > deadline || fingers.size != 1 || !stillInCorner(firstId, firstCorner)) return discard()
                if (action == Action.UP) phase = Phase.READY
                return Result.CAPTURE
            }
            Phase.READY -> {
                if (at > deadline) {
                    reset()
                    return accept(action, at, changedId, fingers, cornerWidth, cornerHeight)
                }
                if (action != Action.DOWN || point == null ||
                    point.x !in 0.10f..0.32f || point.y !in 0.68f..0.90f
                ) return discard()
                firstId = changedId
                phase = Phase.SWIPE
                return Result.CAPTURE
            }
            Phase.SWIPE -> {
                if (at > deadline || fingers.size != 1 || point?.id != firstId) return discard()
                if (action == Action.UP) {
                    reset()
                    if (point.x in 0.68f..0.93f && point.y in 0.07f..0.32f) return Result.COMPLETE
                }
                return Result.CAPTURE
            }
            Phase.DISCARD -> return discard()
        }
        return Result.PASS
    }

    companion object {
        const val HOLD_MS = 5_000L
        const val SECOND_STAGE_MS = 7_000L
        private const val START_GAP = 650L
    }
}
