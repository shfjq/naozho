package com.naozho.clock.alarm

import android.app.Application
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.room.Room
import com.naozho.clock.data.AlarmDatabase
import com.naozho.clock.isolation.ClockIsolation
import com.naozho.clock.weather.WeatherUpdates
import com.naozho.clock.weather.weatherStorageAvailable
import java.time.ZoneId
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AlarmRuntime : Application() {
    override fun onCreate() {
        super.onCreate()
        if (weatherStorageAvailable(this)) WeatherUpdates.get(this)
    }

    internal val background = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    internal val alerts by lazy { AlarmAlerts(this) }
    internal val isolation by lazy { ClockIsolation(this) }
    internal val ringControls by lazy {
        AlarmRingControls { id, occurrence, action ->
            Log.i("NaozhoAlarm", "Ringing window requested $action for $id at $occurrence")
            background.launch { repository.finish(id, occurrence, action) }
        }
    }
    internal val repository by lazy {
        val storage = if (Build.VERSION.SDK_INT >= 24) createDeviceProtectedStorageContext() else this
        val database = Room.databaseBuilder(storage, AlarmDatabase::class.java, "alarms.db").build()
        AlarmRepository(database, AndroidAlarmScheduler(this), alerts::canNotify,
            System::currentTimeMillis, SystemClock::elapsedRealtime, ZoneId::systemDefault)
    }
}
