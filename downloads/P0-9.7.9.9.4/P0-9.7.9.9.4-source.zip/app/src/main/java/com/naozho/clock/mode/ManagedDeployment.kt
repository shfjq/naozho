package com.naozho.clock.mode

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.util.Log
import com.naozho.clock.MainActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Device Owner and the Home policy persist as the foreground mode changes. */
internal class ManagedDeployment(private val context: Context) {
    private val mode = ModeState(context)
    private val desktop = ManagedDesktop(context)
    private val native = NativeDesktop(context)

    suspend fun auditHome(previous: ComponentName?, authorized: () -> Boolean): DesktopResult = update {
        val nativeHome = mode.selectedHome()
        preflight("登记 HOME 范围", nativeHome, authorized)?.let { return@update it }
        if (Build.VERSION.SDK_INT < 36 || nativeHome == null ||
            (previous != null && previous != nativeHome && previous != desktop.clockHome)) {
            return@update desktopFailure("登记 HOME 范围", "当前目标不可用。")
        }
        if (HomePolicyTransaction(context).audit(nativeHome, previous)) DesktopResult.Applied
        else desktopFailure("登记 HOME 范围", "无法保存核对结果。")
    }

    suspend fun inspectHome(importSnapshot: Boolean, authorized: () -> Boolean): DesktopResult = update {
        val native = mode.selectedHome()
        preflight("读取持久 HOME 清单", native, authorized)?.let { return@update it }
        if (Build.VERSION.SDK_INT < 36 || native == null || !context.isDevelopmentBuild)
            return@update desktopFailure("读取 HOME 清单", "需要 Android 16 开发版和已保存的原桌面。")
        val tx = HomePolicyTransaction(context)
        if (importSnapshot) return@update tx.importInspection(native, desktop.clockHome)
        try {
            if (tx.prepareInspection()) DesktopResult.Applied else desktopFailure("准备读取", "无法保存读取编号。")
        } catch (e: java.io.IOException) {
            desktopFailure("准备读取", "无法写入读取编号。")
        }
    }

    suspend fun clearHomeForDiagnostic(authorized: () -> Boolean): DesktopResult = update {
        preflight("独立清除 HOME", mode.selectedHome(), authorized)?.let { return@update it }
        if (!context.isDevelopmentBuild || mode.managesHome() || mode.managedLock()) {
            return@update desktopFailure("独立清除 HOME", "请先暂停专机和预演。")
        }
        desktop.clearAuditedHome()
    }

    /** Optional Home-only diagnostic. It never adds the lock allowlist. */
    suspend fun rehearseDevelopment(authorized: () -> Boolean): DesktopResult = update {
        val step = "启动未锁定预演"
        if (!context.isDevelopmentBuild) return@update desktopFailure(step, "仅开发包可使用预演。")
        val freeme = mode.selectedHome()
        preflight(step, freeme, authorized)?.let { return@update it }
        if (freeme == null) return@update desktopFailure(step, "请先保存原桌面。")
        desktop.checkHomeScope(freeme)?.let { return@update it }
        if (!mode.beginDevelopmentRehearsal()) return@update desktopFailure(step, "无法保存预演状态，请确认专机已暂停。")
        val home = desktop.setHome(desktop.clockHome)
        if (home is DesktopResult.Rejected) restoreFreeme(freeme, home, removeAllowlist = false)
        else home
    }

    suspend fun enable(authorized: () -> Boolean = { true }): DesktopResult = update {
        val step = "启用专机"
        val freeme = mode.selectedHome()
        preflight(step, freeme, authorized)?.let { return@update it }
        if (freeme == null) return@update desktopFailure(step, "请先保存原桌面。")
        desktop.checkHomeScope(freeme)?.let { return@update it }
        // Android may launch the new HOME during the policy write. Let MainActivity show the clock.
        if (!mode.set(DesktopMode.CLOCK)) return@update desktopFailure(step, "无法保存时钟模式。")
        val home = desktop.setHome(desktop.clockHome, reapply = true)
        if (home is DesktopResult.Rejected) return@update restoreFreeme(freeme, home, removeAllowlist = false)
        // Keep the normal build's per-operation authorization valid throughout the change.
        if (!authorized()) return@update restoreFreeme(freeme, desktopFailure(step, "操作已取消。"), removeAllowlist = false)
        val mayHaveAddedClock = !desktop.permitted
        val policy = desktop.allowClock()
        if (policy is DesktopResult.Rejected) return@update restoreFreeme(freeme, policy, removeAllowlist = mayHaveAddedClock)
        if (!authorized() || !mode.saveDeployment(true, DesktopMode.CLOCK)) {
            return@update restoreFreeme(freeme, desktopFailure(step, "操作已取消或无法保存专机状态。"), removeAllowlist = mayHaveAddedClock)
        }
        DesktopResult.Applied
    }

    /** Arm the existing foreground clock without requesting a Home policy change. */
    suspend fun lockCurrentClock(authorized: () -> Boolean = { true }): DesktopResult = update {
        val step = "锁定当前时钟"
        if (!context.isDevelopmentBuild) return@update desktopFailure(step, "仅开发包可独立锁定时钟。")
        preflight(step, mode.selectedHome(), authorized)?.let { return@update it }
        if (mode.managedLock()) return@update desktopFailure(step, "请先暂停已启用的专机配置。")
        val mayHaveAddedClock = !desktop.permitted
        val policy = desktop.allowClock()
        if (policy == DesktopResult.Applied && authorized() &&
            mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false)
        ) {
            // Keep the validated foreground lock usable even when the scheduler rejects enrollment.
            if (Build.VERSION.SDK_INT >= 28) IndependentBootJob(context).register(observeOnly = false)
            return@update DesktopResult.Applied
        }
        if (mayHaveAddedClock) desktop.disallowClock("independent-lock-rollback")
        if (policy is DesktopResult.Rejected) policy
        else desktopFailure(step, "操作已取消或无法保存锁定配置。")
    }

    suspend fun registerBootJob(observeOnly: Boolean): DesktopResult = update {
        if (Build.VERSION.SDK_INT < 28 || !context.isDevelopmentBuild || !desktop.owner)
            return@update desktopFailure("登记开机 Job", "需要开发版和本应用的 Device Owner。")
        if (!observeOnly && !mode.independentLock())
            return@update desktopFailure("登记开机 Job", "请先启用独立锁定。")
        IndependentBootJob(context).register(observeOnly)
    }

    suspend fun pause(authorized: () -> Boolean = { true }): DesktopResult = update {
        val step = "暂停专机"
        if (!desktop.owner) return@update desktopFailure(step, "本应用当前不是 Device Owner。")
        if (desktop.state == ActivityManager.LOCK_TASK_MODE_PINNED) return@update desktopFailure(step, "请先用系统操作退出屏幕固定。")
        if (!authorized()) return@update desktopFailure(step, "操作已取消。")
        if (!desktop.disallowClock("admin-pause")) return@update desktopFailure(step, "撤回允许名单后仍未确认 NONE，当前为 ${desktop.stateName()}。")
        val freeme = mode.selectedHome()
        val validation = native.validateSavedHome(freeme)
        val home = when {
            validation != DesktopResult.Applied || freeme == null -> validation
            mode.independentLock() -> DesktopResult.Applied
            else -> desktop.setHome(freeme)
        }
        if (!mode.saveDeployment(false, if (home == DesktopResult.Applied) DesktopMode.ANDROID else DesktopMode.CLOCK)) {
            return@update desktopFailure(step, "已退出锁定，但未能保存暂停状态。")
        }
        if (Build.VERSION.SDK_INT >= 28 && context.isDevelopmentBuild) {
            val cancelled = IndependentBootJob(context).cancel()
            if (cancelled is DesktopResult.Rejected) return@update cancelled
            Log.i("NaozhoMode", "stationPhase=${mode.stationPhase(false)} event=maintenance-pause boot=${bootCount(context)}")
        }
        home
    }

    suspend fun switchTo(target: DesktopMode, authorized: () -> Boolean = { true }): DesktopResult = update {
        val previous = mode.current()
        if (mode.managesHome() && desktop.state != ActivityManager.LOCK_TASK_MODE_NONE &&
            !(previous == target && target == DesktopMode.CLOCK && desktop.receiptMatches(desktop.clockHome) &&
                desktop.isHomeConfirmed(desktop.clockHome))) {
            return@update desktopFailure("切换模式", "切换 HOME 前需要 NONE，当前为 ${desktop.stateName()}。")
        }
        if (!authorized()) return@update desktopFailure("切换模式", "操作已取消。")
        // Both deployment types can retain the former KEYGUARD bit across an update.
        if (target == DesktopMode.CLOCK && mode.managedLock() && !desktop.dedicatedReady) {
            if (!desktop.hasLegacyLockPolicy) {
                return@update desktopFailure("恢复专机模式", "当前名单或功能标志已变化，请在维护页暂停后重新启用所需锁定模式。")
            }
            val policy = desktop.allowClock()
            if (policy is DesktopResult.Rejected) return@update policy
        }
        if (!mode.set(target)) return@update desktopFailure("切换模式", "未能保存目标模式。")
        val applied = setPreferredHome(target)
        val home = if (applied == DesktopResult.Applied && target == DesktopMode.ANDROID &&
            desktop.state != ActivityManager.LOCK_TASK_MODE_NONE
        ) desktopFailure("确认原桌面", "HOME 已读回，Lock Task=${desktop.stateName()}。") else applied
        if (home is DesktopResult.Rejected) {
            val saved = mode.set(previous)
            val restored = setPreferredHome(previous, rollback = true)
            if (!saved || restored is DesktopResult.Rejected) {
                return@update desktopFailure(home.step, "${home.reason} 回退后也未能确认原模式和 Home。")
            }
        }
        if (home == DesktopResult.Applied && target == DesktopMode.ANDROID && context.isDevelopmentBuild) {
            Log.i("NaozhoMode", "stationPhase=${mode.stationPhase(false)} event=desktop-handoff boot=${bootCount(context)}")
        }
        home
    }

    suspend fun reconcileHome(): DesktopResult = update { setPreferredHome(mode.current()) }

    /** Serialize the one-shot boot request with pause and desktop handoff. Lock only in the focused Activity. */
    suspend fun restoreIndependentAfterBoot(
        source: String = "broadcast",
        onLaunchRequested: () -> Unit = {},
        stillRequested: () -> Boolean = { true },
    ): DesktopResult = update {
        val step = "开机恢复独立锁定"
        val boot = bootCount(context)
        Log.i("NaozhoMode", "Independent boot source=$source count=$boot mode=${mode.current()} armed=${mode.independentLock()} state=${desktop.stateName()}")
        if (!mode.independentLock() || mode.current() != DesktopMode.CLOCK || !stillRequested()) {
            Log.i("NaozhoMode", "Independent boot source=$source boot=$boot skipped: mode or request no longer active")
            return@update DesktopResult.Applied
        }
        if (!desktop.supported || boot < 0) return@update desktopFailure(step, "无法确认 Device Owner 或开机编号。")
        if (mode.lastBootLaunch() == boot || (desktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED && desktop.dedicatedReady)) {
            Log.i("NaozhoMode", "Independent boot source=$source boot=$boot skipped: lastRequest=${mode.lastBootLaunch()} state=${desktop.stateName()}")
            return@update DesktopResult.Applied
        }
        if (desktop.state != ActivityManager.LOCK_TASK_MODE_NONE) return@update desktopFailure(step, "当前状态为 ${desktop.stateName()}。")
        if (!desktop.dedicatedReady) {
            val policy = desktop.allowClock()
            if (policy is DesktopResult.Rejected) return@update policy
        }
        if (!stillRequested()) return@update DesktopResult.Applied
        if (!mode.recordBootLaunch(boot)) return@update desktopFailure(step, "未能保存本次开机启动请求。")
        val clock = Intent(context, MainActivity::class.java).setAction(INDEPENDENT_BOOT_ACTION)
            .putExtra(EXTRA_BOOT_COUNT, boot).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(clock)
            Log.i("NaozhoMode", "Independent boot launch requested boot=$boot source=$source elapsedMs=${SystemClock.elapsedRealtime()} awaiting foreground")
            onLaunchRequested()
            DesktopResult.Applied
        } catch (error: RuntimeException) {
            desktopFailure(step, "系统未接受时钟启动请求（${error.javaClass.simpleName}）。", error)
        }
    }

    // HOME is already on screen on the product image. Reconcile DPM under the same
    // mutex as pause/exit, without launching an Activity or changing the HOME role.
    suspend fun preparePrimaryClock(): DesktopResult = update {
        if (!mode.independentLock() || mode.current() != DesktopMode.CLOCK ||
            !desktop.supported || !desktop.isHomeConfirmed(desktop.clockHome) ||
            desktop.state != ActivityManager.LOCK_TASK_MODE_NONE
        ) return@update desktopFailure("恢复主屏时钟", "当前模式、系统 HOME 或设备管理状态已改变。")
        if (desktop.dedicatedReady) return@update DesktopResult.Applied
        desktop.allowClock()
    }

    suspend fun recoverManagedClock(): DesktopResult = update {
        if (!mode.managesHome() || mode.current() != DesktopMode.CLOCK) return@update DesktopResult.Applied
        val nativeHome = native.validateSavedHome(mode.selectedHome())
        if (nativeHome is DesktopResult.Rejected) return@update nativeHome
        val home = desktop.setHome(desktop.clockHome)
        if (home is DesktopResult.Rejected) return@update home
        if (mode.managedLock() && !desktop.dedicatedReady) {
            val lock = desktop.allowClock()
            if (lock is DesktopResult.Rejected) return@update lock
        }
        home
    }

    private fun preflight(step: String, freeme: ComponentName?, authorized: () -> Boolean): DesktopResult.Rejected? {
        if (!desktop.supported) return desktopFailure(step, "需要 Android 9 或以上版本及本应用的 Device Owner 身份。")
        if (desktop.state != ActivityManager.LOCK_TASK_MODE_NONE) return desktopFailure(step, "当前 Lock Task 状态为 ${desktop.stateName()}，需要 NONE。")
        if (!authorized()) return desktopFailure(step, "操作已取消。")
        return native.validateSavedHome(freeme) as? DesktopResult.Rejected
    }

    private suspend fun restoreFreeme(freeme: ComponentName, failure: DesktopResult.Rejected, removeAllowlist: Boolean): DesktopResult {
        val unlocked = !removeAllowlist || desktop.disallowClock("deployment-rollback")
        // An earlier write may have queued a Home change even while Freeme still resolves.
        val home = desktop.setHome(freeme, reapply = true, rollback = true)
        val saved = mode.saveDeployment(false, if (home == DesktopResult.Applied) DesktopMode.ANDROID else DesktopMode.CLOCK)
        if (unlocked && home == DesktopResult.Applied && saved) return failure
        return desktopFailure(failure.step, "${failure.reason} 自动回退未完全确认，请使用「暂停专机并恢复原桌面」。")
    }

    private suspend fun setPreferredHome(target: DesktopMode, rollback: Boolean = false): DesktopResult {
        if (!mode.managesHome()) return DesktopResult.Applied
        val freeme = mode.selectedHome()
        val validation = native.validateSavedHome(freeme)
        if (validation != DesktopResult.Applied || freeme == null) return validation
        if (target == DesktopMode.CLOCK && mode.managedLock() && !desktop.dedicatedReady) {
            return desktopFailure("恢复专机模式", "Lock Task 允许名单或导航策略已变化，请先暂停并重新启用。")
        }
        return desktop.setHome(if (target == DesktopMode.CLOCK) desktop.clockHome else freeme, reapply = rollback, rollback = rollback)
    }

    private suspend fun update(operation: suspend () -> DesktopResult): DesktopResult = policyWrites.withLock {
        // Finish the write or rollback if assigning Home stops the calling Activity.
        withContext(Dispatchers.IO + NonCancellable) { operation() }
    }

    private companion object {
        val policyWrites = Mutex()
    }
}
