package com.naozho.clock.ui

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.naozho.clock.display.ScreenCapabilities

internal enum class ClockPermission(val title: String, val button: String, val explanation: String) {
    NOTIFICATIONS("闹铃通知", "允许闹铃通知", "允许应用通知，并启用「闹铃提醒」频道。没有闹铃通知权限时，计划不会登记。"),
    EXACT_ALARM("精确闹铃", "允许精确闹铃", "允许 Android 按设定时间触发闹铃。授权后会重新登记计划。"),
    FULL_SCREEN("全屏提醒", "允许全屏提醒", "用于息屏或锁屏时打开响铃界面。未授予时可从闹铃通知进入。"),
    DO_NOT_DISTURB("勿扰访问", "允许勿扰访问", "用于闹钟模式的通知隔离。"),
    AUTO_LOCK("应用锁屏", "授权应用锁屏", "用于时钟空闲息屏，系统锁屏密码继续生效。"),
    HOME("默认桌面", "选择默认桌面", "在系统列表中选择小方块时钟或其他桌面。"),
}

internal data class PermissionStatus(val permission: ClockPermission, val status: String, val canRequest: Boolean = false)

internal data class PermissionSetupStatus(
    val required: List<PermissionStatus>,
    val optional: List<PermissionStatus>,
    val deviceOwner: Boolean,
) {
    val hasRequests: Boolean get() = required.any { it.canRequest } || optional.any { it.canRequest }
}

internal fun permissionSetupStatus(
    alarm: AlarmPermissions,
    screen: ScreenCapabilities,
    dndGranted: Boolean,
    isolationEnabled: Boolean,
    sdk: Int = Build.VERSION.SDK_INT,
): PermissionSetupStatus {
    val notifications = if (alarm.notifications) {
        PermissionStatus(ClockPermission.NOTIFICATIONS, "应用通知和闹铃频道可用")
    } else PermissionStatus(ClockPermission.NOTIFICATIONS, "应用通知或闹铃频道未启用", canRequest = true)
    val exact = when {
        sdk < 31 -> PermissionStatus(ClockPermission.EXACT_ALARM, "本系统无需单独授权")
        alarm.exact -> PermissionStatus(ClockPermission.EXACT_ALARM, "已允许")
        else -> PermissionStatus(ClockPermission.EXACT_ALARM, "未允许", canRequest = true)
    }
    val fullScreen = when {
        sdk < 34 -> PermissionStatus(ClockPermission.FULL_SCREEN, "本系统无需单独授权")
        alarm.fullScreen -> PermissionStatus(ClockPermission.FULL_SCREEN, "已允许")
        else -> PermissionStatus(ClockPermission.FULL_SCREEN, "未允许", canRequest = true)
    }
    val dnd = when {
        sdk < 24 -> PermissionStatus(ClockPermission.DO_NOT_DISTURB, "本系统不支持应用勿扰规则")
        dndGranted && isolationEnabled -> PermissionStatus(ClockPermission.DO_NOT_DISTURB, "已授权")
        dndGranted -> PermissionStatus(ClockPermission.DO_NOT_DISTURB, "已授权 · 通知隔离已关闭")
        !isolationEnabled -> PermissionStatus(ClockPermission.DO_NOT_DISTURB, "未授权 · 通知隔离已关闭")
        else -> PermissionStatus(ClockPermission.DO_NOT_DISTURB, "未授权", canRequest = true)
    }
    val autoLock = when {
        screen.activeAdmin -> PermissionStatus(ClockPermission.AUTO_LOCK, "已启用设备管理员锁屏")
        screen.deviceOwner -> PermissionStatus(ClockPermission.AUTO_LOCK, "锁屏授权由设备管理配置")
        !screen.supportsAdmin -> PermissionStatus(ClockPermission.AUTO_LOCK, "设备未提供应用锁屏能力")
        else -> PermissionStatus(ClockPermission.AUTO_LOCK, "未授权", canRequest = true)
    }
    val home = if (screen.defaultHome) {
        PermissionStatus(ClockPermission.HOME, "系统当前使用小方块时钟")
    } else PermissionStatus(ClockPermission.HOME, "当前未设为小方块时钟", canRequest = true)
    return PermissionSetupStatus(listOf(notifications, exact), listOf(fullScreen, dnd, autoLock, home), screen.deviceOwner)
}

internal fun AlarmPermissions.missingRequests(): List<ClockPermission> = buildList {
    if (!notifications) add(ClockPermission.NOTIFICATIONS)
    if (!exact) add(ClockPermission.EXACT_ALARM)
    if (!fullScreen) add(ClockPermission.FULL_SCREEN)
}

@Composable
internal fun PermissionSetupScreen(
    status: PermissionSetupStatus,
    request: (ClockPermission) -> Unit,
    close: () -> Unit,
) {
    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            Surface(Modifier.fillMaxWidth(), tonalElevation = 2.dp) {
                Box(
                    Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                ) {
                    Button(close, Modifier.fillMaxWidth()) { Text("进入时钟") }
                }
            }
        },
    ) { innerPadding ->
        Column(
            Modifier.fillMaxSize().padding(innerPadding).consumeWindowInsets(innerPadding)
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("授权设置", style = MaterialTheme.typography.headlineMedium)
            Text("可以先进入时钟，稍后在闹铃或显示设置中补充授权。")
            Text("闹铃必需", style = MaterialTheme.typography.titleMedium)
            status.required.forEach { PermissionStatusRow(it, request) }
            Text("可选功能", style = MaterialTheme.typography.titleMedium)
            status.optional.forEach { PermissionStatusRow(it, request) }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("设备所有者", style = MaterialTheme.typography.titleMedium)
                Text(if (status.deviceOwner) "系统确认本应用是 Device Owner" else "本应用未取得 Device Owner")
                Text("设备所有者由 Android 的设备管理流程配置。", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PermissionStatusRow(status: PermissionStatus, request: (ClockPermission) -> Unit) {
    val permission = status.permission
    Column(
        Modifier.testTag(permission.name),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(permission.title, style = MaterialTheme.typography.titleSmall)
        Text(status.status, color = MaterialTheme.colorScheme.secondary)
        if (status.canRequest) {
            Text(permission.explanation, style = MaterialTheme.typography.bodySmall)
            OutlinedButton({ request(permission) }) { Text(permission.button) }
        }
    }
}

@Composable
internal fun PermissionActions(
    requests: List<ClockPermission>,
    request: (ClockPermission) -> Unit,
) {
    for (permission in requests) {
        Text(permission.explanation)
        OutlinedButton({ request(permission) }) { Text(permission.button) }
    }
}
