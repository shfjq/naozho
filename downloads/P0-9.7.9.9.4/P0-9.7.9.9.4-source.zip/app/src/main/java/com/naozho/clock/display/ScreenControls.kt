package com.naozho.clock.display

import android.app.KeyguardManager
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import com.naozho.clock.R
import com.naozho.clock.mode.DesktopPolicyUpdates
import com.naozho.clock.mode.ManagedDesktop

class ClockDeviceAdmin : DeviceAdminReceiver() {
    override fun onLockTaskModeEntering(context: Context, intent: Intent, pkg: String) {
        val desktop = ManagedDesktop(context)
        Log.i("NaozhoMode", "Lock Task system callback event=enter package=$pkg state=${desktop.stateName()} allowed=${desktop.permitted}")
        DesktopPolicyUpdates.refresh()
    }

    override fun onLockTaskModeExiting(context: Context, intent: Intent) {
        val desktop = ManagedDesktop(context)
        Log.i("NaozhoMode", "Lock Task system callback event=exit state=${desktop.stateName()} allowed=${desktop.permitted}")
        DesktopPolicyUpdates.refresh()
    }
}

internal data class ScreenCapabilities(
    val defaultHome: Boolean = false,
    val supportsAdmin: Boolean = false,
    val activeAdmin: Boolean = false,
    val deviceOwner: Boolean = false,
)

internal class ScreenControls(private val context: Context) {
    private val admin = ComponentName(context, ClockDeviceAdmin::class.java)
    private val policy = context.getSystemService(DevicePolicyManager::class.java)
    private val keyguard = context.getSystemService(KeyguardManager::class.java)

    fun capabilities(): ScreenCapabilities {
        val manager = context.packageManager
        val desktop = ManagedDesktop(context)
        return ScreenCapabilities(
            defaultHome = desktop.effectiveHome() == desktop.clockHome,
            supportsAdmin = policy != null && manager.hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN),
            activeAdmin = policy?.isAdminActive(admin) == true,
            deviceOwner = policy?.isDeviceOwnerApp(context.packageName) == true,
        )
    }

    fun homeSettings(): Intent = Intent(Settings.ACTION_HOME_SETTINGS)

    fun requestAdmin(): Intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, context.getString(R.string.display_admin_explanation))

    fun revokeAdmin() {
        if (policy?.isAdminActive(admin) == true) policy.removeActiveAdmin(admin)
    }

    fun lock(): Boolean {
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN) ||
            policy?.isAdminActive(admin) != true
        ) return false
        return try {
            policy.lockNow()
            true
        } catch (_: SecurityException) {
            false
        }
    }

    fun isKeyguardLocked(): Boolean = keyguard.isKeyguardLocked
}
