package com.naozho.clock.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "alarms")
internal data class AlarmPlan(
    @PrimaryKey val id: String,
    val label: String,
    val hour: Int,
    val minute: Int,
    val weekdays: Int,
    val enabled: Boolean,
    val onceDay: Long? = null,
    val ringtone: String? = null,
    val ringtoneLabel: String? = null,
    val ramp: Boolean = true,
    val snoozeMinutes: Int = 5,
    val nextAt: Long? = null,
    val nextRegistered: Boolean = false,
    val snoozeAt: Long? = null,
    val snoozeElapsed: Long? = null,
    val snoozeRegistered: Boolean = false,
    val activeAt: Long? = null,
    val startedAt: Long? = null,
    val lastDay: Long? = null,
)

@Entity(tableName = "alarm_events")
internal data class AlarmEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val alarmId: String,
    val at: Long,
    val action: String,
    val occurrence: Long? = null,
)

@Dao
internal interface AlarmDao {
    @Query("SELECT 1")
    suspend fun warmConnection(): Int

    @Query("SELECT * FROM alarms ORDER BY hour, minute, id")
    fun observe(): Flow<List<AlarmPlan>>

    @Query("SELECT * FROM alarms WHERE activeAt IS NOT NULL ORDER BY startedAt IS NULL, activeAt, id")
    fun active(): Flow<List<AlarmPlan>>

    @Query("SELECT * FROM alarms")
    suspend fun all(): List<AlarmPlan>

    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun find(id: String): AlarmPlan?

    @Upsert
    suspend fun save(plan: AlarmPlan)

    @Query("DELETE FROM alarms WHERE id = :id")
    suspend fun delete(id: String)

    @Upsert
    suspend fun event(event: AlarmEvent)

    @Query("DELETE FROM alarm_events WHERE id NOT IN (SELECT id FROM alarm_events ORDER BY id DESC LIMIT 200)")
    suspend fun pruneEvents()

    @Query("SELECT * FROM alarm_events ORDER BY id DESC LIMIT 30")
    fun events(): Flow<List<AlarmEvent>>
}

@Database(entities = [AlarmPlan::class, AlarmEvent::class], version = 1, exportSchema = true)
internal abstract class AlarmDatabase : RoomDatabase() {
    abstract fun alarms(): AlarmDao
}
