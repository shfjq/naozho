package com.naozho.clock.isolation

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.Context
import com.naozho.clock.mode.DesktopMode
import com.naozho.clock.mode.ModeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

internal enum class IsolationPhase {
    OFF, MANUAL_ONLY, NEEDS_ACCESS, REQUESTED, LEGACY_REQUESTED, WAITING_FOR_PROVIDER,
    RULE_MISSING, RULE_DISABLED, RULE_CHANGED, ERROR, RELEASE_UNCERTAIN,
}

internal data class IsolationStatus(
    val enabled: Boolean = true,
    val phase: IsolationPhase = IsolationPhase.OFF,
    val hasAccess: Boolean = false,
    val filter: Int = NotificationManager.INTERRUPTION_FILTER_UNKNOWN,
    val alarmBlocked: Boolean = false,
)

internal data class ClockRule(
    val id: String,
    val enabled: Boolean,
    val compatible: Boolean,
    val visualPolicy: Boolean,
)

internal interface ZenBackend {
    val available: Boolean
    val customVisuals: Boolean
    fun hasAccess(): Boolean
    fun currentFilter(): Int
    fun blocksAlarms(filter: Int): Boolean
    fun ownedRule(): ClockRule?
    fun createRule(): ClockRule?
    fun setEnabled(rule: ClockRule, enabled: Boolean): Boolean
    fun activate(rule: ClockRule): Boolean
}

internal class ClockIsolation(
    context: Context,
    private val backend: ZenBackend = AndroidZenBackend(context),
    private val mode: () -> DesktopMode = ModeState(context)::current,
) {
    private val prefs = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
    private val mutableStatus = MutableStateFlow(IsolationStatus(enabled = prefs.getBoolean(ENABLED, true)))
    val status = mutableStatus.asStateFlow()
    private val mutex = Mutex()
    private var lastActivated: String? = null

    suspend fun reconcile(): IsolationStatus = mutex.withLock {
        withContext(Dispatchers.IO) { apply(wantsIsolation()) }
    }

    @SuppressLint("UseKtx") // Keep the result of the durable preference write.
    suspend fun setEnabled(enabled: Boolean): IsolationStatus = mutex.withLock {
        withContext(Dispatchers.IO) {
            if (!prefs.edit().putBoolean(ENABLED, enabled).commit()) publish(IsolationPhase.ERROR)
            else apply(wantsIsolation())
        }
    }

    suspend fun registerAgain(): IsolationStatus = mutex.withLock {
        withContext(Dispatchers.IO) { apply(wantsIsolation(), replaceMissing = true) }
    }

    suspend fun refreshSystemStatus(): IsolationStatus = mutex.withLock {
        withContext(Dispatchers.IO) {
            val phase = mutableStatus.value.phase
            if (phase == IsolationPhase.WAITING_FOR_PROVIDER) apply(wantsIsolation())
            else publish(phase)
        }
    }

    /** Release our rule before publishing the new mode. Reapply the clock request if the handoff is cancelled. */
    suspend fun handOffToAndroid(
        authorized: () -> Boolean = { true },
        handoff: suspend () -> Boolean,
    ): Boolean = mutex.withLock {
        var saved = false
        var released = false
        try {
            withContext(Dispatchers.IO) {
                if (authorized()) {
                    released = true
                    apply(active = false)
                }
            }
            if (!released) return@withLock false
            saved = handoff()
            saved
        } finally {
            if (released && !saved) withContext(NonCancellable + Dispatchers.IO) { apply(wantsIsolation()) }
        }
    }

    private fun wantsIsolation(): Boolean =
        prefs.getBoolean(ENABLED, true) && mode() == DesktopMode.CLOCK

    private fun apply(active: Boolean, replaceMissing: Boolean = false): IsolationStatus {
        val phase = try {
            when {
                !backend.available -> if (active) IsolationPhase.MANUAL_ONLY else IsolationPhase.OFF
                !backend.hasAccess() -> {
                    lastActivated = null
                    when {
                        active -> IsolationPhase.NEEDS_ACCESS
                        prefs.contains(RULE) -> IsolationPhase.RELEASE_UNCERTAIN
                        else -> IsolationPhase.OFF
                    }
                }
                active -> requestRule(replaceMissing)
                else -> if (pauseRule(backend.ownedRule())) IsolationPhase.OFF else IsolationPhase.RELEASE_UNCERTAIN
            }
        } catch (_: RuntimeException) {
            if (active) IsolationPhase.ERROR else IsolationPhase.RELEASE_UNCERTAIN
        }
        return publish(phase)
    }

    private fun requestRule(replaceMissing: Boolean): IsolationPhase {
        val rule = backend.ownedRule() ?: run {
            lastActivated = null
            if (!replaceMissing && prefs.contains(RULE)) return IsolationPhase.RULE_MISSING
            backend.createRule() ?: return IsolationPhase.ERROR
        }
        val paused = prefs.getString(PAUSED_RULE, null) == rule.id
        if (prefs.getString(RULE, null) != rule.id && !writeRule(rule.id, paused)) return IsolationPhase.ERROR
        if (!rule.compatible) {
            return if (pauseRule(rule)) IsolationPhase.RULE_CHANGED else IsolationPhase.RELEASE_UNCERTAIN
        }
        if (!rule.enabled) {
            lastActivated = null
            if (!paused) return IsolationPhase.RULE_DISABLED
            if (!backend.setEnabled(rule, true)) return IsolationPhase.ERROR
        }
        if (paused && !writeRule(rule.id, paused = false)) return IsolationPhase.ERROR

        if (backend.customVisuals) {
            if (lastActivated != rule.id) {
                if (!backend.activate(rule)) return IsolationPhase.ERROR
                lastActivated = rule.id
            }
            return if (rule.visualPolicy) IsolationPhase.REQUESTED else IsolationPhase.LEGACY_REQUESTED
        }
        return if (backend.activate(rule)) IsolationPhase.LEGACY_REQUESTED else IsolationPhase.WAITING_FOR_PROVIDER
    }

    private fun pauseRule(rule: ClockRule?): Boolean {
        lastActivated = null
        if (rule == null || !rule.enabled) return true
        return writeRule(rule.id, paused = true) && backend.setEnabled(rule, false)
    }

    // Keep the rule ID and our pause marker durable across an app or device restart.
    @SuppressLint("ApplySharedPref", "UseKtx")
    private fun writeRule(id: String, paused: Boolean): Boolean {
        val editor = prefs.edit().putString(RULE, id)
        if (paused) editor.putString(PAUSED_RULE, id) else editor.remove(PAUSED_RULE)
        return editor.commit()
    }

    private fun publish(phase: IsolationPhase): IsolationStatus {
        val enabled = prefs.getBoolean(ENABLED, true)
        val current = try {
            val filter = backend.currentFilter()
            IsolationStatus(enabled, phase, backend.hasAccess(), filter, backend.blocksAlarms(filter))
        } catch (_: RuntimeException) {
            IsolationStatus(enabled, phase)
        }
        mutableStatus.value = current
        return current
    }

    companion object {
        private const val PREFERENCES = "notification_isolation"
        private const val ENABLED = "enabled"
        private const val RULE = "rule"
        private const val PAUSED_RULE = "paused"

        fun requestedByClock(context: Context): Boolean =
            context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).getBoolean(ENABLED, true) &&
                ModeState(context).current() == DesktopMode.CLOCK
    }
}
