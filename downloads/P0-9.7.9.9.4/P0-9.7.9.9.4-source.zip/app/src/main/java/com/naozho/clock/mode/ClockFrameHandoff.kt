package com.naozho.clock.mode

import android.content.Context
import android.os.SystemClock
import java.io.File
import java.io.IOException

/** Owned by one Activity on its UI thread. A render callback can arrive on either side of LOCKED. */
internal class ClockFrameHandoff(val ticket: WakeTicket) {
    private var awaitingCommit = false
    private var committed = false
    private var locked = false
    private var released = false

    val needsDraw get() = !awaitingCommit && !committed && !released

    fun armForClockDraw(hardwareFrame: Boolean): Boolean {
        if (!hardwareFrame || !needsDraw) return false
        awaitingCommit = true
        return true
    }

    fun frameSubmitted(): Boolean {
        if (!awaitingCommit || released) return false
        awaitingCommit = false
        committed = true
        return true
    }

    fun lockConfirmed() { locked = true }

    fun takeHandoff(liveClockFocus: Boolean): Boolean {
        if (released || !committed || !locked || !liveClockFocus) return false
        released = true
        return true
    }

    /** App-private acknowledgment for the root observer of this exact wake. Only the
     * Activity UI thread writes it, after its final live policy and mode readback. */
    fun publishFrameReceipt(context: Context): Boolean {
        if (!released || !ticket.fresh(SystemClock.elapsedRealtime()) ||
            bootCount(context) != ticket.boot || !ticket.attested(context)) return false
        val pending = File(context.filesDir, "wake-epoch.frame.tmp")
        return try {
            context.openFileOutput(pending.name, Context.MODE_PRIVATE).use {
                it.write(ticket.receipt.toByteArray(Charsets.US_ASCII))
            }
            // Same-directory rename on Android replaces the previous wake atomically.
            pending.renameTo(File(context.filesDir, "wake-epoch.frame"))
        } catch (_: IOException) {
            false
        } catch (_: SecurityException) {
            false
        } finally {
            pending.delete()
        }
    }
}
