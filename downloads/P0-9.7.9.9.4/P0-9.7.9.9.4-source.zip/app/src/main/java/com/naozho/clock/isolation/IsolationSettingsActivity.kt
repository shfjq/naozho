package com.naozho.clock.isolation

import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.naozho.clock.alarm.AlarmRuntime
import com.naozho.clock.mode.ManagedDesktop
import kotlinx.coroutines.launch

class IsolationSettingsActivity : ComponentActivity() {
    private val isolation get() = (application as AlarmRuntime).isolation
    private var panelRestricted by mutableStateOf(false)
    private var saving by mutableStateOf(false)
    private val systemChanges = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            lifecycleScope.launch {
                if (intent.action == NotificationManager.ACTION_NOTIFICATION_POLICY_ACCESS_GRANTED_CHANGED) {
                    isolation.reconcile()
                } else isolation.refreshSystemStatus()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val status by isolation.status.collectAsStateWithLifecycle()
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        TextButton(::finish) { Text("返回") }
                        Text("通知隔离", style = MaterialTheme.typography.headlineMedium)
                        if (Build.VERSION.SDK_INT >= 24) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("闹钟模式启用勿扰", Modifier.weight(1f))
                                Switch(
                                    status.enabled, { enabled -> change { isolation.setEnabled(enabled) } },
                                    enabled = !saving,
                                    modifier = Modifier.semantics { contentDescription = "闹钟模式启用勿扰" },
                                )
                            }
                            Text("应用规则在安卓模式暂停。其他勿扰规则和手动设置仍由系统管理。")
                        }
                        Text(phaseText(status.phase))
                        Text("系统勿扰 ${filterText(status.filter)}", style = MaterialTheme.typography.bodyMedium)
                        if (status.alarmBlocked) {
                            Text("系统当前策略可能屏蔽闹铃声音。请在系统勿扰设置中允许闹铃。",
                                color = MaterialTheme.colorScheme.error)
                        }
                        if (Build.VERSION.SDK_INT >= 24 && !status.hasAccess) {
                            OutlinedButton({ open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }) {
                                Text("授予勿扰访问权限")
                            }
                        }
                        if (status.phase == IsolationPhase.RULE_MISSING) {
                            OutlinedButton({ change { isolation.registerAgain() } }, enabled = !saving) {
                                Text("重新登记应用规则")
                            }
                        }
                        OutlinedButton(::openSystemDnd) { Text("系统勿扰设置") }
                        if (Build.VERSION.SDK_INT in 24..28) {
                            Text("此版本的横幅与弹窗显示取决于系统勿扰设置。可在系统中检查视觉效果。")
                        }
                        Text(if (panelRestricted) "当前受管锁定限制下拉通知面板。"
                            else "普通沉浸式只隐藏时钟窗口的系统栏，边缘手势仍由 Android 处理。")

                        HorizontalDivider()
                        Text("vivo 健康后台运行", style = MaterialTheme.typography.titleMedium)
                        Text("在系统应用列表中选择 vivo 健康，检查电池用量、后台运行、附近设备或蓝牙、数据用量。")
                        Text("如系统提供应用后台或自启动管理，按设备设置核对允许项并保留所需前台服务通知。")
                        OutlinedButton({ open(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS) }) {
                            Text("打开系统应用列表")
                        }
                        OutlinedButton({ open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }) {
                            Text("打开电池优化设置")
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, systemChanges, IntentFilter().apply {
            addAction(NotificationManager.ACTION_NOTIFICATION_POLICY_ACCESS_GRANTED_CHANGED)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(NotificationManager.ACTION_NOTIFICATION_POLICY_CHANGED)
        }, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onResume() {
        super.onResume()
        panelRestricted = ManagedDesktop(this).restrictsNotificationShade()
        lifecycleScope.launch { isolation.reconcile() }
    }

    override fun onStop() {
        unregisterReceiver(systemChanges)
        super.onStop()
    }

    private fun change(action: suspend () -> Unit) {
        if (saving) return
        saving = true
        lifecycleScope.launch {
            try { action() } finally { saving = false }
        }
    }

    private fun openSystemDnd() = open(
        if (Build.VERSION.SDK_INT >= 26) Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS else Settings.ACTION_SOUND_SETTINGS,
    )

    private fun open(action: String) {
        try {
            startActivity(Intent(action))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "此设备未提供对应入口，请从 Android 设置查找。", Toast.LENGTH_LONG).show()
        } catch (_: SecurityException) {
            Toast.makeText(this, "当前设备管理策略限制打开此设置。", Toast.LENGTH_LONG).show()
        }
    }
}

private fun phaseText(phase: IsolationPhase): String = when (phase) {
    IsolationPhase.OFF -> "应用勿扰规则已暂停或尚未登记。"
    IsolationPhase.MANUAL_ONLY -> "当前 Android 版本请手动配置勿扰，并选择允许闹铃。"
    IsolationPhase.NEEDS_ACCESS -> "请先在系统设置中授予勿扰访问权限。系统隔离尚未启用。"
    IsolationPhase.REQUESTED -> "已向 Android 提交隔离规则。系统会合并其他有效的勿扰规则。"
    IsolationPhase.LEGACY_REQUESTED -> "已向 Android 提交仅闹铃规则。横幅、弹窗和例外由系统勿扰设置决定。"
    IsolationPhase.WAITING_FOR_PROVIDER -> "等待 Android 连接勿扰规则，系统隔离尚未确认。"
    IsolationPhase.RULE_MISSING -> "系统已移除应用规则，可重新登记。"
    IsolationPhase.RULE_DISABLED -> "应用规则已在系统中停用。可从系统勿扰设置重新启用。"
    IsolationPhase.RULE_CHANGED -> "应用规则已更改并暂停，请在系统中核对闹铃允许项及规则类型。"
    IsolationPhase.ERROR -> "Android 未接受隔离设置，请核对权限和系统规则。"
    IsolationPhase.RELEASE_UNCERTAIN -> "未能确认应用规则已暂停，请在系统勿扰设置中核对。"
}

private fun filterText(filter: Int): String = when (filter) {
    NotificationManager.INTERRUPTION_FILTER_ALL -> "关闭"
    NotificationManager.INTERRUPTION_FILTER_PRIORITY -> "优先"
    NotificationManager.INTERRUPTION_FILTER_ALARMS -> "仅闹铃"
    NotificationManager.INTERRUPTION_FILTER_NONE -> "完全静音"
    else -> "状态未知"
}
