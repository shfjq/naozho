package com.naozho.clock.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.naozho.clock.MainActivity

internal class AndroidAlarmScheduler(private val context: Context) : AlarmScheduler {
    private val manager = context.getSystemService(AlarmManager::class.java)

    override fun canSchedule(): Boolean =
        Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()

    override fun schedule(occurrence: AlarmOccurrence, triggerAt: Long): Boolean {
        if (!canSchedule()) return false
        val operation = operation(occurrence, PendingIntent.FLAG_UPDATE_CURRENT) ?: return false
        val show = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return try {
            manager.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), operation)
            true
        } catch (_: SecurityException) {
            false
        } catch (_: IllegalStateException) {
            false
        }
    }

    override fun cancel(occurrence: AlarmOccurrence) {
        operation(occurrence, PendingIntent.FLAG_NO_CREATE)?.let {
            manager.cancel(it)
            it.cancel()
        }
    }

    private fun operation(occurrence: AlarmOccurrence, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(
            context,
            0,
            Intent(context, AlarmReceiver::class.java).setData(
                Uri.Builder().scheme("naozho").authority("alarm")
                    .appendPath(occurrence.id).appendPath(occurrence.slot.name)
                    .appendPath(occurrence.at.toString()).build(),
            ),
            flags or PendingIntent.FLAG_IMMUTABLE,
        )
}
