package com.naozho.clock.ui

import android.Manifest
import android.content.Intent
import android.os.SystemClock
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.naozho.clock.display.DisplaySettings
import com.naozho.clock.display.ScreenCapabilities
import com.naozho.clock.weather.CityLocator
import com.naozho.clock.weather.CityResult
import com.naozho.clock.weather.WeatherLocation
import java.util.Locale
import kotlinx.coroutines.launch

@Composable
internal fun DisplaySettingsScreen(
    settings: DisplaySettings,
    capabilities: ScreenCapabilities,
    systemUiAvailable: Boolean,
    close: () -> Unit,
    save: (DisplaySettings) -> Unit,
    chooseHome: () -> Unit,
    openPermissions: () -> Unit,
    systemSettings: () -> Unit,
    admin: () -> Unit,
    lockNow: () -> Unit,
    recovery: () -> Unit,
    notificationSettings: () -> Unit,
    autoLocationResolved: (WeatherLocation, Long) -> Unit,
    hiddenExit: (() -> Unit)? = null,
) {
    var day by rememberSaveable { mutableStateOf(formatMinutes(settings.dayStart)) }
    var night by rememberSaveable { mutableStateOf(formatMinutes(settings.nightStart)) }
    var brightness by rememberSaveable { mutableStateOf(settings.nightPercent.toString()) }
    var idle by rememberSaveable { mutableStateOf(settings.idleSeconds.toString()) }
    var lockScreen by rememberSaveable { mutableStateOf(settings.showOnLockScreen) }
    var name by rememberSaveable { mutableStateOf(settings.weatherLocation?.label.orEmpty()) }
    var latitude by rememberSaveable { mutableStateOf(settings.weatherLocation?.latitude?.toString().orEmpty()) }
    var longitude by rememberSaveable { mutableStateOf(settings.weatherLocation?.longitude?.toString().orEmpty()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var weatherAuto by rememberSaveable { mutableStateOf(settings.weatherAuto) }
    var resolvedAt by rememberSaveable { mutableStateOf(settings.weatherResolvedAt) }
    var locating by remember { mutableStateOf(false) }
    var locationNote by rememberSaveable { mutableStateOf<String?>(null) }
    var permissionAsked by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val locator = remember(context) { CityLocator(context.applicationContext) }
    val tapCounter = remember { TapExitCounter() }
    val versionLabel = remember(context) {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName.orEmpty()
        }.getOrDefault("")
    }
    val autoLocate: () -> Unit = autoLocate@{
        if (locating) return@autoLocate
        locating = true
        locationNote = "正在获取位置…"
        scope.launch {
            when (val result = locator.resolve()) {
                is CityResult.Resolved -> {
                    name = result.location.label
                    latitude = result.location.latitude.toString()
                    longitude = result.location.longitude.toString()
                    weatherAuto = true
                    resolvedAt = result.resolvedAt
                    autoLocationResolved(result.location, result.resolvedAt)
                    locationNote = "已自动获取：${result.location.label}"
                }
                CityResult.PermissionMissing -> {
                    locating = false
                    permissionAsked = true
                    locationNote = "未获得定位权限，天气可手动填写坐标。"
                }
                CityResult.ServiceDisabled -> locationNote = "系统定位服务已关闭，请在系统设置中开启定位。"
                CityResult.NoFix -> locationNote = "暂时无法获取位置，请稍后重试。"
                is CityResult.NoCity -> {
                    val saved = settings.weatherLocation
                    if (saved != null) {
                        locationNote = "暂时无法识别城市，已保留上次的天气位置。"
                    } else {
                        name = ""
                        latitude = result.location.latitude.toString()
                        longitude = result.location.longitude.toString()
                        weatherAuto = true
                        resolvedAt = result.resolvedAt
                        autoLocationResolved(result.location, result.resolvedAt)
                        locationNote = "已更新天气位置，暂时无法识别城市。"
                    }
                }
            }
            locating = false
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        permissionAsked = true
        if (granted) autoLocate() else locationNote = "未获得定位权限，天气可手动填写坐标。"
    }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TextButton(close) { Text("返回时钟") }
            Text("显示设置", style = MaterialTheme.typography.headlineMedium)
            if (systemUiAvailable) {
                TextButton(openPermissions) { Text("授权与系统状态") }
            }
            Text("亮度", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(day, { day = it.take(5) }, Modifier.weight(1f),
                    label = { Text("白天 HH:mm") }, singleLine = true)
                OutlinedTextField(night, { night = it.take(5) }, Modifier.weight(1f),
                    label = { Text("夜间 HH:mm") }, singleLine = true)
            }
            OutlinedTextField(brightness, { brightness = it.filter(Char::isDigit).take(2) },
                Modifier.fillMaxWidth(), label = { Text("夜间亮度 5–50%") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            Text("白天沿用系统亮度。夜间只调暗时钟应用窗口。", style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()
            Text("息屏与唤醒", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(idle, { idle = it.filter(Char::isDigit).take(3) },
                Modifier.fillMaxWidth(), label = { Text("空闲息屏秒数，0 为关闭") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            Text(
                when {
                    capabilities.activeAdmin -> "已授权。时钟空闲达到设定时间后锁屏。安全锁仍由系统管理。"
                    capabilities.supportsAdmin -> "当前沿用系统息屏时间。可授权应用在空闲时锁屏。"
                    else -> "此设备未提供设备管理功能，息屏时间由系统管理。"
                },
                style = MaterialTheme.typography.bodySmall,
            )
            if (capabilities.supportsAdmin && !capabilities.deviceOwner) {
                OutlinedButton(admin) {
                    Text(if (capabilities.activeAdmin) "停用应用锁屏授权" else "授权应用锁屏")
                }
            }
            if (capabilities.activeAdmin) {
                TextButton(lockNow) { Text("立即息屏") }
            }
            if (systemUiAvailable) {
                OutlinedButton(chooseHome) {
                    Text(if (capabilities.defaultHome) "更换默认桌面" else "设为默认桌面")
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("锁屏时显示前台时钟", Modifier.weight(1f))
                Switch(lockScreen, { lockScreen = it }, Modifier.semantics { contentDescription = "锁屏显示时钟" })
            }
            Text("时钟在前台时可显示在锁屏上。访问设置或切换桌面仍需通过 Android 解锁。",
                style = MaterialTheme.typography.bodySmall)
            if (systemUiAvailable) {
                TextButton(systemSettings) { Text("打开 Android 设置") }
                TextButton(notificationSettings) { Text("通知隔离") }
            } else {
                Text("受管时钟模式中，请先验证 PIN 进入安卓模式，再打开 Android 设置。")
            }
            TextButton(recovery) { Text("管理员恢复") }

            HorizontalDivider()
            Text("天气", style = MaterialTheme.typography.titleMedium)
            Text("天气使用已保存的坐标查询 Open-Meteo。自动定位可能向 BigDataCloud 发送约略坐标以识别城市。清空经纬度可关闭天气。",
                style = MaterialTheme.typography.bodySmall)
            Button(
                onClick = {
                    if (locator.hasPermission()) autoLocate()
                    else permissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !locating,
            ) { Text(if (locating) "正在定位…" else "自动获取当前位置") }
            val statusLine = when {
                locating -> "正在获取位置…"
                weatherAuto && name.isNotBlank() ->
                    "当前城市：$name" + if (resolvedAt > 0L) {
                        "（" + android.text.format.DateFormat.format("MM-dd HH:mm", resolvedAt) + " 更新）"
                    } else ""
                latitude.isNotEmpty() && longitude.isNotEmpty() -> "已填写天气位置。"
                permissionAsked && !locator.hasPermission() -> "未获得定位权限。"
                else -> "未设置天气位置。"
            }
            Text(statusLine, style = MaterialTheme.typography.bodyMedium)
            if (!locator.hasPermission() && permissionAsked) {
                Text("天气需要定位权限才能自动获取城市。授予后即可自动完成，无需手动输入。",
                    style = MaterialTheme.typography.bodySmall)
                TextButton({
                    permissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                }) { Text("重新申请定位权限") }
            }
            if (!locator.serviceEnabled()) {
                Text("系统定位服务未开启，天气无法自动定位。",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                if (systemUiAvailable) TextButton({
                    runCatching { context.startActivity(Intent(AndroidSettings.ACTION_LOCATION_SOURCE_SETTINGS)) }
                }) { Text("打开系统定位设置") }
            }
            locationNote?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            fun markManual() {
                weatherAuto = false
                resolvedAt = 0L
            }
            OutlinedTextField(name, { name = it.take(32); markManual() }, Modifier.fillMaxWidth(),
                label = { Text("地点名称（选填）") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(latitude, { latitude = it.take(16); markManual() }, Modifier.weight(1f),
                    label = { Text("纬度") }, singleLine = true)
                OutlinedTextField(longitude, { longitude = it.take(16); markManual() }, Modifier.weight(1f),
                    label = { Text("经度") }, singleLine = true)
            }
            if (latitude.isNotBlank() || longitude.isNotBlank()) {
                TextButton({ latitude = ""; longitude = ""; name = "" }) { Text("清空天气地点") }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val d = parseMinutes(day)
                    val n = parseMinutes(night)
                    val level = brightness.toIntOrNull()
                    val seconds = idle.toIntOrNull()
                    val location = WeatherLocation.parse(name, latitude, longitude)
                    error = when {
                        d == null || n == null || d == n -> "请输入不同的白天与夜间起始时间（HH:mm）。"
                        level == null || level !in 5..50 -> "请输入 5–50 的夜间亮度。"
                        seconds == null || (seconds != 0 && seconds !in 10..300) -> "息屏时间须为 10–300 秒，或填 0。"
                        location == null && (latitude.isNotBlank() || longitude.isNotBlank()) ->
                            "请输入有效经纬度（纬度 −90 至 90，经度 −180 至 180）。"
                        else -> null
                    }
                    if (error == null && d != null && n != null && level != null && seconds != null) {
                        save(
                            DisplaySettings(
                                dayStart = d,
                                nightStart = n,
                                nightPercent = level,
                                idleSeconds = seconds,
                                showOnLockScreen = lockScreen,
                                weatherLocation = location,
                                weatherAuto = weatherAuto && location != null,
                                weatherResolvedAt = if (weatherAuto && location != null) resolvedAt else 0L,
                            ),
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
            ) { Text("保存显示设置") }
            if (hiddenExit != null && versionLabel.isNotEmpty()) {
                Text(
                    text = "版本 $versionLabel",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                        .clickable(interactionSource = null, indication = null) {
                            if (tapCounter.tap(SystemClock.elapsedRealtime())) hiddenExit()
                        },
                )
            }
        }
    }
}

internal fun parseMinutes(text: String): Int? {
    if (!text.matches(Regex("[0-9]{2}:[0-9]{2}"))) return null
    val hour = text.substring(0, 2).toInt()
    val minute = text.substring(3).toInt()
    return if (hour in 0..23 && minute in 0..59) hour * 60 + minute else null
}

private fun formatMinutes(minutes: Int): String =
    String.format(Locale.ROOT, "%02d:%02d", minutes / 60, minutes % 60)
