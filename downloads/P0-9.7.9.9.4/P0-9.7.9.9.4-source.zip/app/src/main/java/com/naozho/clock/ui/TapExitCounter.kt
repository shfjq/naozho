package com.naozho.clock.ui

/**
 * Hidden exit gesture: N taps on the version label within one time window.
 *
 * Partial gestures stay private. The next tap checks expiry against the first tap.
 */
internal class TapExitCounter(
    private val required: Int = REQUIRED_TAPS,
    private val windowMs: Long = WINDOW_MS,
) {
    init {
        require(required >= 2)
        require(windowMs > 0)
    }

    private var taps = 0
    private var startedAt = 0L
    private var complete = false

    /**
     * Records one tap at [nowMs] (monotonic clock).
     *
     * @return true exactly once when the gesture finishes.
     */
    fun tap(nowMs: Long): Boolean {
        if (complete) return false
        if (taps > 0 && (nowMs < startedAt || nowMs - startedAt > windowMs)) reset()
        if (taps == 0) startedAt = nowMs
        taps += 1
        if (taps >= required) {
            taps = 0
            complete = true
            return true
        }
        return false
    }

    private fun reset() {
        taps = 0
        startedAt = 0L
        complete = false
    }

    companion object {
        const val REQUIRED_TAPS = 7
        const val WINDOW_MS = 5_000L
    }
}
