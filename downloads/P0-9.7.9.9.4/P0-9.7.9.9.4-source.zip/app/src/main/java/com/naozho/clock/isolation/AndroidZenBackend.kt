package com.naozho.clock.isolation

import android.app.AutomaticZenRule
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Build
import android.service.notification.Condition
import android.service.notification.ConditionProviderService
import android.service.notification.ZenPolicy
import androidx.annotation.RequiresApi
import java.lang.ref.WeakReference

internal class AndroidZenBackend(private val context: Context) : ZenBackend {
    private val manager = context.getSystemService(NotificationManager::class.java)
    private val settings = ComponentName(context, IsolationSettingsActivity::class.java)

    @RequiresApi(24)
    private fun owner() = ComponentName(context, ClockConditionProvider::class.java)

    override val available: Boolean get() = Build.VERSION.SDK_INT >= 24
    override val customVisuals: Boolean get() = Build.VERSION.SDK_INT >= 29
    override fun hasAccess(): Boolean = manager.isNotificationPolicyAccessGranted
    override fun currentFilter(): Int = manager.currentInterruptionFilter

    override fun blocksAlarms(filter: Int): Boolean {
        if (filter == NotificationManager.INTERRUPTION_FILTER_NONE) return true
        if (filter != NotificationManager.INTERRUPTION_FILTER_PRIORITY || !hasAccess()) return false
        val policy = when {
            Build.VERSION.SDK_INT >= 30 -> manager.consolidatedNotificationPolicy
            Build.VERSION.SDK_INT == 28 -> manager.notificationPolicy
            else -> return false
        }
        return policy.priorityCategories and NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS == 0
    }

    override fun ownedRule(): ClockRule? {
        if (Build.VERSION.SDK_INT < 24) return null
        return manager.automaticZenRules.entries.firstOrNull { (_, rule) -> owns(rule) }
            ?.let { (id, rule) -> describe(id, rule) }
    }

    @Suppress("DEPRECATION")
    override fun createRule(): ClockRule? {
        if (Build.VERSION.SDK_INT < 24) return null
        val name = "小方块时钟通知隔离"
        val uri = clockConditionId(context)
        val rule = if (Build.VERSION.SDK_INT >= 29) {
            AutomaticZenRule(name, null, settings, uri, clockZenPolicy(), NotificationManager.INTERRUPTION_FILTER_PRIORITY, true)
        } else {
            AutomaticZenRule(name, owner(), uri, NotificationManager.INTERRUPTION_FILTER_ALARMS, true)
        }
        val id = manager.addAutomaticZenRule(rule) ?: return null
        return describe(id, rule)
    }

    override fun setEnabled(rule: ClockRule, enabled: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        val current = manager.getAutomaticZenRule(rule.id)?.takeIf(::owns) ?: return false
        if (current.isEnabled == enabled) return true
        current.isEnabled = enabled
        return manager.updateAutomaticZenRule(rule.id, current)
    }

    override fun activate(rule: ClockRule): Boolean {
        if (Build.VERSION.SDK_INT >= 29) {
            manager.setAutomaticZenRuleState(rule.id, clockCondition(context, true))
            return true
        }
        return Build.VERSION.SDK_INT >= 24 && ClockConditionProvider.publishCurrent()
    }

    @RequiresApi(24)
    private fun owns(rule: AutomaticZenRule): Boolean =
        rule.conditionId == clockConditionId(context) &&
            (rule.owner == owner() || Build.VERSION.SDK_INT >= 29 && rule.configurationActivity == settings)

    @RequiresApi(24)
    private fun describe(id: String, rule: AutomaticZenRule): ClockRule {
        val visualPolicy = Build.VERSION.SDK_INT >= 29 && rule.owner != owner()
        val compatible = if (Build.VERSION.SDK_INT >= 29 && visualPolicy) {
            rule.interruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY &&
                rule.zenPolicy?.let {
                    it.priorityCategoryAlarms == ZenPolicy.STATE_ALLOW &&
                        it.priorityCategoryCalls == ZenPolicy.STATE_DISALLOW &&
                        it.priorityCategoryMessages == ZenPolicy.STATE_DISALLOW &&
                        it.priorityCategoryRepeatCallers == ZenPolicy.STATE_DISALLOW &&
                        it.visualEffectPeek == ZenPolicy.STATE_DISALLOW &&
                        it.visualEffectFullScreenIntent == ZenPolicy.STATE_DISALLOW
                } == true
        } else rule.interruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        return ClockRule(id, rule.isEnabled, compatible, visualPolicy)
    }
}

@RequiresApi(29)
internal fun clockZenPolicy(): ZenPolicy = ZenPolicy.Builder()
    .disallowAllSounds()
    .allowAlarms(true)
    .allowSystem(true)
    .showPeeking(false)
    .showFullScreenIntent(false)
    .showInAmbientDisplay(false)
    .showStatusBarIcons(false)
    .build()

@RequiresApi(24)
private fun clockConditionId(context: Context): Uri = Uri.Builder()
    .scheme(Condition.SCHEME)
    .authority(context.packageName)
    .appendPath("clock-notification-isolation")
    .build()

@RequiresApi(24)
private fun clockCondition(context: Context, active: Boolean) = Condition(
    clockConditionId(context), "小方块时钟模式", if (active) Condition.STATE_TRUE else Condition.STATE_FALSE,
)

/** Android binds this provider for the app's rule only. There is no app-started service. */
@RequiresApi(24)
@Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
class ClockConditionProvider : ConditionProviderService() {
    override fun onConnected() {
        connected = WeakReference(this)
    }

    override fun onSubscribe(conditionId: Uri) {
        if (conditionId == clockConditionId(this)) publish()
    }

    override fun onUnsubscribe(conditionId: Uri) = Unit

    override fun onDestroy() {
        if (connected?.get() === this) connected = null
        super.onDestroy()
    }

    private fun publish() = notifyCondition(clockCondition(this, ClockIsolation.requestedByClock(this)))

    companion object {
        @Volatile private var connected: WeakReference<ClockConditionProvider>? = null

        internal fun publishCurrent(): Boolean {
            val provider = connected?.get() ?: return false
            provider.publish()
            return true
        }
    }
}
