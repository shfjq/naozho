package com.naozho.clock.mode

import android.app.admin.PolicyUpdateReceiver
import android.app.admin.PolicyUpdateResult
import android.app.admin.TargetUser
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Process
import android.util.Log
import androidx.annotation.RequiresApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

@RequiresApi(34)
class ClockPolicyReceiver : PolicyUpdateReceiver() {
    override fun onPolicySetResult(context: Context, policyIdentifier: String, additionalPolicyParams: Bundle,
        targetUser: TargetUser, policyUpdateResult: PolicyUpdateResult) {
        record(context, "set-result", policyIdentifier, additionalPolicyParams, targetUser, policyUpdateResult.resultCode)
    }

    override fun onPolicyChanged(context: Context, policyIdentifier: String, additionalPolicyParams: Bundle,
        targetUser: TargetUser, policyUpdateResult: PolicyUpdateResult) {
        record(context, "changed", policyIdentifier, additionalPolicyParams, targetUser, policyUpdateResult.resultCode)
    }

    private fun record(context: Context, event: String, policy: String, params: Bundle, target: TargetUser, result: Int) {
        val user = when (target) {
            TargetUser.LOCAL_USER -> "LOCAL(${Process.myUserHandle()})"
            TargetUser.GLOBAL -> "GLOBAL"
            TargetUser.PARENT_USER -> "PARENT"
            else -> "UNKNOWN"
        }
        val filter = params.getParcelable(EXTRA_INTENT_FILTER, IntentFilter::class.java)
        val home = filter?.hasAction(Intent.ACTION_MAIN) == true && filter.hasCategory(Intent.CATEGORY_HOME)
        val resultName = when (result) {
            PolicyUpdateResult.RESULT_POLICY_SET -> "SET"
            PolicyUpdateResult.RESULT_POLICY_CLEARED -> "CLEARED"
            PolicyUpdateResult.RESULT_FAILURE_CONFLICTING_ADMIN_POLICY -> "CONFLICTING_ADMIN_POLICY"
            PolicyUpdateResult.RESULT_FAILURE_HARDWARE_LIMITATION -> "HARDWARE_LIMITATION"
            PolicyUpdateResult.RESULT_FAILURE_STORAGE_LIMIT_REACHED -> "STORAGE_LIMIT_REACHED"
            else -> "UNKNOWN"
        }
        Log.i("NaozhoMode", "Policy $event policy=$policy target=$user result=$result homeFilter=$home ($resultName)")
        if (home) {
            val correlation = HomePolicyResults.receive(event, policy, filter, target, result)
            val observed = ManagedDesktop(context).effectiveHome()?.flattenToShortString()
            Log.i("NaozhoMode", "HOME callback event=$event user=$user result=$result $correlation observedHome=$observed")
        }
        // The callbacks report policy administration. Consumers reread actual framework state.
        DesktopPolicyUpdates.refresh()
    }
}

internal object DesktopPolicyUpdates {
    private val changes = MutableStateFlow(0L)
    val revision = changes.asStateFlow()
    private val lockError = MutableStateFlow<String?>(null)
    val lockFailure = lockError.asStateFlow()

    fun refresh() { changes.update { it + 1 } }

    fun recordLockResult(result: DesktopResult?) {
        lockError.value = (result as? DesktopResult.Rejected)?.message
        refresh()
    }
}
