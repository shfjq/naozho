package com.naozho.clock.alarm

import android.content.BroadcastReceiver
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as AlarmRuntime
        val components = intent.data?.takeIf { it.scheme == "naozho" && it.authority == "alarm" }
            ?.pathSegments ?: return
        if (components.size != 3) return
        val slot = AlarmSlot.entries.firstOrNull { it.name == components[1] } ?: return
        val at = components[2].toLongOrNull() ?: return
        val occurrence = AlarmOccurrence(components[0], slot, at)
        val result = goAsync()
        app.background.launch {
            try {
                if (app.repository.receive(occurrence)) {
                    try {
                        ContextCompat.startForegroundService(context, Intent(context, AlarmRingService::class.java))
                    } catch (error: RuntimeException) {
                        Log.e("NaozhoAlarm", "Foreground playback unavailable", error)
                        app.repository.finish(occurrence.id, at, "playback_blocked")
                    }
                }
            } finally {
                result.finish()
            }
        }
    }
}

class AlarmRecoveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val recovery = when (intent.action) {
            Intent.ACTION_LOCKED_BOOT_COMPLETED -> Recovery.REBOOT
            Intent.ACTION_BOOT_COMPLETED -> if (Build.VERSION.SDK_INT >= 24) Recovery.RESTORE else Recovery.REBOOT
            Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> Recovery.CLOCK_CHANGED
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" -> Recovery.RESTORE
            else -> return
        }
        val jobId = AlarmRecoveryJob.idFor(recovery)
        val job = JobInfo.Builder(jobId, ComponentName(context, AlarmRecoveryJob::class.java))
            .setOverrideDeadline(0L)
            .build()
        val queued = context.getSystemService(JobScheduler::class.java).schedule(job)
        if (queued != JobScheduler.RESULT_SUCCESS) {
            Log.e("NaozhoAlarm", "Unable to enqueue recovery reason=$recovery")
            val app = context.applicationContext as AlarmRuntime
            val result = goAsync()
            app.background.launch {
                try {
                    app.repository.recover(recovery)
                } finally {
                    result.finish()
                }
            }
        }
    }
}
