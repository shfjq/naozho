package com.naozho.clock.alarm

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import com.naozho.clock.R
import com.naozho.clock.data.AlarmPlan
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal data class ImportedSound(val key: String, val label: String)

internal class AlarmSounds(private val context: Context) {
    private val folder: File
        get() {
            val storage = if (Build.VERSION.SDK_INT >= 24) context.createDeviceProtectedStorageContext()
            else context
            return File(storage.filesDir, "alarm-sounds")
        }

    suspend fun import(uri: Uri): ImportedSound = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val label = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
        val key = UUID.randomUUID().toString()
        val dir = folder.apply { mkdirs() }
        val temporary = File(dir, "$key.tmp")
        val destination = File(dir, key)
        try {
            val input = resolver.openInputStream(uri) ?: throw IOException("Cannot open audio")
            input.use { source ->
                temporary.outputStream().use { output ->
                    val buffer = ByteArray(8_192)
                    var total = 0
                    while (true) {
                        val count = source.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > MAX_BYTES) throw IOException("Audio exceeds 20 MB")
                        output.write(buffer, 0, count)
                    }
                    if (total == 0) throw IOException("Empty audio")
                }
            }
            if (!temporary.renameTo(destination)) throw IOException("Cannot save audio")
            ImportedSound(key, label?.take(80)?.ifBlank { null } ?: "自定义铃声")
        } finally {
            temporary.delete()
        }
    }

    suspend fun remove(key: String?) = withContext(Dispatchers.IO) {
        key?.let(::customFile)?.delete()
    }

    fun prepare(plan: AlarmPlan, onFallback: () -> Unit): MediaPlayer? {
        if (plan.ringtone != null) {
            val custom = newPlayer(plan.ramp) { player ->
                FileInputStream(customFile(plan.ringtone)).use { player.setDataSource(it.fd) }
            }
            if (custom != null) return custom
            onFallback()
        }
        return newPlayer(plan.ramp) { it.setDataSource(context, Settings.System.DEFAULT_ALARM_ALERT_URI) }
            ?: newPlayer(plan.ramp) { player ->
                context.resources.openRawResourceFd(R.raw.alarm_backup).use {
                    player.setDataSource(it.fileDescriptor, it.startOffset, it.length)
                }
            }
    }

    private fun customFile(key: String): File {
        require(runCatching { UUID.fromString(key).toString() == key }.getOrDefault(false))
        return File(folder, key)
    }

    private fun newPlayer(ramp: Boolean, source: (MediaPlayer) -> Unit): MediaPlayer? {
        val player = MediaPlayer()
        return try {
            player.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
            )
            source(player)
            player.prepare()
            player.isLooping = true
            val volume = if (ramp) START_VOLUME else 1f
            player.setVolume(volume, volume)
            player
        } catch (_: Exception) {
            player.release()
            null
        }
    }

    companion object {
        const val START_VOLUME = 0.15f
        private const val MAX_BYTES = 20 * 1024 * 1024
    }
}
