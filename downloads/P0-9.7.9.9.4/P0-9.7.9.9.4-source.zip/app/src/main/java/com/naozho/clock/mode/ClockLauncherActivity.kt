package com.naozho.clock.mode

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.naozho.clock.MainActivity

class ClockLauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(clockLaunchIntent(this))
        finish()
    }
}

internal fun clockLaunchIntent(context: Context) = Intent(context, MainActivity::class.java)
    .setAction(Intent.ACTION_MAIN)
    .addCategory(Intent.CATEGORY_LAUNCHER)
    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
