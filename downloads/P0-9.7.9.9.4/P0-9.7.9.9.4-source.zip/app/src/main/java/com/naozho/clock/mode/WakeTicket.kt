package com.naozho.clock.mode

import android.content.Context
import android.content.Intent
import java.io.File

/** Fixed schema shared with the root observer. No shell, URI or caller-supplied Activity. */
internal data class WakeTicket(
    val boot: Int, val bootId: String, val dark: Long, val event: Long, val expires: Long,
    val sequence: Long, val id: String, val sender: Int
) {
    fun trace(stage: String, at: Long = android.os.SystemClock.elapsedRealtime(), details: String = "") {
        android.util.Log.i("NaozhoWakePerf", "$at $stage boot=$boot dark=$dark request=$id pid=${android.os.Process.myPid()}$details")
    }
    val epoch get() = "$bootId/$dark/$sequence"
    val receipt get() = "$id|$boot|$epoch|$event|$expires|$sender"
    fun fresh(now: Long) = dark >= 0 && event > dark && event <= now &&
        now <= expires && expires - event == LIFETIME
    fun attested(context: Context): Boolean = runCatching {
        val file = File(context.filesDir, "wake-epoch.proof")
        file.length() in 1..256 && file.readText() == receipt
    }.getOrDefault(false)

    fun entry(context: Context) = Intent(RETURN).setComponent(ClockPowerReturn.target(context))
        .putExtra(EXTRA_BOOT_COUNT, boot).putExtra("boot_id", bootId).putExtra("dark_elapsed", dark)
        .putExtra("event_timestamp", event).putExtra("expiry", expires).putExtra("sequence", sequence)
        .putExtra("request_id", id).putExtra("sender_uid", sender).putExtra("source", "DISPLAY_FULL_WAKE")
        .putExtra("wake_epoch_id", epoch).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    companion object {
        const val RETURN = "com.naozho.clock.action.WAKE_EPOCH_RETURN"
        const val COMMIT = "com.naozho.clock.action.WAKE_EPOCH_COMMIT"
        const val LIFETIME = 12_000L
        private val uuid = Regex("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}")
        fun read(intent: Intent): WakeTicket? {
            val t = WakeTicket(intent.getIntExtra(EXTRA_BOOT_COUNT, -1), intent.getStringExtra("boot_id") ?: "",
                intent.getLongExtra("dark_elapsed", -1), intent.getLongExtra("event_timestamp", -1),
                intent.getLongExtra("expiry", -1), intent.getLongExtra("sequence", -1),
                intent.getStringExtra("request_id") ?: "", intent.getIntExtra("sender_uid", -1))
            return t.takeIf { t.boot >= 0 && uuid.matches(t.bootId) && uuid.matches(t.id) && t.sequence > 0 &&
                t.sender in setOf(0, 2000) && intent.getStringExtra("source") == "DISPLAY_FULL_WAKE" &&
                intent.getStringExtra("wake_epoch_id") == t.epoch }
        }
    }
}
