package com.naozho.clock.weather

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.os.UserManager
import android.util.Log
import com.naozho.clock.display.readWeatherLocation
import com.naozho.clock.display.DisplayPreferences
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

internal fun weatherStorageAvailable(context: Context): Boolean =
    Build.VERSION.SDK_INT < 24 || context.getSystemService(UserManager::class.java)?.isUserUnlocked == true

/** One repository and one launch gate for all triggers in the app process. */
internal class WeatherUpdates private constructor(private val app: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val display = app.getSharedPreferences("clock_display", Context.MODE_PRIVATE)
    private val repo = WeatherRepository(OpenMeteoSource(),
        PreferenceWeatherCache(app.getSharedPreferences("clock_weather", Context.MODE_PRIVATE)))
    private val scheduler = WeatherScheduler(app)
    private val gate = Mutex()
    val state = repo.state

    init {
        scope.launch {
            weatherConnectivity(app).collect { submit() }
        }
    }

    fun settingsChanged() { submit() }

    fun manualRefresh() { submit(force = true) }

    fun backgroundRefresh(): Job = submit()

    fun finishBroadcast(pending: BroadcastReceiver.PendingResult, lease: PowerManager.WakeLock?, resetAlarm: Boolean,
        task: String?) {
        val work = submit(resetAlarm = resetAlarm, taskId = task)
        scope.launch {
            try {
                // Receivers have a short execution budget. The independent network job
                // can catch the next due update if the system tears down our process.
                withTimeoutOrNull(8_500L) { work.join() }
            } finally {
                try { runCatching { if (lease?.isHeld == true) lease.release() } }
                finally { pending.finish() }
            }
        }
    }

    private fun submit(force: Boolean = false, resetAlarm: Boolean = false, taskId: String? = null): Job = scope.launch {
        refreshDisplay()
        if (resetAlarm) scheduler.invalidateAlarm()
        if (force && gate.isLocked) return@launch
        gate.withLock {
            refreshDisplay()
            val before = state.value
            if (before.location == null) {
                scheduler.cancel()
                return@withLock
            }
            scheduler.ensurePeriodic()
            val now = System.currentTimeMillis()
            val retry = before.pendingFailure
            val coolingDown = retry != null && (retry.reason != "offline") == before.online &&
                now - retry.attemptedAt in 0L until WeatherRepository.RETRY_INTERVAL
            val due = WeatherRepository.isDue(now, before.last)
            // Arm recovery first. An AlarmManager one-shot is consumed on receipt,
            // including when the process dies before the network result is cached.
            if (force || (due && !coolingDown)) {
                scheduler.scheduleAlarm(WeatherRepository.recoveryDeadline(now, before))
                val task = taskId ?: UUID.randomUUID().toString()
                if (display.getBoolean("weatherAuto", false)) {
                    val expected = readWeatherLocation(display)
                    val result = withTimeoutOrNull(4_000L) { CityLocator(app).resolve() }
                    // A user edit during location acquisition supersedes this result.
                    if (display.getBoolean("weatherAuto", false) && readWeatherLocation(display) == expected) {
                        val located = when (result) {
                            is CityResult.Resolved -> result.location to result.resolvedAt
                            is CityResult.NoCity -> result.location to result.resolvedAt
                            else -> null
                        }
                        if (located != null) {
                            val prefs = DisplayPreferences(display)
                            val same = located.first.key == expected?.key
                            val location = if (same && located.first.label.isBlank())
                                located.first.copy(label = expected?.label.orEmpty()) else located.first
                            prefs.save(prefs.state.value.copy(weatherLocation = location,
                                weatherAuto = true, weatherResolvedAt = located.second))
                            Log.i(TAG, "location_checked task=$task result=accepted_os_location")
                        } else {
                            if (result == null) LocationEvidence(app).fail("location_timeout")
                            Log.i(TAG, "location_checked task=$task result=${LocationEvidence(app).status(expected)}")
                        }
                    }
                    refreshDisplay()
                    val locationStatus = LocationEvidence(app).status(readWeatherLocation(display))
                    if (locationStatus != "accepted_os_location") {
                        // Keep old readings while the source is unverified. This also prevents
                        // an injected legacy location from receiving a fresh success timestamp.
                        scheduler.scheduleAlarm(now + WeatherRepository.RETRY_INTERVAL)
                        return@withLock
                    }
                }
                repo.refresh(force)
                val after = state.value
                if (after.last != null && after.last != before.last) {
                    Log.i(TAG, "forecast_cache_success updatedAt=${after.last.updatedAt} task=$task")
                } else if (after.lastFailure != null && after.lastFailure != before.lastFailure) {
                    Log.i(TAG, "forecast_refresh_failed reason=${after.lastFailure.reason} task=$task")
                }
            }
            val after = state.value
            if (after.location == null) {
                scheduler.cancel()
            } else {
                val completedAt = System.currentTimeMillis()
                scheduler.scheduleAlarm(WeatherRepository.nextDeadline(completedAt, after))
                if (!after.online && WeatherRepository.isDue(completedAt, after.last)) scheduler.ensureReconnect()
            }
        }
    }

    private fun refreshDisplay() {
        repo.display(readWeatherLocation(display), weatherNetworkAvailable(app))
        repo.locationStatus(if (display.getBoolean("weatherAuto", false))
            LocationEvidence(app).status(readWeatherLocation(display)) else "manual_location")
    }

    companion object {
        @Volatile private var instance: WeatherUpdates? = null

        fun get(context: Context): WeatherUpdates = instance ?: synchronized(this) {
            instance ?: WeatherUpdates(context.applicationContext).also { instance = it }
        }
    }
}

private const val TAG = "NaozhoWeather"
private const val ACTION_REFRESH = "com.naozho.clock.weather.REFRESH"
private const val PERIODIC_JOB = 0x57440001
private const val RECONNECT_JOB = 0x57440002
private const val WEATHER_ALARM = 0x57440003

private class WeatherScheduler(private val context: Context) {
    private val alarms = context.getSystemService(AlarmManager::class.java)
    private val jobs = context.getSystemService(JobScheduler::class.java)
    private var lastAlarm: Pair<Long, Boolean>? = null
    fun invalidateAlarm() { lastAlarm = null }

    private fun alarm(): PendingIntent = PendingIntent.getBroadcast(context, WEATHER_ALARM,
        Intent(context, WeatherUpdateReceiver::class.java).setAction(ACTION_REFRESH),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    @SuppressLint("ScheduleExactAlarm")
    fun scheduleAlarm(at: Long) {
        val manager = alarms ?: return
        val exact = Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()
        val key = at to exact
        if (key == lastAlarm) return
        try {
            if (exact) {
                try {
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarm())
                } catch (_: SecurityException) {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarm())
                    lastAlarm = at to false
                    Log.w(TAG, "weather_schedule inexact permission changed")
                    return
                }
            } else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarm())
            lastAlarm = key
            Log.i(TAG, "weather_schedule ${if (exact) "exact" else "inexact"} at=$at")
        } catch (failure: RuntimeException) {
            Log.w(TAG, "alarm_schedule_failed ${failure.javaClass.simpleName}")
        }
    }

    fun ensurePeriodic() = ensureJob(PERIODIC_JOB) { setPeriodic(WeatherRepository.REFRESH_INTERVAL) }

    fun ensureReconnect() = ensureJob(RECONNECT_JOB) {}

    private fun ensureJob(id: Int, configure: JobInfo.Builder.() -> Unit) {
        val manager = jobs ?: return
        try {
            val existing = if (Build.VERSION.SDK_INT >= 24) manager.getPendingJob(id) != null
                else manager.allPendingJobs.any { it.id == id }
            if (!existing) {
                val info = JobInfo.Builder(id, ComponentName(context, WeatherNetworkJob::class.java))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true)
                    .apply(configure).build()
                if (manager.schedule(info) != JobScheduler.RESULT_SUCCESS) {
                    Log.w(TAG, "network_job_schedule_rejected id=$id")
                }
            }
        } catch (failure: RuntimeException) {
            Log.w(TAG, "network_job_schedule_failed id=$id ${failure.javaClass.simpleName}")
        }
    }

    fun cancel() {
        if (lastAlarm != null) {
            alarms?.cancel(alarm())
            lastAlarm = null
        } else {
            val pending = PendingIntent.getBroadcast(context, WEATHER_ALARM,
                Intent(context, WeatherUpdateReceiver::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE)
            if (pending != null) alarms?.cancel(pending)
        }
        runCatching {
            jobs?.cancel(PERIODIC_JOB)
            jobs?.cancel(RECONNECT_JOB)
        }.onFailure { Log.w(TAG, "weather_job_cancel_failed") }
    }
}

class WeatherUpdateReceiver : BroadcastReceiver() {
    @SuppressLint("WakelockTimeout")
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action !in setOf(ACTION_REFRESH, Intent.ACTION_BOOT_COMPLETED,
                Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIME_CHANGED,
                AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED) ||
            !weatherStorageAvailable(context)
        ) return
        val pending = goAsync()
        val lease = runCatching {
            context.getSystemService(PowerManager::class.java)
                ?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Naozho:WeatherRefresh")
                ?.apply { acquire(9_000L) }
        }.getOrNull()
        val task = intent.getStringExtra("task_id")?.takeIf {
            it.matches(Regex("[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}"))
        }
        WeatherUpdates.get(context).finishBroadcast(pending, lease, resetAlarm = true, task = task)
    }
}

/** Persisted, network-constrained fallback for reconnect and inexact alarm delivery. */
class WeatherNetworkJob : JobService() {
    private val callbacks = mutableMapOf<Int, Job>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onStartJob(params: JobParameters): Boolean {
        if (!weatherStorageAvailable(this)) return false
        callbacks[params.jobId] = scope.launch {
            val work = WeatherUpdates.get(this@WeatherNetworkJob).backgroundRefresh()
            work.join()
            jobFinished(params, false)
            callbacks.remove(params.jobId)
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        callbacks.remove(params.jobId)?.cancel()
        return false
    }

    override fun onDestroy() {
        callbacks.values.forEach { it.cancel() }
        callbacks.clear()
        super.onDestroy()
    }
}
