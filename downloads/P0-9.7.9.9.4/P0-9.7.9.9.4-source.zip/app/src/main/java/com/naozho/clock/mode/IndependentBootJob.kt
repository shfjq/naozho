package com.naozho.clock.mode

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.PersistableBundle
import android.os.SystemClock
import android.os.UserManager
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.content.edit
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TAG = "NaozhoBootJob"

@RequiresApi(24)
internal class IndependentBootJob(private val context: Context) {
    private val scheduler = context.getSystemService(JobScheduler::class.java)
    private val service = ComponentName(context, IndependentBootJobService::class.java)
    private val history get() = context.getSharedPreferences("independent_job_history", Context.MODE_PRIVATE)

    fun recoveryRegistered() = try {
        scheduler.getPendingJob(ID)?.let { it.service == service && it.isPersisted && it.isPeriodic && !it.extras.getBoolean(OBSERVE) } == true
    } catch (_: RuntimeException) { false }

    fun register(observeOnly: Boolean): DesktopResult {
        val step = "登记开机 Job"
        val boot = bootCount(context)
        if (boot < 0) return desktopFailure(step, "无法读取开机编号。")
        try {
            val current = scheduler.getPendingJob(ID)
            if (current != null && current.service != service) return desktopFailure(step, "任务编号已被其他服务使用。")
            if (current?.isPersisted == true && current.isPeriodic &&
                current.extras.containsKey(TICKET) && current.extras.getBoolean(OBSERVE) == observeOnly
            ) return DesktopResult.Applied
            val ticket = UUID.randomUUID().toString()
            val extras = PersistableBundle().apply {
                putString(TICKET, ticket)
                putInt(REGISTERED_BOOT, boot)
                putBoolean(OBSERVE, observeOnly)
            }
            val job = JobInfo.Builder(ID, service).setPersisted(true)
                .setPeriodic(TimeUnit.MINUTES.toMillis(15)).setExtras(extras).build()
            val result = scheduler.schedule(job)
            val readback = scheduler.getPendingJob(ID)
            Log.i(TAG, "register id=$ID ticket=$ticket boot=$boot observe=$observeOnly result=$result pending=${readback != null}")
            if (result != JobScheduler.RESULT_SUCCESS || readback?.extras?.getString(TICKET) != ticket ||
                !readback.isPersisted || !readback.isPeriodic) return desktopFailure(step, "系统登记或持久任务读回失败，result=$result。")
            return DesktopResult.Applied
        } catch (e: RuntimeException) {
            return desktopFailure(step, "系统拒绝登记或查询（${e.javaClass.simpleName}）。", e)
        }
    }

    fun cancel(): DesktopResult = try {
        if (scheduler.getPendingJob(ID)?.service == service) scheduler.cancel(ID)
        if (scheduler.getPendingJob(ID)?.service == service) desktopFailure("取消开机 Job", "任务仍存在。")
        else DesktopResult.Applied
    } catch (e: RuntimeException) {
        desktopFailure("取消开机 Job", "无法确认取消（${e.javaClass.simpleName}）。", e)
    }

    fun describe(): String {
        val pending = try {
            val job = scheduler.getPendingJob(ID)
            if (job == null) "未登记" else {
                val kind = if (job.extras.getBoolean(OBSERVE)) "仅观察" else "独立恢复"
                "$kind，persisted=${job.isPersisted}，登记 boot=${job.extras.getInt(REGISTERED_BOOT, -1)}，pending reasons=${pendingReasons()}"
            }
        } catch (e: RuntimeException) { "查询失败（${e.javaClass.simpleName}）" }
        return "Job $ID：$pending\n最后一次 onStartJob：${history.getString("last", "尚无记录")}\n本次记录所属开机首次执行：${history.getLong("first_ms", -1)} ms\n最近处理：${history.getString("outcome", "尚无记录")}"
    }

    private fun pendingReasons(): String = when {
        Build.VERSION.SDK_INT >= 36 -> try {
            // Public API 36 method; this project still builds against SDK 35.
            val method = JobScheduler::class.java.getMethod("getPendingJobReasons", Int::class.javaPrimitiveType)
            (method.invoke(scheduler, ID) as IntArray).contentToString()
        } catch (e: ReflectiveOperationException) { "读数不可用（${e.javaClass.simpleName}）" }
        Build.VERSION.SDK_INT >= 34 -> scheduler.getPendingJobReason(ID).toString()
        else -> "见 dumpsys jobscheduler"
    }

    suspend fun execute(extras: PersistableBundle, elapsed: Long, active: () -> Boolean) {
        val boot = bootCount(context)
        val origin = extras.getInt(REGISTERED_BOOT, -1)
        val ticket = extras.getString(TICKET)
        val sample = "boot=$boot elapsedMs=$elapsed registeredBoot=$origin ticket=$ticket"
        Log.i(TAG, "onStartJob $sample")
        if (!context.getSystemService(UserManager::class.java).isUserUnlocked) {
            Log.i(TAG, "waiting for user storage; no launch")
            return
        }
        val first = history.getInt("boot", -1) != boot || !history.contains("first_ms")
        history.edit {
            if (first) putLong("first_ms", elapsed)
            putInt("boot", boot)
            putString("last", sample)
            putString("outcome", "处理中")
        }
        val outcome = when {
            !context.isDevelopmentBuild || boot < 0 || origin < 0 || ticket == null -> "登记信息不完整"
            extras.getBoolean(OBSERVE) -> "仅观察，已收到系统调度"
            boot == origin -> "仍为登记时的开机，本次无需启动"
            else -> {
                val result = ManagedDeployment(context).restoreIndependentAfterBoot("job") {
                    active() && scheduler.getPendingJob(ID)?.extras?.getString(TICKET) == ticket
                }
                if (result is DesktopResult.Rejected) result.message else "恢复条件已检查，实际启动与锁定见 NaozhoMode"
            }
        }
        history.edit { putString("outcome", outcome) }
        Log.i(TAG, "finish $sample outcome=$outcome")
    }

    companion object {
        const val ID = 6801
        private const val REGISTERED_BOOT = "registered_boot"
        private const val OBSERVE = "observe"
        private const val TICKET = "ticket"
    }
}

class IndependentBootJobService : JobService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var work: Job? = null

    override fun onStartJob(params: JobParameters): Boolean {
        if (Build.VERSION.SDK_INT < 28 || !isDevelopmentBuild || params.jobId != IndependentBootJob.ID) return false
        val elapsed = SystemClock.elapsedRealtime()
        Log.i(TAG, "service onStartJob id=${params.jobId} elapsedMs=$elapsed")
        work = scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    IndependentBootJob(this@IndependentBootJobService).execute(params.extras, elapsed) { isActive }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Job execution failed id=${params.jobId}", e)
            } finally {
                if (isActive) jobFinished(params, false)
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        val reason = if (Build.VERSION.SDK_INT >= 31) params.stopReason else null
        Log.i(TAG, "onStopJob id=${params.jobId} reason=$reason elapsedMs=${SystemClock.elapsedRealtime()}")
        work?.cancel()
        return false
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
