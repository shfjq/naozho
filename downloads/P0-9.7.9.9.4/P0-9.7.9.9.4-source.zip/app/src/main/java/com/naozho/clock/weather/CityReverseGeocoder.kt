package com.naozho.clock.weather

import android.content.SharedPreferences
import androidx.core.content.edit
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URISyntaxException
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject

internal fun interface NetworkCitySource {
    suspend fun lookup(latitude: String, longitude: String, language: String): String?
}

/**
 * Used only by foreground city resolution. The single cached result is private to the app,
 * separate from weather readings, and keyed by the rounded request coordinates and language.
 */
internal class CityReverseGeocoder(
    private val prefs: SharedPreferences,
    private val source: NetworkCitySource = BigDataCloudCitySource(),
    private val now: () -> Long = System::currentTimeMillis,
) {
    suspend fun city(latitude: Double, longitude: Double, locale: Locale, allowNetwork: Boolean): String? = gate.withLock {
        val lat = rounded(latitude)
        val lon = rounded(longitude)
        val language = locale.language.lowercase(Locale.ROOT).takeIf { it.matches(Regex("[a-z]{2,3}")) } ?: "en"
        val key = "$lat,$lon/$language"
        val time = now()
        val cached = prefs.getString("city", null)?.let(::cityName)
        if (cached != null && key == prefs.getString("key", null) &&
            time - prefs.getLong("resolved", 0) in 0 until CITY_CACHE_MS
        ) return@withLock cached
        if (!allowNetwork) return@withLock null
        val lastAttempt = prefs.getLong("attempt", 0)
        val sinceAttempt = time - lastAttempt
        val retryUntil = prefs.getLong("retryUntil", 0)
        if (lastAttempt != 0L && sinceAttempt in 0 until MIN_REQUEST_INTERVAL_MS ||
            retryUntil - time in 1..MAX_BACKOFF_MS
        ) return@withLock null

        prefs.edit { putLong("attempt", time) }
        try {
            source.lookup(lat, lon, language)?.let(::cityName)?.also { label ->
                prefs.edit {
                    putString("key", key)
                    putString("city", label)
                    putLong("resolved", now())
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (limited: CitySourceRateLimited) {
            prefs.edit { putLong("retryUntil", now() + limited.retryMs.coerceIn(MIN_REQUEST_INTERVAL_MS, MAX_BACKOFF_MS)) }
            null
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private val gate = Mutex()
        private const val MIN_REQUEST_INTERVAL_MS = 60_000L
        private const val CITY_CACHE_MS = 7 * 24 * 60 * 60_000L
        private const val MAX_BACKOFF_MS = 24 * 60 * 60_000L

        internal fun rounded(value: Double): String =
            String.format(Locale.ROOT, "%.2f", value).let { if (it == "-0.00") "0.00" else it }
    }
}

internal class CitySourceRateLimited(val retryMs: Long) : IOException("city_provider_rate_limited")

internal class BigDataCloudCitySource(
    private val open: (URL) -> HttpURLConnection = { it.openConnection() as HttpURLConnection },
    private val elapsedMs: () -> Long = android.os.SystemClock::elapsedRealtime,
) : NetworkCitySource {
    override suspend fun lookup(latitude: String, longitude: String, language: String): String? =
        withContext(Dispatchers.IO) {
            val origin = URI("https://api.bigdatacloud.net/data/reverse-geocode-client" +
                "?latitude=$latitude&longitude=$longitude&localityLanguage=$language")
            query(origin)
        }

    private fun query(origin: URI): String? {
        var target = origin
        val visited = mutableSetOf<URI>()
        val deadline = elapsedMs() + 12_000
        repeat(MAX_REDIRECTS + 1) { hop ->
            val remaining = deadline - elapsedMs()
            if (remaining <= 0) throw IOException("city_provider_timeout")
            if (!visited.add(target.normalize())) throw IOException("city_provider_redirect_loop")
            val connection = open(target.toURL())
            target = try {
                connection.connectTimeout = remaining.coerceAtMost(4_000).toInt()
                connection.readTimeout = remaining.coerceAtMost(4_000).toInt()
                connection.instanceFollowRedirects = false
                connection.requestMethod = "GET"
                connection.useCaches = false
                // Rebuild headers on every request. Neither the previous connection's
                // request headers nor any values supplied by the server are forwarded.
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("User-Agent", "NaozhoCPDAY10/1.0 (+https://github.com/shfjq/naozho)")
                when (connection.responseCode) {
                    301, 302, 303, 307, 308 -> {
                        if (hop == MAX_REDIRECTS) throw IOException("city_provider_redirect_limit")
                        redirect(target, connection.getHeaderField("Location"))
                    }
                    429, 503 -> throw CitySourceRateLimited(retryDelay(connection.getHeaderField("Retry-After")))
                    HttpURLConnection.HTTP_OK -> return parseCity(readBody(connection, deadline))
                    else -> throw IOException("city_provider_response")
                }
            } finally {
                connection.disconnect()
            }
        }
        throw IOException("city_provider_redirect_limit")
    }

    private fun redirect(origin: URI, header: String?): URI {
        val value = header?.trim()?.takeIf { it.isNotEmpty() && it.length <= 2048 }
            ?: throw IOException("city_provider_redirect_missing")
        val target = try {
            // HttpURLConnection does not consistently follow cross-host 307/308.
            // URL resolution also preserves the existing path for a query-only Location.
            val reference = URI(value)
            val resolved = if (reference.rawPath.isNullOrEmpty() && reference.rawQuery != null &&
                !reference.isAbsolute && reference.rawAuthority == null) {
                URI(origin.toString().substringBefore('?') + "?" + value.substringAfter('?'))
            } else origin.resolve(reference)
            resolved
        } catch (_: URISyntaxException) {
            throw IOException("city_provider_redirect_invalid")
        }
        if (!target.scheme.equals("https", ignoreCase = true) ||
            target.host?.lowercase(Locale.ROOT) !in TRUSTED_HOSTS ||
            target.port !in listOf(-1, 443) || target.rawUserInfo != null || target.rawFragment != null
        ) throw IOException("city_provider_redirect_untrusted")
        return target
    }

    private fun readBody(connection: HttpURLConnection, deadline: Long): String {
        val output = ByteArrayOutputStream()
        connection.inputStream.use { stream ->
            val buffer = ByteArray(4096)
            while (true) {
                val count = stream.read(buffer)
                if (elapsedMs() >= deadline) throw IOException("city_provider_timeout")
                if (count < 0) break
                if (output.size() + count > 49_152) throw IOException("city_provider_body_limit")
                output.write(buffer, 0, count)
            }
        }
        return output.toString(Charsets.UTF_8.name())
    }

    companion object {
        private const val MAX_REDIRECTS = 3
        private val TRUSTED_HOSTS = setOf("api.bigdatacloud.net", "api-bdc.io")

        fun parseCity(body: String): String? {
            val root = JSONObject(body)
            return sequenceOf("city", "locality", "principalSubdivision")
                .mapNotNull { field -> (root.opt(field) as? String)?.let(::cityName) }
                .firstOrNull()
        }

        private fun retryDelay(header: String?): Long {
            val text = header?.trim() ?: return 300_000L
            val seconds = text.toLongOrNull()
            if (seconds != null) return seconds.coerceIn(1L, 86_400L) * 1000L
            return runCatching {
                ZonedDateTime.parse(text, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() -
                    System.currentTimeMillis()
            }.getOrDefault(300_000L).coerceIn(1_000L, 86_400_000L)
        }
    }
}

internal fun cityName(value: String): String? =
    value.trim().filterNot(Char::isISOControl).take(32).takeIf { text -> text.any(Char::isLetter) }
