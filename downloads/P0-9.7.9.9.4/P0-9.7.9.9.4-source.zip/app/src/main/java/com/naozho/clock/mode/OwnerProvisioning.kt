package com.naozho.clock.mode

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.os.Build
import android.os.Bundle

/** These entry points are callable only by the system's provisioning flow. */
class ProvisioningModeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 31 && intent.action == DevicePolicyManager.ACTION_GET_PROVISIONING_MODE) {
            val allowed = intent.getIntegerArrayListExtra(DevicePolicyManager.EXTRA_PROVISIONING_ALLOWED_PROVISIONING_MODES)
            val fullyManaged = DevicePolicyManager.PROVISIONING_MODE_FULLY_MANAGED_DEVICE
            if (allowed?.contains(fullyManaged) == true) {
                setResult(RESULT_OK, Intent().putExtra(DevicePolicyManager.EXTRA_PROVISIONING_MODE, fullyManaged))
            }
        }
        finish()
    }
}

class PolicyComplianceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 31 && intent.action == DevicePolicyManager.ACTION_ADMIN_POLICY_COMPLIANCE) {
            val managed = ManagedDesktop(this)
            // Accept enrollment without enabling kiosk restrictions. The operator still has to
            // configure the recovery credentials, Freeme and alarm permissions in the app.
            if (managed.owner && managed.activeAdmin) setResult(RESULT_OK)
        }
        finish()
    }
}
