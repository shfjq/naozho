package com.naozho.clock.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.naozho.clock.mode.ModeCredentials
import com.naozho.clock.mode.PinField

@Composable
internal fun ModeEntryScreen(
    configured: Boolean,
    checking: Boolean,
    error: String?,
    check: (String) -> Unit,
    cancel: () -> Unit,
) {
    var pin by remember { mutableStateOf("") }
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.safeDrawingPadding().imePadding().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("验证时钟 PIN", style = MaterialTheme.typography.headlineMedium)
            if (configured) {
                Text("进入安卓模式还需通过 Android 系统屏幕锁验证。")
                PinField(pin, { pin = it }, "时钟 PIN", !checking)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Button({ check(pin); pin = "" }, enabled = !checking && ModeCredentials.validPin(pin)) {
                    Text(if (checking) "正在验证…" else "进入安卓模式")
                }
            } else {
                Text("尚未设置时钟 PIN。请从管理员恢复设置。")
            }
            OutlinedButton(cancel) { Text("返回时钟") }
        }
    }
}

@Composable
internal fun DesktopUnavailableScreen(returnToClock: () -> Unit, recover: () -> Unit) {
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("桌面切换未完成", style = MaterialTheme.typography.headlineMedium)
            Text("可重试进入时钟，或在管理员恢复中核对原桌面和专机策略。")
            Button(returnToClock) { Text("重试进入时钟") }
            OutlinedButton(recover) { Text("管理员恢复") }
        }
    }
}
