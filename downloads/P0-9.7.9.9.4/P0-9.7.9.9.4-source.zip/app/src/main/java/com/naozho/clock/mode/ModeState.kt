package com.naozho.clock.mode

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.os.UserManager
import android.provider.Settings
import android.util.Log
import com.naozho.clock.R
import com.naozho.clock.alarm.AlarmRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

internal enum class DesktopMode { CLOCK, ANDROID }
internal enum class StationPhase { NOT_CONFIGURED, CLOCK, ANDROID, MAINTENANCE_PAUSED, BOOT_PENDING }
internal const val INDEPENDENT_BOOT_ACTION = "com.naozho.clock.action.INDEPENDENT_BOOT"
internal const val EXTRA_BOOT_COUNT = "boot_count"

internal val Context.isDevelopmentBuild: Boolean get() = resources.getBoolean(R.bool.development_mode)

// Report persistence failures to the caller and write the boot marker before a desktop handoff.
@SuppressLint("ApplySharedPref", "UseKtx")
internal class ModeState(private val context: Context) {
    private companion object { val modeWrites = Any() }

    private val prefs = context.getSharedPreferences("desktop_mode", Context.MODE_PRIVATE)

    fun current(): DesktopMode {
        syncBoot()
        return if (prefs.getBoolean("android", false)) DesktopMode.ANDROID else DesktopMode.CLOCK
    }

    fun set(mode: DesktopMode): Boolean = synchronized(modeWrites) {
        syncBoot()
        val android = mode == DesktopMode.ANDROID
        val editor = prefs.edit().putBoolean("android", android)
        if (prefs.getBoolean("android", false) != android || !prefs.contains("mode_since")) {
            editor.remove("wake_focused").putLong("mode_since", SystemClock.elapsedRealtime()).remove("wake_pending").remove("power_pending")
        }
        editor.commit()
    }

    /** The receiver reserves one send. Only its private Activity entry can commit CLOCK. */
    fun acceptPowerPress(boot: Int, first: Long, released: Long, delivery: PowerDelivery): Boolean = synchronized(modeWrites) {
        if (!independentLock() || current() != DesktopMode.ANDROID || boot < 0 || boot != bootCount(context)) return false
        val now = SystemClock.elapsedRealtime()
        // Old installs pick up the boundary on first use. A new physical gesture is required.
        if (!prefs.contains("mode_since")) {
            prefs.edit().putLong("mode_since", now).commit()
            return false
        }
        if (first <= prefs.getLong("mode_since", Long.MAX_VALUE) || released <= first ||
            released > now || now - released > 2_000 || released - first > 1_000) return false
        val editor = prefs.edit()
        if (delivery != PowerDelivery.RESERVE) {
            if (prefs.getLong("power_pending", -1) != first) return false
            if (delivery == PowerDelivery.CHECK) return true
            editor.remove("wake_pending").remove("power_pending").putBoolean("android", false).putLong("mode_since", now)
        } else {
            val outstanding = prefs.contains("power_pending") &&
                now - prefs.getLong("power_pending_release", 0) <= 2_000
            if ((prefs.contains("wake_pending") && now <= prefs.getLong("wake_expiry", -1)) || outstanding || first <= prefs.getLong("power_last", -1)) return false
            editor.putLong("power_last", first).putLong("power_pending", first)
                .putLong("power_pending_release", released)
        }
        editor.commit()
    }

    fun acceptWake(ticket: WakeTicket, stage: PowerDelivery): Boolean = synchronized(modeWrites) {
        val now = SystemClock.elapsedRealtime()
        val currentBoot = bootCount(context)
        syncBoot(currentBoot, completed = false)
        // A lost clock process may leave CLOCK desired with the OS already back in NONE.
        // Both external foreground proof and live NONE are required before reaching this gate.
        if (!independentLock() || ticket.boot != currentBoot ||
            !ticket.fresh(now) || ticket.dark <= prefs.getLong("mode_since", Long.MAX_VALUE)) return false
        when (stage) {
            PowerDelivery.RESERVE -> {
                if (ticket.dark <= prefs.getLong("wake_last", -1) ||
                    (prefs.contains("power_pending") && now - prefs.getLong("power_pending_release", 0) <= 2000) ||
                    (prefs.contains("wake_pending") && now <= prefs.getLong("wake_expiry", -1))) return false
                prefs.edit().putString("wake_pending", ticket.receipt).putLong("wake_last", ticket.dark)
                    .putLong("wake_expiry", ticket.expires).commit()
            }
            PowerDelivery.CHECK -> prefs.getString("wake_pending", null) == ticket.receipt
            PowerDelivery.CONSUME -> prefs.getString("wake_pending", null) == ticket.receipt &&
                prefs.edit().remove("wake_pending").putString("wake_focused", ticket.id)
                    .putBoolean("android", false).putLong("mode_since", now).commit()
        }
    }

    // A crash after claiming CLOCK must not turn a later, genuine wake into an endless retry.
    fun confirmWake(id: String) = synchronized(modeWrites) {
        if (prefs.getString("wake_focused", null) == id) prefs.edit().remove("wake_focused").commit()
    }

    fun releaseFailedWake(id: String): Boolean = synchronized(modeWrites) {
        if (!independentLock() || prefs.getString("wake_focused", null) != id ||
            current() != DesktopMode.CLOCK) return false
        set(DesktopMode.ANDROID)
    }

    fun selectedHome(): ComponentName? = prefs.getString("native_home", null)?.let(ComponentName::unflattenFromString)

    fun saveHome(component: ComponentName): Boolean {
        if (selectedHome() == component) return true
        return prefs.edit().putString("native_home", component.flattenToString()).commit()
    }

    fun managedLock(): Boolean = prefs.getBoolean("managed_lock", false)

    fun managesHome(): Boolean = (managedLock() && prefs.getBoolean("managed_home", false)) || developmentRehearsal()

    fun independentLock(): Boolean = context.isDevelopmentBuild && managedLock() && !managesHome()

    // Desired mode is durable. A confirmed clock also needs a live foreground/lock readback.
    fun stationPhase(confirmedClock: Boolean): StationPhase {
        if (!managedLock()) {
            return if (prefs.contains("managed_lock")) StationPhase.MAINTENANCE_PAUSED else StationPhase.NOT_CONFIGURED
        }
        if (current() == DesktopMode.ANDROID) return StationPhase.ANDROID
        return if (confirmedClock) StationPhase.CLOCK else StationPhase.BOOT_PENDING
    }

    fun useClockEntryOnRestore(intent: Intent, savedPageBoot: Int): Boolean {
        val boot = bootCount(context)
        if (boot < 0 || boot == savedPageBoot) return false
        // The Activity validates the receipt, owner and current policy before restoring any page.
        if (intent.action == INDEPENDENT_BOOT_ACTION) return acceptsBootLaunch(boot) &&
            intent.getIntExtra(EXTRA_BOOT_COUNT, -1) == boot
        return intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME) &&
            managedLock() && current() == DesktopMode.CLOCK &&
            (managesHome() || (independentLock() && ManagedDesktop(context).isPrimaryClockEntry(intent)))
    }

    fun lastBootLaunch(): Int = prefs.getInt("independent_boot_launch", -1)

    fun recordBootLaunch(boot: Int): Boolean = prefs.edit().putInt("independent_boot_launch", boot).commit()

    fun acceptsBootLaunch(boot: Int): Boolean = boot >= 0 && boot == bootCount(context) &&
        boot == lastBootLaunch() && independentLock() && current() == DesktopMode.CLOCK

    fun developmentRehearsal(): Boolean = context.isDevelopmentBuild && !managedLock() &&
        prefs.getBoolean("dev_rehearsal", false)

    fun beginDevelopmentRehearsal(): Boolean {
        if (!context.isDevelopmentBuild || managedLock()) return false
        syncBoot()
        return prefs.edit().putBoolean("dev_rehearsal", true).putBoolean("android", false).commit()
    }

    fun saveDeployment(enabled: Boolean, mode: DesktopMode, manageHome: Boolean = enabled): Boolean = synchronized(modeWrites) {
        syncBoot()
        val saved = prefs.edit().putBoolean("managed_lock", enabled).putBoolean("managed_home", manageHome)
            .putBoolean("android", mode == DesktopMode.ANDROID).putLong("mode_since", SystemClock.elapsedRealtime())
            .remove("wake_focused").remove("wake_pending").remove("power_pending").remove("dev_rehearsal").remove("dev_exit_home")
            .remove("dev_verified_home").commit()
        if (saved) syncEarlyDisplay()
        return saved
    }

    // Only a presentation hint is copied to DE. Owner, lock and the authoritative mode
    // are checked again after unlock. No credential or desktop component is stored here.
    fun syncEarlyDisplay() {
        if (Build.VERSION.SDK_INT < 24 || !context.isDevelopmentBuild) return
        val de = context.createDeviceProtectedStorageContext().getSharedPreferences("primary_home_display", 0)
        val armed = independentLock()
        if (!de.contains("armed") || de.getBoolean("armed", false) != armed) {
            if (!de.edit().putBoolean("armed", armed).commit()) Log.w("NaozhoMode", "Could not persist early clock display hint")
        }
    }

    fun syncBoot(completed: Boolean = false): Unit = synchronized(modeWrites) {
        syncBoot(bootCount(context), completed)
    }

    private fun syncBoot(boot: Int, completed: Boolean) {
        val paused = prefs.contains("managed_lock") && !managedLock() && !developmentRehearsal()
        if (boot >= 0 && prefs.getInt("boot", -1) != boot) {
            prefs.edit().putBoolean("android", paused).putInt("boot", boot).remove("dev_exit_home")
                .putLong("mode_since", SystemClock.elapsedRealtime()).remove("wake_pending").remove("power_pending").remove("power_last").remove("wake_focused").remove("wake_last").commit()
        } else if (completed && boot < 0) {
            if (!independentLock()) prefs.edit().putBoolean("android", paused).remove("dev_exit_home").commit()
        }
    }
}

internal fun bootCount(context: Context): Int = if (Build.VERSION.SDK_INT >= 24) {
    Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, -1)
} else -1

class ModeBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val boot = intent.action == Intent.ACTION_BOOT_COMPLETED
        if (intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            (Build.VERSION.SDK_INT >= 24 && !context.getSystemService(UserManager::class.java).isUserUnlocked)
        ) {
            // The existing deployment and pause state are credential-encrypted. BOOT_COMPLETED
            // is delivered after this user's storage is available, including automatic unlock.
            Log.i("NaozhoMode", "Mode boot event=${intent.action} waitingForUnlockedBoot elapsedMs=${SystemClock.elapsedRealtime()}")
            return
        }
        if (!boot && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val mode = ModeState(context)
                if (boot) mode.syncBoot(completed = true)
                if (boot && !context.isDevelopmentBuild) ModeCredentials(context).onBootCompleted()
                if (boot && mode.independentLock()) {
                    val result = ManagedDeployment(context).restoreIndependentAfterBoot()
                    if (result is DesktopResult.Rejected) Log.w("NaozhoMode", "Independent boot rejected: ${result.message}")
                } else if (boot && !mode.managesHome()) {
                    Log.i("NaozhoMode", "Mode boot: automatic launch disabled managed=${mode.managedLock()}")
                }
                val runtime = context.applicationContext as AlarmRuntime
                runtime.isolation.reconcile()
                if (!mode.managesHome()) return@launch
                val deployment = ManagedDeployment(context)
                if (mode.current() == DesktopMode.ANDROID) {
                    deployment.reconcileHome()
                    return@launch
                }
                val restored = deployment.recoverManagedClock()
                if (restored is DesktopResult.Rejected) {
                    Log.w("NaozhoMode", "Home recovery event=${intent.action} rejected=${restored.message}")
                    return@launch
                }
                val desktop = ManagedDesktop(context)
                val keyguard = context.getSystemService(KeyguardManager::class.java)
                val canShow = !keyguard.isKeyguardLocked || (context.isDevelopmentBuild && !keyguard.isDeviceSecure)
                val confirmed = desktop.receiptMatches(desktop.clockHome) && desktop.isHomeConfirmed(desktop.clockHome)
                val launchHome = canShow && confirmed && mode.current() == DesktopMode.CLOCK &&
                    ((mode.managedLock() && desktop.dedicatedReady) || mode.developmentRehearsal())
                Log.i("NaozhoMode", "Home recovery event=${intent.action} boot=${bootCount(context)} confirmed=$confirmed " +
                    "keyguardLocked=${keyguard.isKeyguardLocked} launchHome=$launchHome state=${desktop.stateName()}")
                if (launchHome) {
                    // Use the system's HOME resolution, including on the recovery launch.
                    val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { context.startActivity(home) }
                    catch (error: RuntimeException) { Log.w("NaozhoMode", "Clock home recovery launch rejected", error) }
                }
            } finally {
                pending.finish()
            }
        }
    }
}
