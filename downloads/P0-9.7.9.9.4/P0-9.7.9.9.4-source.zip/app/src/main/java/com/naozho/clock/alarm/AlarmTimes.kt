package com.naozho.clock.alarm

import com.naozho.clock.data.AlarmPlan
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

internal object AlarmTimes {
    const val LATE_WINDOW = 10 * 60_000L
    const val RING_LIMIT = 5 * 60_000L

    fun localDay(at: Long, zone: ZoneId): Long =
        Instant.ofEpochMilli(at).atZone(zone).toLocalDate().toEpochDay()

    fun onceDay(plan: AlarmPlan, now: Long, zone: ZoneId): Long {
        val today = LocalDate.ofEpochDay(localDay(now, zone))
        return (if (at(plan, today, zone) > now) today else today.plusDays(1)).toEpochDay()
    }

    fun next(plan: AlarmPlan, now: Long, zone: ZoneId): Long? {
        if (!plan.enabled) return null
        if (plan.weekdays == 0) {
            return plan.onceDay?.let { at(plan, LocalDate.ofEpochDay(it), zone) }
                ?.takeIf { it > now }
        }
        val today = LocalDate.ofEpochDay(localDay(now, zone))
        return (0L..7L).firstNotNullOfOrNull { offset ->
            val day = today.plusDays(offset)
            val selected = plan.weekdays and (1 shl (day.dayOfWeek.value - 1)) != 0
            if (selected && day.toEpochDay() != plan.lastDay) {
                at(plan, day, zone).takeIf { it > now }
            } else null
        }
    }

    fun onceAt(plan: AlarmPlan, zone: ZoneId): Long? =
        plan.onceDay?.let { at(plan, LocalDate.ofEpochDay(it), zone) }

    fun recent(plan: AlarmPlan, now: Long, zone: ZoneId): Long? {
        if (!plan.enabled) return null
        if (plan.weekdays == 0) return onceAt(plan, zone)?.takeIf { now - it in 0..LATE_WINDOW }
        val today = LocalDate.ofEpochDay(localDay(now, zone))
        return listOf(today, today.minusDays(1)).firstNotNullOfOrNull { day ->
            val selected = plan.weekdays and (1 shl (day.dayOfWeek.value - 1)) != 0
            if (selected && day.toEpochDay() != plan.lastDay) {
                at(plan, day, zone).takeIf { now - it in 0..LATE_WINDOW }
            } else null
        }
    }

    private fun at(plan: AlarmPlan, day: LocalDate, zone: ZoneId): Long =
        day.atTime(plan.hour, plan.minute).atZone(zone).toInstant().toEpochMilli()
}

internal enum class AlarmSlot { REGULAR, SNOOZE }

internal data class AlarmOccurrence(val id: String, val slot: AlarmSlot, val at: Long)
