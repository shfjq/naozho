package com.naozho.clock.weather

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Looper
import android.os.SystemClock
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Result of one automatic location attempt. */
internal sealed interface CityResult {
    data class Resolved(val location: WeatherLocation, val resolvedAt: Long) : CityResult
    data class NoCity(val location: WeatherLocation, val resolvedAt: Long) : CityResult
    data object PermissionMissing : CityResult
    data object ServiceDisabled : CityResult
    data object NoFix : CityResult
}

/**
 * Resolves a device location into a displayable city. Network lookup is a foreground fallback.
 *
 * Coarse permission is enough: the weather request only needs a city-sized fix. The most recent
 * known fix from any enabled provider is preferred; a single fresh fix is requested only when the
 * cached one is missing or stale. Reverse geocoding uses the platform [Geocoder].
 */
internal class CityLocator(
    private val context: Context,
    private val reverse: CityReverseGeocoder = CityReverseGeocoder(
        context.getSharedPreferences("clock_city_cache", Context.MODE_PRIVATE),
    ),
    private val platformGeocoder: (Locale) -> Geocoder = { Geocoder(context, it) },
) {

    private val manager: LocationManager? =
        context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private val evidence = LocationEvidence(context)

    fun hasPermission(): Boolean =
        context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun serviceEnabled(): Boolean = runCatching {
        val m = manager ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) m.isLocationEnabled
        else enabledProviders().any { it != LocationManager.PASSIVE_PROVIDER }
    }.getOrDefault(false)

    /** Providers that are currently enabled, most useful first. */
    private fun enabledProviders(): List<String> {
        val m = manager ?: return emptyList()
        val order = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        return order.filter { provider ->
            runCatching { m.allProviders.contains(provider) && m.isProviderEnabled(provider) }.getOrDefault(false)
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun resolve(maxAgeMs: Long = STALE_AFTER_MS): CityResult {
        if (!hasPermission()) { evidence.fail("permission_missing"); return CityResult.PermissionMissing }
        val m = manager ?: return CityResult.ServiceDisabled
        if (!serviceEnabled()) { evidence.fail("location_service_disabled"); return CityResult.ServiceDisabled }
        val providers = enabledProviders()
        if (providers.isEmpty()) return CityResult.ServiceDisabled

        val fixes = providers.mapNotNull { provider ->
            runCatching { m.getLastKnownLocation(provider) }.getOrNull()
        }
        val cached = newestWeatherFix(fixes, SystemClock.elapsedRealtimeNanos(), maxAgeMs)
        evidence.fail(fixes.firstNotNullOfOrNull {
            locationFailure(it, SystemClock.elapsedRealtimeNanos(), maxAgeMs)
        } ?: "awaiting_location")
        var liveFix = if (cached == null) freshFix(m, providers) else null
        var fix = liveFix ?: cached ?: run { evidence.fail("no_acceptable_location"); return CityResult.NoFix }
        if (!validCoordinates(fix)) return CityResult.NoFix
        if (!hasPermission()) { evidence.fail("permission_missing"); return CityResult.PermissionMissing }
        val locale = Locale.getDefault()
        var label = labelFor(fix, locale) ?: reverse.city(fix.latitude, fix.longitude, locale, allowNetwork = false)
        // The free client endpoint is limited to current coordinates from this device.
        // Use a new current-location request when the initial fix came from the local cache.
        if (label == null) {
            if (liveFix == null) liveFix = freshFix(m, providers)
            if (!hasPermission()) { evidence.fail("permission_missing"); return CityResult.PermissionMissing }
            if (liveFix != null && validCoordinates(liveFix)) {
                fix = liveFix
                label = reverse.city(fix.latitude, fix.longitude, locale,
                    allowNetwork = newestWeatherFix(listOf(fix), SystemClock.elapsedRealtimeNanos(), LIVE_FIX_MAX_AGE_MS) != null)
            }
        }
        val resolvedAt = System.currentTimeMillis()
        val location = WeatherLocation(label.orEmpty(), fix.latitude, fix.longitude)
        if (!hasPermission()) { evidence.fail("permission_missing"); return CityResult.PermissionMissing }
        if (!evidence.save(fix, location, resolvedAt)) return CityResult.NoFix
        return if (label == null) CityResult.NoCity(location, resolvedAt)
            else CityResult.Resolved(location, resolvedAt)
    }

    private fun validCoordinates(fix: Location): Boolean =
        fix.latitude in -90.0..90.0 && fix.longitude in -180.0..180.0

    @SuppressLint("MissingPermission")
    private suspend fun freshFix(manager: LocationManager, providers: List<String>): Location? =
        withTimeoutOrNull(FIX_TIMEOUT_MS) {
            for ((index, provider) in providers.withIndex()) {
                // Give later providers a chance within the same 12-second budget.
                val location = withTimeoutOrNull(FIX_TIMEOUT_MS / (providers.size - index)) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        awaitSingleFix(manager, provider)
                    } else {
                        awaitLegacySingleFix(manager, provider)
                    }
                }
                if (location != null) {
                    val failure = locationFailure(location, SystemClock.elapsedRealtimeNanos(), maxAgeMs = 120_000L)
                    if (failure == null) return@withTimeoutOrNull location
                    evidence.fail(failure)
                }
            }
            null
        }

    @SuppressLint("MissingPermission")
    private suspend fun awaitSingleFix(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { continuation ->
            val signal = CancellationSignal()
            val completed = AtomicBoolean()
            fun complete(location: Location?) {
                if (completed.compareAndSet(false, true)) continuation.resume(location)
            }
            runCatching {
                manager.getCurrentLocation(provider, signal, { it.run() }, ::complete)
            }.onFailure { complete(null) }
            continuation.invokeOnCancellation { runCatching { signal.cancel() } }
        }

    @SuppressLint("MissingPermission")
    private suspend fun awaitLegacySingleFix(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { continuation ->
            val completed = AtomicBoolean()
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (completed.compareAndSet(false, true)) continuation.resume(location)
                }

                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit

                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
            }
            val ok = runCatching {
                manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
                true
            }.getOrDefault(false)
            if (!ok && completed.compareAndSet(false, true)) continuation.resume(null)
            continuation.invokeOnCancellation { runCatching { manager.removeUpdates(listener) } }
        }

    private suspend fun labelFor(location: Location, locale: Locale): String? {
        if (!runCatching { Geocoder.isPresent() }.getOrDefault(false)) return null
        val geocoder = runCatching { platformGeocoder(locale) }.getOrNull() ?: return null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return withTimeoutOrNull(PLATFORM_GEOCODE_TIMEOUT_MS) {
                suspendCancellableCoroutine { continuation ->
                    val completed = AtomicBoolean()
                    fun complete(label: String?) {
                        if (completed.compareAndSet(false, true)) continuation.resume(label)
                    }
                    runCatching {
                        geocoder.getFromLocation(location.latitude, location.longitude, 1,
                            object : Geocoder.GeocodeListener {
                                override fun onGeocode(addresses: List<Address>) {
                                    complete(addresses.firstNotNullOfOrNull(::weatherCity))
                                }

                                override fun onError(errorMessage: String?) {
                                    complete(null)
                                }
                            })
                    }.onFailure { complete(null) }
                }
            }
        }
        return withContext(Dispatchers.IO) {
            @Suppress("DEPRECATION")
            runCatching {
                geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    ?.firstNotNullOfOrNull(::weatherCity)
            }.getOrNull()
        }
    }

    companion object {
        /** A fix older than this is treated as missing and one fresh fix is requested. */
        const val STALE_AFTER_MS = 2 * 60 * 1000L
        const val FIX_TIMEOUT_MS = 12_000L
        private const val PLATFORM_GEOCODE_TIMEOUT_MS = 3_000L
        private const val LIVE_FIX_MAX_AGE_MS = 10_000L
    }
}

internal fun newestWeatherFix(fixes: List<Location>, nowNanos: Long, maxAgeMs: Long): Location? {
    return fixes.filter { locationFailure(it, nowNanos, maxAgeMs) == null }
        .maxByOrNull { it.elapsedRealtimeNanos }
}

internal fun weatherCity(address: Address): String? =
    sequenceOf(address.locality, address.subAdminArea, address.subLocality, address.adminArea)
        .mapNotNull { it?.let(::cityName) }
        .firstOrNull()
