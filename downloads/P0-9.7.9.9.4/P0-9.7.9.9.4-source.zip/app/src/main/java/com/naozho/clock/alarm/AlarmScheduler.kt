package com.naozho.clock.alarm

internal interface AlarmScheduler {
    fun canSchedule(): Boolean
    fun schedule(occurrence: AlarmOccurrence, triggerAt: Long): Boolean
    fun cancel(occurrence: AlarmOccurrence)
}
