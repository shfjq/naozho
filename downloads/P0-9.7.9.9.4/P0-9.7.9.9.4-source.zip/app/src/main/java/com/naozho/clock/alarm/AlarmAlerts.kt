package com.naozho.clock.alarm

import android.Manifest
import android.app.Notification
import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.naozho.clock.R
import com.naozho.clock.data.AlarmPlan

internal class AlarmAlerts(private val context: Context) {
    private val manager = context.getSystemService(NotificationManager::class.java)
    private var legacyDisplayWake: PowerManager.WakeLock? = null

    fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        manager.createNotificationChannel(
            NotificationChannel(RING_CHANNEL, "闹铃提醒", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "锁屏或后台显示正在响铃的闹铃"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            },
        )
        manager.createNotificationChannel(
            NotificationChannel(SERVICE_CHANNEL, "闹铃播放", NotificationManager.IMPORTANCE_LOW).apply {
                setSound(null, null)
            },
        )
    }

    fun canNotify(): Boolean {
        createChannels()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(context).areNotificationsEnabled() &&
            (Build.VERSION.SDK_INT < 26 ||
                (manager.getNotificationChannel(RING_CHANNEL)?.importance
                    ?: NotificationManager.IMPORTANCE_NONE) > NotificationManager.IMPORTANCE_NONE)
    }

    fun canFullScreen(): Boolean = Build.VERSION.SDK_INT < 34 || manager.canUseFullScreenIntent()

    fun foreground(): Notification = base(SERVICE_CHANNEL)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentTitle("闹铃播放")
        .setContentText("点按打开响铃界面")
        .setContentIntent(openRing())
        .build()

    fun show(plan: AlarmPlan) {
        val alarm = base(RING_CHANNEL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setContentTitle(plan.label.ifBlank { "闹铃" })
            .setContentText("正在响铃")
            .setContentIntent(openRing())
            .addAction(0, "贪睡 ${plan.snoozeMinutes} 分钟", action(plan, "snoozed"))
            .addAction(0, "停止", action(plan, "stopped"))
        if (canFullScreen()) alarm.setFullScreenIntent(openRing(), true)
        manager.notify(RING_NOTIFICATION_ID, alarm.build())
        if (Build.VERSION.SDK_INT < 29) showOnLegacyLockScreen()
    }

    @Suppress("DEPRECATION") // Pre-29 devices may leave the screen off despite setTurnScreenOn.
    private fun showOnLegacyLockScreen() {
        val power = context.getSystemService(PowerManager::class.java)
        val locked = context.getSystemService(KeyguardManager::class.java).isKeyguardLocked
        if (!power.isInteractive || locked) {
            // Android 9 and earlier allow this launch even when System UI is too
            // busy to dispatch the full-screen notification.
            try {
                if (!power.isInteractive) {
                    releaseLegacyDisplayWake()
                    legacyDisplayWake = power.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                        "naozho:legacy-alarm-display",
                    ).also { it.acquire(15_000L) }
                }
                context.startActivity(ringIntent())
            } catch (error: RuntimeException) {
                Log.w("NaozhoAlarm", "Legacy lock-screen launch unavailable", error)
            }
        }
    }

    fun clear() {
        manager.cancel(RING_NOTIFICATION_ID)
        releaseLegacyDisplayWake()
    }

    private fun releaseLegacyDisplayWake() {
        legacyDisplayWake?.let { if (it.isHeld) it.release() }
        legacyDisplayWake = null
    }

    private fun base(channel: String) = NotificationCompat.Builder(context, channel)
        .setSmallIcon(R.drawable.ic_alarm_notification)
        .setCategory(NotificationCompat.CATEGORY_ALARM)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .setOngoing(true)
        .setSilent(channel == SERVICE_CHANNEL)

    fun ringIntent(inCurrentTask: Boolean = false) = Intent(context, AlarmRingActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        .apply { if (!inCurrentTask) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    private fun openRing() = PendingIntent.getActivity(
        context, 0, ringIntent(),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun action(plan: AlarmPlan, action: String) = PendingIntent.getService(
        context, 0,
        Intent(context, AlarmRingService::class.java).setAction(action)
            .setData(Uri.Builder().scheme("naozho").authority("ring")
                .appendPath(plan.id).appendPath(plan.activeAt.toString()).build()),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    companion object {
        const val RING_CHANNEL = "alarms.ringing"
        private const val SERVICE_CHANNEL = "alarms.playback"
        const val SERVICE_NOTIFICATION_ID = 41
        private const val RING_NOTIFICATION_ID = 42
    }
}
