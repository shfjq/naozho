package com.naozho.clock.weather

import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import org.json.JSONObject

/** Private app storage. Raw coordinates are never written to logcat. */
internal class LocationEvidence(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("clock_location_evidence", Context.MODE_PRIVATE)

    fun save(fix: Location, location: WeatherLocation, resolvedAt: Long): Boolean {
        val failure = locationFailure(fix, SystemClock.elapsedRealtimeNanos(), CityLocator.STALE_AFTER_MS)
        if (failure != null) { fail(failure); return false }
        val row = JSONObject()
            .put("key", location.key).put("city", location.label)
            .put("latitude", fix.latitude).put("longitude", fix.longitude)
            .put("provider", fix.provider).put("accuracy", fix.accuracy.toDouble())
            .put("locationTime", fix.time).put("elapsedNanos", fix.elapsedRealtimeNanos)
            .put("bootCount", Settings.Global.getInt(app.contentResolver, Settings.Global.BOOT_COUNT, -1))
            .put("observedAt", System.currentTimeMillis()).put("cityResolvedAt", resolvedAt)
            .put("coarseGranted", app.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED)
            .put("fineGranted", app.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED)
            .put("mock", false).put("status", "accepted_os_location")
        return prefs.edit().putString("last", row.toString()).putString("status", "accepted_os_location").commit()
    }

    fun fail(reason: String) {
        prefs.edit().putString("status", reason).apply()
    }

    fun status(location: WeatherLocation?): String {
        val raw = prefs.getString("last", null) ?: return "unverified_saved_location"
        val row = runCatching { JSONObject(raw) }.getOrNull() ?: return "unverified_saved_location"
        if (row.optString("key") != location?.key || row.optBoolean("mock", true))
            return "unverified_saved_location"
        val boot = Settings.Global.getInt(app.contentResolver, Settings.Global.BOOT_COUNT, -1)
        if (boot < 0 || row.optInt("bootCount", -2) != boot)
            return "previous_boot_location"
        val age = SystemClock.elapsedRealtimeNanos() - row.optLong("elapsedNanos", -1L)
        if (age !in 0..CityLocator.STALE_AFTER_MS * 1_000_000L) return "stale_saved_location"
        return prefs.getString("status", null) ?: "unverified_saved_location"
    }
}

internal fun locationFailure(fix: Location, nowNanos: Long, maxAgeMs: Long): String? = when {
    (if (Build.VERSION.SDK_INT >= 31) fix.isMock else @Suppress("DEPRECATION") fix.isFromMockProvider) ->
        "mock_location_rejected"
    fix.provider !in setOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER) ->
        "test_or_unknown_provider"
    fix.latitude !in -90.0..90.0 || fix.longitude !in -180.0..180.0 -> "invalid_coordinates"
    !fix.hasAccuracy() || !fix.accuracy.isFinite() || fix.accuracy <= 0f || fix.accuracy > 50_000f ->
        "accuracy_unusable"
    fix.time <= 0L -> "missing_location_time"
    fix.elapsedRealtimeNanos <= 0L || fix.elapsedRealtimeNanos > nowNanos -> "invalid_location_age"
    nowNanos - fix.elapsedRealtimeNanos > maxAgeMs * 1_000_000L -> "stale_location"
    else -> null
}
