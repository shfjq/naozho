package com.naozho.clock.mode

import android.annotation.TargetApi
import android.view.View
import android.view.ViewTreeObserver

/** Each pre-draw gets its own witness. A cancelled traversal cannot claim a later clock draw. */
internal class ClockTraversal {
    private var current: Any? = null
    private var painted = false

    fun next(): Any? {
        if (painted) return null
        return Any().also { current = it }
    }

    fun markHardwareDraw(): Boolean {
        if (current == null) return false
        painted = true
        return true
    }

    fun isPainted(witness: Any) = painted && current === witness
}

/** Installed before traversal. CPDAY10 ViewRootImpl captures frame-commit callbacks before draw(). */
@TargetApi(29)
internal class ClockFrameMonitor(private val decor: View, private val submitted: () -> Unit) :
    ViewTreeObserver.OnPreDrawListener {
    private val traversal = ClockTraversal()
    private var callback: Runnable? = null
    private var closed = false

    fun start() = decor.viewTreeObserver.addOnPreDrawListener(this)

    override fun onPreDraw(): Boolean {
        if (closed || !decor.isAttachedToWindow || !decor.isHardwareAccelerated) return true
        val witness = traversal.next() ?: return true
        val observer = decor.viewTreeObserver
        callback?.let(observer::unregisterFrameCommitCallback)
        callback = Runnable {
            if (!closed && traversal.isPainted(witness)) {
                close()
                submitted()
            }
        }.also(observer::registerFrameCommitCallback)
        return true
    }

    fun markHardwareDraw(): Boolean = !closed && traversal.markHardwareDraw()

    fun close() {
        if (closed) return
        closed = true
        val observer = decor.viewTreeObserver
        if (observer.isAlive) {
            observer.removeOnPreDrawListener(this)
            callback?.let(observer::unregisterFrameCommitCallback)
        }
        callback = null
    }
}
