package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.PowerManager
import android.os.SystemClock
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.lifecycle.Lifecycle
import com.naozho.clock.MainActivity
import com.naozho.clock.display.ClockDeviceAdmin
import java.io.File
import java.util.UUID
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.After
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.android.controller.ActivityController
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowLog

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w360dp-h360dp-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class RetainedClockWindowTest {
    @get:Rule val compose = createEmptyComposeRule()
    private lateinit var controller: ActivityController<MainActivity>
    private val app: Context get() = RuntimeEnvironment.getApplication()
    private val mode get() = ModeState(app)
    private val tasks get() = app.getSystemService(ActivityManager::class.java)

    @After fun closeActivity() {
        if (!::controller.isInitialized) return
        val activity = controller.get()
        if (activity.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) controller.pause()
        if (activity.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) controller.stop()
        if (!activity.isDestroyed) controller.destroy()
    }

    private fun parkClock(): Int {
        prepareOwnerAndHome(app)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(true)
        app.getSharedPreferences("permission_setup", 0).edit().putBoolean("completed", true).commit()
        assertEquals(DesktopResult.Applied, runBlocking { ManagedDeployment(app).lockCurrentClock() })
        controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        controller.windowFocusChanged(true)
        compose.waitUntil(10_000) { compose.waitForIdle(); tasks.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_LOCKED }
        compose.onNodeWithContentDescription("显示设置").performClick()
        val version = compose.onNodeWithText("版本 ", substring = true).performScrollTo()
        repeat(7) { version.performClick() }
        val node = compose.onNodeWithContentDescription("显示设置").fetchSemanticsNode().id
        compose.onNodeWithText("确认退出").performClick()
        compose.waitUntil(10_000) { compose.waitForIdle(); shadowOf(activity).peekNextStartedActivity()?.component == mode.selectedHome() }
        compose.onNodeWithContentDescription("显示设置").assertDoesNotExist()
        compose.onNodeWithText("版本 ", substring = true).assertDoesNotExist()
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").none { "ACTIVITY_READY_AT" in it.msg })
        return node
    }

    private fun newTicket(): WakeTicket {
        val now = SystemClock.elapsedRealtime()
        val ticket = WakeTicket(1, "beeb1d4e-0f34-4dfa-b066-bc40ce6a67e2", now - 100, now,
            now + WakeTicket.LIFETIME, 1, UUID.randomUUID().toString(), 0)
        File(app.filesDir, "wake-epoch.proof").writeText(ticket.receipt)
        assertTrue(ClockPowerReturn.accept(app, ticket.entry(app), PowerDelivery.RESERVE))
        return ticket
    }

    private fun drawCurrentFrame(activity: MainActivity) {
        val view = activity.window.decorView
        val bitmap = android.graphics.Bitmap.createBitmap(view.width, view.height, android.graphics.Bitmap.Config.ARGB_8888)
        try {
            view.draw(android.graphics.Canvas(bitmap))
        } finally {
            bitmap.recycle()
        }
    }

    @Test fun sameActivityReusesInertTreeButRequiresFreshDrawAndForegroundForLock() {
        val originalNode = parkClock()
        controller.windowFocusChanged(false).pause().stop()
        val ticket = newTicket()
        controller.restart().start().newIntent(ticket.entry(app))
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").any {
            "ACTIVITY_START_AT" in it.msg && "entry=on_new_intent retained_clock=true" in it.msg
        })
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").none { "ACTIVITY_READY_AT" in it.msg })
        controller.resume().windowFocusChanged(true)
        compose.waitForIdle()
        drawCurrentFrame(controller.get())
        compose.waitUntil(10_000) { compose.waitForIdle(); tasks.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_LOCKED }
        assertEquals(originalNode, compose.onNodeWithContentDescription("显示设置").assertIsDisplayed().fetchSemanticsNode().id)
        assertEquals(ticket.id, File(app.filesDir, "wake-epoch.locked").readText())
        val policy = app.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(app, ClockDeviceAdmin::class.java)
        assertEquals(80, policy.getLockTaskFeatures(admin))
        assertArrayEquals(arrayOf(app.packageName), policy.getLockTaskPackages(admin))
    }

    @Test fun stoppedHotEntryCannotLockAndMaintenanceRevokesItsTicket() {
        parkClock()
        controller.windowFocusChanged(false).pause().stop()
        val ticket = newTicket()
        controller.restart().start().newIntent(ticket.entry(app))
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID, false))
        controller.resume().windowFocusChanged(true)
        compose.waitForIdle()
        drawCurrentFrame(controller.get())
        compose.waitForIdle()
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertFalse(File(app.filesDir, "wake-epoch.locked").exists())
    }
}
