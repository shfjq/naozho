package com.naozho.clock.tools

import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.os.Process
import android.os.UserHandle
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class HomePolicyReaderTest {
    private val clock = ComponentName("com.naozho.clock", "com.naozho.clock.MainActivity")
    private val stock = ComponentName("com.droiclaw.launcher3", "com.freeme.launcher.FreemeLauncher")
    private val user = Process.myUserHandle()
    private val home = Key(IntentFilter(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_HOME)
        addCategory(Intent.CATEGORY_DEFAULT)
    })
    private val other = Key(IntentFilter(Intent.ACTION_VIEW))
    private val owner = Admin(clock.packageName, user)
    private val thirdParty = Admin("other.owner", user)

    class Key(val intentFilter: IntentFilter, val identifier: String = "persistentPreferredActivity")
    class Admin(val packageName: String, val userHandle: UserHandle) {
        val componentName = ComponentName(packageName, "$packageName.display.ClockDeviceAdmin")
        fun getAuthority(): Any = Class.forName("android.app.admin.DpcAuthority").getField("DPC_AUTHORITY").get(null)!!
    }
    class State(val policiesSetByAdmins: Map<Admin, ComponentName>, val currentResolvedPolicy: ComponentName)

    private fun read(vararg rows: Pair<Key, State>) = HomePolicyReader.previousFor(mapOf(*rows), stock, clock, user)

    @Test fun recognizesEmptyOrSingleHomeAndPreservesUnrelatedAdminAndPackages() {
        assertNull(read())
        val another = ComponentName("another", "another.Main")
        for (selected in listOf(clock, stock)) {
            val rule = home to State(mapOf(owner to selected), selected)
            assertEquals(selected, read(rule, other to State(mapOf(owner to another), another)))
            assertEquals(selected, read(rule, other to State(mapOf(thirdParty to stock), stock)))
        }
    }

    @Test fun rejectsExtraPreferenceForTargetPackageOtherAdminConflictAndUnexpectedHome() {
        val rule = home to State(mapOf(owner to stock), stock)
        for (extra in listOf(stock, clock)) {
            assertThrows(IllegalStateException::class.java) { read(rule, other to State(mapOf(owner to extra), extra)) }
        }
        assertThrows(IllegalStateException::class.java) { read(home to State(mapOf(owner to clock, thirdParty to stock), stock)) }
        assertThrows(IllegalStateException::class.java) { read(home to State(mapOf(owner to stock), clock)) }
        val unexpected = ComponentName(clock.packageName, clock.packageName + ".Another")
        assertThrows(IllegalStateException::class.java) { read(home to State(mapOf(owner to unexpected), unexpected)) }
    }
}
