package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.Application
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewConfiguration
import com.naozho.clock.MainActivity
import com.naozho.clock.alarm.AlarmRuntime
import com.naozho.clock.display.ClockDeviceAdmin
import com.naozho.station.StationPowerShortcut
import java.time.Duration
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = AlarmRuntime::class)
class ConfirmedPowerReturnTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val mode get() = ModeState(app)
    private val dpm get() = app.getSystemService(DevicePolicyManager::class.java)
    private val tasks get() = app.getSystemService(ActivityManager::class.java)
    private val admin get() = ComponentName(app, ClockDeviceAdmin::class.java)

    @Before fun armAndroid() = runBlocking<Unit> {
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, 9)
        shadowOf(app.getSystemService(UserManager::class.java)).setUserUnlocked(true)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(true)
        assertTrue(shadowOf(dpm).setDeviceOwner(admin))
        assertEquals(DesktopResult.Applied, ManagedDesktop(app).allowClock())
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        advance(5)
    }

    private fun advance(ms: Long) = shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(ms))
    private fun request(): Intent {
        val first = SystemClock.elapsedRealtime()
        advance(120)
        return Intent(ClockPowerReturn.ACTION).setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java))
            .putExtra(EXTRA_BOOT_COUNT, 9).putExtra(ClockPowerReturn.FIRST, first)
            .putExtra(ClockPowerReturn.RELEASE, SystemClock.elapsedRealtime())
    }
    private fun deliver(intent: Intent) = ConfirmedPowerReceiver().onReceive(app, intent)

    private fun wake(): WakeTicket {
        val dark = SystemClock.elapsedRealtime()
        advance(250)
        val event = SystemClock.elapsedRealtime()
        return WakeTicket(9, "beeb1d4e-0f34-4dfa-b066-bc40ce6a67e2", dark, event,
            event + WakeTicket.LIFETIME, 1, java.util.UUID.randomUUID().toString(), 0)
    }

    private fun commit(t: WakeTicket): Intent = t.entry(app).setAction(WakeTicket.COMMIT)
        .setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java)).setIdentifier(t.id + ".commit")
    private fun attest(t: WakeTicket) = java.io.File(app.filesDir, "wake-epoch.proof").writeText(t.receipt)

    /** Test counterpart of Android's cmd activity Intent argument parser. Exercise the
     * production root command, and require the actual persisted COMMIT reservation. */
    private fun rootEntry(t: WakeTicket): Intent {
        assertEquals(t.receipt, app.getSharedPreferences("desktop_mode", 0).getString("wake_pending", null))
        assertNull(shadowOf(app).nextStartedActivity)
        val cmd = com.naozho.power.WakeWire(t.boot, t.bootId, t.dark, t.sequence, t.event, t.sender, t.id)
            .startCommand().toList()
        assertEquals(listOf("/system/bin/cmd", "activity", "start-activity", "--user", "0", "-a"), cmd.take(6))
        assertEquals("-n", cmd[7])
        assertEquals("-f", cmd[9])
        return Intent(cmd[6]).apply {
            component = ComponentName.unflattenFromString(cmd[8])
            flags = java.lang.Integer.decode(cmd[10])
            for ((kind,key,value) in cmd.drop(11).chunked(3)) when (kind) {
                "--ei" -> putExtra(key, value.toInt())
                "--el" -> putExtra(key, value.toLong())
                "--es" -> putExtra(key, value)
                else -> error("unauthorized ATM argument")
            }
            assertEquals(t, WakeTicket.read(this))
        }
    }

    @Test fun submittedFocusedFrameReplacesOnlyTheExactAttestedWakeReceipt() {
        val ticket = wake()
        val handoff = ClockFrameHandoff(ticket)
        val file = java.io.File(app.filesDir, "wake-epoch.frame")
        val earlier = ticket.copy(sequence = 2, id = java.util.UUID.randomUUID().toString())
        file.writeText(earlier.receipt)
        attest(ticket)
        // App-side state cannot turn a local draw, an early lock or a stale root
        // envelope into this request's on-disk acknowledgment.
        handoff.lockConfirmed()
        assertFalse(handoff.takeHandoff(true))
        assertFalse(handoff.publishFrameReceipt(app))
        assertTrue(handoff.armForClockDraw(true))
        assertTrue(handoff.frameSubmitted())
        assertFalse(handoff.takeHandoff(false))
        assertFalse(handoff.publishFrameReceipt(app))
        assertTrue(handoff.takeHandoff(true))
        attest(earlier)
        assertFalse(handoff.publishFrameReceipt(app))
        assertEquals(earlier.receipt, file.readText())
        attest(ticket)
        assertTrue(handoff.publishFrameReceipt(app))
        val wire = com.naozho.power.WakeWire(ticket.boot, ticket.bootId, ticket.dark,
            ticket.sequence, ticket.event, ticket.sender, ticket.id)
        assertArrayEquals(wire.receipt().toByteArray(Charsets.US_ASCII), file.readBytes())
        assertFalse(java.io.File(app.filesDir, "wake-epoch.frame.tmp").exists())
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, ticket.boot + 1)
        assertFalse(handoff.publishFrameReceipt(app))
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, ticket.boot)
        advance(WakeTicket.LIFETIME + 1)
        assertFalse(handoff.publishFrameReceipt(app))
    }

    @Test fun protectedClockEntryUsesOnlyClockTaskAndLeavesCallerTaskIntact() {
        val t = wake()
        attest(t)
        deliver(commit(t))
        val entry = rootEntry(t)
        val info = app.packageManager.getActivityInfo(requireNotNull(entry.component), 0)
        assertEquals(MainActivity::class.java.name, info.targetActivity)
        assertEquals(app.packageName, info.taskAffinity)
        assertEquals(android.content.pm.ActivityInfo.LAUNCH_SINGLE_TASK, info.launchMode)
        assertEquals(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION, entry.flags)
        assertFalse(info.exported)
        assertNull(entry.selector)
        assertNull(entry.data)
    }

    @Test fun darkWarmupUsesExistingProcessAndCannotReserveReturnOrOpenUi() = runBlocking<Unit> {
        val runtime = app as AlarmRuntime
        val dark = SystemClock.elapsedRealtime()
        val display = app.getSystemService(android.hardware.display.DisplayManager::class.java).getDisplay(0)
        assertFalse(ClockPrewarm.prepare(runtime,9,dark))
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(false)
        shadowOf(display).setState(android.view.Display.STATE_DOZE)
        assertFalse(ClockPrewarm.prepare(runtime,9,dark))
        shadowOf(display).setState(android.view.Display.STATE_OFF)
        assertTrue(ClockPrewarm.prepare(runtime,9,dark))
        assertFalse(ClockPrewarm.prepare(runtime,9,dark))
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE,tasks.lockTaskModeState)
        assertFalse(app.getSharedPreferences("desktop_mode",0).contains("wake_pending"))
        advance(30)
        assertTrue(ClockPrewarm.prepare(runtime,9,SystemClock.elapsedRealtime()))
        mode.saveDeployment(false,DesktopMode.ANDROID)
        advance(1)
        assertFalse(ClockPrewarm.prepare(runtime,9,SystemClock.elapsedRealtime()))
    }

    private fun drawClock(activity: MainActivity) {
        val view = activity.window.decorView
        val spec = android.view.View.MeasureSpec.makeMeasureSpec(720, android.view.View.MeasureSpec.EXACTLY)
        advance(32)
        view.measure(spec,spec)
        view.layout(0,0,720,720)
        val bitmap = android.graphics.Bitmap.createBitmap(720,720,android.graphics.Bitmap.Config.ARGB_8888)
        view.draw(android.graphics.Canvas(bitmap))
        advance(32)
    }

    @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    @Test fun fullWakeStartsOnceAndReadsBackClockFocusAndExactPolicy() {
        val t = wake()
        val confirmation = commit(t)
        deliver(Intent(confirmation).setAction(WakeTicket.RETURN))
        assertNull(shadowOf(app).nextStartedActivity)
        deliver(confirmation)
        assertNull(shadowOf(app).nextStartedActivity)
        attest(t)
        deliver(confirmation)
        val entry = rootEntry(t)
        deliver(confirmation)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(DesktopMode.ANDROID, mode.current())
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).setup()
        ctrl.windowFocusChanged(true)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        drawClock(ctrl.get())
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(DesktopMode.CLOCK, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_LOCKED, tasks.lockTaskModeState)
        assertEquals(80, dpm.getLockTaskFeatures(admin))
        assertArrayEquals(arrayOf(app.packageName), dpm.getLockTaskPackages(admin))
        assertEquals(t.id, java.io.File(app.filesDir, "wake-epoch.locked").readText())
        // drawClock drives a bitmap canvas. Its real Compose draw and successful lock
        // cannot establish that Android's hardware renderer submitted a clock frame.
        val stages = org.robolectric.shadows.ShadowLog.getLogsForTag("NaozhoWakePerf")
            .map { it.msg }.filter { it.contains("request=${t.id}") }.map { it.split(' ')[1] }
        assertTrue("ACTIVITY_READY_AT" in stages)
        assertTrue("LOCKED_CONFIRMED_AT" in stages)
        assertFalse("CLOCK_FRAME_COMMITTED_AT" in stages)
        assertFalse("CLOCK_FRAME_ACK_AT" in stages)
        assertFalse(java.io.File(app.filesDir, "wake-epoch.frame").exists())
        assertFalse("CLOCK_PREVIEW_HANDOFF_AT" in stages)
        deliver(confirmation)
        assertNull(shadowOf(app).nextStartedActivity)
        ctrl.pause().stop().destroy()
    }

    @Test
    @Config(shadows = [AwaitLockReadback::class])
    @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    fun drawnAndFocusedClockHoldsTouchesUntilRealPolicyReadback() {
        val ticket = wake()
        attest(ticket)
        deliver(commit(ticket))
        val controller = Robolectric.buildActivity(MainActivity::class.java, rootEntry(ticket)).setup()
        val activity = controller.get()
        controller.windowFocusChanged(true)
        var taps = 0
        activity.addContentView(android.view.View(activity).apply {
            setOnTouchListener { _, event ->
                if (event.actionMasked == android.view.MotionEvent.ACTION_DOWN) taps++
                true
            }
        }, android.view.ViewGroup.LayoutParams(-1, -1))
        drawClock(activity)
        assertTrue((shadowOf(activity) as AwaitLockReadback).requested)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        assertFalse(java.io.File(app.filesDir, "wake-epoch.locked").exists())
        fun tap() {
            val down = SystemClock.uptimeMillis()
            for (action in listOf(android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_UP)) {
                val event = android.view.MotionEvent.obtain(down, down, action, 100f, 100f, 0)
                try { activity.dispatchTouchEvent(event) } finally { event.recycle() }
            }
        }
        tap()
        assertEquals(0, taps)
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_LOCKED)
        advance(150)
        assertEquals(ticket.id, java.io.File(app.filesDir, "wake-epoch.locked").readText())
        tap()
        assertEquals(1, taps)
        controller.pause().stop().destroy()
    }

    @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    @Test fun maintenanceAfterFocusBeforeFirstClockDrawCannotLock() {
        val t = wake(); attest(t); deliver(commit(t))
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, rootEntry(t)).setup()
        ctrl.windowFocusChanged(true)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE,tasks.lockTaskModeState)
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID, false))
        drawClock(ctrl.get())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE,tasks.lockTaskModeState)
        assertEquals(DesktopMode.ANDROID,mode.current())
        assertFalse(java.io.File(app.filesDir,"wake-epoch.locked").exists())
        ctrl.pause().stop().destroy()
    }

    @Test fun previewDismissalCanOnlyCloseTheExactVisualGenerationAndNeverLaunch() {
        // Simulate an existing host's widget opt-in, without attaching a test window.
        val enabled = java.io.File(app.createDeviceProtectedStorageContext().filesDir, "wake-preview-widget.present")
        enabled.createNewFile()
        try {
            val store = app.getSharedPreferences("home_visual_preview", 0)
            val modePrefs = app.getSharedPreferences("desktop_mode", 0)
            val before = modePrefs.all.toMap()
            val dark = SystemClock.elapsedRealtime() - 1
            fun message(boot: Int, value: Long, id: String) = Intent(ConfirmedPowerReceiver.DISMISS)
                .setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java)).setIdentifier(id)
                .putExtra(EXTRA_BOOT_COUNT, boot).putExtra("dark_elapsed", value)
            deliver(message(9, dark, "dismiss.9.invalid"))
            deliver(message(8, dark, "dismiss.8.$dark"))
            assertFalse(store.contains("closed_dark"))
            deliver(message(9, dark, "dismiss.9.$dark"))
            deliver(message(9, dark - 1, "dismiss.9." + (dark - 1)))
            assertEquals(dark, store.getLong("closed_dark", -1))
            assertEquals(9, store.getInt("closed_boot", -1))
            assertNull(shadowOf(app).nextStartedActivity)
            assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
            assertEquals(before, modePrefs.all)
        } finally { enabled.delete() }
    }

    @Test fun commitOnlyReservesAndCannotIndependentlyBringClockToFront() {
        val ticket = wake()
        fun timing() = org.robolectric.shadows.ShadowLog.getLogsForTag("NaozhoWakePerf")
            .map { it.msg }.filter { it.contains("request=" + ticket.id) }

        deliver(commit(ticket))
        assertTrue(timing().isEmpty())
        attest(ticket)
        deliver(commit(ticket))
        val logs = timing()
        assertEquals(listOf("COMMIT_RECEIVED_AT"), logs.map { it.split(' ')[1] })
        assertTrue(logs.first().substringBefore(' ').toLong() <= logs.last().substringBefore(' ').toLong())
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ticket.receipt, app.getSharedPreferences("desktop_mode", 0).getString("wake_pending", null))
        deliver(commit(ticket))
        assertEquals(logs, timing())
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun wakePauseBetweenReservationAndFocusSurvivesReenable() {
        val t = wake(); attest(t)
        assertTrue(ClockPowerReturn.accept(app, t.entry(app), PowerDelivery.RESERVE))
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        assertFalse(ClockPowerReturn.accept(app, t.entry(app), PowerDelivery.CONSUME))
        advance(1)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        assertFalse(ClockPowerReturn.accept(app, t.entry(app), PowerDelivery.RESERVE))
    }

    @Test fun wakeRejectsStaleWrongBootWrongSourceAndChangedReceipt() {
        val t = wake(); attest(t)
        for (intent in listOf(commit(t).setIdentifier("other"), commit(t).putExtra("source","SCREEN_ON"),
            commit(t).putExtra("boot_id","other"), commit(t).putExtra("sender_uid",10191),
            commit(t).putExtra(EXTRA_BOOT_COUNT,8), commit(t).putExtra("event_timestamp",t.event+1))) {
            deliver(intent)
            assertNull(shadowOf(app).nextStartedActivity)
            assertFalse(app.getSharedPreferences("desktop_mode", 0).contains("wake_pending"))
        }
        advance(WakeTicket.LIFETIME + 1)
        deliver(commit(t))
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun wakeRevocationStopsReservedHandoffAndNoReplayAfterExit() {
        val t = wake(); attest(t)
        assertTrue(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
        assertTrue(java.io.File(app.filesDir,"wake-epoch.proof").delete())
        assertFalse(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.CONSUME))
        attest(t)
        assertTrue(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.CONSUME))
        advance(1)
        mode.set(DesktopMode.ANDROID)
        assertFalse(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
        advance(1)
        val next = wake(); attest(next)
        assertTrue(ClockPowerReturn.accept(app,next.entry(app),PowerDelivery.RESERVE))
    }

    @Test fun clockProcessLossCanRecoverOnFreshWakeButPinnedOrAlreadyLockedCannot() {
        mode.set(DesktopMode.CLOCK)
        advance(2)
        val t = wake(); attest(t)
        for (state in listOf(ActivityManager.LOCK_TASK_MODE_LOCKED, ActivityManager.LOCK_TASK_MODE_PINNED)) {
            shadowOf(tasks).setLockTaskModeState(state)
            assertFalse(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
        }
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_NONE)
        assertTrue(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
    }

    @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    @Test fun productionRootProtocolReachesRealReceiverActivityAndLockReadback() {
        val t = wake()
        val wire = com.naozho.power.WakeWire(t.boot,t.bootId,t.dark,t.sequence,t.event,t.sender,t.id)
        fun envelope(verb: String) = Intent("com.naozho.clock.action.WAKE_EPOCH_" + verb).apply {
            component = ComponentName(app, ConfirmedPowerReceiver::class.java)
            identifier = wire.trace(verb)
            for ((kind,key,value) in wire.extras().asList().chunked(3)) {
                when(kind) {
                    "--ei" -> putExtra(key,value.toInt())
                    "--el" -> putExtra(key,value.toLong())
                    "--es" -> putExtra(key,value)
                    else -> error("unknown wire type")
                }
            }
        }
        val file = java.io.File(app.filesDir,"wake-epoch.proof")
        val proofRead = java.util.concurrent.atomic.AtomicBoolean()
        var checks = 0
        var deliveredEntry: Intent? = null
        val result = com.naozho.power.WakeDispatch.run(object : com.naozho.power.WakeDispatch.PipelinedPorts {
            override fun guard() {
                checks++
                assertEquals(DesktopMode.ANDROID,mode.current())
            }
            override fun dispatchFormal() {
                deliver(envelope("RETURN"))
                assertNull(shadowOf(app).nextStartedActivity)
            }
            override fun proveFormal(): Int {
                // The AMS record parser and its UID failure paths run in the module suite.
                assertTrue(proofRead.compareAndSet(false, true))
                return t.sender
            }
            override fun publishReceipt() {
                assertTrue(proofRead.get() && checks >= 2)
                file.writeText(wire.receipt())
            }
            override fun confirmOnce(): Int { deliver(envelope("COMMIT")); return 0 }
            override fun launchReservedClock() {
                assertNull(deliveredEntry)
                deliveredEntry = rootEntry(t)
            }
            override fun clockFocusedAndLocked(): Boolean {
                val controller = Robolectric.buildActivity(MainActivity::class.java, requireNotNull(deliveredEntry)).setup()
                controller.windowFocusChanged(true); drawClock(controller.get()); shadowOf(Looper.getMainLooper()).idle()
                val ok = tasks.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_LOCKED &&
                    dpm.getLockTaskFeatures(admin) == 80 && dpm.getLockTaskPackages(admin).toList() == listOf(app.packageName) &&
                    java.io.File(app.filesDir,"wake-epoch.locked").readText() == t.id
                controller.pause().stop().destroy()
                return ok
            }
            override fun clearReceipt() { file.delete() }
        },0)
        assertEquals("CLOCK_FOCUSED",result)
        assertFalse(file.exists())
    }

    @Test fun receiverRequiresSystemPermissionAndClockTargetIsPrivate() {
        val pm = app.packageManager
        val rx = pm.getReceiverInfo(ComponentName(app, ConfirmedPowerReceiver::class.java), 0)
        assertEquals("android.permission.STATUS_BAR_SERVICE", rx.permission)
        assertTrue(rx.exported)
        val entry = pm.getActivityInfo(ClockPowerReturn.target(app), 0)
        assertFalse(entry.exported)
        assertEquals(MainActivity::class.java.name, entry.targetActivity)
    }

    @Test fun adapterSendsOnlyAfterSecondReleaseThenActivityCommitsAndLocksOnFocus() {
        val adapter = StationPowerShortcut(app, Handler(Looper.getMainLooper())) { 4L }
        fun event(action: Int, down: Long) {
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), action, KeyEvent.KEYCODE_POWER, 0), true)
        }
        val first = SystemClock.uptimeMillis()
        event(KeyEvent.ACTION_DOWN, first)
        advance(100)
        event(KeyEvent.ACTION_UP, first)
        advance(89)
        val second = SystemClock.uptimeMillis()
        event(KeyEvent.ACTION_DOWN, second)
        advance(125)
        assertFalse(shadowOf(app).broadcastIntents.any { it.action == ClockPowerReturn.ACTION })
        event(KeyEvent.ACTION_UP, second)
        advance(ViewConfiguration.getMultiPressTimeout().toLong() + 1)
        val signal = shadowOf(app).broadcastIntents.single { it.action == ClockPowerReturn.ACTION }
        // Robolectric records cross-user delivery; execute the protected receiver callback explicitly.
        deliver(signal)
        val entry = shadowOf(app).nextStartedActivity
        assertNotNull(entry)
        assertEquals(DesktopMode.ANDROID, mode.current())
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).setup()
        assertFalse(ctrl.get().isFinishing)
        ctrl.windowFocusChanged(true)
        assertEquals(DesktopMode.CLOCK, mode.current())
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(ActivityManager.LOCK_TASK_MODE_LOCKED, tasks.lockTaskModeState)
        assertEquals(80, dpm.getLockTaskFeatures(admin))
        ctrl.pause().stop().destroy()
    }

    @Test fun dailyAdapterMeasuresDownToDownAndWaitsAfterSecondRelease() {
        var sends = 0
        val adapter = StationPowerShortcut(Handler(Looper.getMainLooper()), { 1L }, 600, 250) { _, _, _, _ ->
            sends++
            true
        }
        fun tap(hold: Long) {
            val now = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(hold)
            adapter.onPowerKey(KeyEvent(now, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
        }
        tap(100)
        advance(500) // full 600 ms from DOWN: this starts a new sequence despite only 500 ms since UP
        tap(100)
        advance(499)
        tap(60)
        advance(599)
        assertEquals(0, sends)
        advance(1)
        assertEquals(1, sends)
        advance(600)
        assertEquals(1, sends)
    }

    @Test fun diagnosticDeliveryCannotInitializeLegacyStateOrOpenAWindow() {
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        assertTrue(prefs.edit().remove("mode_since").commit())
        val before = prefs.all.toMap()
        deliver(Intent("com.naozho.clock.action.P095_PERMISSION_PROBE.offline")
            .setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java)))
        assertEquals(before, prefs.all)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
    }

    @Test fun normalExitInitializesVersion24ModeBoundaryAndPreservesConfiguration() {
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        val home = "com.droiclaw.launcher3/com.freeme.launcher.FreemeLauncher"
        assertTrue(prefs.edit().remove("mode_since").putString("native_home", home).commit())
        assertTrue(mode.set(DesktopMode.CLOCK))
        advance(1)
        assertTrue(mode.set(DesktopMode.ANDROID))
        advance(1)
        val signal = request()
        deliver(signal)
        assertNotNull(shadowOf(app).nextStartedActivity)
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(home, prefs.getString("native_home", null))
        assertTrue(mode.independentLock())
        assertTrue(dpm.isDeviceOwnerApp(app.packageName))
    }

    @Test fun pausedOrAlreadyLockedCannotReserveOrStartClock() {
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        val before = prefs.all.toMap()
        deliver(request())
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(before, prefs.all)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_LOCKED)
        val afterRearm = prefs.all.toMap()
        deliver(request())
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(afterRearm, prefs.all)
    }

    @Test fun pauseThenRearmRejectsBothQueuedBroadcastAndPreviouslyDeliveredActivity() {
        val signal = request()
        deliver(signal)
        val pending = shadowOf(app).nextStartedActivity
        assertNotNull(pending)
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        advance(20)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, pending).create()
        assertTrue(ctrl.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        ctrl.destroy()
    }

    @Test fun pauseWhileClockIsBeingCreatedPreventsCommitAtFirstFocus() {
        deliver(request())
        val entry = shadowOf(app).nextStartedActivity
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).create().start()
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        ctrl.resume().visible().windowFocusChanged(true)
        assertTrue(ctrl.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        ctrl.pause().stop().destroy()
    }

    @Test fun onlyOneWindowRequestCanBeOutstandingAndExpiredDeliveryCannotConsumeANewOne() {
        val first = request()
        deliver(first)
        val firstEntry = shadowOf(app).nextStartedActivity
        assertNotNull(firstEntry)
        val second = request()
        deliver(second)
        assertNull(shadowOf(app).nextStartedActivity)
        advance(2001)
        val third = request()
        deliver(third)
        val thirdEntry = shadowOf(app).nextStartedActivity
        assertNotNull(thirdEntry)
        assertFalse(ClockPowerReturn.accept(app, firstEntry, PowerDelivery.CONSUME))
        assertTrue(ClockPowerReturn.accept(app, thirdEntry, PowerDelivery.CONSUME))
        assertEquals(DesktopMode.CLOCK, mode.current())
    }

    @Test fun staleAndOtherBootDeliveriesDoNotOpenWindows() {
        val old = request()
        advance(2001)
        deliver(old)
        deliver(request().putExtra(EXTRA_BOOT_COUNT, 8))
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(DesktopMode.ANDROID, mode.current())
    }

    @Test fun activityAndPackageCannotSubstituteForThePrivateHandoff() {
        val s = request()
        deliver(s)
        val valid = shadowOf(app).nextStartedActivity
        assertNotNull(valid)
        val forged = Intent(valid).setComponent(ComponentName(app, MainActivity::class.java))
        val controller = Robolectric.buildActivity(MainActivity::class.java, forged).create()
        assertTrue(controller.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        controller.destroy()
        val wrong = Intent(valid).putExtra(ClockPowerReturn.FIRST, -1L)
        assertFalse(ClockPowerReturn.accept(app, wrong, PowerDelivery.CONSUME))
    }

    @Test fun incomingCallAndKeyguardLeaveAndroidInControl() {
        val signal = request()
        app.getSystemService(AudioManager::class.java).mode = AudioManager.MODE_IN_CALL
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        app.getSystemService(AudioManager::class.java).mode = AudioManager.MODE_NORMAL
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(true)
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun cancellingOrLosingGenerationBetweenReleasesAndDispatchSendsNothing() {
        var generation = 4L
        val adapter = StationPowerShortcut(app, Handler(Looper.getMainLooper())) { generation }
        repeat(2) {
            var down = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(down, down, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(20)
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
            advance(55)
            down = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(down, down, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(20)
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
            if (it == 0) adapter.cancel() else generation++
            advance(ViewConfiguration.getMultiPressTimeout().toLong() + 1)
        }
        assertFalse(shadowOf(app).broadcastIntents.any { it.action == ClockPowerReturn.ACTION })
    }
}


@org.robolectric.annotation.Implements(android.app.Activity::class)
class AwaitLockReadback : org.robolectric.shadows.ShadowActivity() {
    var requested = false
    @org.robolectric.annotation.Implementation
    override fun startLockTask() { requested = true }
}
