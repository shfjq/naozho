package com.naozho.clock.mode

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClockFrameHandoffTest {
    private fun frame(sequence: Long = 1) = ClockFrameHandoff(
        WakeTicket(2, "boot", 10L * sequence, 10L * sequence + 1, 12050, sequence, "ticket-$sequence", 0)
    )

    @Test fun submissionAndLockCanArriveInEitherOrderButOnlyCurrentFocusReleasesOnce() {
        for (lockFirst in listOf(true, false)) {
            val state = frame()
            assertTrue(state.armForClockDraw(true))
            assertFalse(state.armForClockDraw(true))
            if (lockFirst) state.lockConfirmed() else assertTrue(state.frameSubmitted())
            assertFalse(state.takeHandoff(true))
            if (lockFirst) assertTrue(state.frameSubmitted()) else state.lockConfirmed()
            assertFalse(state.takeHandoff(false))
            assertTrue(state.takeHandoff(true))
            assertFalse(state.takeHandoff(true))
            assertFalse(state.frameSubmitted())
        }
    }

    @Test fun noSoftwareDrawOrSpuriousCallbackCanBecomeSubmissionProof() {
        val state = frame()
        state.lockConfirmed()
        assertFalse(state.frameSubmitted())
        assertFalse(state.armForClockDraw(false))
        assertFalse(state.frameSubmitted())
        assertFalse(state.takeHandoff(true))
    }

    @Test fun cancelledTraversalAndLaterDrawCannotSupplyEachOthersProof() {
        val monitor = ClockTraversal()
        assertFalse(monitor.markHardwareDraw())
        val cancelled = requireNotNull(monitor.next())
        assertFalse(monitor.isPainted(cancelled))
        val withClock = requireNotNull(monitor.next())
        assertTrue(monitor.markHardwareDraw())
        assertFalse(monitor.isPainted(cancelled))
        assertTrue(monitor.isPainted(withClock))
        assertTrue(monitor.next() == null)
    }

    @Test fun lateCallbackOfReplacedTicketCannotSatisfyAnotherLock() {
        val previous = frame(1)
        val next = frame(2)
        assertTrue(previous.armForClockDraw(true))
        assertTrue(previous.frameSubmitted())
        next.lockConfirmed()
        assertFalse(next.takeHandoff(true))
        assertFalse(previous.takeHandoff(true))
    }
}
