package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.Application
import android.app.admin.DevicePolicyManager
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.provider.Settings
import com.naozho.clock.display.ClockDeviceAdmin
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class PowerReturnActivityTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val mode get() = ModeState(app)
    private val tasks get() = app.getSystemService(ActivityManager::class.java)

    @Before fun setup() {
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, 9)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(true)
    }

    private fun setOwner() {
        assertTrue(shadowOf(app.getSystemService(DevicePolicyManager::class.java))
            .setDeviceOwner(ComponentName(app, ClockDeviceAdmin::class.java)))
    }

    private fun rawRequest() {
        val raw = Intent(app, PowerReturnActivity::class.java)
            .putExtra("exclusive_double", true).putExtra("emergency_complete", true)
        val controller = Robolectric.buildActivity(PowerReturnActivity::class.java, raw).create()
        assertTrue(controller.get().isFinishing)
        assertNull(shadowOf(app).nextStartedActivity)
        controller.destroy()
    }

    @Test fun rawDoubleAndDuplicatesCannotLockAndroidEvenWithClaimedEmergencyClearance() {
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        setOwner()
        assertEquals(PowerRefusal.SYSTEM_ARBITRATION_MISSING, nativePowerRefusal(app, false))
        assertEquals(PowerRefusal.REDELIVERY, nativePowerRefusal(app, true))
        repeat(2) { rawRequest() }
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        assertEquals(DesktopMode.ANDROID, mode.current())
    }

    @Test fun pauseWinsOverLateRequestAndRearmingDoesNotReplayIt() {
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        setOwner()
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        assertEquals(PowerRefusal.PAUSED_OR_UNCONFIGURED, nativePowerRefusal(app, false))
        rawRequest()
        assertFalse(mode.managedLock())
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        assertEquals(PowerRefusal.SYSTEM_ARBITRATION_MISSING, nativePowerRefusal(app, false))
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
    }

    @Test fun clockAndPendingBootNeverStartAnotherClock() {
        setOwner()
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, false))
        for (state in listOf(ActivityManager.LOCK_TASK_MODE_NONE, ActivityManager.LOCK_TASK_MODE_LOCKED)) {
            shadowOf(tasks).setLockTaskModeState(state)
            assertEquals(PowerRefusal.NOT_ANDROID, nativePowerRefusal(app, false))
            rawRequest()
            assertEquals(state, tasks.lockTaskModeState)
        }
    }

    @Test fun rejectsMissingOwnerPinnedKeyguardAndSleepingDisplay() {
        assertEquals(PowerRefusal.PAUSED_OR_UNCONFIGURED, nativePowerRefusal(app, false))
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        assertEquals(PowerRefusal.OWNER_REQUIRED, nativePowerRefusal(app, false))
        setOwner()
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_PINNED)
        assertEquals(PowerRefusal.TASK_ALREADY_RESTRICTED, nativePowerRefusal(app, false))
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_NONE)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(true)
        assertEquals(PowerRefusal.DISPLAY_UNAVAILABLE, nativePowerRefusal(app, false))
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(false)
        assertEquals(PowerRefusal.DISPLAY_UNAVAILABLE, nativePowerRefusal(app, false))
    }
}
