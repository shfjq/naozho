package com.naozho.clock.mode

import android.app.Activity
import android.app.Application
import android.appwidget.AppWidgetProviderInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.RemoteViews
import android.widget.TextClock
import com.naozho.clock.R
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.roundToInt
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowSystemClock

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "zh-rCN-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class WakePreviewLayoutTest {
    private val host by lazy { Robolectric.buildActivity(Activity::class.java).setup().get() }
    private val activityRoot by lazy { FrameLayout(host).also(host::setContentView) }
    private val views by lazy { RemoteViews(host.packageName, R.layout.wake_preview_clock) }

    @Test fun recommendedCellSpanAndFallbackRetainOriginalSmallHostAllocation() {
        host.resources.getXml(R.xml.wake_preview_widget).use { xml ->
            while (xml.next() != org.xmlpull.v1.XmlPullParser.START_TAG) { /* provider-info */ }
            val ns = "http://schemas.android.com/apk/res/android"
            assertEquals(4, xml.getAttributeIntValue(ns, "targetCellWidth", 0))
            assertEquals(2, xml.getAttributeIntValue(ns, "targetCellHeight", 0))
            val attrs = intArrayOf(android.R.attr.minWidth, android.R.attr.minHeight,
                android.R.attr.minResizeWidth, android.R.attr.minResizeHeight,
                android.R.attr.resizeMode, android.R.attr.initialLayout, android.R.attr.updatePeriodMillis)
            val typed = host.obtainStyledAttributes(xml, attrs)
            try {
                for ((idx, expected) in listOf(250, 110, 100, 40).withIndex())
                    assertEquals(dp(expected), typed.getDimensionPixelSize(idx, 0))
                assertEquals(AppWidgetProviderInfo.RESIZE_BOTH, typed.getInt(4, 0))
                assertEquals(R.layout.wake_preview_empty, typed.getResourceId(5, 0))
                assertEquals(0, typed.getInt(6, -1))
            } finally { typed.recycle() }
        }
    }

    private fun dp(value: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), host.resources.displayMetrics).roundToInt()

    private fun mount(): View {
        val view = views.apply(host, activityRoot)
        activityRoot.addView(view)
        return view
    }

    private fun fit(view: View, width: Int, height: Int) {
        val w = dp(width)
        val h = dp(height)
        view.layoutParams = FrameLayout.LayoutParams(w, h)
        // Autosize may request a second layout after choosing its final text size.
        repeat(2) {
            view.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
            view.layout(0, 0, w, h)
        }
        assertEquals(w, view.width)
        assertEquals(h, view.height)
        val time = view.findViewById<TextClock>(R.id.wake_preview_time)
        val date = view.findViewById<TextClock>(R.id.wake_preview_date)
        assertTrue(time.bottom <= date.top)
        assertTrue(date.bottom <= h)
        for (clock in listOf(time, date)) {
            assertEquals(1, clock.layout.lineCount)
            assertEquals(clock.text.length, clock.layout.getLineEnd(0))
            assertEquals(0, clock.layout.getEllipsisCount(0))
            assertTrue("text too wide for ${width}x${height}: ${clock.text}",
                clock.paint.measureText(clock.text.toString()) <= clock.width + 1)
            assertTrue("text too tall for ${width}x${height}: ${clock.text} at ${clock.textSize}px " +
                "requires ${clock.layout.height}px in ${clock.height}px", clock.layout.height <= clock.height + 1)
        }
    }

    @Test fun liveFaceFitsExistingAndRecommendedSlotsWithoutClicksOrStartingAnything() {
        val root = mount()
        assertEquals(Color.rgb(19, 22, 21), (root.background as ColorDrawable).color)
        assertEquals(2, (root as ViewGroup).childCount)
        val time = root.findViewById<TextClock>(R.id.wake_preview_time)
        val date = root.findViewById<TextClock>(R.id.wake_preview_date)
        assertEquals("HH:mm", time.format12Hour.toString())
        assertEquals(time.format12Hour, time.format24Hour)
        assertEquals("yyyy年M月d日 · EEEE", date.format12Hour.toString())
        assertEquals(date.format12Hour, date.format24Hour)
        for (node in listOf(root, time, date)) {
            assertFalse(node.hasOnClickListeners())
            assertFalse(node.isClickable)
            assertFalse(node.isFocusable)
        }
        for ((width, height) in listOf(100 to 40, 124 to 50, 250 to 110, 320 to 160)) {
            fit(root, width, height)
        }
    }

    @Test
    @Config(qualifiers = "zh-rCN-xhdpi")
    fun largeFontAndDenseDisplayStillFitBothCellAllocations() {
        val oldScale = RuntimeEnvironment.getFontScale()
        try {
            RuntimeEnvironment.setFontScale(1.5f)
            val root = mount()
            fit(root, 100, 40)
            fit(root, 250, 110)
        } finally { RuntimeEnvironment.setFontScale(oldScale) }
    }

    @Test fun hostTextClocksUpdateAcrossDateBoundaryInPlaceWithoutNewRemoteViews() {
        val root = mount()
        val time = root.findViewById<TextClock>(R.id.wake_preview_time)
        val date = root.findViewById<TextClock>(R.id.wake_preview_date)
        val dates = mutableSetOf<String>()
        for (zone in listOf("GMT-12:00", "GMT+13:00")) {
            time.timeZone = zone
            date.timeZone = zone
            val calendar = Calendar.getInstance(TimeZone.getTimeZone(zone)).apply {
                timeInMillis = ShadowSystemClock.currentTimeMillis()
            }
            assertEquals(DateFormat.format("HH:mm", calendar).toString(), time.text.toString())
            assertEquals(DateFormat.format(date.format24Hour, calendar).toString(), date.text.toString())
            dates += date.text.toString()
        }
        assertEquals(2, dates.size)
        views.reapply(host, root)
        assertSame(time, root.findViewById(R.id.wake_preview_time))
        assertSame(date, root.findViewById(R.id.wake_preview_date))
    }
}
