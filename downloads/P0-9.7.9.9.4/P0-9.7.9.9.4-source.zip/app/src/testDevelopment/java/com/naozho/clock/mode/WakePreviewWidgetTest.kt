package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.Application
import android.app.KeyguardManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.view.Display
import android.view.View
import android.widget.TextClock
import android.widget.RemoteViews
import com.naozho.clock.R
import java.time.Duration
import org.junit.Assert.*
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.Implements
import org.robolectric.annotation.Implementation
import org.robolectric.shadows.ShadowAppWidgetManager
import org.robolectric.shadows.ShadowAlarmManager
import org.robolectric.shadows.ShadowLog

@Implements(AppWidgetManager::class)
class RefusingHomeWidget : ShadowAppWidgetManager() {
    companion object { var failNext = false; var failNextBlank = false }
    @Implementation
    override fun updateAppWidget(ids: IntArray, views: RemoteViews) {
        if (failNext && views.layoutId == R.layout.wake_preview_clock) {
            failNext = false
            throw IllegalStateException("host update unavailable")
        }
        if (failNextBlank && views.layoutId == R.layout.wake_preview_empty) {
            failNextBlank = false
            throw IllegalStateException("host retraction unavailable")
        }
        super.updateAppWidget(ids, views)
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class WakePreviewWidgetTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val widgets get() = AppWidgetManager.getInstance(app)
    private val alarms get() = app.getSystemService(AlarmManager::class.java)
    private val display get() = app.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
    private val provider get() = ComponentName(app, WakePreviewWidget::class.java)
    private val id = 17
    private val home = "com.droiclaw.launcher3"
    private val looper get() = shadowOf(Looper.getMainLooper())

    @Before fun setup() {
        prepareOwnerAndHome(app)
        shadowOf(app.getSystemService(UserManager::class.java)).setUserUnlocked(true)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        ShadowAlarmManager.setCanScheduleExactAlarms(true)
        shadowOf(widgets).addBoundWidget(id, AppWidgetProviderInfo().apply {
            provider = this@WakePreviewWidgetTest.provider
            initialLayout = R.layout.wake_preview_empty
        })
        assertTrue(ModeState(app).saveDeployment(true, DesktopMode.ANDROID, false))
        looper.idleFor(Duration.ofMillis(25))
    }

    @After fun releaseWatcher() { WakePreviewWidget.clear(app); looper.idle() }

    private fun startDark(): Long {
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(false)
        shadowOf(display).setState(Display.STATE_OFF)
        looper.idleFor(Duration.ofMillis(5))
        return SystemClock.elapsedRealtime().also { WakePreviewWidget.arm(app, 1, it); looper.idle() }
    }
    private fun screen(state: Int, interactive: Boolean) {
        shadowOf(display).setState(state)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(interactive)
        app.sendBroadcast(Intent(if (state == Display.STATE_ON) Intent.ACTION_SCREEN_ON else Intent.ACTION_SCREEN_OFF))
        looper.idle()
    }
    private fun shown(): Boolean {
        val root = shadowOf(widgets).getViewFor(id) ?: return false
        return root.findViewById<TextClock>(R.id.wake_preview_time) != null && root.visibility == View.VISIBLE
    }
    private fun active() = assertTrue(WakePreviewWidget.bind(app, home, id))
    private fun submits() = ShadowLog.getLogsForTag("NaozhoWakePerf").count { "PREVIEW_SUBMITTED_AT" in it.msg }

    @Test fun onlyConfiguredBoundFreemeHomeSlotMayReceivePreview() {
        assertFalse(WakePreviewWidget.bind(app, null, id))
        assertFalse(WakePreviewWidget.bind(app, "com.android.systemui", id))
        assertFalse(WakePreviewWidget.bind(app, home, 999))
        widgets.updateAppWidgetOptions(id, Bundle().apply {
            putInt(AppWidgetManager.OPTION_APPWIDGET_HOST_CATEGORY, AppWidgetProviderInfo.WIDGET_CATEGORY_KEYGUARD)
        })
        assertFalse(WakePreviewWidget.bind(app, home, id))
        startDark(); screen(Display.STATE_ON, true)
        assertEquals(0, submits())
    }

    @Test fun completeClockIsSubmittedWhileOffAndNotSubmittedAgainWhenScreenLights() {
        active()
        val dark = startDark()
        assertTrue(shown())
        val view = shadowOf(widgets).getViewFor(id)
        val prepared = view.findViewById<TextClock>(R.id.wake_preview_time)
        assertNotNull(prepared)
        assertFalse(view.isClickable)
        assertFalse(view.isFocusable)
        assertFalse(prepared.isClickable)
        assertFalse(prepared.isFocusable)
        assertEquals("HH:mm", prepared.format24Hour)
        assertFalse(app.getSystemService(PowerManager::class.java).isInteractive)
        assertEquals(Display.STATE_OFF, display.state)
        screen(Display.STATE_DOZE, false)
        assertEquals(1, submits())
        screen(Display.STATE_ON, true)
        screen(Display.STATE_ON, true)
        assertTrue(shown())
        assertSame(prepared, shadowOf(widgets).getViewFor(id).findViewById<TextClock>(R.id.wake_preview_time))
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, app.getSystemService(ActivityManager::class.java).lockTaskModeState)
        assertFalse(app.getSharedPreferences("desktop_mode", 0).contains("wake_pending"))
        assertEquals(1, submits())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").any { "phase=off" in it.msg })
        val backup = shadowOf(alarms).scheduledAlarms.single()
        assertEquals(AlarmManager.ELAPSED_REALTIME, backup.type)
        assertEquals(ComponentName(app, WakePreviewWidget::class.java), shadowOf(backup.operation).savedIntent.component)
        looper.idleFor(Duration.ofMillis(3001))
        assertTrue(shown())
        looper.idleFor(Duration.ofMillis(13_000))
        assertFalse(shown())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").any { "PREVIEW_CLEARED_AT boot=1 dark=$dark" in it.msg && "reason=timeout" in it.msg })
    }

    @Test fun deferredArmAtInteractiveOnPublishesOnceAndOnlyForTheCurrentGeneration() {
        active()
        // The prewarm receiver witnessed OFF; its worker posts arm to the UI thread.
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(false)
        shadowOf(display).setState(Display.STATE_OFF)
        val dark = SystemClock.elapsedRealtime()
        screen(Display.STATE_ON, true)
        WakePreviewWidget.arm(app, 1, dark)
        WakePreviewWidget.arm(app, 1, dark)
        assertTrue(shown())
        assertEquals(1, submits())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").any { "phase=on" in it.msg })
    }

    @Test @Config(shadows = [RefusingHomeWidget::class])
    fun failedOffTransactionGetsOneSameLayoutFallbackAtOn() {
        active()
        RefusingHomeWidget.failNext = true
        startDark()
        assertEquals(0, submits())
        screen(Display.STATE_OFF, false)
        assertEquals(0, submits())
        screen(Display.STATE_ON, true)
        assertTrue(shown())
        screen(Display.STATE_ON, true)
        assertEquals(1, submits())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").any { "phase=on" in it.msg })
    }

    @Test @Config(application = com.naozho.clock.alarm.AlarmRuntime::class)
    fun authenticatedDarkDeliveryPublishesBeforeAnyAsynchronousWarmCompletion() {
        active()
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(false)
        shadowOf(display).setState(Display.STATE_OFF)
        val dark = SystemClock.elapsedRealtime()
        val delivery = Intent(app, ConfirmedPowerReceiver::class.java).setAction(ClockPrewarm.ACTION)
            .putExtra(EXTRA_BOOT_COUNT, 1).putExtra("dark_elapsed", dark)
        val receiver = ConfirmedPowerReceiver()
        receiver.onReceive(app, Intent(delivery).setIdentifier("warm.wrong"))
        assertFalse(shown())
        receiver.onReceive(app, delivery.setIdentifier("warm.1.$dark"))
        assertTrue(shown())
        assertEquals(1, submits())
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun longDarkReplacesCleanupOnceAndStaleAlarmCannotRevokeOnHandoff() {
        active()
        val dark = startDark()
        val first = shadowOf(shadowOf(alarms).scheduledAlarms.single().operation).savedIntent
        assertEquals("dark_check", first.getStringExtra("lease_phase"))
        WakePreviewWidget().onReceive(app, first)
        val hard = shadowOf(alarms).scheduledAlarms.single()
        assertEquals("hard", shadowOf(hard.operation).savedIntent.getStringExtra("lease_phase"))
        assertEquals(dark + 12 * 60 * 60 * 1000, hard.triggerAtTime)
        WakePreviewWidget().onReceive(app, first)
        assertEquals(hard, shadowOf(alarms).scheduledAlarms.single())
        assertTrue(shown())
        screen(Display.STATE_ON, true)
        WakePreviewWidget().onReceive(app, shadowOf(hard.operation).savedIntent)
        assertTrue(shown())
        assertEquals("on", shadowOf(shadowOf(alarms).scheduledAlarms.single().operation).savedIntent.getStringExtra("lease_phase"))
        WakePreviewWidget.handoff(app, 1, dark - 1)
        assertTrue(shown())
        WakePreviewWidget.handoff(app, 1, dark)
        assertFalse(shown())
    }

    @Test fun consumedModeWaitsForExplicitFocusedCommittedHandoff() {
        active()
        val dark = startDark()
        screen(Display.STATE_ON, true)
        looper.idleFor(Duration.ofMillis(5))
        val mode = app.getSharedPreferences("desktop_mode", 0)
        val id = "074b15d6-dbd0-4d98-81d7-21b6c162242f"
        assertTrue(mode.edit().putBoolean("android", false).putLong("mode_since", SystemClock.elapsedRealtime())
            .putLong("wake_last", dark).putString("wake_focused", id).commit())
        looper.idle()
        assertTrue(shown())
        ModeState(app).confirmWake(id)
        looper.idle()
        WakePreviewWidget().onUpdate(app, widgets, intArrayOf(this.id))
        assertTrue(shown())
        WakePreviewWidget.handoff(app, 1, dark)
        assertFalse(shown())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").any { "reason=handoff" in it.msg })
    }

    @Test fun rejectionBeforeArmCannotResurrectAndOldRejectionLeavesNewCycleAlone() {
        active()
        val first = startDark()
        WakePreviewWidget.dismiss(app, 1, first)
        WakePreviewWidget.arm(app, 1, first)
        screen(Display.STATE_ON, true)
        assertFalse(shown())
        val second = startDark()
        screen(Display.STATE_ON, true)
        assertTrue(shown())
        WakePreviewWidget.dismiss(app, 1, first)
        assertTrue(shown())
        WakePreviewWidget.dismiss(app, 1, second)
        assertFalse(shown())
    }

    @Test fun keyguardOrMissingIndependentCleanupRefusesPreview() {
        active()
        startDark()
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(true)
        screen(Display.STATE_ON, true)
        assertFalse(shown())
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        ShadowAlarmManager.setCanScheduleExactAlarms(false)
        startDark(); screen(Display.STATE_ON, true)
        assertFalse(shown())
        assertEquals(1, submits()) // First cycle submitted in OFF; the lockscreen change withdrew it.
    }

    @Test fun maintenanceRetractsAndRearmDoesNotReplayIlluminatedScreen() {
        active()
        startDark(); screen(Display.STATE_ON, true)
        assertTrue(shown())
        ModeState(app).saveDeployment(false, DesktopMode.ANDROID, false)
        looper.idle()
        assertFalse(shown())
        ModeState(app).saveDeployment(true, DesktopMode.ANDROID, false)
        screen(Display.STATE_ON, true)
        assertEquals(1, submits())
    }

    @Test @Config(shadows = [RefusingHomeWidget::class])
    fun failedClearIsTombstonedAndGetsOneNonWakingHideOnlyRetry() {
        active()
        val dark = startDark()
        assertTrue(shown())
        RefusingHomeWidget.failNextBlank = true
        WakePreviewWidget.dismiss(app, 1, dark)
        val cleanup = shadowOf(alarms).scheduledAlarms.single()
        val intent = shadowOf(cleanup.operation).savedIntent
        assertEquals("clear_retry", intent.getStringExtra("lease_phase"))
        assertEquals(AlarmManager.ELAPSED_REALTIME, cleanup.type)
        WakePreviewWidget.arm(app, 1, dark) // tombstone prevents resurrection
        WakePreviewWidget().onReceive(app, intent)
        assertFalse(shown())
        assertEquals(1, submits())
        assertTrue(shadowOf(alarms).scheduledAlarms.isEmpty())
    }

    @Test fun coldWatcherDistinguishesArmedCleanupFromSuccessfulOffSubmission() {
        active()
        val dark = SystemClock.elapsedRealtime()
        val p = app.getSharedPreferences("home_visual_preview", 0)
        assertTrue(p.edit().putInt("visible_boot", 1).putLong("visible_dark", dark)
            .putString("attempted_phase", "off").putString("lease_phase", "hard")
            .putLong("lease_end", dark + 10_000).putLong("hard_end", dark + 10_000).commit())
        screen(Display.STATE_ON, true)
        WakePreviewWidget.watchMode(app)
        assertTrue(shown())
        assertEquals("on", p.getString("submitted_phase", null))
        WakePreviewWidget.watchMode(app)
        assertEquals(1, submits())
    }

    @Test fun explicitExpiryAfterLossOfRuntimeSubscriptionsClearsPersistedHostPixels() {
        active()
        // Model the system's retained RemoteViews and the application's durable receipt
        // after process loss; no in-process watcher is armed in this test.
        val dark = SystemClock.elapsedRealtime()
        assertTrue(app.getSharedPreferences("home_visual_preview", 0).edit()
            .putInt("visible_boot", 1).putLong("visible_dark", dark).commit())
        widgets.updateAppWidget(id, WakePreviewWidget.views(app, true))
        assertTrue(shown())
        val expiry = Intent(app, WakePreviewWidget::class.java)
            .setAction("com.naozho.clock.action.EXPIRE_HOME_PREVIEW")
            .putExtra(EXTRA_BOOT_COUNT, 1).putExtra("dark_elapsed", dark)
        WakePreviewWidget().onReceive(app, expiry)
        assertFalse(shown())
        assertNull(shadowOf(app).nextStartedActivity)
    }
}
