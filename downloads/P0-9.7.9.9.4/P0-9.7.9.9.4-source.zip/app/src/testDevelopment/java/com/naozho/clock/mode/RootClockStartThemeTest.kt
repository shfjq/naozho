package com.naozho.clock.mode

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.util.TypedValue
import com.naozho.clock.MainActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class RootClockStartThemeTest {
    @Test fun realClockAndPrivateEntryRequestOpaqueSystemStartingBackground() {
        val app: Context = RuntimeEnvironment.getApplication()
        val pm = app.packageManager
        val main = pm.getActivityInfo(ComponentName(app, MainActivity::class.java), 0)
        val alias = pm.getActivityInfo(ComponentName(app, app.packageName + ".mode.PowerClockEntry"), 0)
        assertFalse(alias.exported)
        assertEquals(main.name, alias.targetActivity)
        val theme = app.resources.newTheme().apply { applyStyle(main.themeResource, true) }
        for (attr in listOf(android.R.attr.windowBackground, android.R.attr.windowSplashScreenBackground)) {
            val v = TypedValue()
            assertTrue(theme.resolveAttribute(attr, v, true))
            assertEquals(Color.BLACK, v.data)
        }
        assertTrue(pm.queryIntentServices(Intent(AccessibilityService.SERVICE_INTERFACE)
            .setPackage(app.packageName), PackageManager.GET_META_DATA).isEmpty())
    }
}
