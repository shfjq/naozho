package com.naozho.clock.weather

import android.app.Application
import android.location.Location
import android.location.LocationManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class LocationEvidenceTest {
    private val now = 120_000_000_000L
    private fun fix() = Location(LocationManager.NETWORK_PROVIDER).apply {
        latitude = 30.0; longitude = 120.0
        time = 1_000
        elapsedRealtimeNanos = now - 1_000_000_000L
        accuracy = 100f
    }

    @Test fun rejectsMockEvenWhenPositionAndTimestampAreValid() {
        val mock = fix().apply { isMock = true }
        assertEquals("mock_location_rejected", locationFailure(mock, now, 120_000))
        assertNull(newestWeatherFix(listOf(mock), now, 120_000))
    }

    @Test fun rejectsUnknownTestProviderAndUnusableAccuracy() {
        assertEquals("test_or_unknown_provider", locationFailure(fix().apply { provider = "test" }, now, 120_000))
        assertEquals("accuracy_unusable", locationFailure(fix().apply { removeAccuracy() }, now, 120_000))
        assertEquals("accuracy_unusable", locationFailure(fix().apply { accuracy = Float.NaN }, now, 120_000))
    }

    @Test fun staleAndFutureReadingsAreNeverNewPositions() {
        assertEquals("stale_location", locationFailure(fix().apply { elapsedRealtimeNanos = 1 }, now + 1, 100))
        assertEquals("invalid_location_age", locationFailure(fix().apply { elapsedRealtimeNanos = now + 1 }, now, 120_000))
        assertNull(locationFailure(fix(), now, 120_000))
    }
}
