package com.naozho.clock.ui

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TapExitCounterTest {

    @Test
    fun onlySeventhTapCompletes() {
        val counter = TapExitCounter()
        repeat(6) { assertFalse(counter.tap(it * 100L)) }
        assertTrue(counter.tap(600L))
    }

    @Test
    fun newPageCannotCompletePreviousPageGesture() {
        val previousPage = TapExitCounter()
        repeat(6) { assertFalse(previousPage.tap(it * 100L)) }

        val currentPage = TapExitCounter()
        repeat(6) { assertFalse(currentPage.tap(600L + it * 100L)) }
        assertTrue(currentPage.tap(1_200L))
    }

    @Test
    fun completionDoesNotRepeatWhilePageIsStillOpen() {
        val counter = TapExitCounter()
        repeat(6) { assertFalse(counter.tap(it * 100L)) }
        assertTrue(counter.tap(600L))
        repeat(14) { assertFalse(counter.tap(700L + it * 100L)) }
    }

    @Test
    fun individuallyCloseTapsStillExpireFiveSecondsAfterFirstTap() {
        val counter = TapExitCounter()
        repeat(6) { assertFalse(counter.tap(it * 900L)) }
        repeat(6) { assertFalse(counter.tap(5_400L + it * 100L)) }
        assertTrue(counter.tap(6_000L))
    }

    @Test
    fun seventhTapAtDeadlineCanComplete() {
        val counter = TapExitCounter()
        repeat(6) { assertFalse(counter.tap(it * 100L)) }
        assertTrue(counter.tap(5_000L))
    }
}
