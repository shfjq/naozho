package com.naozho.clock.mode

import android.app.Application
import android.content.Context
import java.security.MessageDigest
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class ModeCredentialsTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()
    private val prefs get() = context.getSharedPreferences("mode_credentials", Context.MODE_PRIVATE)
    private var seconds = 10_000L
    private var boot = 1
    private val first = "470931"
    private val second = "918203"
    private val wrong = "680291"

    private fun credentials() = ModeCredentials(context, { seconds * 1_000 }, { boot }) {
        MessageDigest.getInstance("SHA-256").digest(it)
    }

    private suspend fun ModeCredentials.reset(pin: String) =
        (resetPin(pin, CredentialApproval(AdminOperation.RESET_PIN)) as CredentialResult.RecoveryIssued).code

    private suspend fun ModeCredentials.verify(pin: String) =
        verifyPin(pin, CredentialApproval(AdminOperation.SWITCH_TO_ANDROID))

    private suspend fun ModeCredentials.recover(pin: String, code: String) =
        replacePinWithRecovery(pin, code, CredentialApproval(AdminOperation.USE_RECOVERY))

    @Test
    fun pinAndRecoveryAreStoredAsSaltedVerifiersAndSurviveRecreation() = runBlocking {
        val code = credentials().reset(first)
        val hash = prefs.getString("pin_hash", "")!!
        val salt = prefs.getString("pin_salt", "")!!
        assertTrue(hash.isNotEmpty() && salt.isNotEmpty())
        assertFalse(prefs.all.values.any { it.toString() == first || it.toString() == code })
        assertEquals(CredentialResult.Accepted, credentials().verify(first))
        credentials().reset(first)
        assertNotEquals(hash, prefs.getString("pin_hash", ""))
        assertNotEquals(salt, prefs.getString("pin_salt", ""))
    }

    @Test
    fun unverifiedOrWrongPurposeApprovalCannotSetPinGenerateCodeOrCountAttempts() = runBlocking {
        val store = credentials()
        val expired = CredentialApproval(AdminOperation.RESET_PIN).also { it.revoke() }
        val unrelated = CredentialApproval(AdminOperation.SAVE_HOME)
        val empty = prefs.all.toMap()
        assertEquals(CredentialResult.Unavailable, store.resetPin(first, expired))
        assertEquals(CredentialResult.Unavailable, store.resetPin(first, unrelated))
        assertEquals(empty, prefs.all)
        val code = store.reset(first)
        val snapshot = prefs.all.toMap()
        assertEquals(CredentialResult.Unavailable, store.rotateRecovery(unrelated))
        assertEquals(CredentialResult.Unavailable, store.replacePinWithRecovery(second, code, expired))
        assertEquals(CredentialResult.Unavailable, store.changePin(first, second, unrelated))
        assertEquals(CredentialResult.Unavailable, store.verifyPin(wrong, unrelated))
        assertEquals(snapshot, prefs.all)
    }

    @Test
    fun legacyCodeStopsWorkingOnUpgradeWithoutWritingAndCanBeRotatedWithSystemApproval() = runBlocking {
        val store = credentials()
        val old = store.reset(first)
        assertTrue(prefs.edit().remove("recovery_epoch").commit())
        val snapshot = prefs.all.toMap()
        assertFalse(credentials().recoveryAvailable())
        assertEquals(CredentialResult.Unavailable, credentials().recover(second, old))
        assertEquals(snapshot, prefs.all)
        val rotated = store.rotateRecovery(CredentialApproval(AdminOperation.ROTATE_RECOVERY))
        assertTrue(rotated is CredentialResult.RecoveryIssued)
        assertEquals(snapshot["pin_hash"], prefs.getString("pin_hash", ""))
        assertEquals(CredentialResult.Rejected, store.recover(second, old))
        assertTrue(store.recover(second, (rotated as CredentialResult.RecoveryIssued).code) is CredentialResult.RecoveryIssued)
    }

    @Test
    fun fiveWrongPinsPersistTheLockoutAcrossAppRestartAndSystemBoot() = runBlocking {
        val store = credentials()
        store.reset(first)
        repeat(4) { assertEquals(CredentialResult.Rejected, store.verify(wrong)) }
        assertEquals(CredentialResult.Wait(30), store.verify(wrong))
        seconds += 8
        assertEquals(CredentialResult.Wait(22), credentials().verify(first))
        boot += 1
        seconds = 6
        assertEquals(CredentialResult.Wait(30), credentials().verify(first))
        seconds += 30
        assertEquals(CredentialResult.Accepted, store.verify(first))
        assertEquals(CredentialResult.Rejected, store.verify(wrong))
    }

    @Test
    fun recoveryWorksDuringPinLockoutAndInvalidatesTheUsedCode() = runBlocking {
        val store = credentials()
        val code = store.reset(first)
        repeat(5) { store.verify(wrong) }
        assertEquals(CredentialResult.Rejected, store.recover(second, ""))
        val result = store.recover(second, code.lowercase()) as CredentialResult.RecoveryIssued
        assertEquals(CredentialResult.Rejected, credentials().verify(first))
        assertEquals(CredentialResult.Accepted, credentials().verify(second))
        assertEquals(CredentialResult.Rejected, store.recover(first, code))
        assertTrue(store.recover(first, result.code) is CredentialResult.RecoveryIssued)
    }

    @Test
    fun recoveryCodeCanOnlyCommitOneConcurrentReset() = runBlocking {
        val store = credentials()
        val code = store.reset(first)
        val replacements = listOf(first, second)
        val results = replacements.map { candidate -> async { credentials().recover(candidate, code) } }.awaitAll()
        val winner = results.indexOfFirst { it is CredentialResult.RecoveryIssued }
        assertTrue(winner >= 0)
        assertEquals(1, results.count { it == CredentialResult.Rejected })
        assertEquals(CredentialResult.Accepted, store.verify(replacements[winner]))
        assertEquals(CredentialResult.Rejected, store.verify(replacements[1 - winner]))
    }

    @Test
    fun pinCanBeChangedOnlyWithCurrentPinAndExistingRecoveryCodeRemainsValid() = runBlocking {
        val store = credentials()
        assertFalse(store.configured())
        val code = store.reset(first)
        assertEquals(CredentialResult.Rejected, store.changePin(wrong, second, CredentialApproval(AdminOperation.CHANGE_PIN)))
        assertEquals(CredentialResult.Accepted, store.changePin(first, second, CredentialApproval(AdminOperation.CHANGE_PIN)))
        assertEquals(CredentialResult.Rejected, store.verify(first))
        assertEquals(CredentialResult.Accepted, store.verify(second))
        assertTrue(store.recover(first, code) is CredentialResult.RecoveryIssued)
    }
}
