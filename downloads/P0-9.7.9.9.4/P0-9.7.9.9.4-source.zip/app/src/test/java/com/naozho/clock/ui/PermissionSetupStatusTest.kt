package com.naozho.clock.ui

import com.naozho.clock.display.ScreenCapabilities
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionSetupStatusTest {
    @Test
    fun olderAndroidShowsCapabilitiesWithoutUnsupportedRequests() {
        val status = permissionSetupStatus(
            AlarmPermissions(notifications = true),
            ScreenCapabilities(defaultHome = true),
            dndGranted = false,
            isolationEnabled = true,
            sdk = 23,
        )
        assertEquals(listOf(ClockPermission.NOTIFICATIONS, ClockPermission.EXACT_ALARM),
            status.required.map { it.permission })
        assertEquals("本系统无需单独授权", status.required.single { it.permission == ClockPermission.EXACT_ALARM }.status)
        assertEquals("本系统无需单独授权", status.optional.single { it.permission == ClockPermission.FULL_SCREEN }.status)
        assertFalse(status.hasRequests)
        assertFalse(status.deviceOwner)
    }

    @Test
    fun grantedCapabilitiesDoNotPromptAgainAndOwnerIsIndependent() {
        val screen = ScreenCapabilities(defaultHome = true, supportsAdmin = true, activeAdmin = true)
        val status = permissionSetupStatus(
            AlarmPermissions(exact = true, notifications = true, fullScreen = true),
            screen, dndGranted = true, isolationEnabled = true, sdk = 35,
        )
        assertFalse(status.hasRequests)
        assertFalse(status.deviceOwner)
        val owner = permissionSetupStatus(
            AlarmPermissions(exact = true, notifications = true, fullScreen = false),
            screen.copy(deviceOwner = true), dndGranted = false, isolationEnabled = false, sdk = 35,
        )
        assertTrue(owner.deviceOwner)
        assertFalse(owner.required.any { it.canRequest })
        assertEquals(listOf(ClockPermission.FULL_SCREEN), owner.optional.filter { it.canRequest }.map { it.permission })
    }
}
