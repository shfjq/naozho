package com.naozho.clock.display

import com.naozho.clock.data.AlarmPlan
import com.naozho.clock.ui.parseMinutes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DisplaySettingsTest {
    @Test
    fun brightnessChangesExactlyAtConfiguredBoundariesAcrossMidnight() {
        val display = DisplaySettings(dayStart = 6 * 60 + 20, nightStart = 21 * 60 + 45, nightPercent = 17)
        assertEquals(.17f, display.brightness(0), 0f)
        assertEquals(.17f, display.brightness(6 * 60 + 19), 0f)
        assertEquals(-1f, display.brightness(6 * 60 + 20), 0f)
        assertEquals(-1f, display.brightness(21 * 60 + 44), 0f)
        assertEquals(.17f, display.brightness(21 * 60 + 45), 0f)
    }

    @Test
    fun daylightMayAlsoCrossMidnightAndClockInputIsValidated() {
        val display = DisplaySettings(dayStart = 18 * 60, nightStart = 8 * 60)
        assertEquals(-1f, display.brightness(2 * 60), 0f)
        assertEquals(.12f, display.brightness(12 * 60), 0f)
        assertEquals(1439, parseMinutes("23:59"))
        assertNull(parseMinutes("24:00"))
        assertNull(parseMinutes("09:60"))
    }

    @Test
    fun onlyRingingAndRegisteredNearTermSlotsDeferIdleLock() {
        val now = 100_000L
        val row = AlarmPlan("test", "", 7, 0, 0, true)
        assertFalse(alarmPreventsSleep(listOf(row.copy(nextAt = now + 5_000)), now))
        assertFalse(alarmPreventsSleep(listOf(row.copy(nextAt = now + 60_000, nextRegistered = true)), now))
        assertTrue(alarmPreventsSleep(listOf(row.copy(nextAt = now + 5_000, nextRegistered = true)), now))
        assertTrue(alarmPreventsSleep(listOf(row.copy(snoozeAt = now - 1_000, snoozeRegistered = true)), now))
        assertTrue(alarmPreventsSleep(listOf(row.copy(activeAt = now - 30_000)), now))
    }
}
