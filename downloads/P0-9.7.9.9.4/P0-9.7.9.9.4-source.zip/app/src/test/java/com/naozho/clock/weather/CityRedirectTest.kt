package com.naozho.clock.weather

import android.app.Application
import java.io.ByteArrayInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class CityRedirectTest {
    private class FakeConnection(url: URL, private val status: Int, private val location: String?) :
        HttpURLConnection(url) {
        var released = false
        override fun getResponseCode() = status
        override fun getHeaderField(name: String?) = if (name == "Location") location else null
        override fun getInputStream() = ByteArrayInputStream("""{"city":"北京市","locality":"其他"}""".toByteArray())
        override fun disconnect() { released = true }
        override fun usingProxy() = false
        override fun connect() = Unit
    }

    private suspend fun resolve(source: BigDataCloudCitySource) = source.lookup("39.90", "116.40", "zh")

    @Test
    fun preservesGetAcross307AndReadsCityFrom200() = runBlocking {
        val calls = mutableListOf<FakeConnection>()
        val source = BigDataCloudCitySource(open = { url ->
            val first = calls.isEmpty()
            FakeConnection(url, if (first) 307 else 200,
                "https://api-bdc.io/data/reverse-geocode-client?latitude=39.90&longitude=116.40")
                .also(calls::add)
        })
        assertEquals("北京市", resolve(source))
        assertEquals(listOf("api.bigdatacloud.net", "api-bdc.io"), calls.map { it.url.host })
        for (call in calls) {
            assertEquals("GET", call.requestMethod)
            assertEquals(setOf("Accept", "User-Agent"), call.requestProperties.keys)
            assertFalse(call.instanceFollowRedirects)
            assertTrue(call.released)
        }
    }

    @Test
    fun supportsRelativeLocationsIncludingQueryOnly() = runBlocking {
        for (status in listOf(301, 302, 303, 307, 308)) {
            val urls = mutableListOf<URL>()
            val source = BigDataCloudCitySource(open = { url ->
                urls += url
                when (urls.size) {
                    1 -> FakeConnection(url, status, "/data/next")
                    2 -> FakeConnection(url, status, "?city=1")
                    else -> FakeConnection(url, 200, null)
                }
            })
            assertEquals("北京市", resolve(source))
            assertEquals(listOf("/data/reverse-geocode-client", "/data/next", "/data/next"), urls.map { it.path })
            assertEquals("city=1", urls.last().query)
        }
    }

    @Test
    fun refusesDowngradeHostPortCredentialsAndMissingLocation() = runBlocking {
        for (destination in listOf(null, "http://api-bdc.io/", "https://api-bdc.io.example/",
            "https://api-bdc.io:8443/", "https://example@api-bdc.io/", "//example.org/",
            "https://api-bdc.io//#anchor", "https://api-bdc.io/invalid path")
        ) {
            var calls = 0
            val source = BigDataCloudCitySource(open = { url ->
                calls++
                FakeConnection(url, 307, destination)
            })
            try {
                resolve(source)
                fail("must reject invalid Location")
            } catch (_: IOException) {
                assertEquals(1, calls)
            }
        }
    }

    @Test
    fun refusesCyclesAndBoundsDistinctRedirects() = runBlocking {
        for (cycle in listOf(true, false)) {
            var calls = 0
            val source = BigDataCloudCitySource(open = { url ->
                calls++
                FakeConnection(url, 307, if (cycle) "/data/loop" else "/data/next-$calls")
            })
            try {
                resolve(source)
                fail("must stop redirect chain")
            } catch (e: IOException) {
                assertEquals(if (cycle) "city_provider_redirect_loop" else "city_provider_redirect_limit", e.message)
                assertEquals(if (cycle) 2 else 4, calls)
            }
        }
    }
}
