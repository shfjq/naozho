package com.naozho.clock.alarm

import android.app.AlarmManager
import android.app.Application
import android.app.job.JobScheduler
import android.content.Intent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlarmManager

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class AndroidAlarmSchedulerTest {
    @Test
    fun recoveryBroadcastsQueueIndependentJobsAndCoalesceDuplicateTimeChanges() {
        val context = RuntimeEnvironment.getApplication()
        val receiver = AlarmRecoveryReceiver()
        receiver.onReceive(context, Intent(Intent.ACTION_LOCKED_BOOT_COMPLETED))
        receiver.onReceive(context, Intent(Intent.ACTION_BOOT_COMPLETED))
        receiver.onReceive(context, Intent(Intent.ACTION_MY_PACKAGE_REPLACED))
        receiver.onReceive(context, Intent(Intent.ACTION_TIME_CHANGED))
        receiver.onReceive(context, Intent(Intent.ACTION_TIMEZONE_CHANGED))
        val jobs = context.getSystemService(JobScheduler::class.java).allPendingJobs
        assertEquals(Recovery.entries.map(AlarmRecoveryJob::idFor).toSet(), jobs.map { it.id }.toSet())
        assertTrue(jobs.all { it.service.className == AlarmRecoveryJob::class.java.name })
    }

    @Test
    fun exactPermissionGatesAlarmClockAndEachOperationCancelsIndependently() {
        val context = RuntimeEnvironment.getApplication()
        val manager = context.getSystemService(AlarmManager::class.java)
        val scheduler = AndroidAlarmScheduler(context)
        val now = System.currentTimeMillis()
        val first = AlarmOccurrence("first", AlarmSlot.REGULAR, now + 60_000)
        val second = AlarmOccurrence("second", AlarmSlot.REGULAR, first.at)
        val snooze = AlarmOccurrence("first", AlarmSlot.SNOOZE, now + 120_000)

        ShadowAlarmManager.setCanScheduleExactAlarms(false)
        assertFalse(scheduler.canSchedule())
        assertFalse(scheduler.schedule(first, first.at))
        assertNull(manager.nextAlarmClock)

        ShadowAlarmManager.setCanScheduleExactAlarms(true)
        assertTrue(scheduler.schedule(first, first.at))
        assertTrue(scheduler.schedule(second, second.at))
        assertTrue(scheduler.schedule(snooze, snooze.at))
        assertEquals(first.at, manager.nextAlarmClock.triggerTime)
        val scheduled = shadowOf(manager).scheduledAlarms
        assertEquals(3, scheduled.size)
        assertTrue(scheduled.all { it.alarmClockInfo != null })
        scheduler.cancel(first)
        assertEquals(2, shadowOf(manager).scheduledAlarms.size)
        assertEquals(second.at, manager.nextAlarmClock.triggerTime)
        scheduler.cancel(second)
        assertEquals(snooze.at, manager.nextAlarmClock.triggerTime)
    }
}
