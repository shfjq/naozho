package com.naozho.clock.mode

import android.Manifest
import android.app.Activity
import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import com.naozho.clock.display.ClockDeviceAdmin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class OwnerProvisioningTest {
    @Test
    fun provisioningComponentsRequireTheSystemPermission() {
        val context = RuntimeEnvironment.getApplication()
        for (activity in listOf(ProvisioningModeActivity::class.java, PolicyComplianceActivity::class.java)) {
            val info = context.packageManager.getActivityInfo(ComponentName(context, activity), 0)
            assertTrue(info.exported)
            assertEquals(Manifest.permission.BIND_DEVICE_ADMIN, info.permission)
        }
    }

    @Test
    fun setupReturnsOnlyAnAllowedFullyManagedMode() {
        val action = DevicePolicyManager.ACTION_GET_PROVISIONING_MODE
        val modes = DevicePolicyManager.EXTRA_PROVISIONING_ALLOWED_PROVISIONING_MODES
        val fullyManaged = DevicePolicyManager.PROVISIONING_MODE_FULLY_MANAGED_DEVICE
        val managedProfile = DevicePolicyManager.PROVISIONING_MODE_MANAGED_PROFILE
        Robolectric.buildActivity(ProvisioningModeActivity::class.java,
            Intent(action).putIntegerArrayListExtra(modes, arrayListOf(managedProfile))).use {
            assertEquals(Activity.RESULT_CANCELED, shadowOf(it.create().get()).resultCode)
        }
        Robolectric.buildActivity(ProvisioningModeActivity::class.java, Intent(action)).use {
            assertEquals(Activity.RESULT_CANCELED, shadowOf(it.create().get()).resultCode)
        }
        Robolectric.buildActivity(ProvisioningModeActivity::class.java,
            Intent(action).putIntegerArrayListExtra(modes, arrayListOf(managedProfile, fullyManaged))).use {
            val result = shadowOf(it.create().get())
            assertEquals(Activity.RESULT_OK, result.resultCode)
            assertEquals(fullyManaged, result.resultIntent.getIntExtra(DevicePolicyManager.EXTRA_PROVISIONING_MODE, 0))
        }
    }

    @Test
    fun complianceNeedsOwnerAndDoesNotEnableKiosk() {
        val context = RuntimeEnvironment.getApplication()
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADMIN_POLICY_COMPLIANCE)
        shadowOf(policy).setActiveAdmin(admin)
        Robolectric.buildActivity(PolicyComplianceActivity::class.java, intent).use {
            assertEquals(Activity.RESULT_CANCELED, shadowOf(it.create().get()).resultCode)
        }
        assertTrue(shadowOf(policy).setDeviceOwner(admin))
        Robolectric.buildActivity(PolicyComplianceActivity::class.java, intent).use {
            assertEquals(Activity.RESULT_OK, shadowOf(it.create().get()).resultCode)
        }
        assertFalse(ModeState(context).managedLock())
        assertFalse(policy.isLockTaskPermitted(context.packageName))
    }
}
