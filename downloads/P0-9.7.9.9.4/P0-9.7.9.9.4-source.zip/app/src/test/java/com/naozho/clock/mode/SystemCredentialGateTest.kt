package com.naozho.clock.mode

import android.app.Application
import android.app.KeyguardManager
import androidx.activity.ComponentActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class SystemCredentialGateTest {
    @Test
    fun desktopSwitchRequiresItsOwnResultAndDoesNotAcceptPreviouslyApprovedOperation() {
        Robolectric.buildActivity(ComponentActivity::class.java).setup().use { host ->
            val activity = host.get()
            shadowOf(activity.getSystemService(KeyguardManager::class.java)).setIsDeviceSecure(true)
            val callbacks = mutableListOf<(Boolean) -> Unit>()
            val gate = SystemCredentialGate(activity, DeviceCredentialPrompt { _, result ->
                callbacks += result
                val cancel: () -> Unit = {}
                cancel
            })
            var previous: CredentialApproval? = null
            gate.request(AdminOperation.RESET_PIN, { error(it) }) { previous = it }
            callbacks.single()(true)
            assertNotNull(previous)
            assertFalse(previous!!.permits(AdminOperation.SWITCH_TO_ANDROID))

            val store = ModeState(activity)
            assertEquals(DesktopMode.CLOCK, store.current())
            val prefs = activity.getSharedPreferences("desktop_mode", 0)
            val before = prefs.all.toMap()
            var writes = 0
            fun requestSwitch() = gate.request(AdminOperation.SWITCH_TO_ANDROID, {}) { grant ->
                grant.whileValid(AdminOperation.SWITCH_TO_ANDROID) {
                    writes++
                    assertTrue(store.set(DesktopMode.ANDROID))
                }
            }

            requestSwitch()
            requestSwitch()
            assertEquals(2, callbacks.size)
            callbacks[0](true)
            assertEquals(before, prefs.all)
            assertEquals(0, writes)
            callbacks[1](false)
            assertEquals(before, prefs.all)
            requestSwitch()
            callbacks[2](true)
            callbacks[2](true)
            assertEquals(1, writes)
            assertEquals(DesktopMode.ANDROID, store.current())
        }
    }
}
