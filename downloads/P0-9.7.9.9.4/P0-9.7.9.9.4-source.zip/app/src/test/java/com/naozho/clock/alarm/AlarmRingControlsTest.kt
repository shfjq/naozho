package com.naozho.clock.alarm

import android.app.Application
import android.content.Intent
import android.view.KeyEvent
import com.naozho.clock.data.AlarmPlan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class AlarmRingControlsTest {
    private val actions = mutableListOf<Triple<String, Long, String>>()
    private val controls = AlarmRingControls { id, at, action -> actions += Triple(id, at, action) }

    @Test
    fun backgroundAndForegroundRingingUseTheSameLockScreenActivity() {
        val alerts = AlarmAlerts(RuntimeEnvironment.getApplication())
        val fullScreen = alerts.ringIntent()
        val inTask = alerts.ringIntent(inCurrentTask = true)
        assertEquals(AlarmRingActivity::class.java.name, fullScreen.component?.className)
        assertEquals(fullScreen.component, inTask.component)
        assertTrue(fullScreen.flags and Intent.FLAG_ACTIVITY_NEW_TASK != 0)
        assertEquals(Intent.FLAG_ACTIVITY_SINGLE_TOP, inTask.flags)
    }

    @Test
    fun ordinaryVolumeAndOtherKeysAreLeftToAndroid() {
        assertFalse(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 100)))
        assertFalse(controls.dispatch(up(KeyEvent.KEYCODE_VOLUME_UP, 100)))
        assertFalse(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_DOWN, 200)))
        assertFalse(controls.dispatch(up(KeyEvent.KEYCODE_VOLUME_DOWN, 200)))
        controls.show(plan("alarm", 10))
        assertFalse(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_MUTE, 300)))
        assertFalse(controls.dispatch(down(KeyEvent.KEYCODE_BACK, 400)))
        assertTrue(actions.isEmpty())
    }

    @Test
    fun stopConsumesRepeatAndReleaseEvenAfterTheAlarmHasEnded() {
        controls.show(plan("alarm", 10))
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 100)))
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 140, start = 100, repeats = 1)))
        controls.show(null)
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 160, start = 100, repeats = 2)))
        assertTrue(controls.dispatch(up(KeyEvent.KEYCODE_VOLUME_UP, 100)))
        assertFalse(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 500)))
        assertEquals(listOf(Triple("alarm", 10L, "stopped")), actions)
    }

    @Test
    fun buttonsAndKeysAddressTheSameOccurrenceOnce() {
        val current = plan("alarm", 10)
        controls.show(current)
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_DOWN, 100)))
        assertTrue(controls.dispatch(up(KeyEvent.KEYCODE_VOLUME_DOWN, 100)))
        assertFalse(controls.request(current, "stopped"))
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_DOWN, 500)))
        assertEquals(listOf(Triple("alarm", 10L, "snoozed")), actions)
    }

    @Test
    fun rapidPressDoesNotConsumeNextAlarmAndLaterSeparatePressWorks() {
        val first = plan("first", 10)
        controls.show(first)
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_DOWN, 100)))
        assertTrue(controls.dispatch(up(KeyEvent.KEYCODE_VOLUME_DOWN, 100)))
        controls.show(plan("next", 11))
        assertFalse(controls.request(first, "snoozed"))
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 200)))
        assertTrue(controls.dispatch(up(KeyEvent.KEYCODE_VOLUME_UP, 200)))
        assertEquals(listOf(Triple("first", 10L, "snoozed")), actions)
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 500)))
        assertEquals(listOf(Triple("first", 10L, "snoozed"), Triple("next", 11L, "stopped")), actions)
    }

    @Test
    fun repeatOfKeyPressedBeforeRingingDoesNotActOnTheAlarm() {
        assertFalse(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 100)))
        controls.show(plan("alarm", 10))
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 600, start = 100, repeats = 1)))
        assertTrue(controls.dispatch(up(KeyEvent.KEYCODE_VOLUME_UP, 100)))
        assertTrue(actions.isEmpty())
        assertTrue(controls.dispatch(down(KeyEvent.KEYCODE_VOLUME_UP, 800)))
        assertEquals(listOf(Triple("alarm", 10L, "stopped")), actions)
    }

    private fun plan(id: String, at: Long) = AlarmPlan(id, "", 7, 0, 0, false, activeAt = at)

    private fun down(code: Int, at: Long, start: Long = at, repeats: Int = 0) =
        KeyEvent(start, at, KeyEvent.ACTION_DOWN, code, repeats)

    private fun up(code: Int, start: Long) =
        KeyEvent(start, start + 10, KeyEvent.ACTION_UP, code, 0)
}
