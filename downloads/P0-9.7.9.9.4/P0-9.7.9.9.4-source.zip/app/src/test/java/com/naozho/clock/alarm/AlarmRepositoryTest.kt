package com.naozho.clock.alarm

import android.app.Application
import android.provider.Settings
import android.view.KeyEvent
import androidx.room.Room
import com.naozho.clock.data.AlarmDatabase
import com.naozho.clock.data.AlarmPlan
import java.time.Instant
import java.time.ZoneId
import java.util.UUID
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowMediaPlayer
import org.robolectric.shadows.util.DataSource

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class AlarmRepositoryTest {
    private lateinit var database: AlarmDatabase
    private lateinit var scheduler: RecordingScheduler
    private lateinit var repo: AlarmRepository
    private var now = instant("2026-11-23T06:30:00Z") // Monday
    private var elapsed = 10_000L
    private var zone: ZoneId = ZoneId.of("UTC")
    private var notification = true

    @Before
    fun setup() {
        database = Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(), AlarmDatabase::class.java)
            .build()
        scheduler = RecordingScheduler()
        repo = newRepository()
    }

    @After
    fun close() = database.close()

    @Test
    fun oneShotConsumesOnlyOnceAndCanBeStopped() = runBlocking {
        repo.save(plan("once"))
        val delivery = regular("once")
        assertEquals(instant("2026-11-23T07:00:00Z"), scheduler.pending[delivery])
        advanceTo(delivery.at)
        assertTrue(repo.receive(delivery))
        assertFalse(repo.receive(delivery))
        assertFalse(row("once").enabled)
        assertNull(row("once").nextAt)
        assertEquals("once", repo.active.first().single().id)
        repo.finish("once", delivery.at, "stopped")
        assertTrue(repo.active.first().isEmpty())
        assertTrue(scheduler.pending.isEmpty())
        assertEquals(1, repo.events.first().count { it.action == "triggered" })
        assertTrue(repo.events.first().any { it.action == "stopped" })
    }

    @Test
    fun ringingWindowKeysEndPlaybackQueueAndScheduleOnlyOneSnooze() = runBlocking {
        val operations = mutableListOf<Triple<String, Long, String>>()
        val controls = AlarmRingControls { id, at, action -> operations.add(Triple(id, at, action)) }
        repo.save(plan("key-actions"))
        val first = regular("key-actions")
        advanceTo(first.at)
        assertTrue(repo.receive(first))
        val active = repo.active.first().single()
        controls.show(active)

        assertTrue(controls.dispatch(KeyEvent(100, 100, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_VOLUME_DOWN, 0)))
        assertTrue(controls.dispatch(KeyEvent(100, 200, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_VOLUME_DOWN, 1)))
        assertFalse(controls.request(active, "stopped"))
        val (id, at, action) = operations.single()
        repo.finish(id, at, action)
        assertTrue(repo.active.first().isEmpty())
        val delayed = snooze(id)
        assertEquals(first.at + 5 * 60_000L, delayed.at)
        assertEquals(setOf(delayed), scheduler.pending.keys)
        controls.show(null)
        assertTrue(controls.dispatch(KeyEvent(100, 210, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_VOLUME_DOWN, 0)))

        advanceTo(delayed.at)
        assertTrue(repo.receive(delayed))
        controls.show(repo.active.first().single())
        assertTrue(controls.dispatch(KeyEvent(600, 600, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_VOLUME_UP, 0)))
        val (stopId, stopAt, stopAction) = operations.last()
        repo.finish(stopId, stopAt, stopAction)
        assertTrue(repo.active.first().isEmpty())
        assertTrue(scheduler.pending.isEmpty())
        assertEquals(1, repo.events.first().count { it.action == "snoozed" })
        assertEquals(1, repo.events.first().count { it.action == "stopped" })
    }

    @Test
    fun dailyAndSelectedWeekdaysAdvanceIndependently() = runBlocking {
        repo.save(plan("daily", days = 127))
        repo.save(plan("monday-friday", days = 1 or 16))
        val daily = regular("daily")
        val selected = regular("monday-friday")
        advanceTo(daily.at)
        assertTrue(repo.receive(daily))
        assertTrue(repo.receive(selected))
        assertEquals(instant("2026-11-24T07:00:00Z"), regular("daily").at)
        assertEquals(instant("2026-11-27T07:00:00Z"), regular("monday-friday").at)
        assertEquals(listOf("daily", "monday-friday"), repo.active.first().map { it.id })
        repo.finish("daily", daily.at, "stopped")
        assertEquals("monday-friday", repo.active.first().single().id)
    }

    @Test
    fun snoozeUsesConfiguredTimeAndRejectsStaleControls() = runBlocking {
        repo.save(plan("custom").copy(snoozeMinutes = 7))
        repo.save(plan("default", minute = 1))
        val timed = regular("custom")
        advanceTo(timed.at)
        assertTrue(repo.receive(timed))
        repo.finish("custom", timed.at, "snoozed")
        val delayed = snooze("custom")
        assertEquals(timed.at + 7 * 60_000L, delayed.at)
        val next = regular("default")
        advanceTo(next.at)
        assertTrue(repo.receive(next))
        repo.finish("default", next.at, "snoozed")
        assertEquals(next.at + 5 * 60_000L, snooze("default").at)
        advanceTo(delayed.at)
        assertTrue(repo.receive(delayed))
        assertFalse(repo.receive(delayed))
        repo.finish("custom", timed.at, "stopped")
        assertEquals(delayed.at, row("custom").activeAt)
        repo.finish("custom", delayed.at, "stopped")
        assertNull(row("custom").activeAt)
    }

    @Test
    fun nearSimultaneousPlansAndEditsDoNotUseEachOthersOperations() = runBlocking {
        repo.save(plan("first"))
        repo.save(plan("second", minute = 1))
        repo.save(plan("third", minute = 2))
        val superseded = regular("third")
        repo.save(row("third").copy(minute = 3))
        assertFalse(scheduler.pending.containsKey(superseded))
        assertFalse(repo.receive(superseded))
        val first = regular("first")
        val second = regular("second")
        advanceTo(first.at)
        assertTrue(repo.receive(first))
        advanceTo(second.at)
        assertTrue(repo.receive(second))
        assertEquals(listOf("first", "second"), repo.active.first().map { it.id })
        repo.setEnabled("first", false)
        repo.delete("third")
        assertEquals("second", repo.active.first().single().id)
        assertTrue(scheduler.pending.isEmpty())
    }

    @Test
    fun concurrentDuplicateCallbacksStillConsumeEachAlarmExactlyOnce() = runBlocking {
        repo.save(plan("first"))
        repo.save(plan("second"))
        val first = regular("first")
        val second = regular("second")
        advanceTo(first.at)

        val callbacks = List(5) { listOf(first, second) }.flatten()
        val accepted = callbacks.map { delivery -> async { repo.receive(delivery) } }.awaitAll()
        assertEquals(2, accepted.count { it })
        assertEquals(
            mapOf("first" to 1, "second" to 1),
            repo.events.first().filter { it.action == "triggered" }.groupingBy { it.alarmId }.eachCount(),
        )
        assertEquals(setOf("first", "second"), repo.active.first().map { it.id }.toSet())
    }

    @Test
    fun rollingClockBackOnTheDayAlreadyConsumedDoesNotRepeatTheDailyAlarm() = runBlocking {
        repo.save(plan("daily", days = 127))
        val consumed = regular("daily")
        advanceTo(consumed.at)
        assertTrue(repo.receive(consumed))
        repo.finish("daily", consumed.at, "stopped")

        now = consumed.at - 2 * 60_000L
        repo.recover(Recovery.CLOCK_CHANGED)
        assertFalse(repo.receive(consumed))
        assertEquals(instant("2026-11-24T07:00:00Z"), regular("daily").at)
        assertEquals(1, repo.events.first().count { it.action == "triggered" })
    }

    @Test
    fun outOfOrderDeliveryDoesNotInterruptTheAlarmAlreadyPlaying() = runBlocking {
        repo.save(plan("early"))
        repo.save(plan("playing", minute = 1))
        val early = regular("early")
        val playing = regular("playing")
        advanceTo(playing.at)
        assertTrue(repo.receive(playing))
        assertNotNull(repo.begin("playing", playing.at))
        assertTrue(repo.receive(early))
        assertEquals(listOf("playing", "early"), repo.active.first().map { it.id })
        repo.finish("playing", playing.at, "stopped")
        assertEquals("early", repo.active.first().single().id)
    }

    @Test
    fun rebootReRegistersFuturePlansAndEndsInterruptedRinging() = runBlocking {
        repo.save(plan("ringing", days = 127))
        repo.save(plan("future", minute = 2))
        repo.save(plan("snooze", minute = 1))
        val ringing = regular("ringing")
        advanceTo(ringing.at)
        assertTrue(repo.receive(ringing))
        repo.begin("ringing", ringing.at)
        val entry = regular("snooze")
        advanceTo(entry.at)
        assertTrue(repo.receive(entry))
        repo.finish("snooze", entry.at, "snoozed")
        val pending = setOf(regular("ringing"), regular("future"), snooze("snooze"))
        scheduler = RecordingScheduler()
        elapsed = 100
        repo = newRepository()
        repo.recover(Recovery.REBOOT)
        repo.recover(Recovery.RESTORE)
        assertEquals(pending, scheduler.pending.keys)
        assertTrue(repo.active.first().isEmpty())
        assertFalse(repo.receive(ringing))
        assertTrue(repo.events.first().any { it.action == "interrupted_reboot" })
    }

    @Test
    fun recoveryCatchesRecentMissAndDiscardsExpiredOneShot() = runBlocking {
        repo.save(plan("expired"))
        repo.save(plan("recent", minute = 20))
        val old = regular("expired")
        val recent = regular("recent")
        advanceTo(recent.at + 60_000L)
        repo.recover(Recovery.RESTORE)
        assertFalse(row("expired").enabled)
        assertFalse(repo.receive(old))
        assertEquals(now + 500, scheduler.pending[recent])
        assertTrue(repo.receive(recent))
        assertTrue(repo.events.first().any { it.alarmId == "expired" && it.action == "missed" })
    }

    @Test
    fun timezoneAndTimeChangesRecomputeAndPreserveSnoozeDuration() = runBlocking {
        repo.save(plan("regular", days = 127))
        repo.save(plan("nap", minute = 1))
        val original = regular("regular")
        val nap = regular("nap")
        advanceTo(nap.at)
        assertTrue(repo.receive(nap))
        repo.finish("nap", nap.at, "snoozed")
        zone = ZoneId.of("America/Los_Angeles")
        now += 60 * 60_000
        elapsed += 60_000
        repo.recover(Recovery.CLOCK_CHANGED)
        assertEquals(instant("2026-11-23T15:00:00Z"), regular("regular").at)
        assertFalse(repo.receive(original))
        assertEquals(now + 4 * 60_000, snooze("nap").at)
    }

    @Test
    fun deniedPermissionsDoNotReportRegistrationAndRecoveryRetries() = runBlocking {
        scheduler.allowed = false
        repo.save(plan("blocked"))
        assertFalse(row("blocked").nextRegistered)
        assertTrue(scheduler.pending.isEmpty())
        scheduler.allowed = true
        notification = false
        repo.recover(Recovery.RESTORE)
        assertFalse(row("blocked").nextRegistered)
        notification = true
        repo.recover(Recovery.RESTORE)
        assertTrue(row("blocked").nextRegistered)
        assertEquals(setOf(regular("blocked")), scheduler.pending.keys)
    }

    @Test
    fun missingCustomSoundCallsFallback() {
        var fellBack = false
        val context = RuntimeEnvironment.getApplication()
        ShadowMediaPlayer.addMediaInfo(
            DataSource.toDataSource(context, Settings.System.DEFAULT_ALARM_ALERT_URI),
            ShadowMediaPlayer.MediaInfo(),
        )
        val sounds = AlarmSounds(context)
        val player = sounds.prepare(plan("missing").copy(ringtone = UUID.randomUUID().toString())) {
            fellBack = true
        }
        try {
            assertTrue(fellBack)
            assertNotNull(player)
        } finally {
            player?.release()
        }
    }

    private fun newRepository() =
        AlarmRepository(database, scheduler, { notification }, { now }, { elapsed }, { zone })

    private fun plan(id: String, minute: Int = 0, days: Int = 0) =
        AlarmPlan(id, id, 7, minute, days, true)

    private suspend fun row(id: String) = checkNotNull(database.alarms().find(id))

    private suspend fun regular(id: String) = AlarmOccurrence(id, AlarmSlot.REGULAR, checkNotNull(row(id).nextAt))

    private suspend fun snooze(id: String) = AlarmOccurrence(id, AlarmSlot.SNOOZE, checkNotNull(row(id).snoozeAt))

    private fun advanceTo(newNow: Long) {
        elapsed += newNow - now
        now = newNow
    }

    private fun instant(value: String): Long = Instant.parse(value).toEpochMilli()

    private class RecordingScheduler : AlarmScheduler {
        var allowed = true
        val pending = mutableMapOf<AlarmOccurrence, Long>()
        override fun canSchedule() = allowed
        override fun schedule(occurrence: AlarmOccurrence, triggerAt: Long): Boolean {
            pending[occurrence] = triggerAt
            return true
        }
        override fun cancel(occurrence: AlarmOccurrence) {
            pending.remove(occurrence)
        }
    }
}
