package com.naozho.clock.isolation

import android.app.Application
import android.app.NotificationManager
import android.content.Context
import com.naozho.clock.mode.DesktopMode
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class ClockIsolationTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()
    private val system = FakeZen()
    private var mode = DesktopMode.CLOCK
    private fun isolation() = ClockIsolation(context, system) { mode }

    @Test
    fun deniedAccessAndUnsupportedAndroidLeaveSystemAlone() = runBlocking {
        val clock = isolation()
        system.access = false
        assertEquals(IsolationPhase.NEEDS_ACCESS, clock.reconcile().phase)
        assertNull(system.rule)
        assertTrue(system.writes.isEmpty())
        system.available = false
        assertEquals(IsolationPhase.MANUAL_ONLY, clock.reconcile().phase)
        assertTrue(system.writes.isEmpty())
    }

    @Test
    fun repeatedHandoffsPauseOnlyOurRuleAndKeepTheOriginalSystemFilter() = runBlocking {
        val clock = isolation()
        system.externalFilter = NotificationManager.INTERRUPTION_FILTER_PRIORITY
        assertEquals(IsolationPhase.REQUESTED, clock.reconcile().phase)
        repeat(3) {
            assertTrue(clock.handOffToAndroid {
                assertFalse(system.rule!!.enabled)
                mode = DesktopMode.ANDROID
                true
            })
            assertEquals(IsolationPhase.OFF, isolation().reconcile().phase)
            assertEquals(NotificationManager.INTERRUPTION_FILTER_PRIORITY, system.currentFilter())
            mode = DesktopMode.CLOCK
            assertEquals(IsolationPhase.REQUESTED, isolation().reconcile().phase)
            assertTrue(system.rule!!.enabled)
        }
        assertEquals(1, system.writes.count { it == "create" })
    }

    @Test
    fun cancelledHandoffRestoresTheClockRequest() = runBlocking {
        val clock = isolation()
        clock.reconcile()
        assertFalse(clock.handOffToAndroid {
            assertFalse(system.rule!!.enabled)
            false
        })
        assertEquals(IsolationPhase.REQUESTED, clock.status.value.phase)
        assertTrue(system.rule!!.enabled)
        assertEquals("activate", system.writes.last())
    }

    @Test
    fun coroutineCancelledWhileLeavingLockTaskRestoresTheClockRule() = runBlocking {
        val clock = isolation()
        clock.reconcile()
        val waiting = CompletableDeferred<Unit>()
        val handoff = launch {
            clock.handOffToAndroid {
                assertFalse(system.rule!!.enabled)
                waiting.complete(Unit)
                awaitCancellation()
            }
        }
        waiting.await()
        handoff.cancelAndJoin()
        assertEquals(DesktopMode.CLOCK, mode)
        assertEquals(IsolationPhase.REQUESTED, clock.status.value.phase)
        assertTrue(system.rule!!.enabled)
    }

    @Test
    fun staleActiveRuleAfterCrashIsReleasedInAndroidMode() = runBlocking {
        isolation().reconcile()
        mode = DesktopMode.ANDROID
        val restored = isolation()
        assertEquals(IsolationPhase.OFF, restored.reconcile().phase)
        assertFalse(system.rule!!.enabled)
        mode = DesktopMode.CLOCK
        assertEquals(IsolationPhase.REQUESTED, isolation().reconcile().phase)
        assertEquals("clock", system.rule!!.id)
    }

    @Test
    fun permissionRevocationAndRestoreFailureAreReportedAndRecoverable() = runBlocking {
        val clock = isolation()
        clock.reconcile()
        system.updateSucceeds = false
        assertTrue(clock.handOffToAndroid { mode = DesktopMode.ANDROID; true })
        assertEquals(IsolationPhase.RELEASE_UNCERTAIN, clock.status.value.phase)
        assertTrue(system.rule!!.enabled)
        system.access = false
        assertEquals(IsolationPhase.RELEASE_UNCERTAIN, isolation().reconcile().phase)
        system.access = true
        system.updateSucceeds = true
        assertEquals(IsolationPhase.OFF, isolation().reconcile().phase)
        assertFalse(system.rule!!.enabled)
    }

    @Test
    fun userDisabledRuleStaysDisabledAndDeletedRuleRequiresExplicitRegistration() = runBlocking {
        val clock = isolation()
        clock.reconcile()
        system.rule = system.rule!!.copy(enabled = false)
        assertEquals(IsolationPhase.RULE_DISABLED, clock.reconcile().phase)
        clock.handOffToAndroid { mode = DesktopMode.ANDROID; true }
        mode = DesktopMode.CLOCK
        assertEquals(IsolationPhase.RULE_DISABLED, isolation().reconcile().phase)
        system.rule = null
        assertEquals(IsolationPhase.RULE_MISSING, isolation().reconcile().phase)
        assertEquals(1, system.writes.count { it == "create" })
        assertEquals(IsolationPhase.REQUESTED, isolation().registerAgain().phase)
        assertEquals(2, system.writes.count { it == "create" })
    }

    @Test
    fun unsafeRuleEditIsPausedAndExternalTotalSilenceIsReported() = runBlocking {
        val clock = isolation()
        clock.reconcile()
        system.rule = system.rule!!.copy(compatible = false)
        system.externalFilter = NotificationManager.INTERRUPTION_FILTER_NONE
        val state = clock.reconcile()
        assertEquals(IsolationPhase.RULE_CHANGED, state.phase)
        assertTrue(state.alarmBlocked)
        assertFalse(system.rule!!.enabled)
        assertEquals(NotificationManager.INTERRUPTION_FILTER_NONE, system.currentFilter())
    }

    @Test
    fun olderPlatformWaitsForItsProviderAndPausesWithoutIt() = runBlocking {
        val clock = isolation()
        system.customVisuals = false
        system.providerReady = false
        assertEquals(IsolationPhase.WAITING_FOR_PROVIDER, clock.reconcile().phase)
        system.providerReady = true
        assertEquals(IsolationPhase.LEGACY_REQUESTED, clock.refreshSystemStatus().phase)
        system.providerReady = false
        assertTrue(clock.handOffToAndroid { mode = DesktopMode.ANDROID; true })
        assertEquals(IsolationPhase.OFF, clock.status.value.phase)
        assertFalse(system.rule!!.enabled)
    }

    @Test
    fun turningOffBetweenModeChangesDoesNotStartTheRuleAgain() = runBlocking {
        val clock = isolation()
        mode = DesktopMode.ANDROID
        assertEquals(IsolationPhase.OFF, clock.setEnabled(false).phase)
        mode = DesktopMode.CLOCK
        assertEquals(IsolationPhase.OFF, isolation().reconcile().phase)
        assertNull(system.rule)
        assertEquals(IsolationPhase.REQUESTED, isolation().setEnabled(true).phase)
    }

    private class FakeZen : ZenBackend {
        override var available = true
        override var customVisuals = true
        var access = true
        var externalFilter = NotificationManager.INTERRUPTION_FILTER_ALL
        var rule: ClockRule? = null
        var updateSucceeds = true
        var providerReady = true
        val writes = mutableListOf<String>()

        override fun hasAccess() = access
        override fun currentFilter() = externalFilter
        override fun blocksAlarms(filter: Int) = filter == NotificationManager.INTERRUPTION_FILTER_NONE
        override fun ownedRule() = rule

        override fun createRule(): ClockRule {
            writes += "create"
            return ClockRule("clock", enabled = true, compatible = true, visualPolicy = customVisuals).also { rule = it }
        }

        override fun setEnabled(rule: ClockRule, enabled: Boolean): Boolean {
            writes += if (enabled) "enable" else "pause"
            if (updateSucceeds) this.rule = rule.copy(enabled = enabled)
            return updateSucceeds
        }

        override fun activate(rule: ClockRule): Boolean {
            if (!providerReady) return false
            writes += "activate"
            return true
        }
    }
}
