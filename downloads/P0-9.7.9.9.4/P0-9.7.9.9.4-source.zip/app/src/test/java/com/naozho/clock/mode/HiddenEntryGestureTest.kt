package com.naozho.clock.mode

import com.naozho.clock.mode.HiddenEntryGesture.Action
import com.naozho.clock.mode.HiddenEntryGesture.Finger
import com.naozho.clock.mode.HiddenEntryGesture.Result
import org.junit.Assert.assertEquals
import org.junit.Test

class HiddenEntryGestureTest {
    private val gesture = HiddenEntryGesture()
    private val top = Finger(4, .08f, .08f)
    private val bottom = Finger(9, .92f, .92f)
    private val swipeStart = Finger(2, .22f, .78f)
    private val swipeEnd = Finger(2, .81f, .22f)

    @Test
    fun bothCornersHoldFiveSecondsBeforeTheTimedDiagonalSwipe() {
        arm()
        assertEquals(Result.CAPTURE, step(Action.DOWN, 6_000, swipeStart.id, swipeStart))
        assertEquals(Result.COMPLETE, step(Action.UP, 6_500, swipeEnd.id, swipeEnd))
        assertEquals(Result.PASS, step(Action.DOWN, 6_600, swipeStart.id, swipeStart))
    }

    @Test
    fun supportsEitherCornerFirstButRejectsLateSecondFingerAndSingleTouch() {
        step(Action.DOWN, 0, bottom.id, bottom)
        assertEquals(Result.PASS, step(Action.POINTER_DOWN, 651, top.id, bottom, top))
        assertEquals(Result.PASS, step(Action.UP, 5_800, bottom.id, bottom))
        step(Action.DOWN, 6_000, bottom.id, bottom)
        assertEquals(Result.CAPTURE, step(Action.POINTER_DOWN, 6_150, top.id, bottom, top))
        assertEquals(Result.CAPTURE, step(Action.POINTER_UP, 11_150, top.id, bottom, top))
        assertEquals(Result.CAPTURE, step(Action.UP, 11_170, bottom.id, bottom))
        step(Action.DOWN, 11_500, swipeStart.id, swipeStart)
        assertEquals(Result.COMPLETE, step(Action.UP, 11_800, swipeEnd.id, swipeEnd))
    }

    @Test
    fun earlyLiftOrMovingOutsideOneCornerRequiresStartingAgain() {
        hold()
        step(Action.POINTER_UP, 5_089, top.id, top, bottom)
        step(Action.UP, 5_150, bottom.id, bottom)
        assertEquals(Result.PASS, step(Action.DOWN, 5_300, swipeStart.id, swipeStart))

        hold()
        step(Action.MOVE, 3_000, top.id, top.copy(y = .27f), bottom)
        step(Action.POINTER_UP, 5_090, top.id, top, bottom)
        step(Action.UP, 5_150, bottom.id, bottom)
        assertEquals(Result.PASS, step(Action.DOWN, 5_300, swipeStart.id, swipeStart))
    }

    @Test
    fun rejectsThirdFingerWhileHoldingAndWhileSwiping() {
        hold()
        assertEquals(Result.CAPTURE, step(Action.POINTER_DOWN, 200, swipeStart.id, top, bottom, swipeStart))
        step(Action.POINTER_UP, 5_400, swipeStart.id, top, bottom, swipeStart)
        step(Action.POINTER_UP, 5_410, top.id, top, bottom)
        step(Action.UP, 5_450, bottom.id, bottom)
        assertEquals(Result.PASS, step(Action.DOWN, 5_800, swipeStart.id, swipeStart))
        arm()
        step(Action.DOWN, 6_000, swipeStart.id, swipeStart)
        step(Action.POINTER_DOWN, 6_050, top.id, swipeStart, top)
        step(Action.POINTER_UP, 6_080, top.id, swipeEnd, top)
        assertEquals(Result.CAPTURE, step(Action.UP, 6_100, swipeEnd.id, swipeEnd))
    }

    @Test
    fun wrongDirectionAndTimedOutEntryReturnToNormalTouchHandling() {
        arm()
        step(Action.DOWN, 6_000, swipeStart.id, swipeStart)
        assertEquals(Result.CAPTURE, step(Action.UP, 6_500, swipeStart.id, swipeStart.copy(x = .71f)))
        assertEquals(Result.PASS, step(Action.DOWN, 6_700, swipeStart.id, swipeStart))
        arm()
        assertEquals(Result.PASS, step(Action.DOWN, 12_091, swipeStart.id, swipeStart))
        assertEquals(Result.PASS, step(Action.UP, 12_200, swipeEnd.id, swipeEnd))
        arm()
        step(Action.DOWN, 12_000, swipeStart.id, swipeStart)
        assertEquals(Result.CAPTURE, step(Action.UP, 12_100, swipeEnd.id, swipeEnd))
    }

    @Test
    fun lifecycleCancellationClearsACompletedHold() {
        arm()
        gesture.reset()
        assertEquals(Result.PASS, step(Action.DOWN, 6_000, swipeStart.id, swipeStart))
        assertEquals(Result.PASS, step(Action.UP, 6_500, swipeEnd.id, swipeEnd))
    }

    private fun hold() {
        assertEquals(Result.PASS, step(Action.DOWN, 0, top.id, top))
        assertEquals(Result.CAPTURE, step(Action.POINTER_DOWN, 90, bottom.id, top, bottom))
    }

    private fun arm() {
        hold()
        assertEquals(Result.CAPTURE, step(Action.POINTER_UP, 5_090, top.id, top, bottom))
        assertEquals(Result.CAPTURE, step(Action.UP, 5_150, bottom.id, bottom))
    }

    private fun step(action: Action, time: Long, id: Int, vararg fingers: Finger) =
        gesture.accept(action, time, id, fingers.toList(), .17f, .17f)
}
