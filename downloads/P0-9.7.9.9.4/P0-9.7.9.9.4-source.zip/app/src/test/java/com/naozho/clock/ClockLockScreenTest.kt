package com.naozho.clock

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Looper
import android.os.UserManager
import android.view.ViewGroup
import android.widget.TextClock
import com.naozho.clock.alarm.AlarmRuntime
import com.naozho.clock.mode.DesktopMode
import com.naozho.clock.mode.ModeState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = AlarmRuntime::class)
class ClockLockScreenTest {
    @Test
    fun homeRegistrationMatchesDirectBootAndKeepsTheLauncherSeparate() {
        val app = RuntimeEnvironment.getApplication()
        val pm = app.packageManager
        val home = ComponentName(app, MainActivity::class.java)
        val info = pm.getActivityInfo(home, PackageManager.MATCH_DIRECT_BOOT_AWARE)
        assertTrue(info.directBootAware && info.exported && info.enabled)
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addCategory(Intent.CATEGORY_DEFAULT)
        val hits = pm.queryIntentActivities(query, PackageManager.MATCH_DIRECT_BOOT_AWARE or PackageManager.GET_RESOLVED_FILTER)
        assertTrue(hits.any { it.activityInfo.name == home.className && it.filter.hasCategory(Intent.CATEGORY_DEFAULT) })
        val icon = ComponentName(app, com.naozho.clock.mode.ClockLauncherActivity::class.java)
        assertFalse(pm.getActivityInfo(icon, 0).directBootAware)
        assertFalse(hits.any { it.activityInfo.name == icon.className })
    }

    @Test
    fun firstUnlockResumesHomeWithoutChangingDesktopChoiceWhileUserStorageIsLocked() {
        val app = RuntimeEnvironment.getApplication()
        val user = shadowOf(app.getSystemService(UserManager::class.java))
        val prefs = app.getSharedPreferences("desktop_mode", Context.MODE_PRIVATE)
        val original = prefs.all.toMap()
        user.setUserUnlocked(false)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val controller = Robolectric.buildActivity(MainActivity::class.java, home).setup()
        val lockedHome = controller.get()
        val content = lockedHome.findViewById<ViewGroup>(android.R.id.content)
        assertTrue(content.getChildAt(0) is TextClock)
        assertFalse(shadowOf(lockedHome).showWhenLocked)
        assertFalse(shadowOf(lockedHome).turnScreenOn)
        lockedHome.onUserInteraction()
        lockedHome.onWindowFocusChanged(true)
        controller.newIntent(home)
        assertEquals(original, prefs.all)
        user.setUserUnlocked(true)
        app.sendBroadcast(Intent(Intent.ACTION_USER_UNLOCKED))
        shadowOf(Looper.getMainLooper()).idle()
        val unlockedContent = controller.get().findViewById<ViewGroup>(android.R.id.content)
        assertFalse(unlockedContent.getChildAt(0) is TextClock)
        controller.pause().stop().destroy()
    }

    @Test
    fun ordinaryForegroundClockCanShowAboveKeyguardWithoutPoweringOnDisplay() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).create()
        val window = shadowOf(activity.get())
        assertTrue(window.showWhenLocked)
        assertFalse(window.turnScreenOn)
        activity.destroy()
    }

    @Test
    fun androidModeAndDisabledLockScreenOptionDoNotShowAboveKeyguard() {
        val context = RuntimeEnvironment.getApplication()
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val state = ModeState(context)
        assertTrue(state.set(DesktopMode.ANDROID))
        val android = Robolectric.buildActivity(MainActivity::class.java, home).create()
        assertFalse(shadowOf(android.get()).showWhenLocked)
        android.destroy()

        assertTrue(state.set(DesktopMode.CLOCK))
        assertTrue(context.getSharedPreferences("clock_display", 0)
            .edit().putBoolean("showOnLockScreen", false).commit())
        val clock = Robolectric.buildActivity(MainActivity::class.java, home).create()
        assertFalse(shadowOf(clock.get()).showWhenLocked)
        clock.destroy()
    }
}
