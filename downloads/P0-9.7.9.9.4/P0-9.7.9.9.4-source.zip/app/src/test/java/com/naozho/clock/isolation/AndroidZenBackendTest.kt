package com.naozho.clock.isolation

import android.app.Application
import android.app.AutomaticZenRule
import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.net.Uri
import android.service.notification.ZenPolicy
import com.naozho.clock.alarm.AlarmAlerts
import com.naozho.clock.data.AlarmPlan
import com.naozho.clock.mode.DesktopMode
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class AndroidZenBackendTest {
    @Test
    fun modernPolicySilencesMessagesAndCallsAndPreservesAlarmsAndSystemSounds() {
        val zen = clockZenPolicy()
        assertEquals(ZenPolicy.STATE_ALLOW, zen.priorityCategoryAlarms)
        assertEquals(ZenPolicy.STATE_ALLOW, zen.priorityCategorySystem)
        assertEquals(ZenPolicy.STATE_DISALLOW, zen.priorityCategoryMessages)
        assertEquals(ZenPolicy.STATE_DISALLOW, zen.priorityCategoryCalls)
        assertEquals(ZenPolicy.STATE_DISALLOW, zen.priorityCategoryRepeatCallers)
        assertEquals(ZenPolicy.STATE_DISALLOW, zen.visualEffectPeek)
        assertEquals(ZenPolicy.STATE_DISALLOW, zen.visualEffectFullScreenIntent)
    }

    @Suppress("DEPRECATION")
    @Test
    fun typedRuleDoesNotModifyAnotherRuleOrTheOriginalNotificationPolicy() = runBlocking {
        val context = RuntimeEnvironment.getApplication()
        val manager = context.getSystemService(NotificationManager::class.java)
        shadowOf(manager).setNotificationPolicyAccessGranted(true)
        val original = NotificationManager.Policy(
            NotificationManager.Policy.PRIORITY_CATEGORY_MESSAGES,
            NotificationManager.Policy.PRIORITY_SENDERS_CONTACTS,
            NotificationManager.Policy.PRIORITY_SENDERS_STARRED,
            NotificationManager.Policy.SUPPRESSED_EFFECT_BADGE,
        )
        manager.notificationPolicy = original
        val user = manager.addAutomaticZenRule(AutomaticZenRule(
            "Existing rule", null, ComponentName(context, IsolationSettingsActivity::class.java),
            Uri.parse("condition://${context.packageName}/existing"), clockZenPolicy(),
            NotificationManager.INTERRUPTION_FILTER_PRIORITY, true,
        ))
        var mode = DesktopMode.CLOCK
        val clock = ClockIsolation(context, AndroidZenBackend(context)) { mode }
        assertEquals(IsolationPhase.REQUESTED, clock.reconcile().phase)
        assertEquals(2, manager.automaticZenRules.size)
        assertTrue(clock.handOffToAndroid { mode = DesktopMode.ANDROID; true })
        assertTrue(manager.getAutomaticZenRule(user).isEnabled)
        assertFalse(AndroidZenBackend(context).ownedRule()!!.enabled)
        assertEquals(original, manager.notificationPolicy)
    }

    @Test
    fun sameTimeNormalNotificationDoesNotChangeAlarmCategoryOrChannel() {
        val context = RuntimeEnvironment.getApplication()
        val manager = context.getSystemService(NotificationManager::class.java)
        val alerts = AlarmAlerts(context)
        alerts.createChannels()
        manager.createNotificationChannel(android.app.NotificationChannel("fixture", "Normal", NotificationManager.IMPORTANCE_HIGH))
        manager.notify(19, Notification.Builder(context, "fixture").setSmallIcon(android.R.drawable.ic_dialog_email)
            .setCategory(Notification.CATEGORY_MESSAGE).build())
        val plan = AlarmPlan(
            id = "isolated-alarm", label = "Alarm", hour = 7, minute = 0, weekdays = 0,
            enabled = true, activeAt = 1L,
        )
        alerts.show(plan)
        val notifications = manager.activeNotifications.associateBy { it.id }
        assertEquals(Notification.CATEGORY_MESSAGE, notifications.getValue(19).notification.category)
        val alarm = notifications.values.single { it.notification.category == Notification.CATEGORY_ALARM }.notification
        assertEquals(Notification.CATEGORY_ALARM, alarm.category)
        assertEquals(AlarmAlerts.RING_CHANNEL, alarm.channelId)
    }
}
