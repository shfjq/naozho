package com.naozho.clock.device

import java.util.Calendar
import java.util.GregorianCalendar
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ClockSnapshotTest {
    @Test
    fun midnightUsesZeroHourAndCorrectCalendarDate() {
        val instant = calendar("Asia/Shanghai", 2024, Calendar.MARCH, 3, 0, 5)

        assertEquals(
            ClockSnapshot("00:05", 2024, 3, 3, Calendar.SUNDAY - Calendar.SUNDAY, 76),
            ClockSnapshot.from(instant, 76),
        )
    }

    @Test
    fun sameInstantUsesTheSuppliedTimeZoneAcrossMidnight() {
        val utc = calendar("UTC", 2024, Calendar.FEBRUARY, 29, 17, 9)
        val local = GregorianCalendar(TimeZone.getTimeZone("Asia/Shanghai")).apply {
            timeInMillis = utc.timeInMillis
        }

        assertEquals(
            ClockSnapshot("17:09", 2024, 2, 29, Calendar.THURSDAY - Calendar.SUNDAY, null),
            ClockSnapshot.from(utc, null),
        )
        assertEquals(
            ClockSnapshot("01:09", 2024, 3, 1, Calendar.FRIDAY - Calendar.SUNDAY, null),
            ClockSnapshot.from(local, null),
        )
    }

    @Test
    fun batteryUsesAndroidScaleAndRoundsToNearestPercent() {
        assertEquals(0, batteryPercentage(0, 100))
        assertEquals(33, batteryPercentage(1, 3))
        assertEquals(67, batteryPercentage(2, 3))
        assertEquals(100, batteryPercentage(Int.MAX_VALUE, Int.MAX_VALUE))
    }

    @Test
    fun missingOrOutOfRangeBatteryExtrasReturnUnknown() {
        assertNull(batteryPercentage(-1, 100))
        assertNull(batteryPercentage(1, 0))
        assertNull(batteryPercentage(1, -1))
        assertNull(batteryPercentage(101, 100))
    }

    private fun calendar(
        zone: String,
        year: Int,
        month: Int,
        day: Int,
        hour: Int,
        minute: Int,
    ): Calendar = GregorianCalendar(TimeZone.getTimeZone(zone)).apply {
        clear()
        set(year, month, day, hour, minute)
    }
}
