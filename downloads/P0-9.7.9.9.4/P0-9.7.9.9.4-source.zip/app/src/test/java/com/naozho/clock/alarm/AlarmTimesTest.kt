package com.naozho.clock.alarm

import com.naozho.clock.data.AlarmPlan
import java.time.Instant
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AlarmTimesTest {
    @Test
    fun springGapShiftsForwardAndFallOverlapUsesEarlierOffset() {
        val berlin = ZoneId.of("Europe/Berlin")
        val alarm = AlarmPlan("daily", "", 2, 30, 127, true)
        assertEquals(at("2026-03-29T01:30:00Z"), AlarmTimes.next(alarm, at("2026-03-29T00:00:00Z"), berlin))
        assertEquals(at("2026-10-25T00:30:00Z"), AlarmTimes.next(alarm, at("2026-10-25T00:00:00Z"), berlin))
        val fired = AlarmTimes.localDay(at("2026-10-25T00:30:00Z"), berlin)
        assertEquals(
            at("2026-10-26T01:30:00Z"),
            AlarmTimes.next(alarm.copy(lastDay = fired), at("2026-10-25T01:00:00Z"), berlin),
        )
    }

    @Test
    fun onceChoosesTomorrowAfterTheSelectedMinute() {
        val utc = ZoneId.of("UTC")
        val alarm = AlarmPlan("once", "", 23, 59, 0, true)
        val now = at("2026-11-22T23:59:00Z")
        val stored = alarm.copy(onceDay = AlarmTimes.onceDay(alarm, now, utc))
        assertEquals(at("2026-11-23T23:59:00Z"), AlarmTimes.next(stored, now, utc))
        assertNull(AlarmTimes.next(stored, at("2026-11-24T00:00:00Z"), utc))
    }

    private fun at(instant: String) = Instant.parse(instant).toEpochMilli()
}
