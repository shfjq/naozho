package com.naozho.clock.mode

import android.app.Activity
import android.app.ActivityManager
import android.app.Application
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.provider.Settings
import com.naozho.clock.display.ClockDeviceAdmin
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class DesktopModeTest {
    private val context: Application get() = RuntimeEnvironment.getApplication()

    @Test
    fun sameBootPreservesAndroidModeAndRebootRestoresClockWithoutDroppingSettings() {
        val store = ModeState(context)
        val original = ComponentName("org.phone.home", "org.phone.home.Home")
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 12)
        assertEquals(DesktopMode.CLOCK, store.current())
        assertTrue(store.saveHome(original))
        assertTrue(store.saveDeployment(true, DesktopMode.CLOCK))
        assertTrue(store.set(DesktopMode.ANDROID))
        assertEquals(DesktopMode.ANDROID, ModeState(context).current())

        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 13)
        assertEquals(DesktopMode.CLOCK, ModeState(context).current())
        assertEquals(original, store.selectedHome())
        assertTrue(store.managedLock())
        assertTrue(store.managesHome())
        assertTrue(store.set(DesktopMode.ANDROID))
        store.syncBoot(completed = true)
        assertEquals(DesktopMode.ANDROID, store.current())
    }

    @Test
    fun opensAnExportedHomeAndUsesAnExplicitComponent() {
        val original = addHome("org.phone.home", system = true, priority = 10)
        addHome("org.unrelated.userhome", system = false)
        addHome("org.unrelated.privatehome", system = true, exported = false)
        addHome("org.fallback.home", system = true, priority = -1000)
        val homes = NativeDesktop(context)
        assertEquals(original, homes.target(null))
        assertNull(homes.target(ComponentName(context.packageName, "${context.packageName}.MainActivity")))
        assertTrue(homes.open(ComponentName("org.unknown.home", ".Missing")) is DesktopResult.Rejected)
        assertEquals(DesktopResult.Applied, homes.open(null))
        val intent = shadowOf(context).nextStartedActivity
        assertEquals(original, intent.component)
        assertTrue(intent.hasCategory(Intent.CATEGORY_HOME))
        assertTrue(intent.flags and Intent.FLAG_ACTIVITY_NEW_TASK != 0)
    }

    @Test
    fun savesTheEffectiveOemHomeEvenWithoutASystemFlag() {
        val freeme = addHome("com.droiclaw.launcher3", system = false, className = "com.freeme.launcher.FreemeLauncher")
        val homes = NativeDesktop(context)
        assertEquals(freeme, homes.target(null))
        val store = ModeState(context)
        assertTrue(store.saveHome(freeme))

        // Selecting the clock as default does not remove the previously saved HOME.
        addHome(context.packageName, system = false, priority = 10)
        addHome("org.unrelated.userhome", system = false)
        assertNull(homes.target(null))
        assertEquals(listOf(freeme), homes.candidates(store.selectedHome()).map(NativeHome::component))
        assertEquals(DesktopResult.Applied, homes.open(store.selectedHome()))
        assertEquals(freeme, shadowOf(context).nextStartedActivity.component)
        assertTrue(homes.open(null) is DesktopResult.Rejected)
    }

    @Test
    fun multipleNativeHomesRequireASelectionAndUnmanagedAppCannotApplyPolicy() = runBlocking {
        val first = addHome("org.first.home", system = true)
        addHome("org.second.home", system = true)
        val homes = NativeDesktop(context)
        assertNull(homes.target(null))
        assertEquals(first, homes.target(first))
        val desktop = ManagedDesktop(context)
        assertFalse(desktop.owner)
        assertTrue(desktop.allowClock() is DesktopResult.Rejected)
    }

    @Test
    fun activeAdminAloneHasNeitherOwnerIdentityNorLockTaskAuthorization() = runBlocking {
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        shadowOf(policy).setActiveAdmin(ComponentName(context, ClockDeviceAdmin::class.java))
        val desktop = ManagedDesktop(context)
        assertTrue(desktop.activeAdmin)
        assertFalse(desktop.owner)
        assertFalse(desktop.profileOwner)
        assertFalse(desktop.permitted)
        assertFalse(desktop.dedicatedReady)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, desktop.state)
        assertTrue(desktop.allowClock() is DesktopResult.Rejected)
    }

    @Test
    fun ownerAllowlistingRejectsOtherPackagesWithoutOverwritingThem() = runBlocking {
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        assertTrue(shadowOf(policy).setDeviceOwner(admin))
        policy.setLockTaskPackages(admin, arrayOf("org.existing.managed"))
        policy.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_GLOBAL_ACTIONS or
            DevicePolicyManager.LOCK_TASK_FEATURE_HOME or DevicePolicyManager.LOCK_TASK_FEATURE_OVERVIEW or
            DevicePolicyManager.LOCK_TASK_FEATURE_NOTIFICATIONS)
        val desktop = ManagedDesktop(context)
        assertTrue(desktop.allowClock() is DesktopResult.Rejected)
        assertEquals(setOf("org.existing.managed"), policy.getLockTaskPackages(admin).toSet())
        policy.setLockTaskPackages(admin, emptyArray())
        assertEquals(DesktopResult.Applied, desktop.allowClock())
        assertTrue(desktop.dedicatedReady)
        assertEquals(setOf(context.packageName), policy.getLockTaskPackages(admin).toSet())
        val kioskFeatures = policy.getLockTaskFeatures(admin)
        assertEquals(
            DevicePolicyManager.LOCK_TASK_FEATURE_GLOBAL_ACTIONS or
                DevicePolicyManager.LOCK_TASK_FEATURE_BLOCK_ACTIVITY_START_IN_TASK,
            kioskFeatures,
        )
        assertEquals(80, kioskFeatures)
        assertEquals(0, kioskFeatures and DevicePolicyManager.LOCK_TASK_FEATURE_NOTIFICATIONS)
    }

    @Test
    fun removalFromAllowlistKeepsDeviceOwnerAndPreservesOtherEntries() = runBlocking {
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        assertTrue(shadowOf(policy).setDeviceOwner(admin))
        policy.setLockTaskPackages(admin, arrayOf(context.packageName, "org.existing.managed"))
        val desktop = ManagedDesktop(context)
        assertTrue(desktop.disallowClock("test"))
        assertTrue(desktop.owner)
        assertFalse(desktop.permitted)
        assertEquals(setOf("org.existing.managed"), policy.getLockTaskPackages(admin).toSet())
    }

    @Test
    fun deviceOwnerCannotDisableASecureKeyguardThroughTheApp() {
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        val desktop = ManagedDesktop(context)
        assertFalse(desktop.setUnsecuredKeyguardDisabled(true))
        assertTrue(shadowOf(policy).setDeviceOwner(admin))
        shadowOf(context.getSystemService(KeyguardManager::class.java)).setIsDeviceSecure(true)
        assertFalse(desktop.setUnsecuredKeyguardDisabled(true))
    }

    @Test
    fun deploymentRestoresEffectiveFreemeAndReassertsClockAfterReboot() = runBlocking {
        val freeme = addHome("com.droiclaw.launcher3", system = true, priority = 10, className = "com.freeme.launcher.FreemeLauncher")
        val desktop = ManagedDesktop(context)
        addHome(context.packageName, system = false, className = desktop.clockHome.className)
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        assertTrue(shadowOf(policy).setDeviceOwner(ComponentName(context, ClockDeviceAdmin::class.java)))
        val store = ModeState(context)
        assertTrue(store.saveHome(freeme))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 4)
        val deployment = ManagedDeployment(context)

        assertEquals(DesktopResult.Applied, deployment.enable())
        assertEquals(desktop.clockHome, desktop.effectiveHome())
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.ANDROID))
        assertEquals(freeme, desktop.effectiveHome())
        assertTrue(desktop.owner)
        assertTrue(desktop.dedicatedReady)
        assertEquals(DesktopResult.Applied, ManagedDeployment(context).reconcileHome())
        assertEquals(freeme, desktop.effectiveHome())

        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        policy.setLockTaskPackages(admin, emptyArray())
        policy.setLockTaskFeatures(admin, 112) // Policy from a pre-0.6.6 full deployment.
        assertEquals(DesktopResult.Applied, deployment.recoverManagedClock())
        assertEquals(freeme, desktop.effectiveHome())
        assertFalse(desktop.permitted)
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 5)
        assertEquals(DesktopResult.Applied, deployment.recoverManagedClock())
        assertEquals(desktop.clockHome, desktop.effectiveHome())
        assertTrue(desktop.dedicatedReady)
        assertEquals(DesktopMode.CLOCK, store.current())
        assertEquals(80, policy.getLockTaskFeatures(admin))
        assertEquals(DesktopResult.Applied, deployment.pause())
        assertEquals(freeme, desktop.effectiveHome())
        assertTrue(desktop.owner)
        assertFalse(store.managesHome())
        assertFalse(desktop.permitted)
    }

    @Test
    fun missingNativeHomeBlocksHandoffButStillAllowsMaintenanceToPauseKiosk() = runBlocking {
        val desktop = ManagedDesktop(context)
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        assertTrue(shadowOf(policy).setDeviceOwner(ComponentName(context, ClockDeviceAdmin::class.java)))
        assertEquals(DesktopResult.Applied, desktop.allowClock())
        val store = ModeState(context)
        assertTrue(store.saveHome(ComponentName("org.missing.home", "org.missing.home.Home")))
        assertTrue(store.saveDeployment(true, DesktopMode.CLOCK))
        val deployment = ManagedDeployment(context)
        assertTrue(deployment.switchTo(DesktopMode.ANDROID) is DesktopResult.Rejected)
        assertEquals(DesktopMode.CLOCK, store.current())
        assertTrue(deployment.pause() is DesktopResult.Rejected) // The saved Home cannot be restored, but the kiosk is paused.
        assertFalse(store.managedLock())
        assertFalse(desktop.permitted)
        assertTrue(desktop.owner)
    }

    @Test
    fun startingLockTaskNeverWritesPolicyAndPinningIsNotAcceptedAsManagedLock() = runBlocking {
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        assertTrue(shadowOf(policy).setDeviceOwner(admin))
        val desktop = ManagedDesktop(context)
        val tasks = shadowOf(context.getSystemService(ActivityManager::class.java))
        val activity = Robolectric.buildActivity(Activity::class.java).create()
        assertTrue(desktop.start(activity.get()) is DesktopResult.Rejected)
        assertTrue(policy.getLockTaskPackages(admin).isEmpty())
        assertEquals(DesktopResult.Applied, desktop.allowClock())
        policy.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_HOME)
        assertTrue(desktop.start(activity.get()) is DesktopResult.Rejected)
        assertEquals(DevicePolicyManager.LOCK_TASK_FEATURE_HOME, policy.getLockTaskFeatures(admin))
        assertEquals(DesktopResult.Applied, desktop.allowClock())
        tasks.setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_PINNED)
        assertTrue(desktop.start(activity.get()) is DesktopResult.Rejected)
        assertFalse(desktop.leave(activity.get()))
        assertFalse(desktop.restrictsNotificationShade())
        tasks.setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_LOCKED)
        assertTrue(desktop.start(activity.get()) is DesktopResult.Rejected)
        assertTrue(desktop.restrictsNotificationShade())
        tasks.setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_NONE)
        assertTrue(desktop.leave(activity.get()))
        activity.destroy()
        Unit
    }

    @Suppress("DEPRECATION")
    private fun addHome(
        pkg: String, system: Boolean, exported: Boolean = true, priority: Int = 0, className: String = "$pkg.Home",
    ): ComponentName {
        val component = ComponentName(pkg, className)
        val info = ActivityInfo().apply {
            packageName = pkg
            name = component.className
            enabled = true
            this.exported = exported
            applicationInfo = ApplicationInfo().apply {
                packageName = pkg
                flags = if (system) ApplicationInfo.FLAG_SYSTEM else 0
            }
        }
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = ResolveInfo().apply {
            activityInfo = info
            isDefault = true
            this.priority = priority
            nonLocalizedLabel = pkg
            filter = IntentFilter(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
            }
        }
        val pm = shadowOf(context.packageManager)
        val canonical = Intent(intent).addCategory(Intent.CATEGORY_DEFAULT)
        pm.addResolveInfoForIntent(intent, resolved)
        pm.addResolveInfoForIntent(canonical, resolved)
        pm.addResolveInfoForIntent(Intent(canonical).setPackage(pkg), resolved)
        return component
    }
}
