package com.naozho.clock.mode

import android.app.admin.DevicePolicyIdentifiers
import android.app.admin.PolicyUpdateReceiver
import android.app.admin.PolicyUpdateResult
import android.app.admin.TargetUser
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import android.util.Base64
import java.io.File
import org.json.JSONObject
import androidx.core.os.bundleOf
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.yield
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class HomePolicyTransactionTest {
    private val context: Context = RuntimeEnvironment.getApplication()
    private val clock = ComponentName(context.packageName, "${context.packageName}.MainActivity")
    private val native = ComponentName("com.droiclaw.launcher3", "com.freeme.launcher.FreemeLauncher")
    private val tx = HomePolicyTransaction(context)
    private val writes = mutableListOf<String>()
    private val key = DevicePolicyIdentifiers.PERSISTENT_PREFERRED_ACTIVITY_POLICY
    private val filter = IntentFilter(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_HOME)
        addCategory(Intent.CATEGORY_DEFAULT)
    }
    private val set = PolicyUpdateResult.RESULT_POLICY_SET
    private val cleared = PolicyUpdateResult.RESULT_POLICY_CLEARED

    private fun callback(code: Int, event: String = "set-result", policy: String = key,
        user: TargetUser = TargetUser.LOCAL_USER, match: IntentFilter = filter) =
        HomePolicyResults.receive(event, policy, match, user, code)

    private suspend fun change(target: ComponentName?, value: HomePolicyTransaction = tx, refresh: Boolean = false) =
        value.apply(native, clock, target, "test", refresh, { native }, { writes.add("clear:$it") },
            { writes.add("set:${it.packageName}") })

    @Test fun verifiesBothPhasesAndIgnoresOtherUsersFiltersChangesAndLateResults() = runBlocking {
        assertTrue(tx.audit(native, native))
        val op = async(start = CoroutineStart.UNDISPATCHED) { change(clock) }
        assertEquals(listOf("clear:${native.packageName}"), writes)
        callback(set)
        callback(cleared, event = "changed")
        callback(cleared, policy = DevicePolicyIdentifiers.LOCK_TASK_POLICY)
        callback(cleared, user = TargetUser.PARENT_USER)
        callback(cleared, match = IntentFilter(filter).apply { addDataScheme("https") })
        yield()
        assertEquals(1, writes.size)
        // Deliver an actual framework-shaped broadcast, through the production receiver.
        ClockPolicyReceiver().onReceive(context, Intent(PolicyUpdateReceiver.ACTION_DEVICE_POLICY_SET_RESULT)
            .putExtra("android.app.admin.extra.POLICY_KEY", key)
            .putExtra("android.app.admin.extra.POLICY_TARGET_USER_ID", -1)
            .putExtra("android.app.admin.extra.POLICY_UPDATE_RESULT_KEY", cleared)
            .putExtra("android.app.admin.extra.POLICY_BUNDLE_KEY",
                bundleOf(PolicyUpdateReceiver.EXTRA_INTENT_FILTER to filter)))
        yield()
        assertEquals(listOf("clear:${native.packageName}", "set:${clock.packageName}"), writes)
        callback(cleared)
        yield()
        assertFalse(op.isCompleted)
        callback(set)
        assertEquals(DesktopResult.Applied, op.await())
        assertFalse(tx.verified(clock)) // Effective HOME is verified separately by ManagedDesktop.
        assertTrue(tx.verify(clock))
        val back = async(start = CoroutineStart.UNDISPATCHED) { change(native) }
        assertFalse(tx.verified(clock))
        assertEquals("clear:${clock.packageName}", writes.last())
        callback(cleared); yield()
        assertEquals("set:${native.packageName}", writes.last())
        callback(set)
        assertEquals(DesktopResult.Applied, back.await())
        assertTrue(callback(set).contains("unattributed"))
    }

    @Test fun inspectionMustBeFreshForThisUserAndSelectionAndCanBeImportedOnlyOnce() {
        assertTrue(tx.audit(native, clock))
        assertTrue(tx.verify(clock))
        assertTrue(tx.prepareInspection())
        assertFalse(tx.hasKnownScope(native))
        assertFalse(tx.verified(clock))
        val nonce = File(context.filesDir, "home-policy-challenge").readText()
        val auditFile = File(context.filesDir, "home-policy-audit.txt")
        val data = JSONObject().put("user", 0).put("nonce", nonce).put("native", native.flattenToString())
            .put("previous", native.flattenToString()).put("elapsed", SystemClock.elapsedRealtime())
        fun submit(): DesktopResult {
            auditFile.writeText(Base64.encodeToString(data.toString().toByteArray(), Base64.NO_WRAP))
            return tx.importInspection(native, clock)
        }
        for ((field, invalid) in listOf("nonce" to "old", "user" to 10, "native" to clock.flattenToString(),
            "previous" to "another/another.Main", "elapsed" to (SystemClock.elapsedRealtime() - 300_001L))) {
            val original = data.get(field)
            data.put(field, invalid)
            assertTrue(submit() is DesktopResult.Rejected)
            assertFalse(tx.hasKnownScope(native))
            data.put(field, original)
        }
        assertEquals(DesktopResult.Applied, submit())
        assertTrue(tx.hasKnownScope(native))
        assertFalse(tx.verified(native))
        assertTrue(submit() is DesktopResult.Rejected)
    }

    @Test fun reapplyingAnIneffectiveExistingKeyRemovesItBeforeTheNewSet() = runBlocking {
        assertTrue(tx.audit(native, clock))
        val op = async(start = CoroutineStart.UNDISPATCHED) { change(clock, refresh = true) }
        assertEquals(listOf("clear:${clock.packageName}"), writes)
        callback(cleared)
        yield()
        assertEquals(listOf("clear:${clock.packageName}", "set:${clock.packageName}"), writes)
        callback(set)
        assertEquals(DesktopResult.Applied, op.await())
    }

    @Test fun missingOrChangedScopeDoesNotWriteAndClearOnlyDoesNotSet() = runBlocking {
        assertTrue(change(clock) is DesktopResult.Rejected)
        assertTrue(tx.audit(ComponentName("other", "other.Home"), native))
        assertTrue(change(clock) is DesktopResult.Rejected)
        assertTrue(writes.isEmpty())
        assertTrue(tx.audit(native, native))
        val clear = async(start = CoroutineStart.UNDISPATCHED) { change(null) }
        callback(cleared)
        assertEquals(DesktopResult.Applied, clear.await())
        assertEquals(DesktopResult.Applied, change(null, HomePolicyTransaction(context)))
        assertEquals(listOf("clear:${native.packageName}"), writes)
    }

    @Test fun conflictAndTimeoutFenceRetriesAndLateResultsCannotAuthorizeANewWrite() = runBlocking {
        assertTrue(tx.audit(native, native))
        val clear = async(start = CoroutineStart.UNDISPATCHED) { change(clock) }
        callback(PolicyUpdateResult.RESULT_FAILURE_CONFLICTING_ADMIN_POLICY)
        assertTrue(clear.await() is DesktopResult.Rejected)
        assertTrue(change(native) is DesktopResult.Rejected)
        assertEquals(listOf("clear:${native.packageName}"), writes)
        // DSH has now inspected the actual post-conflict state and drained broadcasts.
        assertTrue(tx.audit(native, null))
        assertTrue(change(clock) is DesktopResult.Rejected)
        assertTrue(callback(set).contains("unattributed"))
        assertTrue(change(native, HomePolicyTransaction(context)) is DesktopResult.Rejected)
        assertEquals(listOf("clear:${native.packageName}", "set:${clock.packageName}"), writes)
    }
}
