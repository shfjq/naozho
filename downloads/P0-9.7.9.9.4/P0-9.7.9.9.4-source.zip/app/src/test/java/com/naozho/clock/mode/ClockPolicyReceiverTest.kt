package com.naozho.clock.mode

import android.app.Application
import android.app.admin.DevicePolicyIdentifiers
import android.app.admin.PolicyUpdateReceiver
import android.app.admin.PolicyUpdateResult
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import androidx.core.os.bundleOf
import com.naozho.clock.MainActivity
import com.naozho.clock.R
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLog

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
@Suppress("DEPRECATION")
class ClockPolicyReceiverTest {
    private val context: Application get() = RuntimeEnvironment.getApplication()

    @Test
    fun distinctLauncherAndHomeAreDiscoverableWithCorrectLabels() {
        val clock = ComponentName(context, MainActivity::class.java)
        val launcher = ComponentName(context, ClockLauncherActivity::class.java)
        val pm = context.packageManager
        val entries = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER).setPackage(context.packageName), 0)
        val entry = entries.single { it.activityInfo.name == launcher.className }
        assertEquals("小方块时钟", entry.loadLabel(pm).toString())
        assertEquals(R.string.app_name, entry.activityInfo.labelRes)
        assertEquals(R.drawable.ic_clock, entry.activityInfo.icon)
        assertFalse(entries.any { it.activityInfo.name == clock.className })
        if (context.isDevelopmentBuild) assertEquals(1, entries.size)
        val resolvedHome = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME).addCategory(Intent.CATEGORY_DEFAULT),
            PackageManager.MATCH_DEFAULT_ONLY or PackageManager.GET_RESOLVED_FILTER)
            .single { it.activityInfo.name == clock.className && it.activityInfo.packageName == clock.packageName }
        assertEquals(ActivityInfo.LAUNCH_SINGLE_TASK, resolvedHome.activityInfo.launchMode)
        assertTrue(resolvedHome.activityInfo.enabled)
        assertTrue(resolvedHome.activityInfo.exported)
        assertTrue(resolvedHome.isDefault)
        val filter = requireNotNull(resolvedHome.filter)
        assertTrue(filter.hasAction(Intent.ACTION_MAIN))
        assertTrue(filter.hasCategory(Intent.CATEGORY_HOME))
        assertTrue(filter.hasCategory(Intent.CATEGORY_DEFAULT))
    }

    @Test
    fun policyBroadcastsRefreshActualStateAndLogPolicyUserAndResult() {
        val result = PolicyUpdateReceiver.ACTION_DEVICE_POLICY_SET_RESULT
        val changed = PolicyUpdateReceiver.ACTION_DEVICE_POLICY_CHANGED
        val before = DesktopPolicyUpdates.revision.value
        val receiver = ClockPolicyReceiver()
        for (action in listOf(result, changed)) {
            val info = context.packageManager.queryBroadcastReceivers(Intent(action).setPackage(context.packageName), 0)
                .single().activityInfo
            assertEquals(ClockPolicyReceiver::class.java.name, info.name)
            assertEquals("android.permission.BIND_DEVICE_ADMIN", info.permission)
            assertTrue(info.exported)
            val policy = if (action == result) DevicePolicyIdentifiers.PERSISTENT_PREFERRED_ACTIVITY_POLICY
            else DevicePolicyIdentifiers.LOCK_TASK_POLICY
            val code = if (action == result) PolicyUpdateResult.RESULT_POLICY_SET
            else PolicyUpdateResult.RESULT_FAILURE_CONFLICTING_ADMIN_POLICY
            val filter = IntentFilter(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_HOME) }
            // Construct framework callback input for the routing test, without sending a broadcast.
            receiver.onReceive(context, Intent(action)
                .putExtra("android.app.admin.extra.POLICY_KEY", policy)
                .putExtra("android.app.admin.extra.POLICY_TARGET_USER_ID", -1)
                .putExtra("android.app.admin.extra.POLICY_UPDATE_RESULT_KEY", code)
                .putExtra("android.app.admin.extra.POLICY_BUNDLE_KEY", bundleOf(PolicyUpdateReceiver.EXTRA_INTENT_FILTER to filter)))
            assertTrue(ShadowLog.getLogsForTag("NaozhoMode").any {
                it.msg.contains("policy=$policy target=LOCAL(") && it.msg.contains("result=$code homeFilter=true")
            })
        }
        assertEquals(before + 2, DesktopPolicyUpdates.revision.value)
        assertEquals(2, ShadowLog.getLogsForTag("NaozhoMode").count { it.msg.contains("operation=unattributed") })
    }
}
