package com.naozho.clock.display

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.provider.Settings
import com.naozho.clock.MainActivity
import com.naozho.clock.mode.ClockLauncherActivity
import com.naozho.clock.weather.WeatherLocation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class ScreenControlsTest {
    @Test
    fun mainActivityIsAnExportedDirectHomeWithSeparateLauncherEntry() {
        val context = RuntimeEnvironment.getApplication()
        val controls = ScreenControls(context)
        val manager = context.packageManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val localHome = Intent(home).addCategory(Intent.CATEGORY_DEFAULT).setPackage(context.packageName)
        val offered = manager.queryIntentActivities(localHome, PackageManager.MATCH_DEFAULT_ONLY).single()
        assertEquals(MainActivity::class.java.name, offered.activityInfo.name)
        assertTrue(offered.activityInfo.exported)
        assertNull(offered.activityInfo.targetActivity)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(context.packageName)
        val launchers = manager.queryIntentActivities(launcher, 0).map { it.activityInfo.name }
        assertTrue(ClockLauncherActivity::class.java.name in launchers)
        assertFalse(MainActivity::class.java.name in launchers)
        assertEquals(Settings.ACTION_HOME_SETTINGS, controls.homeSettings().action)
        assertNull(controls.homeSettings().component)
    }

    @Test
    fun currentHomeIsReadFromAndroidAndUpdatesAfterSwitchingBack() {
        val context = RuntimeEnvironment.getApplication()
        val controls = ScreenControls(context)
        val manager = context.packageManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val canonical = Intent(home).addCategory(Intent.CATEGORY_DEFAULT)
        val clock = manager.queryIntentActivities(Intent(canonical).setPackage(context.packageName),
            PackageManager.MATCH_DEFAULT_ONLY).single()
        val stock = ResolveInfo().apply {
            isDefault = true
            activityInfo = ActivityInfo().apply {
                packageName = "example.stock.launcher"
                name = "example.stock.launcher.Home"
                enabled = true
                exported = true
                applicationInfo = ApplicationInfo().apply { packageName = "example.stock.launcher" }
            }
        }
        val system = shadowOf(manager)
        system.setResolveInfosForIntent(canonical, listOf(stock, clock))
        assertEquals(setOf("example.stock.launcher", context.packageName),
            manager.queryIntentActivities(canonical, PackageManager.MATCH_DEFAULT_ONLY).map { it.activityInfo.packageName }.toSet())
        system.setResolveInfosForIntent(home, listOf(stock))
        assertFalse(controls.capabilities().defaultHome)
        system.setResolveInfosForIntent(home, listOf(clock))
        assertTrue(controls.capabilities().defaultHome)
        system.setResolveInfosForIntent(home, listOf(stock))
        assertFalse(controls.capabilities().defaultHome)
    }

    @Test
    fun lockingRequiresTheAppOwnAdminAndCanBeRevoked() {
        val context = RuntimeEnvironment.getApplication()
        shadowOf(context.packageManager).setSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN, true)
        val controls = ScreenControls(context)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        assertEquals(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN, controls.requestAdmin().action)
        assertFalse(controls.lock())
        shadowOf(context.getSystemService(DevicePolicyManager::class.java)).setActiveAdmin(admin)
        assertTrue(controls.capabilities().activeAdmin)
        assertFalse(controls.capabilities().deviceOwner)
        assertTrue(controls.lock())
        controls.revokeAdmin()
        assertFalse(controls.lock())
    }

    @Test
    fun deviceOwnerStatusIsReadFromDevicePolicyManager() {
        val context = RuntimeEnvironment.getApplication()
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        val controls = ScreenControls(context)
        assertFalse(controls.capabilities().deviceOwner)
        assertTrue(shadowOf(context.getSystemService(DevicePolicyManager::class.java)).setDeviceOwner(admin))
        assertTrue(controls.capabilities().deviceOwner)
    }

    @Test
    fun displayAndLocationSettingsSurviveActivityRecreation() {
        val prefs = RuntimeEnvironment.getApplication().getSharedPreferences("p2-display-test", 0)
        val saved = DisplaySettings(540, 1170, 22, 45, false, WeatherLocation("上海", 31.23, 121.47))
        DisplayPreferences(prefs).save(saved)
        assertEquals(saved, DisplayPreferences(prefs).state.value)
    }
}
