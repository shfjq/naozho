package com.naozho.clock.mode

import android.content.Context

@Suppress("UNUSED_PARAMETER")
internal object WakePreviewRelease {
    fun handoff(context: Context, ticket: WakeTicket) = Unit
    fun cancel(context: Context, ticket: WakeTicket) = Unit
}
