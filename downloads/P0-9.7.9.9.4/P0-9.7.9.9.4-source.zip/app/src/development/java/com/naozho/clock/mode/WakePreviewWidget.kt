package com.naozho.clock.mode

import android.app.Activity
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.util.Log
import android.view.Display
import android.view.View
import android.widget.RemoteViews
import com.naozho.clock.R
import java.io.File

/** The launcher renders these RemoteViews within a user-placed HOME widget. No WindowManager or
 * input token, focus, Return, LockTask, shell access or PendingIntent in either widget layout. */
class WakePreviewWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val app = context.applicationContext
        // System updates can arrive when a stopped host resumes. Do not erase its
        // existing, unexpired cached layout or count a second preview submission.
        val key = active(app)
        val keep = key != null && !closed(app, key) && bootCount(app) == key.boot && !expired(app) &&
            (modeAllows(app, key) || handingOff(app, key))
        if (!keep && key != null) clear(app)
        val blank = ids.filter { !keep || it.toString() !in approved(context) }.toIntArray()
        if (blank.isNotEmpty()) manager.updateAppWidget(blank, views(context, false))
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        val left = approved(context) - ids.map(Int::toString).toSet()
        store(context).edit().putStringSet(IDS, left).commit()
        if (left.isEmpty()) {
            present(context).delete()
            clear(context)
        }
    }

    override fun onDisabled(context: Context) {
        clear(context)
        present(context).delete()
        store(context).edit().remove(IDS).commit()
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == EXPIRY) {
            alarmFired(context.applicationContext, Key(intent.getIntExtra(EXTRA_BOOT_COUNT, -1),
                intent.getLongExtra("dark_elapsed", -1)), intent.getStringExtra("lease_phase"))
        } else super.onReceive(context, intent)
    }

    companion object {
        private const val HOME = "com.droiclaw.launcher3"
        private const val IDS = "approved_home_widget_ids"
        private const val EXPIRY = "com.naozho.clock.action.EXPIRE_HOME_PREVIEW"
        private const val DARK_CHECK_MS = 2500L
        private const val ON_LEASE_MS = 16_000L // 3 s settling + 12 s ticket lifetime + 1 s render margin
        private const val DARK_LIMIT_MS = 12L * 60 * 60 * 1000
        private const val DARK_CHECK = "dark_check"
        private const val HARD = "hard"
        private const val ON = "on"
        private const val CLEAR_RETRY = "clear_retry"
        private val main = Handler(Looper.getMainLooper())
        private var waiting: Watch? = null
        private var observedPrefs: SharedPreferences? = null
        private var modeListener: SharedPreferences.OnSharedPreferenceChangeListener? = null

        private data class Key(val boot: Int, val dark: Long)
        private fun store(c: Context) = c.getSharedPreferences("home_visual_preview", Context.MODE_PRIVATE)
        private fun approved(c: Context) = store(c).getStringSet(IDS, emptySet()).orEmpty()
        private fun present(c: Context) = File(c.createDeviceProtectedStorageContext().filesDir, "wake-preview-widget.present")
        private fun component(c: Context) = ComponentName(c, WakePreviewWidget::class.java)
        internal fun views(c: Context, shown: Boolean): RemoteViews =
            if (!shown) RemoteViews(c.packageName, R.layout.wake_preview_empty)
            else RemoteViews(c.packageName, R.layout.wake_preview_clock).apply {
                setViewVisibility(R.id.wake_preview_root, View.VISIBLE)
            }

        private fun mainThread(action: () -> Unit) {
            val guarded = Runnable {
                try { action() } catch (e: RuntimeException) {
                    Log.w("NaozhoWakePreview", "Home preview unavailable: " + e.javaClass.simpleName)
                }
            }
            if (Looper.myLooper() == Looper.getMainLooper()) guarded.run() else main.post(guarded)
        }

        private fun freeme(c: Context): Boolean {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            return c.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == HOME
        }

        private fun homeCategory(mgr: AppWidgetManager, id: Int): Boolean =
            mgr.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_HOST_CATEGORY,
                AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) == AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN

        internal fun bind(c: Context, caller: String?, id: Int): Boolean {
            if (Build.VERSION.SDK_INT < 34 || caller != HOME || id <= 0 || !freeme(c)) {
                Log.i("NaozhoWakePreview", "Home widget configuration refused: host_or_home")
                return false
            }
            val mgr = AppWidgetManager.getInstance(c)
            if (id !in mgr.getAppWidgetIds(component(c)) || !homeCategory(mgr, id)) {
                Log.i("NaozhoWakePreview", "Home widget configuration refused: binding_or_category")
                return false
            }
            mgr.updateAppWidget(id, views(c, false))
            if (!store(c).edit().putStringSet(IDS, approved(c) + id.toString()).commit()) return false
            return try { present(c).createNewFile(); true } catch (e: java.io.IOException) {
                store(c).edit().putStringSet(IDS, approved(c) - id.toString()).commit()
                false
            }
        }

        private fun hostIds(c: Context): IntArray {
            val ids = approved(c)
            if (ids.isEmpty() || !freeme(c)) return intArrayOf()
            val mgr = AppWidgetManager.getInstance(c)
            return mgr.getAppWidgetIds(component(c)).filter { it.toString() in ids && homeCategory(mgr, it) }.toIntArray()
        }

        private fun modeAllows(c: Context, key: Key): Boolean {
            if (!c.getSystemService(UserManager::class.java).isUserUnlocked || !ModeState(c).independentLock()) return false
            val mode = c.getSharedPreferences("desktop_mode", 0)
            return mode.getBoolean("android", false) && mode.getInt("boot", -1) == key.boot &&
                mode.getLong("mode_since", Long.MAX_VALUE) < key.dark
        }

        private fun active(c: Context): Key? {
            val p = store(c)
            return if (p.contains("visible_dark")) Key(p.getInt("visible_boot", -1), p.getLong("visible_dark", -1)) else null
        }

        private fun closed(c: Context, key: Key): Boolean {
            val p = store(c)
            return p.getInt("closed_boot", -1) == key.boot && key.dark <= p.getLong("closed_dark", -1)
        }

        private fun expired(c: Context) =
            SystemClock.elapsedRealtime() >= store(c).getLong("hard_end", 0L)

        /** A formal reserve is still ANDROID. Only its exact dark generation may continue
         * displaying the widget for a bounded time after CONSUME changes the mode to CLOCK. */
        private fun handingOff(c: Context, key: Key): Boolean {
            val m = c.getSharedPreferences("desktop_mode", 0)
            val since = m.getLong("mode_since", -1)
            if (!ModeState(c).independentLock() || m.getBoolean("android", true) ||
                m.getInt("boot", -1) != key.boot || m.getLong("wake_last", -1) != key.dark ||
                since <= key.dark || active(c) != key) return false
            val p = store(c)
            if (p.getLong("handoff_since", -1) == since) return true
            return !m.getString("wake_focused", null).isNullOrEmpty() &&
                p.edit().putLong("handoff_since", since).commit()
        }

        fun watchMode(context: Context) = mainThread {
            val c = context.applicationContext
            if (Build.VERSION.SDK_INT < 34 || !present(c).exists()) return@mainThread
            val durable = active(c)
            if (waiting == null && durable != null) {
                // COMMIT or a non-wakeup alarm can arrive in a fresh application process.
                if (closed(c, durable) || bootCount(c) != durable.boot || expired(c) ||
                    (!modeAllows(c, durable) && !handingOff(c, durable))) {
                    close(c, durable, "ineligible")
                    return@mainThread
                }
                installWatch(c, durable)
            }
            if (observedPrefs != null || waiting == null) return@mainThread
            val p = c.getSharedPreferences("desktop_mode", 0)
            val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, field ->
                if (field == null || field in setOf("android", "boot", "mode_since", "dev_rehearsal", "managed_home", "managed_lock")) {
                    mainThread {
                        val key = waiting?.key ?: active(c)
                        if (key != null && !modeAllows(c, key) && !handingOff(c, key))
                            close(c, key, "maintenance")
                    }
                }
            }
            p.registerOnSharedPreferenceChangeListener(listener)
            modeListener = listener
            observedPrefs = p
        }

        private fun installWatch(c: Context, key: Key) {
            val next = Watch(c, key)
            waiting = next
            try {
                next.start()
            } catch (e: RuntimeException) {
                close(c, key, "ineligible")
                throw e
            }
        }

        fun arm(context: Context, boot: Int, dark: Long) = mainThread {
            val c = context.applicationContext
            // ClockPrewarm has already witnessed a physical OFF and checked its protected
            // envelope. If the main-thread arm arrives after ON, retain this same key;
            // only a recently witnessed OFF and a fresh, eligible ON can publish then.
            val now = SystemClock.elapsedRealtime()
            if (Build.VERSION.SDK_INT < 34 || !present(c).exists() || dark !in 1L..now ||
                now - dark > 5000 || boot != bootCount(c)) return@mainThread
            val key = Key(boot, dark)
            if (closed(c, key)) return@mainThread
            val current = waiting?.key ?: active(c)
            if (current == key) { watchMode(c); return@mainThread }
            if (current != null && current.boot == boot && current.dark > dark) return@mainThread
            if (!modeAllows(c, key) || hostIds(c).isEmpty()) return@mainThread
            if (current != null) {
                close(c, current, "withdrawn")
                if (active(c) != null) return@mainThread // old host update still needs retraction
            }
            trace("PREVIEW_ARMED_AT", key)
            installWatch(c, key)
            watchMode(c)
        }

        /** Called only after the exact ticket's committed clock frame and real window focus. */
        fun handoff(context: Context, boot: Int, dark: Long) = mainThread {
            val c = context.applicationContext
            val key = Key(boot, dark)
            if ((waiting?.key ?: active(c)) == key && bootCount(c) == boot) close(c, key, "handoff")
        }

        fun clear(context: Context) = mainThread {
            val c = context.applicationContext
            val key = waiting?.key ?: active(c) ?: return@mainThread
            close(c, key, "withdrawn")
        }

        /** A late terminal broadcast must neither resurrect an old arm nor clear a newer clock. */
        fun dismiss(context: Context, boot: Int, dark: Long) = mainThread {
            val c = context.applicationContext
            if (Build.VERSION.SDK_INT < 34 || boot < 0 || dark <= 0 || dark > SystemClock.elapsedRealtime() ||
                (!present(c).exists() && waiting == null && active(c) == null) || bootCount(c) != boot) return@mainThread
            close(c, Key(boot, dark), "terminal")
        }

        private fun close(c: Context, key: Key, reason: String) {
            val (boot, dark) = key
            val p = store(c)
            if (boot == bootCount(c) && (p.getInt("closed_boot", -1) != boot || p.getLong("closed_dark", -1) < dark)) {
                p.edit().putInt("closed_boot", boot).putLong("closed_dark", dark).commit()
            }
            val current = waiting?.key ?: active(c)
            if (current != null && current.boot == boot && current.dark <= dark) retract(c, current, reason)
        }

        private fun retract(c: Context, key: Key, reason: String) {
            val p = store(c)
            if (waiting?.key == key) {
                val old = waiting
                waiting = null
                old?.close()
            }
            if (active(c) == key) {
                // Clear every previously approved slot, even if the user has since switched HOME.
                val ids = approved(c).mapNotNull(String::toIntOrNull).toIntArray()
                val phase = p.getString("lease_phase", null)
                try {
                    if (ids.isNotEmpty()) AppWidgetManager.getInstance(c).updateAppWidget(ids, views(c, false))
                } catch (failed: RuntimeException) {
                    // A binder error does not certify that the system host is blank.
                    // Keep the durable tombstone and permit one non-wakeup clear retry.
                    // Future normal widget callbacks can still withdraw a tombstoned view.
                    if (phase != CLEAR_RETRY) {
                        runCatching { lease(c, key, CLEAR_RETRY, SystemClock.elapsedRealtime() + 1000) }
                    }
                    trace("PREVIEW_CLEAR_DEFERRED", key, "reason=$reason")
                    return
                }
                p.edit().remove("visible_boot").remove("visible_dark").remove("lease_phase")
                    .remove("hard_end").remove("lease_end").remove("handoff_since")
                    .remove("submitted_phase").remove("attempted_phase").commit()
                if (phase != null) c.getSystemService(AlarmManager::class.java).cancel(expiry(c, key, phase))
                trace("PREVIEW_CLEARED_AT", key, "reason=$reason")
            }
            if (waiting == null && active(c) == null) {
                modeListener?.let { observedPrefs?.unregisterOnSharedPreferenceChangeListener(it) }
                observedPrefs = null
                modeListener = null
            }
        }

        private fun expiry(c: Context, key: Key, phase: String): PendingIntent {
            val intent = Intent(c, WakePreviewWidget::class.java).setAction(EXPIRY)
                .setData(Uri.parse("naozho-preview://expiry/${key.boot}/${key.dark}/$phase"))
                .putExtra(EXTRA_BOOT_COUNT, key.boot).putExtra("dark_elapsed", key.dark)
                .putExtra("lease_phase", phase)
            return PendingIntent.getBroadcast(c, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        /** Schedule cleanup before publishing pixels. A process death between scheduling,
         * durable write and update either leaves the previous lease or triggers cleanup. */
        private fun lease(c: Context, key: Key, phase: String, deadline: Long): Boolean {
            val alarm = c.getSystemService(AlarmManager::class.java)
            if (!alarm.canScheduleExactAlarms()) return false
            val p = store(c)
            val previous = p.getString("lease_phase", null)
            val next = expiry(c, key, phase)
            alarm.setExact(AlarmManager.ELAPSED_REALTIME, deadline, next)
            if (!p.edit().putInt("visible_boot", key.boot).putLong("visible_dark", key.dark)
                    .putString("lease_phase", phase).putLong("lease_end", deadline)
                    .putLong("hard_end", key.dark + DARK_LIMIT_MS).commit()) {
                alarm.cancel(next)
                return false
            }
            if (previous != null && previous != phase) alarm.cancel(expiry(c, key, previous))
            return true
        }

        private fun alarmFired(c: Context, key: Key, phase: String?) = mainThread {
            val p = store(c)
            if (active(c) != key || p.getString("lease_phase", null) != phase) return@mainThread
            // A delivered legacy alarm carries no phase and only retracts. New alarms
            // are explicit and bind boot, dark and phase; stale dark checks cannot erase ON.
            if (closed(c, key) || phase != DARK_CHECK || bootCount(c) != key.boot || expired(c)) {
                close(c, key, "timeout")
                return@mainThread
            }
            if (!modeAllows(c, key) && !handingOff(c, key)) {
                close(c, key, "maintenance")
                return@mainThread
            }
            try {
                // One short, non-wakeup alarm may arrive while still OFF. Replace once
                // with one hard bound instead of going into a periodic dark polling loop.
                if (!lease(c, key, HARD, key.dark + DARK_LIMIT_MS)) { close(c, key, "timeout"); return@mainThread }
                watchMode(c)
                waiting?.sample()
            } catch (_: RuntimeException) { close(c, key, "timeout") }
        }

        private fun trace(stage: String, key: Key, extra: String = "", at: Long = SystemClock.elapsedRealtime()) = Log.i("NaozhoWakePerf",
            "$at $stage boot=${key.boot} dark=${key.dark} pid=${android.os.Process.myPid()} $extra")

        private class Watch(val c: Context, val key: Key) : DisplayManager.DisplayListener {
            val displays = c.getSystemService(DisplayManager::class.java)
            private val preparedClock = views(c, true)
            private var seenOn = false
            private var armedOnTimer = false
            private val expire = Runnable { if (waiting === this) close(c, key, "timeout") }
            private val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) { sample() }
            }

            fun start() {
                displays.registerDisplayListener(this, main)
                c.registerReceiver(receiver, IntentFilter().apply {
                    addAction(Intent.ACTION_SCREEN_ON)
                    addAction(Intent.ACTION_SCREEN_OFF)
                }, Context.RECEIVER_NOT_EXPORTED)
                sample()
            }

            override fun onDisplayChanged(id: Int) { if (id == Display.DEFAULT_DISPLAY) sample() }
            override fun onDisplayAdded(id: Int) { if (id == Display.DEFAULT_DISPLAY) sample() }
            override fun onDisplayRemoved(id: Int) {
                if (id == Display.DEFAULT_DISPLAY && waiting === this) close(c, key, "display")
            }

            fun sample() {
                if (waiting !== this) return
                try { readDisplay() } catch (e: RuntimeException) {
                    Log.w("NaozhoWakePreview", "Display evidence unavailable: " + e.javaClass.simpleName)
                    close(c, key, "ineligible")
                }
            }

            private fun eligible(atDark: Boolean): Boolean {
                val keyguard = c.getSystemService(KeyguardManager::class.java)
                val protectedLock = keyguard.isKeyguardLocked && (!atDark || keyguard.isDeviceSecure)
                return !protectedLock && modeAllows(c, key) &&
                    c.getSystemService(AudioManager::class.java).mode == AudioManager.MODE_NORMAL &&
                    c.getSystemService(ActivityManager::class.java).lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE &&
                    c.getSystemService(DevicePolicyManager::class.java).isDeviceOwnerApp(c.packageName)
            }

            private fun readDisplay() {
                val state = displays.getDisplay(Display.DEFAULT_DISPLAY)?.state
                val interactive = c.getSystemService(PowerManager::class.java).isInteractive
                val atDark = state == Display.STATE_OFF && !interactive
                val on = state == Display.STATE_ON && interactive
                if (state == Display.STATE_ON && !seenOn) {
                    seenOn = true
                    trace("PREVIEW_ON_OBSERVED_AT", key)
                }
                // A watchdog/COMMIT may recreate this watcher in a fresh process.
                // Once ON was reached, a new dark/AOD needs its own physical cycle.
                val p = store(c)
                val leased = active(c) == key
                val wasOn = leased && p.getString("lease_phase", null) == ON
                if (wasOn && !on) { close(c, key, "display"); return }
                if (!atDark && !on) {
                    if (state !in setOf(Display.STATE_OFF, Display.STATE_ON, Display.STATE_DOZE, Display.STATE_DOZE_SUSPEND)
                        || (seenOn && state != Display.STATE_ON) || (armedOnTimer && !on)) close(c, key, "display")
                    return
                }
                if (atDark && seenOn) { close(c, key, "display"); return }
                val now = SystemClock.elapsedRealtime()
                if (closed(c, key)) { close(c, key, "terminal"); return }
                if (now >= key.dark + DARK_LIMIT_MS) { close(c, key, "timeout"); return }
                // While formally entering CLOCK a duplicate display callback must not pull
                // the tile early. The committed-frame + focused handoff owns its removal.
                if (!(on && leased && handingOff(c, key)) && !eligible(atDark)) {
                    close(c, key, "ineligible"); return
                }
                val ids = hostIds(c)
                if (ids.isEmpty()) { close(c, key, "ineligible"); return }
                val hardEnd = key.dark + DARK_LIMIT_MS
                if (!leased || (on && p.getString("lease_phase", null) != ON)) {
                    val deadline = minOf(hardEnd, now + if (atDark) DARK_CHECK_MS else ON_LEASE_MS)
                    if (!lease(c, key, if (atDark) DARK_CHECK else ON, deadline)) {
                        close(c, key, "ineligible")
                        return
                    }
                }
                // A scheduled cleanup (visible_dark) does not prove that the system
                // accepted an update. Claim an attempt before IPC and record success
                // after it; a fresh process may retry an unconfirmed OFF only at ON.
                val attemptPhase = if (atDark) "off" else ON
                if (p.getString("submitted_phase", null) == null &&
                    p.getString("attempted_phase", null) != attemptPhase) {
                    if (!p.edit().putString("attempted_phase", attemptPhase).commit()) {
                        close(c, key, "ineligible"); return
                    }
                    val mgr = AppWidgetManager.getInstance(c)
                    val callStart = SystemClock.elapsedRealtime()
                    try {
                        mgr.updateAppWidget(ids, preparedClock)
                    } catch (failed: RuntimeException) {
                        if (!atDark) throw failed
                        // A thrown system transaction is ambiguous. Preserve its cleanup
                        // lease and retry the same idempotent layout only at interactive ON.
                        trace("PREVIEW_OFF_UPDATE_FAILED", key)
                        return
                    }
                    val acceptedAt = SystemClock.elapsedRealtime()
                    trace("PREVIEW_SUBMITTED_AT", key, "phase=$attemptPhase call_start=$callStart", acceptedAt)
                    if (!p.edit().putString("submitted_phase", attemptPhase).commit()) {
                        close(c, key, "ineligible"); return
                    }
                }
                if (on && !armedOnTimer) {
                    armedOnTimer = true
                    main.postDelayed(expire, (p.getLong("lease_end", 0) - now).coerceAtLeast(0L))
                }
            }

            fun close() {
                main.removeCallbacks(expire)
                displays.unregisterDisplayListener(this)
                runCatching { c.unregisterReceiver(receiver) }
            }
        }
    }
}

/** Require the real HOME launching for result, and verify system binding before recording the id. */
class WakePreviewConfiguration : Activity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        val ok = intent.action == AppWidgetManager.ACTION_APPWIDGET_CONFIGURE &&
            runCatching { WakePreviewWidget.bind(this, callingPackage, id) }.getOrDefault(false)
        if (ok) setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)) else setResult(RESULT_CANCELED)
        finish()
    }
}
