package com.naozho.clock.mode

import android.app.Activity
import android.app.ActivityManager
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.UserManager
import android.util.Log

/**
 * Review endpoint for PhoneWindowManager's explicit, actionless Intent. The firmware does
 * not supply the initial screen state, second release or mode-bound event times. Even a system
 * caller cannot establish either fact by adding extras. Never dispatch this raw request.
 */
class PowerReturnActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        observeAndFinish(savedInstanceState != null)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        observeAndFinish(true)
    }

    private fun observeAndFinish(redelivered: Boolean) {
        try {
            Log.i("NaozhoPowerReturn", nativePowerRefusal(this, redelivered).name)
        } catch (error: SecurityException) {
            Log.w("NaozhoPowerReturn", "System state unavailable", error)
        } catch (error: IllegalStateException) {
            Log.w("NaozhoPowerReturn", "User state unavailable", error)
        } finally {
            finish()
        }
    }
}

internal enum class PowerRefusal {
    REDELIVERY, USER_UNAVAILABLE, PAUSED_OR_UNCONFIGURED, NOT_ANDROID,
    INDEPENDENT_MODE_REQUIRED, OWNER_REQUIRED, TASK_ALREADY_RESTRICTED,
    DISPLAY_UNAVAILABLE, SYSTEM_ARBITRATION_MISSING
}

internal fun nativePowerRefusal(context: Context, redelivered: Boolean): PowerRefusal {
    if (redelivered) return PowerRefusal.REDELIVERY
    if (Build.VERSION.SDK_INT < 28 ||
        context.getSystemService(UserManager::class.java)?.isUserUnlocked != true
    ) return PowerRefusal.USER_UNAVAILABLE
    val mode = ModeState(context)
    when (mode.stationPhase(confirmedClock = false)) {
        StationPhase.MAINTENANCE_PAUSED, StationPhase.NOT_CONFIGURED -> return PowerRefusal.PAUSED_OR_UNCONFIGURED
        StationPhase.ANDROID -> Unit
        else -> return PowerRefusal.NOT_ANDROID
    }
    if (!mode.independentLock()) return PowerRefusal.INDEPENDENT_MODE_REQUIRED
    if (!ManagedDesktop(context).owner) return PowerRefusal.OWNER_REQUIRED
    if (context.getSystemService(ActivityManager::class.java)?.lockTaskModeState !=
        ActivityManager.LOCK_TASK_MODE_NONE
    ) return PowerRefusal.TASK_ALREADY_RESTRICTED
    if (context.getSystemService(PowerManager::class.java)?.isInteractive != true ||
        context.getSystemService(KeyguardManager::class.java)?.isKeyguardLocked != false
    ) return PowerRefusal.DISPLAY_UNAVAILABLE
    return PowerRefusal.SYSTEM_ARBITRATION_MISSING
}
