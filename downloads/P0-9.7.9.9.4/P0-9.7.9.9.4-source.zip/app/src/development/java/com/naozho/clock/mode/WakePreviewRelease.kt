package com.naozho.clock.mode

import android.content.Context
import android.util.Log

internal object WakePreviewRelease {
    fun handoff(context: Context, ticket: WakeTicket) {
        try {
            WakePreviewWidget.handoff(context, ticket.boot, ticket.dark)
        } catch (error: RuntimeException) {
            Log.w("NaozhoWakePerf", "Home widget handoff failed", error)
        }
    }

    fun cancel(context: Context, ticket: WakeTicket) {
        try {
            WakePreviewWidget.dismiss(context, ticket.boot, ticket.dark)
        } catch (error: RuntimeException) {
            Log.w("NaozhoWakePerf", "Home widget cancellation failed", error)
        }
    }
}
