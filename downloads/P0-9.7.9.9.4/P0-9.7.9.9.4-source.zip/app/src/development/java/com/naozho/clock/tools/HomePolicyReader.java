package com.naozho.clock.tools;

import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;
import android.os.SystemClock;
import android.os.UserHandle;
import android.util.Base64;
import java.util.Map;
import org.json.JSONObject;

/** Read-only Android 16 shell diagnostic. No Activity, receiver or service exposes this entry point. */
public final class HomePolicyReader {
    private static final String CLOCK = "com.naozho.clock";

    public static void main(String[] args) {
        try {
            if (Build.VERSION.SDK_INT != 36 || Process.myUid() != 2000 || args.length != 2)
                throw new IllegalArgumentException("Requires API 36, adb shell user 0, native HOME and audit nonce");
            ComponentName stock = ComponentName.unflattenFromString(args[0]);
            if (stock == null || CLOCK.equals(stock.getPackageName())) throw new IllegalArgumentException("Invalid native HOME");
            ComponentName clock = new ComponentName(CLOCK, CLOCK + ".MainActivity");
            UserHandle user = Process.myUserHandle();

            // Shell holds MANAGE_PROFILE_AND_DEVICE_OWNERS on AOSP. The ordinary owner app does not.
            // These platform diagnostic interfaces may be unavailable on OEM builds. Fail closed.
            IBinder binder = (IBinder) Class.forName("android.os.ServiceManager")
                    .getMethod("getService", String.class).invoke(null, "device_policy");
            Class<?> serviceClass = Class.forName("android.app.admin.IDevicePolicyManager");
            Object service = Class.forName(serviceClass.getName() + "$Stub")
                    .getMethod("asInterface", IBinder.class).invoke(null, binder);
            Object snapshot = serviceClass.getMethod("getDevicePolicyState").invoke(service);
            Map<?, ?> policies = (Map<?, ?>) snapshot.getClass().getMethod("getPoliciesForUser", UserHandle.class)
                    .invoke(snapshot, user);
            ComponentName previous = previousFor(policies, stock, clock, user);
            JSONObject audit = new JSONObject().put("user", 0).put("nonce", args[1])
                    .put("elapsed", SystemClock.elapsedRealtime()).put("native", stock.flattenToString())
                    .put("previous", previous == null ? "" : previous.flattenToString());
            System.out.println(Base64.encodeToString(audit.toString().getBytes("UTF-8"), Base64.NO_WRAP));
        } catch (Throwable failure) {
            Throwable cause = failure.getCause() == null ? failure : failure.getCause();
            System.err.println("HOME audit unavailable: " + cause);
            System.exit(1);
        }
    }

    static ComponentName previousFor(Map<?, ?> policies, ComponentName stock, ComponentName clock, UserHandle user)
            throws ReflectiveOperationException {
        ComponentName previous = null;
        ComponentName expectedAdmin = new ComponentName(CLOCK, CLOCK + ".display.ClockDeviceAdmin");
        for (Map.Entry<?, ?> entry : policies.entrySet()) {
            Object key = entry.getKey();
            if (!"persistentPreferredActivity".equals(get(key, "getIdentifier"))) continue;
            IntentFilter f = (IntentFilter) get(key, "getIntentFilter");
            Object state = entry.getValue();
            Map<?, ?> admins = (Map<?, ?>) get(state, "getPoliciesSetByAdmins");
            for (Map.Entry<?, ?> row : admins.entrySet()) {
                ComponentName component = (ComponentName) row.getValue();
                Object admin = row.getKey();
                boolean owner = CLOCK.equals(get(admin, "getPackageName")) && user.equals(get(admin, "getUserHandle"));
                boolean targetPackage = CLOCK.equals(component.getPackageName()) ||
                        stock.getPackageName().equals(component.getPackageName());
                if (!owner || !targetPackage) continue;
                if (!"android.app.admin.DpcAuthority".equals(get(admin, "getAuthority").getClass().getName()) ||
                        !expectedAdmin.equals(get(admin, "getComponentName")) ||
                        !exactHome(f) || previous != null || !(component.equals(stock) || component.equals(clock)))
                    throw new IllegalStateException("Additional or unexpected persistent preference for these packages; no audit issued");
                previous = component;
            }
            if (exactHome(f) && (admins.size() != 1 || previous == null ||
                    !previous.equals(get(state, "getCurrentResolvedPolicy"))))
                throw new IllegalStateException("Another administrator or conflicting HOME value; no audit issued");
        }
        return previous;
    }

    private static Object get(Object obj, String method) throws ReflectiveOperationException {
        return obj.getClass().getMethod(method).invoke(obj);
    }

    private static boolean exactHome(IntentFilter f) {
        return Build.VERSION.SDK_INT >= 35 && f != null && f.countActions() == 1 && f.hasAction(Intent.ACTION_MAIN) && f.countCategories() == 2 &&
                f.hasCategory(Intent.CATEGORY_HOME) && f.hasCategory(Intent.CATEGORY_DEFAULT) &&
                f.countDataTypes() == 0 && f.countDataSchemes() == 0 && f.countDataPaths() == 0 &&
                f.countDataSchemeSpecificParts() == 0 && f.countDataAuthorities() == 0 && f.countUriRelativeFilterGroups() == 0;
    }
}
