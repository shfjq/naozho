package com.naozho.clock.mode

import android.app.KeyguardManager
import android.content.ActivityNotFoundException
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.view.WindowManager
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.lifecycle.Lifecycle
import com.naozho.clock.MainActivity
import java.util.concurrent.Executor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import org.robolectric.util.ReflectionHelpers
import org.robolectric.util.ReflectionHelpers.ClassParameter

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w360dp-h360dp-xhdpi", shadows = [TestCredentialPrompt::class])
class AdminRecoverySecurityTest {
    @get:Rule val compose = createAndroidComposeRule<AdminRecoveryActivity>()
    private val prefs get() = compose.activity.getSharedPreferences("mode_credentials", 0)

    @Before
    fun prepare() {
        TestCredentialPrompt.requests.clear()
        TestCredentialPrompt.unavailable = false
        setSecure()
    }

    @Test
    fun firstSetupRequestsSystemCredentialsBeforeDisplayingForm() {
        val before = prefs.all.toMap()
        assertTrue(compose.activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
        compose.onNodeWithText("设置 PIN 和恢复码").performClick()
        assertEquals(1, TestCredentialPrompt.requests.size)
        assertNoForm()
        assertEquals(before, prefs.all)
        compose.runOnIdle { TestCredentialPrompt.requests.single().succeed() }
        compose.onNodeWithText("新 PIN（6–12 位数字）").assertIsDisplayed()
        compose.onNodeWithText("新的一次性恢复码").assertDoesNotExist()
        assertEquals(before, prefs.all)
    }

    @Test
    fun resetAndRotationBothRequireFreshSuccessfulSystemCredentials() {
        val before = existingPin()
        compose.onNodeWithText("重设 PIN 和恢复码").performClick()
        assertNoForm()
        compose.runOnIdle { TestCredentialPrompt.requests[0].reject(BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED) }
        assertNoForm()
        assertEquals(before, prefs.all)

        compose.onNodeWithText("重新生成恢复码").performClick()
        assertNoForm()
        compose.runOnIdle { TestCredentialPrompt.requests[1].succeed() }
        compose.onNodeWithText("生成并仅显示一次").assertIsDisplayed()
        compose.onNodeWithText("新的一次性恢复码").assertDoesNotExist()
        assertEquals(before, prefs.all)
        compose.onNodeWithText("取消编辑").performClick()

        compose.onNodeWithText("重设 PIN 和恢复码").performClick()
        compose.runOnIdle { TestCredentialPrompt.requests[1].succeed() }
        assertNoForm()
        assertEquals(before, prefs.all)
        compose.runOnIdle { TestCredentialPrompt.requests[2].failed() }
        assertNoForm()
        assertEquals(before, prefs.all)
    }

    @Test
    fun absentCredentialAndUnlaunchablePromptBothFailClosed() {
        val before = existingPin()
        compose.runOnIdle {
            shadowOf(compose.activity.getSystemService(KeyguardManager::class.java)).setIsDeviceSecure(false)
        }
        compose.onNodeWithText("重设 PIN 和恢复码").performClick()
        assertNoForm()
        assertTrue(TestCredentialPrompt.requests.isEmpty())
        assertEquals(before, prefs.all)
        compose.runOnIdle {
            shadowOf(compose.activity.getSystemService(KeyguardManager::class.java)).setIsDeviceSecure(true)
            TestCredentialPrompt.unavailable = true
        }
        compose.onNodeWithText("重新生成恢复码").performClick()
        assertNoForm()
        assertEquals(before, prefs.all)
    }

    @Test
    fun duplicateClicksAndResultAfterRecreationCannotOpenOrChangeAnything() {
        val before = existingPin()
        compose.onNodeWithText("重设 PIN 和恢复码").performClick()
        compose.onNodeWithText("重设 PIN 和恢复码").assertIsNotEnabled()
        compose.onNodeWithText("重新生成恢复码").assertIsNotEnabled()
        val old = TestCredentialPrompt.requests.single()
        compose.activityRule.scenario.recreate()
        setSecure()
        compose.runOnIdle { old.succeed() }
        assertNoForm()
        assertEquals(before, prefs.all)
        compose.onNodeWithText("重新生成恢复码").performClick()
        compose.runOnIdle { old.succeed() }
        assertNoForm()
        assertEquals(before, prefs.all)
        compose.runOnIdle { TestCredentialPrompt.requests.last().succeed(BiometricPrompt.AUTHENTICATION_RESULT_TYPE_BIOMETRIC) }
        assertNoForm()
        assertEquals(before, prefs.all)
    }

    @Test
    fun aVerifiedFormIsClosedOnRecreationAndNeedsANewChallenge() {
        val before = existingPin()
        compose.onNodeWithText("重新生成恢复码").performClick()
        compose.runOnIdle { TestCredentialPrompt.requests.single().succeed() }
        compose.onNodeWithText("生成并仅显示一次").assertIsDisplayed()
        compose.activityRule.scenario.recreate()
        setSecure()
        assertNoForm()
        assertEquals(before, prefs.all)
        compose.onNodeWithText("重新生成恢复码").performClick()
        assertEquals(2, TestCredentialPrompt.requests.size)
        assertNoForm()
        assertEquals(before, prefs.all)
    }

    @Test
    fun committedCodeIsRenderedWithoutTextSemanticsAndCannotBeViewedAfterBackgrounding() {
        val before = existingPin()
        compose.onNodeWithText("重新生成恢复码").performClick()
        compose.runOnIdle { TestCredentialPrompt.requests.single().succeed() }
        compose.onNodeWithText("生成并仅显示一次").performClick()
        compose.waitUntil(5_000) { compose.onAllNodes(SemanticsMatcher.expectValue(
            SemanticsProperties.Text, listOf(androidx.compose.ui.text.AnnotatedString("新的一次性恢复码")),
        )).fetchSemanticsNodes().isNotEmpty() }
        val recoveryPattern = Regex("[0-9A-F]{4}(?:-[0-9A-F]{4}){3}")
        val exposedNodes = compose.onAllNodes(SemanticsMatcher("recovery material in exposed text") { node ->
            val config = node.config
            val text = config.getOrNull(SemanticsProperties.Text).orEmpty() +
                listOfNotNull(config.getOrNull(SemanticsProperties.EditableText))
            text.any { recoveryPattern.containsMatchIn(it.text) }
        }, useUnmergedTree = true).fetchSemanticsNodes().size
        assertEquals(0, exposedNodes)
        assertEquals(before["pin_hash"], prefs.getString("pin_hash", ""))
        assertTrue(prefs.contains("recovery_hash"))
        val after = prefs.all.toMap()
        compose.activityRule.scenario.moveToState(Lifecycle.State.STARTED)
        compose.activityRule.scenario.moveToState(Lifecycle.State.RESUMED)
        compose.onNodeWithText("新的一次性恢复码").assertDoesNotExist()
        assertEquals(after, prefs.all)
    }

    private fun existingPin(): Map<String, *> {
        compose.runOnIdle { assertTrue(prefs.edit().putString("pin_hash", "fixture").commit()) }
        compose.activityRule.scenario.recreate()
        setSecure()
        return prefs.all.toMap()
    }

    private fun setSecure() = compose.runOnIdle {
        shadowOf(compose.activity.getSystemService(KeyguardManager::class.java)).setIsDeviceSecure(true)
    }

    private fun assertNoForm() {
        compose.onNodeWithText("新 PIN（6–12 位数字）").assertDoesNotExist()
        compose.onNodeWithText("生成并仅显示一次").assertDoesNotExist()
        compose.onNodeWithText("新的一次性恢复码").assertDoesNotExist()
    }
}

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w360dp-h360dp-xhdpi", shadows = [TestCredentialPrompt::class])
class AndroidHandoffSecurityTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test
    fun submittingClockPinRequestsSystemCredentialBeforeChangingStateOrAttemptCounters() {
        TestCredentialPrompt.requests.clear()
        TestCredentialPrompt.unavailable = false
        compose.runOnIdle {
            assertTrue(compose.activity.getSharedPreferences("mode_credentials", 0).edit().putString("pin_hash", "fixture").commit())
        }
        compose.activityRule.scenario.recreate()
        val activity = compose.activity
        val credentials = activity.getSharedPreferences("mode_credentials", 0)
        val mode = activity.getSharedPreferences("desktop_mode", 0)
        val page = MainActivity::class.java.declaredClasses.single { it.simpleName == "Page" }
        val auth = checkNotNull(page.enumConstants).single { (it as Enum<*>).name == "AUTH" }
        compose.runOnIdle {
            shadowOf(activity.getSystemService(KeyguardManager::class.java)).setIsDeviceSecure(true)
            ReflectionHelpers.callInstanceMethod<Unit>(activity, "show", ClassParameter.from(page, auth))
        }
        val beforeCredentials = credentials.all.toMap()
        val beforeMode = mode.all.toMap()
        compose.onNode(hasSetTextAction()).performTextInput("123456")
        compose.onNodeWithText("进入安卓模式").performClick()
        assertEquals(1, TestCredentialPrompt.requests.size)
        assertEquals(beforeCredentials, credentials.all)
        assertEquals(beforeMode, mode.all)
        compose.runOnIdle { TestCredentialPrompt.requests.single().reject(BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED) }
        assertEquals(beforeCredentials, credentials.all)
        assertEquals(beforeMode, mode.all)
        compose.onNodeWithText("验证时钟 PIN").assertIsDisplayed()
    }
}

@Implements(BiometricPrompt::class)
class TestCredentialPrompt {
    @Implementation
    fun authenticate(cancellation: CancellationSignal, executor: Executor, callback: BiometricPrompt.AuthenticationCallback) {
        if (unavailable) throw ActivityNotFoundException()
        requests += Request(cancellation, callback)
    }

    class Request(val signal: CancellationSignal, private val callback: BiometricPrompt.AuthenticationCallback) {
        fun succeed(type: Int = BiometricPrompt.AUTHENTICATION_RESULT_TYPE_DEVICE_CREDENTIAL) {
            val result = ReflectionHelpers.callConstructor(BiometricPrompt.AuthenticationResult::class.java,
                ClassParameter.from(BiometricPrompt.CryptoObject::class.java, null),
                ClassParameter.from(Int::class.javaPrimitiveType, type))
            callback.onAuthenticationSucceeded(result)
        }

        fun reject(error: Int) = callback.onAuthenticationError(error, "")
        fun failed() = callback.onAuthenticationFailed()
    }

    companion object {
        val requests = mutableListOf<Request>()
        var unavailable = false
    }
}
