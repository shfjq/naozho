package com.naozho.station;

import java.util.function.Consumer;

/** Host-side deterministic input timelines. No Android services or telephony. */
public final class StationPowerArbiterTest {
    private static final class Rig implements StationPowerArbiter.Host {
        long epoch = 1;
        long first;
        long released;
        boolean emergencyPending;
        int returns;
        final StationPowerArbiter keys = new StationPowerArbiter(this, 300, 500, 100);
        public long eligibleGeneration() { return epoch; }
        public boolean tryReturn(long expected, long firstDown, long lastUp) {
            if (expected != epoch || emergencyPending) return false;
            first = firstDown;
            released = lastUp;
            returns++;
            return true;
        }
        void one() { keys.firstDown(10, 0, true); keys.up(10, 30, false); }
        void two() { one(); keys.nextDown(10, 90, false); keys.up(10, 120, false); }
        void finish() { keys.finish(10, 421, true); }
    }

    private static void check(String name, int expected, Consumer<Rig> timeline) {
        Rig rig = new Rig();
        timeline.accept(rig);
        if (rig.returns != expected) throw new AssertionError(name + ": " + rig.returns);
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        check("exclusive double exactly once", 1, r -> { r.two(); r.finish(); r.finish(); });
        check("single remains system-owned", 0, r -> { r.one(); r.finish(); });
        check("second still held", 0, r -> { r.one(); r.keys.nextDown(10, 90, false); r.finish(); });
        check("second long press", 0, r -> { r.one(); r.keys.nextDown(10, 90, false); r.keys.up(10, 600, false); r.keys.finish(10, 950, true); });
        check("repeat", 0, r -> { r.one(); r.keys.nextDown(10, 90, true); r.finish(); });
        check("third tap", 0, r -> { r.two(); r.keys.nextDown(10, 200, false); r.finish(); });
        check("five taps are not a double", 0, r -> {
            r.two();
            for (int i = 2; i < 5; i++) {
                r.keys.nextDown(10, i * 90, false);
                r.keys.up(10, i * 90 + 30, false);
            }
            r.keys.finish(10, 900, false);
        });
        check("too early", 0, r -> { r.two(); r.keys.finish(10, 419, true); r.finish(); });
        check("expired while policy thread was busy", 0, r -> { r.two(); r.keys.finish(10, 521, true); });
        check("current product context vetoes delivery", 0, r -> { r.two(); r.keys.finish(10, 450, false); });
        check("raw second down never delivers", 0, r -> r.two());
        check("screen previously off", 0, r -> { r.keys.firstDown(10, 0, false); r.keys.up(10, 30, false); r.keys.nextDown(10, 90, false); r.keys.up(10, 120, false); r.finish(); });
        check("maintenance pause then rearm rejects old sequence", 0, r -> { r.two(); r.epoch++; r.finish(); });
        check("pause before start", 0, r -> { r.epoch = -1; r.two(); r.epoch = 2; r.finish(); });
        check("already locked", 0, r -> { r.epoch = -1; r.two(); r.finish(); });
        check("system or mode cancellation", 0, r -> { r.two(); r.keys.cancel(); r.finish(); });
        check("emergency pending at commit", 0, r -> { r.two(); r.emergencyPending = true; r.finish(); });
        check("no SOS recognition required for double", 1, r -> {
            r.two(); r.finish();
            if (r.first != 0 || r.released != 120) throw new AssertionError("wrong input timestamps");
        });
        check("switch bounce", 0, r -> { r.one(); r.keys.nextDown(10, 31, false); r.keys.up(10, 52, false); r.finish(); });
        check("down-to-down interval too long", 0, r -> {
            r.keys.firstDown(10, 0, true); r.keys.up(10, 280, false); r.keys.nextDown(10, 305, false);
            r.keys.up(10, 325, false); r.keys.finish(10, 625, true);
        });
        check("old delivery cannot finalize new press", 0, r -> { r.two(); r.keys.firstDown(11, 350, true); r.finish(); });
        check("fresh sequence after resuming", 1, r -> {
            r.two(); r.epoch++; r.finish();
            r.keys.firstDown(11, 500, true); r.keys.up(11, 530, false);
            r.keys.nextDown(11, 590, false); r.keys.up(11, 620, false); r.keys.finish(11, 920, true);
        });
        check("cancelled key up", 0, r -> { r.one(); r.keys.nextDown(10, 90, false); r.keys.up(10, 120, true); r.finish(); });
    }
}
