package com.naozho.station;

/**
 * Run from the product's serialized power-policy thread. System policy owns the
 * sequence ID, clocks and ordinary power actions.
 * Observing raw keys never starts an activity and never consumes an input event.
 */
public final class StationPowerArbiter {
    public interface Host {
        /** Negative unless the active user is in eligible, interactive Android mode.
         * The token changes across user/boot, pause, re-arm and every mode change. */
        long eligibleGeneration();

        /** In one serialized transaction, recheck generation, keyguard, pending
         * call UI and routing context before delivery. Times use input-event uptime. */
        boolean tryReturn(long expectedGeneration, long firstDown, long lastUp);
    }

    private final Host host;
    private final long quietMs;
    private final long longPressMs;
    private final long dispatchGraceMs;
    private long sequence = -1;
    private long generation = -1;
    private long lastEvent;
    private long downAt;
    private long firstDown;
    private int taps;
    private boolean held;
    private boolean rejected = true;

    /** quietMs is the product multi-press interval. */
    public StationPowerArbiter(Host host, long quietMs, long longPressMs, long dispatchGraceMs) {
        if (host == null || quietMs <= 0 || longPressMs <= 0 || dispatchGraceMs < 0) {
            throw new IllegalArgumentException("Missing host or system gesture timeouts");
        }
        this.host = host;
        this.quietMs = quietMs;
        this.longPressMs = longPressMs;
        this.dispatchGraceMs = dispatchGraceMs;
    }

    /** Exactly once on the first non-repeat down. IDs increase on this instance. */
    public void firstDown(long id, long time, boolean interactive) {
        if (id <= sequence || time < 0) {
            if (id == sequence) cancel();
            return;
        }
        sequence = id;
        generation = interactive ? host.eligibleGeneration() : -1;
        held = true;
        firstDown = downAt = lastEvent = time;
        taps = 0;
        rejected = generation < 0;
    }

    public void nextDown(long id, long time, boolean repeat) {
        if (id != sequence || rejected) return;
        if (repeat || held || taps != 1 || time < lastEvent || time - firstDown < 40 || time - firstDown >= quietMs) {
            cancel();
            return;
        }
        held = true;
        downAt = lastEvent = time;
    }

    public boolean up(long id, long time, boolean cancelled) {
        if (id != sequence || rejected) return false;
        if (!held || cancelled || time <= lastEvent || time - downAt >= longPressMs) {
            cancel();
            return false;
        }
        held = false;
        lastEvent = time;
        taps++;
        return taps == 2;
    }

    /** Includes power menu, call UI, screen-off, chords and user/mode changes. */
    public void cancel() {
        rejected = true;
    }

    /** Finish a released double after its quiet interval on the same policy thread.
     * The host can veto pending calls, chords, or a changed display/user.
     */
    public boolean finish(long id, long time, boolean eligible) {
        if (id != sequence || rejected) return false;
        rejected = true;
        if (!eligible || held || taps != 2 || time < lastEvent ||
                time - lastEvent < quietMs || time - lastEvent - quietMs > dispatchGraceMs ||
                host.eligibleGeneration() != generation) return false;
        return host.tryReturn(generation, firstDown, lastEvent);
    }
}
