# CPDAY10 原窗口黑幕 · OEM 源码原型

此目录用于同版系统源码集成评审。它独立于 APK、KernelSU ZIP 和系统启动路径。没有安装入口、独立 Binder、网络或输入注入能力。现有 CPDAY10 固件未装载它。独立 Root 进程不能通过本原型取得其他应用的 Surface 或令牌。

## 已实现的行为

WindowClockTransition 在承载方 UI 线程创建公开 API 的 SurfaceControlViewHost。它用真实来源窗口的 InputTransferToken 建立独立子输入通道，绘制纯黑视图。窗口不可获键盘焦点，可消费命中该区域的触摸；实现不读取坐标、文字、按键或内容。视图提交本地渲染帧后才允许显示。每轮 WM placement 同时核对旧窗口对象、同一父 Surface 句柄、可用来源、实际子输入通道、有效范围、控制进程及期限。满足后，在该轮宿主传入的有序 SurfaceControl.Transaction 中将子层置于源窗口本地坐标原点，并仅在源窗口子树内提高层级。原应用上方的另一个 Activity 或系统窗口仍由系统决定顺序。

公开的 SurfaceControlViewHost.setView(view,w,h) 在本固件将 LayoutParams 交给 View 后用同一组属性创建嵌入窗口。代码保留触摸通道并设置 NOT_FOCUSABLE 与 NOT_TOUCH_MODAL。CPDAY10 的 ViewRootImpl.getInputTransferToken 使用当前装有输入通道的窗口生成令牌，WindowState.openInputChannel 将通道登记进 WMS。WMS.grantInputChannel 在方法偏移 0018–001a 查询该真实主通道，然后在 0043 为主窗口创建嵌入窗口和独立通道。OEM 宿主须在 WMS 自己的注册表核对这个子通道确实关联回**同一原窗口**。仅能读到一个非空 Binder 不足以放行。

## 厂商接线契约

1. 需要同构建的 WindowManager 源码、正常签名构建及恢复路径。宿主从已核验的普通、非安全主窗口保留 WindowState 身份、由该窗口拥有的实际 Surface、真实主通道的 InputTransferToken、本地可见尺寸及控制器存活 Binder。所有这些参数都来自系统已拥有的对象。禁止从窗口列表解析字符串、伪造令牌、借用别的系统窗口，或将句柄返回给不受信任应用。保留的父 Surface 句柄由宿主维护寿命，不能被重用为另一父窗口。
2. 在显示/UI 线程且 WMS 全局锁外调用 prepare。为原窗口建立的子输入通道、合法的父 Surface 和原窗口身份缺一项即放弃。WMS 或 Shell 自己应在观察到合法 OFF 后取得这些输入；已保护、旋转/缩放中、分屏、无法确证坐标的窗口应跳过。一个 dark 只创建一个租约，新周期开始前关闭旧周期。需要同一显示器的已启动 UI 环境。
3. 在同一次系统 surface placement 和同一原子事务里调用 place。host.hasEmbeddedInput 必须在 WMS 锁内校验真实输入绑定。ordinary 必须是当前同一用户、显示器、原窗口和保护状态的实时判定。若已开始该代的正式时钟切换，可以让尚存的原应用子层留在原窗口之下直至正式交接，不能将其再次挂到时钟或任何新弹出的窗口。保护检测与放置/移除必须发生在同一窗口重排中。调用前后不可复用过期事务。默认显示器上的系统栏与关键界面保留自己的输入区域。
4. 正常亮屏边沿调用 onWakeCandidate。该方法开启 8 秒非唤醒超时。正常交接的 cancel 必须发生在正式协议完成且真实首帧、WMS 焦点、LOCKED + 80 和单包允许名单均验证以后。中断、维护暂停、安全窗口、再息屏、来自其他流程的恢复及控制器死亡则直接撤销。关机、停用与 OEM 服务 teardown 在 UI 线程调用 close；Binder death、超时及服务销毁均需实装。不要持有唤醒锁。
5. onSurfaceCommitted 表示对应合成器事务已提交。实际面板是否出现黑幕、输入是否被源窗口截获仍要在隔离的同版系统镜像和批准的设备上验证。若设备暗屏时没有产生本地帧、已移除的 Surface 仍可能被系统组合或任何输入映射无法证实，保持停用。原窗口完全移出显示、带系统栏、不同尺寸、分屏或受保护界面在其上时，这个源窗口子层不能承诺覆盖物理面板的每一个像素。

## 构建和验证

在装有 JDK 17 和 Android SDK 的独立环境运行以下命令，参数可重复，用于比较不同版本的公开 SDK。

```sh
python3 platform/wake-transition/test.py --android-jar "$ANDROID_HOME/platforms/android-35/android.jar" --android-jar "$ANDROID_HOME/platforms/android-36/android.jar"
```

API 35 和 API 36 均已用 -Werror 编译，生产 SourceLease 通过 34 项断言，包括真实帧门槛、错误来源、尺寸或输入绑定被替换、受保护界面、息屏代过期、取消、单次展示和超时。测试没有使用真实 WMS 句柄、InputDispatcher、SurfaceFlinger 或面板。此阶段仅提供源码，回滚候选模块无须卸载本目录中的任何手机组件。
