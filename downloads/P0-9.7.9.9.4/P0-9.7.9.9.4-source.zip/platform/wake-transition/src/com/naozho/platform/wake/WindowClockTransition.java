package com.naozho.platform.wake;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceControl;
import android.view.SurfaceControlViewHost;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.window.InputTransferToken;
import java.util.Objects;

/**
 * OEM source integration for a single primary display. Never published to ServiceManager and never
 * linked into the KSU candidate. The WM integration supplies original, scoped platform capabilities.
 * prepare and close run OUTSIDE the WMS lock on the host UI looper. place() is called in each
 * relevant WM placement under its lock, using that placement's ordered compositor transaction.
 */
public final class WindowClockTransition implements AutoCloseable {
    public interface PlacementHost {
        /** Schedule a WM traversal; implementation must post without waiting for it. */
        void requestPlacement();
        /** Async transaction commit, not proof of physical display or input acceptance. */
        void onSurfaceCommitted(long dark, boolean visible);
        /** Under WMS lock, prove the child's *current* channel maps to this exact original window. */
        boolean hasEmbeddedInput(Object sourceWindow, InputTransferToken child);
    }

    private final Context uiContext;
    private final Handler handler;
    private final PlacementHost host;
    private final SourceLease leases = new SourceLease();
    private Instance current;

    public WindowClockTransition(Context uiContext, Handler handler, PlacementHost host) {
        this.uiContext = Objects.requireNonNull(uiContext);
        this.handler = Objects.requireNonNull(handler);
        this.host = Objects.requireNonNull(host);
    }

    private final class Instance {
        final long dark;
        final Object origin;
        final SurfaceControl parent;
        final int width, height;
        final IBinder controller;
        final IBinder.DeathRecipient death;
        final Runnable expiry;
        SurfaceControlViewHost root;
        SurfaceControlViewHost.SurfacePackage child;

        Instance(long dark, Object origin, SurfaceControl parent, int width, int height, IBinder controller) {
            this.dark = dark; this.origin = origin; this.parent = parent;
            this.width = width; this.height = height; this.controller = controller;
            this.death = () -> handler.post(() -> cancel(dark));
            this.expiry = () -> expire(this);
        }
    }

    private void onUi() {
        if (Looper.myLooper() != handler.getLooper()) throw new IllegalStateException("host UI looper required");
    }

    /** sourceWindow and sourceParent are host-owned references, never accepted from a client. */
    public boolean prepare(long dark, Object sourceWindow, SurfaceControl sourceParent,
                           InputTransferToken sourceInput, int width, int height,
                           Display display, IBinder controllerLifetime) {
        onUi();
        if (sourceParent == null || !sourceParent.isValid() || sourceInput == null ||
                controllerLifetime == null || !controllerLifetime.isBinderAlive() || display == null ||
                display.getDisplayId() != Display.DEFAULT_DISPLAY || width <= 0 || height <= 0 ||
                width > 16384 || height > 16384) return false;
        final Instance value;
        synchronized (this) {
            if (current != null || !leases.begin(dark, sourceWindow, SystemClock.elapsedRealtime())) return false;
            current = value = new Instance(dark, sourceWindow, sourceParent,width,height,controllerLifetime);
        }
        try {
            controllerLifetime.linkToDeath(value.death, 0);
            value.root = new SurfaceControlViewHost(uiContext, display, sourceInput);
            Cover cover = new Cover(uiContext);
            value.root.setView(cover, width, height);
            SurfaceControlViewHost.SurfacePackage child = Objects.requireNonNull(value.root.getSurfacePackage());
            synchronized (this) { value.child = child; }
            if (!child.getSurfaceControl().isValid() || child.getInputTransferToken() == null) {
                cancel(dark);
                return false;
            }
            cover.getViewTreeObserver().registerFrameCommitCallback(() -> {
                synchronized (WindowClockTransition.this) {
                    if (!leases.frame(dark)) return;
                }
                host.requestPlacement();
            });
            cover.invalidate();
            handler.postDelayed(value.expiry, Math.max(0, dark + SourceLease.MAX_DARK_MS - SystemClock.elapsedRealtime()));
            return true;
        } catch (RuntimeException | RemoteException failure) {
            cancel(dark);
            return false;
        }
    }

    /** Called at ON even if formal wake is subsequently refused. This timeout never wakes the device. */
    public void onWakeCandidate(long dark) {
        onUi();
        synchronized (this) {
            if (!leases.live(dark)) return;
            long now = SystemClock.elapsedRealtime();
            leases.onInteractive(dark, now);
            handler.removeCallbacks(current.expiry);
            handler.postDelayed(current.expiry, Math.max(0, leases.expires() - now));
        }
    }

    private void expire(Instance value) {
        synchronized (this) {
            if (current != value || !leases.live(value.dark)) return;
            long left = leases.expires() - SystemClock.elapsedRealtime();
            if (left > 0) { handler.postDelayed(value.expiry, left); return; }
        }
        cancel(value.dark);
    }

    /**
     * Host checks that this *window* remains the approved origin. Supply false on keyguard, emergency,
     * credentials, incoming calls, permission/unknown overlays, mode change or OFF reversal.
     * Width and height are source-local, unrotated dimensions. A replaced surface aborts the lease.
     * The host must apply its transaction in placement order before running a newer placement.
     */
    public synchronized void place(long dark, Object actualWindow, SurfaceControl actualParent,
                                   int width, int height, boolean ordinary,
                                   SurfaceControl.Transaction placement) {
        Instance value = current;
        if (value == null || !leases.live(dark)) return;
        if (value.child == null && ordinary && actualWindow == value.origin &&
                actualParent == value.parent && actualParent.isValid() && width == value.width &&
                height == value.height && SystemClock.elapsedRealtime() < leases.expires()) return;
        SurfaceControl surface = value.child == null ? null : value.child.getSurfaceControl();
        boolean input = false;
        if (ordinary && actualWindow == value.origin && surface != null && surface.isValid()) {
            try { input = host.hasEmbeddedInput(actualWindow, value.child.getInputTransferToken()); }
            catch (RuntimeException unavailable) { /* refuse this placement */ }
        }
        SourceLease.Action action = leases.placement(dark, actualWindow, ordinary && value.controller.isBinderAlive(),
                input, actualParent == value.parent && value.parent.isValid() &&
                width == value.width && height == value.height, SystemClock.elapsedRealtime());
        try {
            if (action == SourceLease.Action.ATTACH) {
                placement.reparent(surface, value.parent).setPosition(surface, 0, 0)
                        .setCrop(surface, new Rect(0, 0, width, height)).setLayer(surface, Integer.MAX_VALUE)
                        .setVisibility(surface, true).addTransactionCommittedListener(handler::post, () -> {
                            synchronized (WindowClockTransition.this) { if (!leases.live(dark)) return; }
                            host.onSurfaceCommitted(dark, true);
                        });
            } else if (action == SourceLease.Action.REMOVE) {
                if (surface != null && surface.isValid()) {
                    placement.setVisibility(surface, false).reparent(surface, null);
                }
                handler.post(() -> cancel(dark));
            }
        } catch (RuntimeException failure) {
            leases.end(dark);
            handler.post(() -> cancel(dark));
        }
    }

    /** A verified handoff or an abort uses the exact generation, never a generic display-layer teardown. */
    public void cancel(long dark) {
        onUi();
        final Instance value;
        synchronized (this) {
            if (current == null || current.dark != dark) return;
            value = current;
            leases.end(dark);
            current = null;
        }
        handler.removeCallbacks(value.expiry);
        try { value.controller.unlinkToDeath(value.death, 0); } catch (RuntimeException alreadyDead) { /* release below */ }
        try {
            if (value.child != null && value.child.getSurfaceControl().isValid()) {
                SurfaceControl s = value.child.getSurfaceControl();
                try (SurfaceControl.Transaction tx = new SurfaceControl.Transaction()) {
                    tx.setVisibility(s, false).reparent(s, null)
                            .addTransactionCommittedListener(handler::post, () -> host.onSurfaceCommitted(dark,false))
                            .apply();
                }
            }
        } catch (RuntimeException unavailable) {
            Log.w("ClockTransition", "Compositor detach unavailable; releasing the embedded window");
        } finally {
            try {
                if (value.root != null) value.root.release();
            } catch (RuntimeException alreadyGone) {
                Log.w("ClockTransition", "Embedded window cleanup unavailable");
            }
            try {
                if (value.child != null) value.child.release();
            } catch (RuntimeException alreadyGone) {
                Log.w("ClockTransition", "Surface package cleanup unavailable");
            }
        }
    }

    @Override public void close() {
        onUi();
        final Instance value;
        synchronized (this) { value = current; }
        if (value != null) cancel(value.dark);
    }

    static final class Cover extends View {
        Cover(Context context) {
            super(context);
            setBackgroundColor(Color.BLACK);
            setFocusable(false);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        }
        @Override public void setLayoutParams(ViewGroup.LayoutParams p) {
            if (!(p instanceof WindowManager.LayoutParams)) throw new IllegalArgumentException("expected embedded window");
            WindowManager.LayoutParams w = (WindowManager.LayoutParams)p;
            if ((w.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) != 0) {
                throw new IllegalStateException("embedded window has no pointer input");
            }
            w.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
            super.setLayoutParams(p);
        }
        @Override public boolean onTouchEvent(MotionEvent unused) { return true; }
    }
}
