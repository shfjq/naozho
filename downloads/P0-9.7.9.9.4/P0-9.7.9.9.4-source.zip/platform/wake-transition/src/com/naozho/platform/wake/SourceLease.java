package com.naozho.platform.wake;

/** One host process, one boot; each generation is the observed monotonic DARK edge. */
final class SourceLease {
    enum Action { WAIT, ATTACH, KEEP, REMOVE, STALE }
    static final long MAX_ON_MS = 8000;
    static final long MAX_DARK_MS = 24 * 60 * 60 * 1000L;
    private long generation = -1, expires;
    private Object window;
    private boolean frame, attached, closed = true, waking;

    boolean begin(long next, Object identity, long now) {
        if (!closed || identity == null || next < 1 || next <= generation || now < next ||
                now - next >= MAX_DARK_MS) return false;
        generation = next;
        window = identity;
        expires = next + MAX_DARK_MS;
        frame = attached = waking = false;
        closed = false;
        return true;
    }

    boolean frame(long key) {
        if (!live(key)) return false;
        frame = true;
        return true;
    }

    void onInteractive(long key, long now) {
        if (live(key) && !waking) {
            waking = true;
            expires = Math.min(expires, now + MAX_ON_MS);
        }
    }

    long expires() { return expires; }
    boolean live(long key) { return !closed && key == generation; }

    Action placement(long key, Object liveWindow, boolean eligible, boolean sameInputHost,
                     boolean sameGeometry, long now) {
        if (!live(key)) return Action.STALE;
        if (liveWindow != window || !eligible || !sameInputHost || !sameGeometry || now >= expires) {
            end(key);
            return Action.REMOVE;
        }
        if (!frame) return Action.WAIT;
        if (attached) return Action.KEEP;
        attached = true;
        return Action.ATTACH;
    }

    boolean end(long key) {
        if (!live(key)) return false;
        closed = true;
        window = null;
        return true;
    }
}
