package com.naozho.platform.wake;

import static com.naozho.platform.wake.SourceLease.Action.*;

/** Runs the same generation, expiry and placement decisions used by WindowClockTransition. */
public final class SourceLeaseTest {
    private static int checked;
    private static void expect(Object actual, Object value) {
        checked++;
        if (!value.equals(actual)) throw new AssertionError("expected " + value + " got " + actual);
    }
    public static void main(String[] args) {
        SourceLease state = new SourceLease();
        Object a = new Object(), b = new Object();
        expect(state.begin(2,a,1),false);
        expect(state.begin(2,null,2),false);
        expect(state.begin(2,a,2),true);
        expect(state.begin(3,a,3),false);
        expect(state.placement(2,a,true,true,true,3),WAIT);
        expect(state.frame(1),false);
        expect(state.frame(2),true);
        expect(state.placement(2,a,true,true,true,4),ATTACH);
        expect(state.placement(2,a,true,true,true,5),KEEP);
        expect(state.placement(2,b,true,true,true,6),REMOVE);
        expect(state.placement(2,a,true,true,true,7),STALE);
        expect(state.frame(2),false);
        expect(state.begin(2,a,8),false);
        expect(state.begin(8,b,8),true);
        expect(state.end(2),false);
        expect(state.frame(8),true);
        expect(state.placement(8,b,false,true,true,8),REMOVE);
        for (int i=0;i<2;i++) {
            int key=10+i;
            expect(state.begin(key,b,key),true);
            expect(state.frame(key),true);
            expect(state.placement(key,b,true,i!=0,i!=1,key),REMOVE);
        }
        expect(state.begin(12,b,12),true);
        expect(state.frame(12),true);
        state.onInteractive(12,100);
        long deadline=state.expires();
        expect(deadline,8100L);
        state.onInteractive(12,900);
        expect(state.expires(),deadline);
        expect(state.placement(12,b,true,true,true,8099),ATTACH);
        expect(state.placement(12,b,true,true,true,8100),REMOVE);
        expect(state.begin(92,b,92+SourceLease.MAX_DARK_MS),false);
        expect(state.begin(93,b,93),true);
        expect(state.end(93),true);
        expect(state.end(93),false);
        expect(state.frame(93),false);
        System.out.println("SourceLeaseTest: " + checked + " assertions passed");
    }
}
