"""Compile the optional OEM platform helper; run only its production state-policy assertions."""
import argparse
from pathlib import Path
import subprocess
import tempfile

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--android-jar', required=True, type=Path, action='append')
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    sources = sorted((here / 'src').rglob('*.java'))
    tests = sorted((here / 'tests').rglob('*.java'))
    with tempfile.TemporaryDirectory() as tmp:
        for sdk in args.android_jar:
            subprocess.run(['javac', '--release', '11', '-Werror', '-Xlint:all', '-cp', str(sdk),
                            '-d', tmp, *sources, *tests], check=True)
            print('Platform helper compiled against', sdk.name, flush=True)
        subprocess.run(['java', '-cp', tmp, 'com.naozho.platform.wake.SourceLeaseTest'], check=True)
