plugins {
    id("com.android.application")
}

android {
    namespace = "com.naozho.homeprobe"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.naozho.homeprobe"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
