package com.naozho.homeprobe;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.UserManager;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** An ordinary HOME candidate and an independent PackageManager caller. */
public final class MainActivity extends Activity {
    private TextView output;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        output = new TextView(this);
        output.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(output);
        layout.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Button done = new Button(this);
        done.setText("结束对照");
        done.setOnClickListener(view -> finish());
        layout.addView(done);
        setContentView(layout);
    }

    @Override
    public void onResume() {
        super.onResume();
        StringBuilder result = new StringBuilder("HOME 对照 · userUnlocked=")
                .append(getSystemService(UserManager.class).isUserUnlocked()).append('\n');
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        report(result, home, 0);
        report(result, new Intent(home).addCategory(Intent.CATEGORY_DEFAULT), PackageManager.MATCH_DEFAULT_ONLY);
        output.setText(result);
        Log.i("NaozhoHomeProbe", result.toString());
    }

    private void report(StringBuilder out, Intent intent, int flags) {
        PackageManager pm = getPackageManager();
        out.append(intent.getCategories()).append(" flags=").append(flags).append('\n');
        for (String scope : new String[]{null, "com.naozho.clock", getPackageName()}) {
            List<String> found = new ArrayList<>();
            for (ResolveInfo info : pm.queryIntentActivities(new Intent(intent).setPackage(scope), flags)) {
                found.add(component(info));
            }
            Collections.sort(found);
            out.append(scope == null ? "global" : scope).append(" = ").append(found).append('\n');
        }
        // Match the ordinary HOME launch and the DEFAULT-category lookup used by the clock.
        int launchFlags = PackageManager.MATCH_DEFAULT_ONLY | PackageManager.GET_SHARED_LIBRARY_FILES;
        ResolveInfo resolved = pm.resolveActivity(intent, flags == 0 ? launchFlags : flags);
        out.append("resolved = ").append(resolved == null ? "none" : component(resolved)).append('\n');
    }

    private static String component(ResolveInfo info) {
        ActivityInfo activity = info.activityInfo;
        return new ComponentName(activity.packageName, activity.name).flattenToShortString();
    }
}
