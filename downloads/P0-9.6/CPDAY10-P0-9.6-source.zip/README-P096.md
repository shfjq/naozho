# CPDAY10 P0-9.6 交付源码

源码提交 1a636c0bc6f8e88496f130e346925120d065327e。包含现有 0.6.13-dev 应用工程、系统适配模块、测试和 DSH 工具。本次只构建适配模块。
使用 Python 3.9+、JDK 17、Android 36 SDK 和 Build Tools 35.0.0。将 JAVA_HOME 指向 JDK，再从本目录执行以下离线命令，其中 SDK 为本机 Android SDK 根路径。

```sh
python3 kernelsu/naozho_power/test.py --android-jar SDK/platforms/android-36/android.jar --d8 SDK/build-tools/35.0.0/d8 --out naozho-power-trial-0.2.1.zip
python3 -m unittest discover -s tools/p095
```

本轮交接文档为 tools/p095/P096-DSH.md 及 P096-report.md。历史版本的报告和回滚流程仅供对照。此源码包不包含签名私钥。
