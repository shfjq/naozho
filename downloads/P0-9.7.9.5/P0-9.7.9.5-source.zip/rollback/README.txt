Use a copy of this source tree. Run git apply rollback/5842423.patch to restore the verified 0.6.17-dev/32 + 1.3.0 source.
The paired rollback APK distributed here is built from those sources with only versionCode = 33 in app/build.gradle.kts, and its accompanying 1.3.0 module pins that APK. Use the original signing identity.
