package com.naozho.clock.mode

/** Owned by one Activity on its UI thread. A render callback can arrive on either side of LOCKED. */
internal class ClockFrameHandoff(val ticket: WakeTicket) {
    private var awaitingCommit = false
    private var committed = false
    private var locked = false
    private var released = false

    val needsDraw get() = !awaitingCommit && !committed && !released

    fun armForClockDraw(hardwareFrame: Boolean): Boolean {
        if (!hardwareFrame || !needsDraw) return false
        awaitingCommit = true
        return true
    }

    fun frameSubmitted(): Boolean {
        if (!awaitingCommit || released) return false
        awaitingCommit = false
        committed = true
        return true
    }

    fun lockConfirmed() { locked = true }

    fun takeHandoff(liveClockFocus: Boolean): Boolean {
        if (released || !committed || !locked || !liveClockFocus) return false
        released = true
        return true
    }
}
