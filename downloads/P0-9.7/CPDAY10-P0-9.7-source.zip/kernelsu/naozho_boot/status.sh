# Sourced by the three KernelSU entry scripts.
umask 077
state="$MODDIR/state"
mkdir -p "$state" || exit 1

uptime_seconds() {
  read -r elapsed ignored < /proc/uptime || return 1
  printf '%s\n' "${elapsed%%.*}"
}

kernel_boot_id() {
  local id
  read -r id < /proc/sys/kernel/random/boot_id || return 1
  case "$id" in ''|*[!a-f0-9-]*) return 1 ;; esac
  [ "${#id}" = 36 ] || return 1
  printf '%s\n' "$id"
}

snapshot() {
  completed=$(timeout 3 /system/bin/getprop sys.boot_completed 2>/dev/null)
  count=$(timeout 4 /system/bin/settings get global boot_count 2>/dev/null)
  case "$count" in ''|*[!0-9]*) count=unknown ;; esac
  user=$(timeout 4 /system/bin/am get-current-user 2>/dev/null)
  storage=$(timeout 4 /system/bin/am get-started-user-state 0 2>/dev/null)
}

note() {
  printf '%s uptime_s=%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$(uptime_seconds)" "$*" >> "$journal"
}

stages_enabled() {
  [ ! -e "$MODDIR/disable" ] && [ ! -e "$MODDIR/remove" ]
}
