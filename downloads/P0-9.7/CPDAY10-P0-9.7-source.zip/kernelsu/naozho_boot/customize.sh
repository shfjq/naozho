[ "$KSU" = true ] || abort "Install with KernelSU Manager"
for file in service.sh boot-completed.sh action.sh; do
  set_perm "$MODPATH/$file" 0 0 0755
done
ui_print "- Observe mode is the default. Use Action to toggle the next boot experiment."
