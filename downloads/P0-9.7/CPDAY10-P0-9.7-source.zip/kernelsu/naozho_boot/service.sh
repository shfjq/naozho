#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/status.sh"
stages_enabled || exit 0
journal="$state/service.log"
: > "$journal" || exit 1
note "stage=service entered"
snapshot
note "stage=service boot_count=$count sys.boot_completed=${completed:-unknown} current_user=${user:-unknown} user0=${storage:-unknown}"
