#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/status.sh"
stages_enabled || { echo "Module is disabled or pending removal."; exit 1; }
if [ -e "$state/enabled-from" ]; then
  rm -f "$state/enabled-from" || exit 1
  echo "OBSERVE. Boot events will only be logged."
else
  id=$(kernel_boot_id) || { echo "Cannot identify this boot."; exit 1; }
  printf '%s\n' "$id" > "$state/enable.$$" && mv -f "$state/enable.$$" "$state/enabled-from" || exit 1
  echo "REQUEST on subsequent boots. The clock application decides whether to open."
fi
