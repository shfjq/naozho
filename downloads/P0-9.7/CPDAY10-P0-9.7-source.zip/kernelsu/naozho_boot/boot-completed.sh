#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/status.sh"
stages_enabled || exit 0
journal="$state/boot.log"
id=$(kernel_boot_id) || { note "stop=boot_id_unavailable"; exit 1; }
# mkdir claims the kernel boot atomically, even across repeated ksud callbacks.
mkdir "$state/boot-$id" 2>/dev/null || { note "stop=duplicate_or_claim_failed"; exit 0; }
for old in "$state"/boot-*/; do
  [ -d "$old" ] && [ "$old" != "$state/boot-$id/" ] && rmdir "$old"
done
if [ -f "$journal" ]; then mv -f "$journal" "$state/previous-boot.log" || exit 1; fi
note "stage=boot-completed entered" || exit 1
origin=$(cat "$state/enabled-from" 2>/dev/null)
snapshot
note "boot_count=$count sys.boot_completed=${completed:-unknown} current_user=${user:-unknown} user0=${storage:-unknown}"
case "$origin" in ''|*[!a-f0-9-]*) note "phase=observe"; exit 0 ;; esac
if [ "${#origin}" != 36 ] || [ "$origin" = "$id" ]; then note "phase=observe reason=invalid_or_just_armed"; exit 0; fi

# A late first unlock may miss the experiment; never reopen apps later that day.
start=$(uptime_seconds) || exit 1
while [ "$completed" != 1 ] || [ "$count" = unknown ] || [ "$user" != 0 ] || [ "$storage" != RUNNING_UNLOCKED ]; do
  if ! stages_enabled || [ "$(cat "$state/enabled-from" 2>/dev/null)" != "$origin" ]; then note "stop=disabled"; exit 0; fi
  now=$(uptime_seconds) || exit 1
  if [ "$((now - start))" -ge 120 ]; then note "stop=readiness_timeout boot_count=$count completed=$completed user=$user user0=$storage"; exit 0; fi
  sleep 3
  snapshot
done
if ! stages_enabled || [ "$(cat "$state/enabled-from" 2>/dev/null)" != "$origin" ]; then note "stop=disabled"; exit 0; fi
note "phase=request submitting boot_count=$count user=0 user0=$storage" || exit 1
/system/bin/log -t NaozhoKsu "before-request:$id" 2>/dev/null
reply=$(timeout 20 /system/bin/am broadcast --user 0 --exclude-stopped-packages \
  -a com.naozho.clock.action.MODULE_BOOT_READY \
  -n com.naozho.clock/.mode.ModuleBootReceiver --ei boot_count "$count" 2>&1)
status=$?
note "dispatch_exit=$status reply=$reply"
record_denial() {
  # Restrict evidence to this handoff. A missing system reason remains unknown.
  reason=$(timeout 4 /system/bin/logcat -d -t 400 -b main -b system -v brief \
    -s NaozhoKsu:I ActivityTaskManager:V ActivityManager:V Atlas:V 2>/dev/null |
    awk -v marker="before-request:$id" 'index($0, marker) {seen=1; next}
      seen && /com\.naozho\.clock/ && tolower($0) ~ /denied|blocked|abort|not allowed|background activity start denied/ {last=substr($0,1,1200)}
      END {print last}')
  note "system_reason=${reason:-not_observed}"
}
if [ "$status" != 0 ]; then note "stop=dispatch_failed_or_timed_out"; record_denial; exit 1; fi
case "$reply" in
  *"Broadcast completed: result=201"*)
    note "activity_requested"
    sleep 3
    lock=$(timeout 5 /system/bin/dumpsys activity activities 2>/dev/null |
      awk '/mLockTaskModeState=/ {sub(/.*mLockTaskModeState=/,""); print $1; exit}')
    focus=$(timeout 5 /system/bin/dumpsys window windows 2>/dev/null |
      awk '/mCurrentFocus=/ {print (index($0,"com.naozho.clock/") ? "clock" : "other_or_none"); exit}')
    note "one_readback lock=${lock:-unknown} focus=${focus:-unknown}"
    if [ "$lock" != LOCKED ] || [ "$focus" != clock ]; then record_denial; fi ;;
  *"Broadcast completed: result=204"*) note "no_new_request" ;;
  *) note "stop=rejected_or_no_app_ack"; record_denial; exit 1 ;;
esac
