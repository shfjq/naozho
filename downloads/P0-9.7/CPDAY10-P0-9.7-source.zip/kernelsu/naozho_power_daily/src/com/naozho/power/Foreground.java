package com.naozho.power;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.naozho.power.TrialChecks.Refused;

/** API 36 WindowState.dump and RootWindowContainer.dumpWindowsNoHeader. No UI text or view tree. */
final class Foreground {
    static final String SETTINGS = "com.android.settings";
    static final String CALC = "com.darkempire78.opencalculator";
    static final String CALC_PAGE = CALC + "/" + CALC + ".activities.MainActivity";
    static final String CALC_SHA = "43b6befd1fecc686ba1611bbda18896cc26d966047e788be995def569a4510f3";
    static final String NAME = "[a-zA-Z][a-zA-Z0-9_.$]*";
    private static final Pattern HEADER = Pattern.compile("(?m)^  Window #(\\d+) Window\\{([0-9a-fA-F]+) u(\\d+) ([^\\r\\n{}]+)\\}: *$");
    static String canonical(String c) throws Refused {
        if (!c.matches(NAME + "/" + NAME + "|" + NAME + "/\\." + NAME)) throw new Refused("unclassified_window");
        int sep=c.indexOf('/');
        return c.charAt(sep+1)=='.' ? c.substring(0,sep+1)+c.substring(0,sep)+c.substring(sep+1) : c;
    }

    static String focus(String display) throws Refused {
        String target=canonical(TrialChecks.focus(display));
        String resumed=TrialChecks.one(display,"^ *mFocusedApp=ActivityRecord\\{[^\\s{}]+ u0 ([^\\s{}]+) t[0-9]+[^{}]*\\} *$", "focused_app_unknown");
        if (!target.equals(canonical(resumed))) throw new Refused("focus_transition");
        return target;
    }

    static boolean settingsHome(String c) {
        return c.equals(SETTINGS + "/" + SETTINGS + ".Settings") ||
                c.equals(SETTINGS + "/" + SETTINGS + ".homepage.SettingsHomepageActivity");
    }

    static String settingsRouteFilter(String display) throws Refused {
        String id=TrialChecks.one(display,"^ *mFocusedApp=ActivityRecord\\{([0-9a-fA-F]+) u0 [^{}]+\\} *$","activity_identity_unknown");
        // Only classification bits leave the producer. Shared Settings containers may host
        // security fragments, so reject deep links, extras, dialogs and non-root routes.
        String token="(flg=0x[0-9a-fA-F]+|xflg=0x[0-9a-fA-F]+|pkg=com[.]android[.]settings"
                +"|cat=\\[android[.]intent[.]category[.]LAUNCHER\\]"
                +"|cmp=com[.]android[.]settings\\/(com[.]android[.]settings)?[.](Settings|homepage[.]SettingsHomepageActivity))";
        return "/^[ ]*[*] Hist #[0-9]+: ActivityRecord\\{"+id+" u0 /,/^[ ]*rootOfTask=/ { "
                +"/^[ ]*Intent \\{ act=(android[.]settings[.]SETTINGS|android[.]intent[.]action[.]MAIN)( "+token+")* \\}$/s/.*/ordinary/p; "
                +"/^[ ]*rootOfTask=true /s/.*/root/p; }";
    }

    static void callsIdle(String states) throws Refused {
        if (!states.matches("0(?:\\n0)*")) throw new Refused("call_or_unknown");
    }

    static void lockAndKeyguard(String states) throws Refused {
        if (!TrialChecks.one(states,"^mLockTaskModeState=(?:LOCK_TASK_MODE_)?(\\w+)$","lock_state_unknown").equals("NONE"))
            throw new Refused("task_already_locked");
        boolean known=false;
        for (String line:states.split("\n")) {
            if (line.startsWith("isKeyguardShowing=") || line.startsWith("mKeyguardShowing=")) {
                if (!line.equals("isKeyguardShowing=false") && !line.equals("mKeyguardShowing=false")) throw new Refused("keyguard");
                known=true;
            }
        }
        if (!known) throw new Refused("keyguard_unknown");
    }

    static String focusId(String display) throws Refused {
        return TrialChecks.one(display,"^ *mCurrentFocus=Window\\{([0-9a-fA-F]+) u0 [^\\s{}]+\\} *$","focus_id_unknown");
    }

    static void mode(String rows, long first) throws Refused {
        if (!TrialChecks.one(rows, "^ *<boolean name=\"android\" value=\"(true|false)\" */> *$", "mode_unknown").equals("true") ||
                !TrialChecks.one(rows,"^ *<boolean name=\"managed_lock\" value=\"(true|false)\" */> *$", "lock_unknown").equals("true") ||
                !TrialChecks.one(rows,"^ *<boolean name=\"managed_home\" value=\"(true|false)\" */> *$", "home_unknown").equals("false") ||
                first <= Long.parseLong(TrialChecks.one(rows,"^ *<long name=\"mode_since\" value=\"([0-9]{1,15})\" */> *$", "generation_unknown")))
            throw new Refused("mode_ineligible");
    }

    static void visible(String dump,String target,String focusId) throws Refused {
        if (!dump.startsWith("WINDOW MANAGER WINDOWS") || dump.contains("Hiding System Alert Windows:") ||
                dump.contains("Windows force removing:")) throw new Refused("windows_unconfirmed");
        Matcher header=HEADER.matcher(dump);
        int n=0;
        boolean seen=false;
        while (header.find()) {
            if (Integer.parseInt(header.group(1))!=n++ || !"0".equals(header.group(3))) throw new Refused("unexpected_window");
            int stop=dump.indexOf("\n  Window #",header.end());
            String body=dump.substring(header.end(),stop<0?dump.length():stop);
            // Other WMS sections after the final window are not part of that window.
            Matcher section=Pattern.compile("(?m)^  [^ \\r\\n]").matcher(body);
            if (section.find()) body=body.substring(0,section.start());
            String name=header.group(4);
            String type=TrialChecks.one(body,"^ *mAttrs=\\{[^\\r\\n]* ty=([A-Z_]+)\\b[^\\r\\n]*$", "window_type_unknown");
            String owner=TrialChecks.one(body,"^ *mOwnerUid=\\d+ showForAllUsers=(?:true|false) package=([a-zA-Z0-9_.]+) .*$","window_owner_unknown");
            String flags=TrialChecks.one(body,"^ +fl=([^\\r\\n}]+)\\}? *$","window_flags_unknown");
            if (!body.matches("(?s).*\\n *mDisplayId=0 .*") || !flags.matches("0|[A-Z][A-Z_0-9]*(?:[ |]+[A-Z][A-Z_0-9]*)*") ||
                    flags.matches(".*\\b(?:FLAG_)?SECURE\\b.*")) throw new Refused("secure_or_unknown_window");
            if (name.contains("/") && type.equals("BASE_APPLICATION") && owner.equals(target.split("/",2)[0]) &&
                    canonical(name).equals(target) && header.group(2).equals(focusId) && !seen) { seen=true; continue; }
            if (seen && type.equals("WALLPAPER")) continue;
            boolean chrome=owner.equals("com.android.systemui") && flags.contains("NOT_FOCUSABLE") && (
                    type.equals("STATUS_BAR") && name.equals("StatusBar") ||
                    type.equals("NAVIGATION_BAR") && name.matches("NavigationBar(?:0)?") ||
                    type.equals("DISPLAY_OVERLAY") && name.matches("ScreenDecorOverlay[A-Za-z0-9]*") && flags.contains("NOT_TOUCHABLE"));
            if (!chrome) throw new Refused("additional_visible_window");
        }
        // An unrecognised header must not hide a second window.
        if (!seen || dump.split("(?m)^  Window #",-1).length-1!=n) throw new Refused("window_set_incomplete");
    }
    private Foreground() {}
}
