package com.naozho.power;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;

/** Only bounded outcomes and aggregate counters; no window names, key edges or gesture timestamps. */
final class DailyLog {
    private final Path dir;
    private long lastVeto;
    int probes,attempted,delivered,vetoed;
    DailyLog(Path dir) { this.dir=dir; }
    synchronized void veto(String reason) throws IOException {
        vetoed++;
        long now=System.nanoTime();
        if (lastVeto==0 || now-lastVeto>=TimeUnit.MINUTES.toNanos(1)) {
            write("skipped_"+reason); lastVeto=now;
        }
    }
    synchronized void write(String reason) throws IOException {
        if (!reason.matches("[a-zA-Z0-9_]{1,100}")) reason="unclassified_error";
        String line="state="+reason+" probes="+probes+" attempts="+attempted+" delivered="+delivered+" skipped="+vetoed+"\n";
        Path file=dir.resolve("daily.log");
        long day=TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis());
        if (Files.exists(file) && (Files.size(file)+line.length()>8192 ||
                TimeUnit.MILLISECONDS.toDays(Files.getLastModifiedTime(file).toMillis())!=day))
            Files.move(file,dir.resolve("daily.log.1"),StandardCopyOption.REPLACE_EXISTING);
        byte[] bytes=line.getBytes(StandardCharsets.US_ASCII);
        Files.write(file,bytes,StandardOpenOption.CREATE,StandardOpenOption.APPEND);
        Path tmp=dir.resolve("status.tmp");
        Files.write(tmp,bytes);
        Files.move(tmp,dir.resolve("status"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
    }
}
