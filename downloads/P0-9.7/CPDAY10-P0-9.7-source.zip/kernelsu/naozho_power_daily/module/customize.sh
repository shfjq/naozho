[ "$KSU" = true ] && [ "$API" = 36 ] && [ "$ARCH" = arm64 ] && [ "$(getprop ro.product.device)" = CPDAY10 ] || abort "Requires CPDAY10, API 36, arm64 and KernelSU"
[ ! -e /data/adb/modules/naozho_power_trial/module.prop ] || abort "Remove the trial module first"
set_perm_recursive "$MODPATH" 0 0 0700 0600
for f in start.sh action.sh boot-completed.sh uninstall.sh; do set_perm "$MODPATH/$f" 0 0 0700; done
set_perm "$MODPATH/libpowerinput.so" 0 0 0700
ui_print "- Installed inactive. After review use Action to enable. Action again stops the listener."
