#!/system/bin/sh
rm -f /data/adb/modules/naozho_power_daily/armed
