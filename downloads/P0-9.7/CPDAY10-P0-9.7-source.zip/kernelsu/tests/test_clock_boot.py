"""Run the shipped shell hooks against a fake Android command boundary."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


class ClockBootTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.mod = self.root / "module"
        shutil.copytree(Path(__file__).resolve().parents[1] / "naozho_boot", self.mod)
        self.bin = self.root / "bin"
        self.bin.mkdir()
        self.put("bootid", "11111111-1111-1111-1111-111111111111")
        self.put("uptime", "60.05 1.0")
        self.put("count", "18")
        self.put("user", "0")
        self.put("storage", "RUNNING_UNLOCKED")
        self.put("completed", "1")
        self.put("result", "201")
        for script in self.mod.glob("*.sh"):
            code = script.read_text().replace("/system/bin/", str(self.bin) + "/")
            code = code.replace("/proc/uptime", str(self.root / "uptime"))
            code = code.replace("/proc/sys/kernel/random/boot_id", str(self.root / "bootid"))
            code = code.replace("sleep 3", str(self.bin / "sleep") + " 3")
            script.write_text(code)
        self.stub("getprop", 'cat "$FAKE/completed"')
        self.stub("settings", 'cat "$FAKE/count"')
        self.stub("log", 'echo "$3" > "$FAKE/log-marker"')
        self.stub("logcat", '''
echo "Atlas: blocked com.naozho.clock OLD_EVENT"
cat "$FAKE/log-marker"
[ ! -f "$FAKE/denied" ] || echo "ActivityTaskManager: blocked com.naozho.clock CURRENT_EVENT"''')
        self.stub("dumpsys", '''
case "$1" in
  activity) echo 'mLockTaskModeState=LOCKED' ;;
  window) [ -f "$FAKE/denied" ] && echo 'mCurrentFocus=NotificationShade' ||
          echo 'mCurrentFocus=Window{100 u0 com.naozho.clock/.MainActivity}' ;;
esac''')
        self.stub("am", '''
case "$1" in
  get-current-user) cat "$FAKE/user" ;;
  get-started-user-state) cat "$FAKE/storage" ;;
  broadcast)
    echo "$*" >> "$FAKE/sends"
    [ ! -f "$FAKE/fail" ] || { echo "Permission denied"; exit 1; }
    echo "Broadcast completed: result=$(cat "$FAKE/result")" ;;
  *) exit 2 ;;
esac''')
        self.stub("sleep", '''
if [ -f "$FAKE/unlock" ]; then echo RUNNING_UNLOCKED > "$FAKE/storage"; fi
if [ -f "$FAKE/disable" ]; then touch "$FAKE/module/disable"; fi
echo "240.00 4.0" > "$FAKE/uptime"''')
        self.env = {"FAKE": str(self.root), "PATH": str(self.bin) + ":" + os.defpath}
        busybox = os.environ.get("KSU_TEST_BUSYBOX")
        self.shell = [busybox, "sh"] if busybox else ["sh"]
        if busybox:
            self.env["ASH_STANDALONE"] = "1"

    def stub(self, name, body):
        file = self.bin / name
        file.write_text("#!/bin/sh\n" + body + "\n")
        file.chmod(0o755)

    def put(self, key, value):
        (self.root / key).write_text(value + "\n")

    def hook(self, script, success=True):
        proc = subprocess.run(self.shell + [str(self.mod / (script + ".sh"))], env=self.env,
                              capture_output=True, text=True, timeout=6)
        self.assertEqual(success, proc.returncode == 0, proc.stderr)

    def arm_and_reboot(self):
        self.hook("action")
        self.put("bootid", "22222222-2222-2222-2222-222222222222")
        self.put("count", "19")

    def sends(self):
        file = self.root / "sends"
        return file.read_text().splitlines() if file.exists() else []

    def journal(self):
        return (self.mod / "state/boot.log").read_text()

    def test_observe_and_service(self):
        self.hook("service")
        self.hook("boot-completed")
        self.assertIn("phase=observe", self.journal())
        self.assertIn("boot_count=18", (self.mod / "state/service.log").read_text())
        self.assertEqual([], self.sends())

    def test_action_waits_for_next_boot(self):
        self.hook("action")
        self.hook("boot-completed")
        self.assertIn("just_armed", self.journal())
        self.assertEqual([], self.sends())

    def test_concurrent_callbacks_dispatch_exactly_once(self):
        self.arm_and_reboot()
        args = self.shell + [str(self.mod / "boot-completed.sh")]
        procs = [subprocess.Popen(args, env=self.env) for _ in range(4)]
        for proc in procs:
            self.assertEqual(0, proc.wait(timeout=6))
        self.assertEqual(["broadcast --user 0 --exclude-stopped-packages -a com.naozho.clock.action.MODULE_BOOT_READY "
                          "-n com.naozho.clock/.mode.ModuleBootReceiver --ei boot_count 19"], self.sends())
        self.assertIn("lock=LOCKED focus=clock", self.journal())

    def test_unfocused_request_records_only_current_denial(self):
        self.arm_and_reboot()
        self.put("denied", "")
        self.hook("boot-completed")
        self.assertIn("focus=other_or_none", self.journal())
        self.assertIn("CURRENT_EVENT", self.journal())
        self.assertNotIn("OLD_EVENT", self.journal())
        self.assertEqual(1, len(self.sends()))

    def test_maintenance_response_is_not_successful_launch(self):
        self.arm_and_reboot()
        self.put("result", "204")
        self.hook("boot-completed")
        self.assertIn("no_new_request", self.journal())
        self.assertNotIn("activity_requested", self.journal())

    def test_cold_storage_times_out(self):
        self.arm_and_reboot()
        self.put("storage", "RUNNING_LOCKED")
        self.hook("boot-completed")
        self.assertIn("readiness_timeout", self.journal())
        self.assertEqual([], self.sends())

    def test_observe_only_after_toggle_off(self):
        self.arm_and_reboot()
        self.hook("action")
        self.hook("boot-completed")
        self.assertIn("phase=observe", self.journal())
        self.assertEqual([], self.sends())

    def test_unlock_during_window(self):
        self.arm_and_reboot()
        self.put("storage", "RUNNING_LOCKED")
        self.put("unlock", "")
        self.hook("boot-completed")
        self.assertEqual(1, len(self.sends()))

    def test_disabled_during_wait(self):
        self.arm_and_reboot()
        self.put("storage", "RUNNING_LOCKED")
        self.put("disable", "")
        self.hook("boot-completed")
        self.assertIn("stop=disabled", self.journal())
        self.assertEqual([], self.sends())

    def test_permission_denial_not_retried(self):
        self.arm_and_reboot()
        self.put("fail", "")
        self.hook("boot-completed", False)
        self.hook("boot-completed")
        self.assertIn("Permission denied", self.journal())
        self.assertEqual(1, len(self.sends()))

    def test_default_system_reply_is_not_app_ack(self):
        self.arm_and_reboot()
        self.put("result", "0")
        self.hook("boot-completed", False)
        self.assertIn("no_app_ack", self.journal())

    def test_foreground_user_must_be_zero(self):
        self.arm_and_reboot()
        self.put("user", "10")
        self.hook("boot-completed")
        self.assertIn("readiness_timeout", self.journal())
        self.assertEqual([], self.sends())


if __name__ == "__main__":
    unittest.main()
