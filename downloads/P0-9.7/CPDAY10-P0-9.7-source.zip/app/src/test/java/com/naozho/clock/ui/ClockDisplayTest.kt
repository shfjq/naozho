package com.naozho.clock.ui

import android.Manifest
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.BatteryManager
import android.provider.Settings
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.text.TextLayoutResult
import androidx.test.core.app.ApplicationProvider
import androidx.test.platform.app.InstrumentationRegistry
import com.naozho.clock.MainActivity
import com.naozho.clock.display.DisplayPreferences
import com.naozho.clock.display.DisplaySettings
import com.naozho.clock.mode.DesktopMode
import com.naozho.clock.mode.ModeState
import com.naozho.clock.weather.CachedWeather
import com.naozho.clock.weather.PreferenceWeatherCache
import com.naozho.clock.weather.WeatherLocation
import com.naozho.clock.weather.WeatherReading
import org.junit.Assert.assertEquals
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowAlarmManager

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w360dp-h360dp-xhdpi")
class ClockDisplayTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test
    fun squareShowsClockAlarmWeatherSettingsAndUpdatesBattery() {
        enterClock()
        assertEquals(720, compose.activity.resources.displayMetrics.widthPixels)
        assertEquals(720, compose.activity.resources.displayMetrics.heightPixels)
        compose.onNodeWithContentDescription("显示设置").assertIsDisplayed()
        assertTextFits("下一次闹铃")
        assertTextFits("天气")
        assertEquals(2, compose.onAllNodesWithText("未配置", useUnmergedTree = true).fetchSemanticsNodes().size)

        val application = ApplicationProvider.getApplicationContext<Context>()
        compose.runOnIdle {
            application.sendBroadcast(Intent(Intent.ACTION_BATTERY_CHANGED).apply {
                putExtra(BatteryManager.EXTRA_LEVEL, 43)
                putExtra(BatteryManager.EXTRA_SCALE, 100)
            })
        }
        assertTextFits("电量 43%")
    }

    @Test
    fun updateTimestampFitsInsideTheDefaultSquareWithoutScrolling() {
        enterClock()
        val application = ApplicationProvider.getApplicationContext<Context>()
        val location = WeatherLocation("上海", 31.23, 121.47)
        DisplayPreferences(application.getSharedPreferences("clock_display", 0))
            .save(DisplaySettings(weatherLocation = location))
        PreferenceWeatherCache(application.getSharedPreferences("clock_weather", 0))
            .write(CachedWeather(location.key, WeatherReading(19.5, 3), System.currentTimeMillis()))
        compose.activityRule.scenario.recreate()

        assertTextFits("阴 · 20°C")
        val timestamp = compose.onNodeWithText("缓存 ·", substring = true, useUnmergedTree = true)
            .assertIsDisplayed().fetchSemanticsNode()
        assertTrue(
            "Weather update label must be fully visible: ${timestamp.boundsInRoot} of ${timestamp.size}",
            timestamp.boundsInRoot.height >= timestamp.size.height - 1,
        )
    }

    @Test
    @Config(qualifiers = "w300dp-h300dp-xhdpi")
    fun compactSquareWithDoubleFontCanScrollToCardsWithoutTextOverflow() {
        enterClock()
        RuntimeEnvironment.setFontScale(2f)
        compose.activityRule.scenario.recreate()
        assertEquals(600, compose.activity.resources.displayMetrics.widthPixels)
        assertEquals(600, compose.activity.resources.displayMetrics.heightPixels)
        val first = compose.onNodeWithText("下一次闹铃", useUnmergedTree = true)
        first.performScrollTo()
        assertTextFits("下一次闹铃")
        val weather = compose.onNodeWithText("天气", useUnmergedTree = true)
        weather.performScrollTo()
        assertTextFits("天气")
    }

    @Test
    fun screenOffClosesSettingsAndLeavesTheClockReadyForWake() {
        enterClock()
        compose.onNodeWithContentDescription("显示设置").performClick()
        compose.onNodeWithText("锁屏时显示前台时钟").assertExists()
        compose.runOnIdle {
            RuntimeEnvironment.getApplication().sendBroadcast(Intent(Intent.ACTION_SCREEN_OFF))
        }
        compose.onNodeWithContentDescription("显示设置").assertIsDisplayed()
        compose.onNodeWithText("锁屏时显示前台时钟").assertDoesNotExist()
    }

    @Test
    fun restoringAnActivityInAndroidModeKeepsThatModeUntilAnExplicitAppLaunch() {
        enterClock()
        val context = RuntimeEnvironment.getApplication()
        val modes = ModeState(context)
        val freeme = "com.droiclaw.launcher3"
        val home = ComponentName(freeme, "$freeme.MainActivity")
        compose.runOnIdle {
            setResolvedHome(context, freeme)
            assertTrue(modes.saveHome(home))
            assertTrue(modes.set(DesktopMode.ANDROID))
        }
        compose.activityRule.scenario.recreate()
        val activity = compose.activity
        compose.waitUntil(timeoutMillis = 5_000) { shadowOf(activity).peekNextStartedActivity()?.component == home }
        compose.onNodeWithContentDescription("显示设置").assertDoesNotExist()
        assertEquals(DesktopMode.ANDROID, modes.current())

        compose.runOnIdle {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(activity.componentName)
            InstrumentationRegistry.getInstrumentation().callActivityOnNewIntent(activity, intent)
        }
        compose.onNodeWithContentDescription("显示设置").assertIsDisplayed()
        assertEquals(DesktopMode.CLOCK, modes.current())
    }

    @Test
    fun firstLaunchOffersPermissionsAndSkipsThePromptAfterContinuing() {
        val context = RuntimeEnvironment.getApplication()
        val manager = context.getSystemService(NotificationManager::class.java)
        compose.runOnIdle {
            shadowOf(context).denyPermissions(Manifest.permission.POST_NOTIFICATIONS)
            ShadowAlarmManager.setCanScheduleExactAlarms(false)
            shadowOf(manager).setNotificationPolicyAccessGranted(false)
            shadowOf(context.packageManager).setSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN, true)
            setResolvedHome(context, "example.stock.launcher")
        }
        compose.activityRule.scenario.recreate()

        compose.onNodeWithText("授权设置").assertIsDisplayed()
        compose.onNodeWithText("允许勿扰访问").assertExists()
        compose.onNodeWithText("授权应用锁屏").assertExists()
        compose.onNodeWithText("选择默认桌面").assertExists()
        compose.onNodeWithText("本应用未取得 Device Owner").assertExists()
        if (!manager.canUseFullScreenIntent()) compose.onNodeWithText("允许全屏提醒").assertExists()

        compose.onNodeWithText("允许闹铃通知").performScrollTo().performClick()
        compose.runOnIdle {
            assertArrayEquals(arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                shadowOf(compose.activity).lastRequestedPermission.requestedPermissions)
        }
        compose.onNodeWithText("允许精确闹铃").performScrollTo().performClick()
        compose.runOnIdle {
            val opened = shadowOf(compose.activity).nextStartedActivity
            assertEquals(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, opened.action)
            assertEquals("package:${context.packageName}", opened.dataString)
            ShadowAlarmManager.setCanScheduleExactAlarms(true)
        }
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText("允许精确闹铃").assertDoesNotExist()
        compose.onNodeWithText("允许闹铃通知").assertExists()
        compose.onNodeWithText("选择默认桌面").performScrollTo().performClick()
        compose.runOnIdle {
            val opened = shadowOf(compose.activity).nextStartedActivity
            assertEquals(Settings.ACTION_HOME_SETTINGS, opened.action)
            setResolvedHome(context, context.packageName)
        }
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText("选择默认桌面").assertDoesNotExist()
        compose.onNodeWithText("系统当前使用小方块时钟").assertExists()

        enterClock()
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText("授权设置").assertIsNotDisplayed()
        compose.onNodeWithContentDescription("显示设置").assertIsDisplayed()
        compose.onNodeWithContentDescription("显示设置").performClick()
        compose.onNodeWithText("授权与系统状态").performClick()
        compose.onNodeWithText("授权设置").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("允许精确闹铃").assertDoesNotExist()
    }

    @Test
    @Config(qualifiers = "w240dp-h240dp-xxhdpi")
    fun authorizationContentScrollsAboveFixedButtonAtLargeFontAndDisplayScaling() {
        RuntimeEnvironment.setFontScale(2f)
        val context = RuntimeEnvironment.getApplication()
        compose.runOnIdle {
            shadowOf(context).denyPermissions(Manifest.permission.POST_NOTIFICATIONS)
            ShadowAlarmManager.setCanScheduleExactAlarms(false)
            setResolvedHome(context, "example.stock.launcher")
        }
        compose.activityRule.scenario.recreate()
        assertEquals(720, compose.activity.resources.displayMetrics.widthPixels)
        val footer = compose.onNodeWithText("进入时钟").assertIsDisplayed()
        val originalPosition = footer.fetchSemanticsNode().boundsInRoot
        compose.onNodeWithText("允许精确闹铃").performScrollTo().assertIsDisplayed()
        val lastText = "设备所有者由 Android 的设备管理流程配置。"
        val last = compose.onNodeWithText(lastText).performScrollTo().assertIsDisplayed()
        assertTextFits(lastText)
        assertEquals(originalPosition, footer.fetchSemanticsNode().boundsInRoot)
        assertTrue(last.fetchSemanticsNode().boundsInRoot.bottom <= originalPosition.top)
        footer.performClick()
        compose.onNodeWithContentDescription("显示设置").assertIsDisplayed()
    }

    private fun setResolvedHome(context: Context, name: String) {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val result = ResolveInfo().apply {
            isDefault = true
            activityInfo = ActivityInfo().apply {
                packageName = name
                this.name = "$name.MainActivity"
                enabled = true
                exported = true
                applicationInfo = ApplicationInfo().apply { packageName = name }
            }
        }
        val pm = shadowOf(context.packageManager)
        pm.setResolveInfosForIntent(home, listOf(result))
        pm.setResolveInfosForIntent(Intent(home).addCategory(Intent.CATEGORY_DEFAULT), listOf(result))
    }

    private fun enterClock() {
        val button = compose.onAllNodesWithText("进入时钟")
        if (button.fetchSemanticsNodes().isNotEmpty()) button[0].performClick()
    }

    private fun assertTextFits(text: String) {
        val node = compose.onNodeWithText(text, useUnmergedTree = true).assertIsDisplayed()
        val layouts = mutableListOf<TextLayoutResult>()
        node.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        val layout = layouts.single()
        val paragraph = layout.multiParagraph
        assertFalse(text, paragraph.didExceedMaxLines)
        assertTrue(text, paragraph.height <= layout.size.height + 1)
        for (line in 0 until paragraph.lineCount) {
            assertTrue(text, paragraph.getLineRight(line) - paragraph.getLineLeft(line) <= layout.size.width + 1)
        }
    }
}
