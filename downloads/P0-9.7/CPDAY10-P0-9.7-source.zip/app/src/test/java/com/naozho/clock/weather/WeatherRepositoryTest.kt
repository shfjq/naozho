package com.naozho.clock.weather

import android.app.Application
import com.naozho.clock.ui.weatherTile
import java.io.IOException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class WeatherRepositoryTest {
    private val place = WeatherLocation("上海", 31.23, 121.47)
    private val current = WeatherReading(19.5, 3)
    private val time = 1_795_343_200_000L

    @Test
    fun openMeteoCurrentPayloadYieldsTemperatureAndWeatherCode() {
        val parsed = OpenMeteoSource.parseCurrent("""{"current":{"temperature_2m":19.5,"weather_code":3}}""")
        assertEquals(current, parsed)
        assertEquals("阴", weatherDescription(parsed.code))
        assertNull(WeatherLocation.parse("", "NaN", "121.47"))
        assertNull(WeatherLocation.parse("", "31", "-181"))
    }

    @Test
    fun validWeatherPersistsAndIsShownOfflineWithOriginalUpdateTime() = runBlocking {
        var requests = 0
        val source = WeatherSource { requests++; current }
        val repo = WeatherRepository(source, cache(), { time })
        repo.display(place, online = true)
        repo.refresh()
        assertEquals(CachedWeather(place.key, current, time), repo.state.value.last)
        assertFalse(repo.state.value.cached)
        repo.refresh()
        assertEquals(1, requests)

        val restored = WeatherRepository(source, cache(), { time + 3_600_000 })
        restored.display(place, online = false)
        restored.refresh(force = true)
        assertTrue(restored.state.value.cached)
        assertEquals(time, restored.state.value.last?.updatedAt)
        assertEquals("阴 · 20°C", weatherTile(restored.state.value).value)
        assertTrue(weatherTile(restored.state.value).detail.orEmpty().startsWith("缓存 · "))
        assertEquals(1, requests)
    }

    @Test
    fun failureKeepsCacheAndDifferentLocationNeverUsesPriorData() = runBlocking {
        var failing = false
        val source = WeatherSource { if (failing) throw IOException("unreachable") else current }
        val repo = WeatherRepository(source, cache(), { time })
        repo.display(place, online = true)
        repo.refresh()
        failing = true
        repo.refresh(force = true)
        assertTrue(repo.state.value.cached)
        assertEquals(time, repo.state.value.last?.updatedAt)
        assertFalse(repo.state.value.refreshing)
        assertNotNull(cache().read())

        repo.display(WeatherLocation("杭州", 30.3, 120.2), online = true)
        repo.refresh(force = true)
        assertNull(repo.state.value.last)
        assertEquals("暂不可用", weatherTile(repo.state.value).value)
    }

    private fun cache() = PreferenceWeatherCache(
        RuntimeEnvironment.getApplication().getSharedPreferences("p2-weather-test", 0),
    )
}
