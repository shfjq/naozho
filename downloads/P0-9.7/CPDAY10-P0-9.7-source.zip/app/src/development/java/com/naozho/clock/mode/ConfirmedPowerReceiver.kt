package com.naozho.clock.mode

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

/** Explicit system delivery. No input event listener or receiver-supplied launch target. */
class ConfirmedPowerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.component != ComponentName(context, ConfirmedPowerReceiver::class.java)) return
        try {
            if (!ClockPowerReturn.accept(context, intent, PowerDelivery.RESERVE)) {
                Log.i("NaozhoPowerReturn", "Double rejected at receiver; no activity requested")
                return
            }
            val entry = Intent(ClockPowerReturn.ACTION).setComponent(ClockPowerReturn.target(context))
                .putExtra(EXTRA_BOOT_COUNT, intent.getIntExtra(EXTRA_BOOT_COUNT, -1))
                .putExtra(ClockPowerReturn.FIRST, intent.getLongExtra(ClockPowerReturn.FIRST, -1))
                .putExtra(ClockPowerReturn.RELEASE, intent.getLongExtra(ClockPowerReturn.RELEASE, -1))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(entry)
            Log.i("NaozhoPowerReturn", "Confirmed double delivered; awaiting foreground and lock readback")
        } catch (error: RuntimeException) {
            Log.w("NaozhoPowerReturn", "Confirmed double unavailable", error)
        }
    }
}
