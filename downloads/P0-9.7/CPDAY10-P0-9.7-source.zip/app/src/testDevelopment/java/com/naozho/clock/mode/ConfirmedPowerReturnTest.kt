package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.Application
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewConfiguration
import com.naozho.clock.MainActivity
import com.naozho.clock.alarm.AlarmRuntime
import com.naozho.clock.display.ClockDeviceAdmin
import com.naozho.station.StationPowerShortcut
import java.time.Duration
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = AlarmRuntime::class)
class ConfirmedPowerReturnTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val mode get() = ModeState(app)
    private val dpm get() = app.getSystemService(DevicePolicyManager::class.java)
    private val tasks get() = app.getSystemService(ActivityManager::class.java)
    private val admin get() = ComponentName(app, ClockDeviceAdmin::class.java)

    @Before fun armAndroid() = runBlocking<Unit> {
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, 9)
        shadowOf(app.getSystemService(UserManager::class.java)).setUserUnlocked(true)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(true)
        assertTrue(shadowOf(dpm).setDeviceOwner(admin))
        assertEquals(DesktopResult.Applied, ManagedDesktop(app).allowClock())
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        advance(5)
    }

    private fun advance(ms: Long) = shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(ms))
    private fun request(): Intent {
        val first = SystemClock.elapsedRealtime()
        advance(120)
        return Intent(ClockPowerReturn.ACTION).setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java))
            .putExtra(EXTRA_BOOT_COUNT, 9).putExtra(ClockPowerReturn.FIRST, first)
            .putExtra(ClockPowerReturn.RELEASE, SystemClock.elapsedRealtime())
    }
    private fun deliver(intent: Intent) = ConfirmedPowerReceiver().onReceive(app, intent)

    @Test fun receiverRequiresSystemPermissionAndClockTargetIsPrivate() {
        val pm = app.packageManager
        val rx = pm.getReceiverInfo(ComponentName(app, ConfirmedPowerReceiver::class.java), 0)
        assertEquals("android.permission.STATUS_BAR_SERVICE", rx.permission)
        assertTrue(rx.exported)
        val entry = pm.getActivityInfo(ClockPowerReturn.target(app), 0)
        assertFalse(entry.exported)
        assertEquals(MainActivity::class.java.name, entry.targetActivity)
    }

    @Test fun adapterSendsOnlyAfterSecondReleaseThenActivityCommitsAndLocksOnFocus() {
        val adapter = StationPowerShortcut(app, Handler(Looper.getMainLooper())) { 4L }
        fun event(action: Int, down: Long) {
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), action, KeyEvent.KEYCODE_POWER, 0), true)
        }
        val first = SystemClock.uptimeMillis()
        event(KeyEvent.ACTION_DOWN, first)
        advance(100)
        event(KeyEvent.ACTION_UP, first)
        advance(89)
        val second = SystemClock.uptimeMillis()
        event(KeyEvent.ACTION_DOWN, second)
        advance(125)
        assertFalse(shadowOf(app).broadcastIntents.any { it.action == ClockPowerReturn.ACTION })
        event(KeyEvent.ACTION_UP, second)
        advance(ViewConfiguration.getMultiPressTimeout().toLong() + 1)
        val signal = shadowOf(app).broadcastIntents.single { it.action == ClockPowerReturn.ACTION }
        // Robolectric records cross-user delivery; execute the protected receiver callback explicitly.
        deliver(signal)
        val entry = shadowOf(app).nextStartedActivity
        assertNotNull(entry)
        assertEquals(DesktopMode.ANDROID, mode.current())
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).setup()
        assertFalse(ctrl.get().isFinishing)
        ctrl.windowFocusChanged(true)
        assertEquals(DesktopMode.CLOCK, mode.current())
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(ActivityManager.LOCK_TASK_MODE_LOCKED, tasks.lockTaskModeState)
        assertEquals(80, dpm.getLockTaskFeatures(admin))
        ctrl.pause().stop().destroy()
    }

    @Test fun diagnosticDeliveryCannotInitializeLegacyStateOrOpenAWindow() {
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        assertTrue(prefs.edit().remove("mode_since").commit())
        val before = prefs.all.toMap()
        deliver(Intent("com.naozho.clock.action.P095_PERMISSION_PROBE.offline")
            .setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java)))
        assertEquals(before, prefs.all)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
    }

    @Test fun normalExitInitializesVersion24ModeBoundaryAndPreservesConfiguration() {
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        val home = "com.droiclaw.launcher3/com.freeme.launcher.FreemeLauncher"
        assertTrue(prefs.edit().remove("mode_since").putString("native_home", home).commit())
        assertTrue(mode.set(DesktopMode.CLOCK))
        advance(1)
        assertTrue(mode.set(DesktopMode.ANDROID))
        advance(1)
        val signal = request()
        deliver(signal)
        assertNotNull(shadowOf(app).nextStartedActivity)
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(home, prefs.getString("native_home", null))
        assertTrue(mode.independentLock())
        assertTrue(dpm.isDeviceOwnerApp(app.packageName))
    }

    @Test fun pausedOrAlreadyLockedCannotReserveOrStartClock() {
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        val before = prefs.all.toMap()
        deliver(request())
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(before, prefs.all)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_LOCKED)
        val afterRearm = prefs.all.toMap()
        deliver(request())
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(afterRearm, prefs.all)
    }

    @Test fun pauseThenRearmRejectsBothQueuedBroadcastAndPreviouslyDeliveredActivity() {
        val signal = request()
        deliver(signal)
        val pending = shadowOf(app).nextStartedActivity
        assertNotNull(pending)
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        advance(20)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, pending).create()
        assertTrue(ctrl.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        ctrl.destroy()
    }

    @Test fun pauseWhileClockIsBeingCreatedPreventsCommitAtFirstFocus() {
        deliver(request())
        val entry = shadowOf(app).nextStartedActivity
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).create().start()
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        ctrl.resume().visible().windowFocusChanged(true)
        assertTrue(ctrl.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        ctrl.pause().stop().destroy()
    }

    @Test fun onlyOneWindowRequestCanBeOutstandingAndExpiredDeliveryCannotConsumeANewOne() {
        val first = request()
        deliver(first)
        val firstEntry = shadowOf(app).nextStartedActivity
        assertNotNull(firstEntry)
        val second = request()
        deliver(second)
        assertNull(shadowOf(app).nextStartedActivity)
        advance(2001)
        val third = request()
        deliver(third)
        val thirdEntry = shadowOf(app).nextStartedActivity
        assertNotNull(thirdEntry)
        assertFalse(ClockPowerReturn.accept(app, firstEntry, PowerDelivery.CONSUME))
        assertTrue(ClockPowerReturn.accept(app, thirdEntry, PowerDelivery.CONSUME))
        assertEquals(DesktopMode.CLOCK, mode.current())
    }

    @Test fun staleAndOtherBootDeliveriesDoNotOpenWindows() {
        val old = request()
        advance(2001)
        deliver(old)
        deliver(request().putExtra(EXTRA_BOOT_COUNT, 8))
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(DesktopMode.ANDROID, mode.current())
    }

    @Test fun activityAndPackageCannotSubstituteForThePrivateHandoff() {
        val s = request()
        deliver(s)
        val valid = shadowOf(app).nextStartedActivity
        assertNotNull(valid)
        val forged = Intent(valid).setComponent(ComponentName(app, MainActivity::class.java))
        val controller = Robolectric.buildActivity(MainActivity::class.java, forged).create()
        assertTrue(controller.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        controller.destroy()
        val wrong = Intent(valid).putExtra(ClockPowerReturn.FIRST, -1L)
        assertFalse(ClockPowerReturn.accept(app, wrong, PowerDelivery.CONSUME))
    }

    @Test fun incomingCallAndKeyguardLeaveAndroidInControl() {
        val signal = request()
        app.getSystemService(AudioManager::class.java).mode = AudioManager.MODE_IN_CALL
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        app.getSystemService(AudioManager::class.java).mode = AudioManager.MODE_NORMAL
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(true)
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun cancellingOrLosingGenerationBetweenReleasesAndDispatchSendsNothing() {
        var generation = 4L
        val adapter = StationPowerShortcut(app, Handler(Looper.getMainLooper())) { generation }
        repeat(2) {
            var down = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(down, down, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(20)
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
            advance(55)
            down = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(down, down, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(20)
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
            if (it == 0) adapter.cancel() else generation++
            advance(ViewConfiguration.getMultiPressTimeout().toLong() + 1)
        }
        assertFalse(shadowOf(app).broadcastIntents.any { it.action == ClockPowerReturn.ACTION })
    }
}
