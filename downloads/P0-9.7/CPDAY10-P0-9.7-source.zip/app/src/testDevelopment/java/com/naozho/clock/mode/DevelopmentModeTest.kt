package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.Activity
import android.app.Application
import android.app.KeyguardManager
import android.app.job.JobScheduler
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.provider.Settings
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeUp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.test.platform.app.InstrumentationRegistry
import com.naozho.clock.MainActivity
import com.naozho.clock.display.ClockDeviceAdmin
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import org.robolectric.shadow.api.Shadow
import org.robolectric.shadows.ShadowApplicationPackageManager
import org.robolectric.shadows.ShadowDevicePolicyManager
import org.robolectric.shadows.ShadowDialog
import org.robolectric.shadows.ShadowKeyguardManager
import org.robolectric.shadows.ShadowLog

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class DevelopmentModeTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()

    @Test
    fun phaseTracksPersistedIntentAndRequiresActualForegroundConfirmation() {
        prepareOwnerAndHome(context)
        val mode = ModeState(context)
        assertEquals(StationPhase.NOT_CONFIGURED, mode.stationPhase(false))
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        assertEquals(StationPhase.BOOT_PENDING, mode.stationPhase(false))
        assertEquals(StationPhase.CLOCK, mode.stationPhase(true))
        assertTrue(mode.set(DesktopMode.ANDROID))
        assertEquals(StationPhase.ANDROID, ModeState(context).stationPhase(true))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        assertEquals(StationPhase.BOOT_PENDING, ModeState(context).stationPhase(false))
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 3)
        assertEquals(StationPhase.MAINTENANCE_PAUSED, ModeState(context).stationPhase(true))
    }

    @Test
    fun primaryHomeRestoresIndependentPolicyWithoutLaunchingOrReassigningHome() = runBlocking<Unit> {
        prepareOwnerAndHome(context, clockFirst = true)
        val mode = ModeState(context)
        val desktop = ManagedDesktop(context)
        val deployment = ManagedDeployment(context)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        assertTrue(desktop.isHomeConfirmed(desktop.clockHome))
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        assertTrue(mode.useClockEntryOnRestore(home, 0))
        assertEquals(DesktopResult.Applied, deployment.preparePrimaryClock())
        assertTrue(desktop.dedicatedReady)
        assertEquals(-1, mode.lastBootLaunch())
        assertNull(shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity)
        assertTrue(mode.set(DesktopMode.ANDROID))
        assertFalse(mode.useClockEntryOnRestore(home, 0))
        assertTrue(deployment.preparePrimaryClock() is DesktopResult.Rejected)
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        assertTrue(deployment.preparePrimaryClock() is DesktopResult.Rejected)
        assertEquals(StationPhase.MAINTENANCE_PAUSED, mode.stationPhase(false))
    }

    @Test
    fun anotherPrimaryHomeCannotTriggerPolicyRepair() = runBlocking<Unit> {
        prepareOwnerAndHome(context)
        assertTrue(ModeState(context).saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        assertTrue(ManagedDeployment(context).preparePrimaryClock() is DesktopResult.Rejected)
        assertFalse(ManagedDesktop(context).permitted)
    }

    @Test
    @Config(application = com.naozho.clock.alarm.AlarmRuntime::class)
    fun earlyArmedPrimaryHomeCanToggleDateWithoutUnlockOrStartingAnotherActivity() = runBlocking<Unit> {
        prepareOwnerAndHome(context, clockFirst = true)
        assertTrue(ModeState(context).saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        assertEquals(DesktopResult.Applied, ManagedDesktop(context).allowClock())
        val user = shadowOf(context.getSystemService(android.os.UserManager::class.java))
        user.setUserUnlocked(false)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val controller = Robolectric.buildActivity(MainActivity::class.java, home).setup()
        val content = controller.get().findViewById<android.view.ViewGroup>(android.R.id.content)
        val view = content.getChildAt(0) as android.widget.TextClock
        assertTrue(view.performClick())
        assertEquals("MM-dd EEE", view.format24Hour)
        assertTrue(view.performClick())
        assertEquals("HH:mm", view.format24Hour)
        assertFalse(context.getSystemService(android.os.UserManager::class.java).isUserUnlocked)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, ManagedDesktop(context).state)
        controller.pause().stop().destroy()
    }

    @Test
    @Config(application = com.naozho.clock.alarm.AlarmRuntime::class)
    fun primaryHomeAfterRebootOpensClockInsteadOfOldSettingsWithoutBootReceipt() {
        prepareOwnerAndHome(context, clockFirst = true)
        val mode = ModeState(context)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, manageHome = false))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        shadowOf(context.getSystemService(android.os.UserManager::class.java)).setUserUnlocked(true)
        val saved = android.os.Bundle().apply { putString("clockPage", "DISPLAY"); putInt("clockPageBoot", 1) }
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val controller = Robolectric.buildActivity(MainActivity::class.java, home).create(saved)
        val observed = android.os.Bundle()
        controller.saveInstanceState(observed)
        assertEquals("CLOCK", observed.getString("clockPage"))
        assertEquals(-1, mode.lastBootLaunch())
        controller.destroy()
    }

    @Test
    @Config(application = com.naozho.clock.alarm.AlarmRuntime::class)
    fun maintenancePauseOverridesAStillReadableEarlyLockPolicy() = runBlocking<Unit> {
        prepareOwnerAndHome(context, clockFirst = true)
        val mode = ModeState(context)
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        assertEquals(DesktopResult.Applied, ManagedDesktop(context).allowClock())
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        shadowOf(context.getSystemService(android.os.UserManager::class.java)).setUserUnlocked(false)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val controller = Robolectric.buildActivity(MainActivity::class.java, home).setup()
        val content = controller.get().findViewById<android.view.ViewGroup>(android.R.id.content)
        assertFalse(content.getChildAt(0) is android.widget.TextClock)
        assertFalse(content.getChildAt(0).isClickable)
        controller.pause().stop().destroy()
    }

    @Test
    fun savedSettingsPageOnlyYieldsToAnArmedEntryFromANewBoot() {
        prepareOwnerAndHome(context)
        val mode = ModeState(context)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val boot = Intent(INDEPENDENT_BOOT_ACTION).putExtra(EXTRA_BOOT_COUNT, 1)
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        assertFalse(mode.useClockEntryOnRestore(home, -1))
        assertFalse(mode.useClockEntryOnRestore(boot, -1))
        assertTrue(mode.recordBootLaunch(1))
        assertTrue(mode.useClockEntryOnRestore(boot, -1))
        assertFalse(mode.useClockEntryOnRestore(boot, 1))
        assertTrue(mode.set(DesktopMode.ANDROID))
        assertFalse(mode.useClockEntryOnRestore(boot, -1))
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = true))
        assertTrue(mode.useClockEntryOnRestore(home, 0))
        assertFalse(mode.useClockEntryOnRestore(home, 1))
        assertFalse(mode.useClockEntryOnRestore(Intent(Intent.ACTION_MAIN), 0))
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        assertFalse(mode.useClockEntryOnRestore(home, 0))
    }

    @Test
    @Config(application = com.naozho.clock.alarm.AlarmRuntime::class)
    fun acceptedBootIntentCannotRestoreLastBootsDisplaySettings() = runBlocking<Unit> {
        prepareOwnerAndHome(context)
        shadowOf(context.getSystemService(android.os.UserManager::class.java)).setUserUnlocked(true)
        val mode = ModeState(context)
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        assertEquals(201, ModuleBootReceiver().handle(context, 2).first)
        val entry = shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity
        val saved = android.os.Bundle().apply { putString("clockPage", "DISPLAY"); putInt("clockPageBoot", 1) }
        val controller = Robolectric.buildActivity(MainActivity::class.java, entry).create(saved)
        assertFalse(controller.get().isFinishing)
        val observed = android.os.Bundle()
        controller.saveInstanceState(observed)
        assertEquals("CLOCK", observed.getString("clockPage"))
        controller.destroy()
    }

    @Test
    fun moduleBootUsesTheSharedReceiptAndHonoursExitAndPause() = runBlocking {
        prepareOwnerAndHome(context)
        val mode = ModeState(context)
        val app = shadowOf(RuntimeEnvironment.getApplication())
        val module = ModuleBootReceiver()
        shadowOf(context.getSystemService(android.os.UserManager::class.java)).setUserUnlocked(true)
        mode.saveDeployment(true, DesktopMode.ANDROID, manageHome = false)
        assertEquals(204 to "desktop_mode", module.handle(context, 1))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        assertEquals(201 to "activity_requested", module.handle(context, 2))
        assertEquals(INDEPENDENT_BOOT_ACTION, app.nextStartedActivity.action)
        assertEquals(204 to "no_new_request", module.handle(context, 2))
        ManagedDeployment(context).restoreIndependentAfterBoot("job")
        assertTrue(app.nextStartedActivity == null)
        mode.saveDeployment(false, DesktopMode.ANDROID)
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 3)
        assertEquals(204 to "independent_not_armed", module.handle(context, 3))
        assertTrue(app.nextStartedActivity == null)
    }

    @Test
    fun moduleBootRejectsStaleBootAndLockedStorageOrCredentials() = runBlocking {
        prepareOwnerAndHome(context)
        val mode = ModeState(context)
        mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false)
        val module = ModuleBootReceiver()
        assertEquals(409, module.handle(context, 8).first)
        val user = shadowOf(context.getSystemService(android.os.UserManager::class.java))
        user.setUserUnlocked(false)
        assertEquals(423, module.handle(context, 1).first)
        user.setUserUnlocked(true)
        val keyguard = shadowOf(context.getSystemService(KeyguardManager::class.java))
        keyguard.setIsDeviceSecure(true)
        keyguard.setKeyguardLocked(true)
        assertEquals(423, module.handle(context, 1).first)
        assertEquals(-1, mode.lastBootLaunch())
        assertTrue(shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity == null)
    }

    @Test
    fun ownerCanEnableDirectlyAndPauseWithoutChangingOwner() = runBlocking {
        val freeme = prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val desktop = ManagedDesktop(context)
        val store = ModeState(context)
        assertFalse(store.developmentRehearsal())
        assertEquals(DesktopResult.Applied, deployment.enable())
        assertEquals(desktop.clockHome, desktop.effectiveHome())
        assertTrue(store.managedLock())
        assertTrue(desktop.dedicatedReady)
        assertTrue(desktop.owner)
        assertEquals(DesktopResult.Applied, deployment.pause())
        assertEquals(freeme, desktop.effectiveHome())
        assertEquals(DesktopMode.ANDROID, store.current())
        assertFalse(desktop.permitted)
        assertTrue(desktop.owner)
    }

    @Test
    @Config(shadows = [HomeCandidateGap::class])
    fun independentBootLaunchesOnceWithNoGlobalClockHomeAndRestoresAllowlist() = runBlocking {
        val stock = prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val mode = ModeState(context)
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        // Persisted by the already deployed development versions when exiting to Freeme.
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, manageHome = false))
        Shadow.extract<HomeCandidateGap>(context.packageManager).omitRawGlobalClock = true
        val app = shadowOf(RuntimeEnvironment.getApplication())
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        assertTrue(app.nextStartedActivity == null)
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        val launch = app.nextStartedActivity
        assertEquals(ComponentName(context, MainActivity::class.java), launch.component)
        assertEquals(INDEPENDENT_BOOT_ACTION, launch.action)
        assertTrue(launch.categories.isNullOrEmpty())
        assertTrue(mode.acceptsBootLaunch(launch.getIntExtra(EXTRA_BOOT_COUNT, -1)))
        assertEquals(stock, ManagedDesktop(context).effectiveHome())
        assertEquals(setOf(context.packageName), policy.getLockTaskPackages(admin).toSet())
        assertEquals(80, policy.getLockTaskFeatures(admin))
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, ManagedDesktop(context).state)
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        assertTrue(app.nextStartedActivity == null)
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.ANDROID))
        assertFalse(mode.acceptsBootLaunch(2))
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        assertTrue(app.nextStartedActivity == null)
    }

    @Test
    fun persistedJobIsStableAndBroadcastSharesOneBootRequest() = runBlocking {
        val stock = prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val scheduler = context.getSystemService(JobScheduler::class.java)
        val job = IndependentBootJob(context)
        val app = shadowOf(RuntimeEnvironment.getApplication())
        assertEquals(DesktopResult.Applied, deployment.lockCurrentClock())
        val info = requireNotNull(scheduler.getPendingJob(IndependentBootJob.ID))
        assertTrue(info.isPeriodic && info.isPersisted)
        assertEquals(900000L, info.intervalMillis)
        assertFalse(info.isRequireCharging || info.isRequireDeviceIdle)
        assertEquals(ComponentName(context, IndependentBootJobService::class.java), info.service)
        assertEquals(DesktopResult.Applied, deployment.registerBootJob(false))
        assertEquals(info.extras.getString("ticket"), requireNotNull(scheduler.getPendingJob(info.id)).extras.getString("ticket"))
        job.execute(info.extras, 1000) { true }
        assertTrue(app.nextStartedActivity == null)
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        job.execute(info.extras, 3200) { true }
        assertEquals(INDEPENDENT_BOOT_ACTION, app.nextStartedActivity.action)
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        job.execute(info.extras, 900000) { true }
        assertTrue(app.nextStartedActivity == null)
        assertEquals(stock, ManagedDesktop(context).effectiveHome())
        assertTrue(job.describe().contains("3200 ms"))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 3)
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        assertEquals(INDEPENDENT_BOOT_ACTION, app.nextStartedActivity.action)
        job.execute(info.extras, 5300) { true }
        assertTrue(app.nextStartedActivity == null)
    }

    @Test
    fun jobRespectsDesktopExitPauseAndReplacedOrStoppedWork() = runBlocking {
        prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val scheduler = context.getSystemService(JobScheduler::class.java)
        val job = IndependentBootJob(context)
        val app = shadowOf(RuntimeEnvironment.getApplication())
        assertEquals(DesktopResult.Applied, deployment.lockCurrentClock())
        val first = requireNotNull(scheduler.getPendingJob(IndependentBootJob.ID)).extras
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        job.execute(first, 100) { false }
        assertTrue(app.nextStartedActivity == null)
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.ANDROID))
        job.execute(first, 110) { true }
        assertTrue(app.nextStartedActivity == null)
        assertEquals(DesktopMode.ANDROID, ModeState(context).current())
        assertEquals(DesktopResult.Applied, deployment.registerBootJob(true))
        val observation = requireNotNull(scheduler.getPendingJob(IndependentBootJob.ID)).extras
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 3)
        job.execute(first, 440) { true }
        job.execute(observation, 550) { true }
        assertTrue(app.nextStartedActivity == null)
        assertTrue(job.describe().contains("仅观察，已收到系统调度"))
        assertEquals(DesktopResult.Applied, deployment.pause())
        assertTrue(scheduler.getPendingJob(IndependentBootJob.ID) == null)
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 4)
        job.execute(first, 1000) { true }
        assertTrue(app.nextStartedActivity == null)
        assertEquals(DesktopMode.ANDROID, ModeState(context).current())
    }

    @Test
    fun schedulerRefusalLeavesStandaloneLockAvailableAndReportsMissingJob() = runBlocking {
        prepareOwnerAndHome(context)
        val scheduler = context.getSystemService(JobScheduler::class.java)
        shadowOf(scheduler).failOnJob(IndependentBootJob.ID)
        val deployment = ManagedDeployment(context)
        assertEquals(DesktopResult.Applied, deployment.lockCurrentClock())
        assertTrue(ManagedDesktop(context).dedicatedReady)
        assertTrue(ModeState(context).independentLock())
        assertFalse(IndependentBootJob(context).recoveryRegistered())
        assertTrue(deployment.registerBootJob(false) is DesktopResult.Rejected)
    }

    @Test
    fun upgradedDeploymentCanEnrollAndJobWaitsForAccessibleStorage() = runBlocking {
        prepareOwnerAndHome(context)
        val mode = ModeState(context)
        val deployment = ManagedDeployment(context)
        val scheduler = context.getSystemService(JobScheduler::class.java)
        assertTrue(deployment.registerBootJob(false) is DesktopResult.Rejected)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, manageHome = false))
        assertEquals(DesktopResult.Applied, deployment.registerBootJob(false))
        assertEquals(DesktopMode.ANDROID, mode.current())
        val info = requireNotNull(scheduler.getPendingJob(IndependentBootJob.ID))
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        val user = shadowOf(context.getSystemService(android.os.UserManager::class.java))
        user.setUserUnlocked(false)
        IndependentBootJob(context).execute(info.extras, 1000) { true }
        assertTrue(shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity == null)
        user.setUserUnlocked(true)
        assertEquals(-1, mode.lastBootLaunch())
        IndependentBootJob(context).execute(info.extras, 2000) { true }
        assertEquals(INDEPENDENT_BOOT_ACTION, shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity.action)
    }

    @Test
    fun pauseSurvivesRebootAndExplicitReenableArmsTheFollowingBoot() = runBlocking {
        val stock = prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val mode = ModeState(context)
        val app = shadowOf(RuntimeEnvironment.getApplication())
        assertEquals(DesktopResult.Applied, deployment.lockCurrentClock())
        assertEquals(DesktopResult.Applied, deployment.pause())
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        mode.syncBoot(completed = true)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        assertTrue(app.nextStartedActivity == null)
        assertFalse(ManagedDesktop(context).permitted)
        assertEquals(stock, ManagedDesktop(context).effectiveHome())
        assertEquals(DesktopResult.Applied, deployment.lockCurrentClock())
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 3)
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        assertTrue(mode.acceptsBootLaunch(app.nextStartedActivity.getIntExtra(EXTRA_BOOT_COUNT, -1)))
    }

    @Test
    fun lockedBootDefersToUnlockedBootWithoutLaunchingOrChangingDeployment() {
        val stock = prepareOwnerAndHome(context)
        val mode = ModeState(context)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, manageHome = false))
        val prefs = context.getSharedPreferences("desktop_mode", Context.MODE_PRIVATE)
        val before = prefs.all.toMap()
        shadowOf(context.getSystemService(android.os.UserManager::class.java)).setUserUnlocked(false)
        ModeBootReceiver().onReceive(context, Intent(Intent.ACTION_LOCKED_BOOT_COMPLETED))
        assertEquals(before, prefs.all)
        assertTrue(shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity == null)
        assertEquals(stock, mode.selectedHome())
    }

    @Test
    fun staleExplicitBootActivityCannotUndoConfirmedDesktopExit() = runBlocking {
        prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        assertEquals(DesktopResult.Applied, deployment.lockCurrentClock())
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        assertEquals(DesktopResult.Applied, deployment.restoreIndependentAfterBoot())
        val stale = shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.ANDROID))
        val activity = Robolectric.buildActivity(MainActivity::class.java, stale).create()
        assertTrue(activity.get().isFinishing)
        activity.destroy()
        assertEquals(DesktopMode.ANDROID, ModeState(context).current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, ManagedDesktop(context).state)
    }

    @Test
    fun missingOwnerAndConflictingAllowlistCannotLaunchClockAtBoot() = runBlocking {
        val mode = ModeState(context)
        val deployment = ManagedDeployment(context)
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 1)
        assertTrue(mode.saveDeployment(true, DesktopMode.CLOCK, manageHome = false))
        assertTrue(deployment.restoreIndependentAfterBoot() is DesktopResult.Rejected)
        prepareOwnerAndHome(context)
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        policy.setLockTaskPackages(admin, arrayOf("other.app"))
        assertTrue(deployment.restoreIndependentAfterBoot() is DesktopResult.Rejected)
        assertEquals(setOf("other.app"), policy.getLockTaskPackages(admin).toSet())
        assertTrue(shadowOf(RuntimeEnvironment.getApplication()).nextStartedActivity == null)
    }

    @Test
    fun legacyIndependentDeploymentUpdatesOnClockReentryOnlyAndPreservesHome() = runBlocking {
        val stock = prepareOwnerAndHome(context)
        val policy = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        val deployment = ManagedDeployment(context)
        val mode = ModeState(context)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, manageHome = false))
        policy.setLockTaskPackages(admin, arrayOf(context.packageName))
        policy.setLockTaskFeatures(admin, 112)
        assertEquals(DesktopResult.Applied, deployment.recoverManagedClock())
        assertEquals(112, policy.getLockTaskFeatures(admin))
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.CLOCK))
        assertEquals(80, policy.getLockTaskFeatures(admin))
        assertEquals(stock, ManagedDesktop(context).effectiveHome())
        policy.setLockTaskPackages(admin, arrayOf(context.packageName, "other.managed"))
        policy.setLockTaskFeatures(admin, 112)
        assertTrue(deployment.switchTo(DesktopMode.CLOCK) is DesktopResult.Rejected)
        assertEquals(112, policy.getLockTaskFeatures(admin))
        assertEquals(setOf(context.packageName, "other.managed"), policy.getLockTaskPackages(admin).toSet())
    }

    @Test
    @Config(shadows = [HomeCandidateGap::class])
    fun fullDeploymentMigratesLegacyFlagsAndRechecksHomeImmediatelyBeforeLock() = runBlocking<Unit> {
        prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val desktop = ManagedDesktop(context)
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        assertEquals(DesktopResult.Applied, deployment.enable())
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.ANDROID))
        dpm.setLockTaskFeatures(admin, 112)
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.CLOCK))
        assertEquals(80, dpm.getLockTaskFeatures(admin))
        assertTrue(desktop.isHomeConfirmed(desktop.clockHome))
        Shadow.extract<HomeCandidateGap>(context.packageManager).omitRawGlobalClock = true
        val activity = Robolectric.buildActivity(Activity::class.java).create()
        assertTrue(desktop.start(activity.get()) is DesktopResult.Rejected)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, desktop.state)
        activity.destroy()
    }

    @Test
    fun diagnosticOnlyChangesHomeAndRebootDoesNotArmLock() = runBlocking {
        val freeme = prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val desktop = ManagedDesktop(context)
        assertEquals(DesktopResult.Applied, deployment.rehearseDevelopment { true })
        assertEquals(desktop.clockHome, desktop.effectiveHome())
        assertEquals(DesktopResult.Applied, deployment.switchTo(DesktopMode.ANDROID))
        assertEquals(freeme, desktop.effectiveHome())
        Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 2)
        assertEquals(DesktopResult.Applied, deployment.reconcileHome())
        assertEquals(desktop.clockHome, desktop.effectiveHome())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, desktop.state)
        assertFalse(desktop.permitted)
    }

    @Test
    fun preflightDistinguishesAbsentOwnerPinnedAndStaleSavedHome() = runBlocking {
        val deployment = ManagedDeployment(context)
        val noOwner = deployment.enable() as DesktopResult.Rejected
        assertTrue(noOwner.reason.contains("Device Owner"))
        val freeme = prepareOwnerAndHome(context)
        val tasks = shadowOf(context.getSystemService(ActivityManager::class.java))
        tasks.setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_PINNED)
        val pinned = deployment.enable() as DesktopResult.Rejected
        assertTrue(pinned.reason.contains("PINNED"))
        tasks.setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_NONE)
        val missing = ComponentName(freeme.packageName, "org.missing.RemovedActivity")
        val store = ModeState(context)
        assertTrue(store.saveHome(missing))
        val stale = deployment.rehearseDevelopment { true } as DesktopResult.Rejected
        assertEquals("检查原桌面", stale.step)
        assertTrue(stale.reason.contains(missing.flattenToShortString()))
        assertFalse(store.managedLock())
    }

    @Test
    @Config(shadows = [FailingHomePolicy::class, HomeCandidateGap::class])
    @Suppress("DEPRECATION")
    fun absentClockInBroadHomeQueryStillAttemptsPolicyForUsableOwnActivity() = runBlocking {
        val freeme = prepareOwnerAndHome(context)
        val desktop = ManagedDesktop(context)
        val pm = context.packageManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addCategory(Intent.CATEGORY_DEFAULT)
        val scoped = Intent(home).setPackage(context.packageName)
        val flags = PackageManager.MATCH_DEFAULT_ONLY
        assertEquals(desktop.clockHome.className, pm.queryIntentActivities(scoped, flags).single().activityInfo.name)
        assertTrue(pm.getActivityInfo(desktop.clockHome, 0).exported)
        assertEquals(listOf(freeme), NativeDesktop(context).candidates(freeme).map(NativeHome::component))
        Shadow.extract<HomeCandidateGap>(pm).omitClock = true
        assertFalse(pm.queryIntentActivities(home, flags).any { it.activityInfo.name == desktop.clockHome.className })
        assertTrue(pm.queryIntentActivities(scoped, flags).isEmpty())
        val policy = shadowOf(context.getSystemService(DevicePolicyManager::class.java)) as FailingHomePolicy
        policy.reject = true
        val result = ManagedDeployment(context).enable() as DesktopResult.Rejected
        assertEquals("写入 Home 策略", result.step)
        assertEquals(1, policy.clockWrites)
        assertEquals(1, policy.fallbackWrites)
        assertEquals(freeme, desktop.effectiveHome())
        assertTrue(ShadowLog.getLogsForTag("NaozhoMode").any { it.msg.contains("candidate=omitted explicit=usable") })
    }

    @Test
    @Config(shadows = [HomeCandidateGap::class])
    @Suppress("DEPRECATION")
    fun savedFreemeRemainsSelectableWhenGlobalHomeQueryOmitsIt() {
        val freeme = prepareOwnerAndHome(context)
        val pm = context.packageManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addCategory(Intent.CATEGORY_DEFAULT)
        Shadow.extract<HomeCandidateGap>(pm).omitUnscopedPackage = freeme.packageName
        val broad = pm.queryIntentActivities(home, PackageManager.MATCH_DEFAULT_ONLY)
        assertFalse(broad.any { it.activityInfo.packageName == freeme.packageName })
        assertEquals(listOf(freeme), NativeDesktop(context).candidates(freeme).map(NativeHome::component))
    }

    @Test
    @Config(shadows = [HomeCandidateGap::class])
    fun rejectsWhenHomeLaunchResolvesClockButSettingsStillResolvesFreeme() = runBlocking {
        val freeme = prepareOwnerAndHome(context)
        val desktop = ManagedDesktop(context)
        val launchHome = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val canonicalHome = Intent(launchHome).addCategory(Intent.CATEGORY_DEFAULT)
        val pm = context.packageManager
        val shadow = Shadow.extract<HomeCandidateGap>(pm)
        shadow.launchHomeOverride = desktop.clockHome
        shadow.settingsHomeOverride = freeme

        val result = desktop.setHome(desktop.clockHome, reapply = true)

        assertEquals(freeme.className,
            pm.resolveActivity(canonicalHome, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.name)
        assertEquals(desktop.clockHome, desktop.effectiveHome())
        assertTrue(result is DesktopResult.Rejected)
        assertTrue((result as DesktopResult.Rejected).reason.contains(freeme.flattenToShortString()))
    }

    @Test
    @Config(shadows = [HomeCandidateGap::class])
    fun rejectsClockMissingFromGlobalCandidatesEvenWhenBothResolversSelectIt() = runBlocking {
        prepareOwnerAndHome(context)
        val desktop = ManagedDesktop(context)
        val pm = context.packageManager
        val launchHome = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val canonicalHome = Intent(launchHome).addCategory(Intent.CATEGORY_DEFAULT)
        val shadow = Shadow.extract<HomeCandidateGap>(pm)
        shadow.omitGlobalCanonicalClock = true
        shadow.launchHomeOverride = desktop.clockHome
        shadow.settingsHomeOverride = desktop.clockHome

        val result = desktop.setHome(desktop.clockHome, reapply = true)

        assertEquals(desktop.clockHome, desktop.effectiveHome())
        assertEquals(desktop.clockHome.className,
            pm.resolveActivity(canonicalHome, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.name)
        assertFalse(pm.queryIntentActivities(canonicalHome, PackageManager.MATCH_DEFAULT_ONLY)
            .any { it.activityInfo.name == desktop.clockHome.className })
        assertTrue(result is DesktopResult.Rejected)
    }

    @Test
    @Config(shadows = [HomeCandidateGap::class])
    fun scopedHomeAndDefaultQueriesCannotMaskMissingRawGlobalHome() {
        prepareOwnerAndHome(context)
        val desktop = ManagedDesktop(context)
        val shadow = Shadow.extract<HomeCandidateGap>(context.packageManager)
        shadow.launchHomeOverride = desktop.clockHome
        shadow.settingsHomeOverride = desktop.clockHome
        assertTrue(desktop.isHomeConfirmed(desktop.clockHome))
        shadow.omitRawGlobalClock = true
        assertFalse(desktop.isHomeConfirmed(desktop.clockHome))
        assertTrue(desktop.diagnoseHome().contains("HOME(0) 全局=false，本包=true"))
    }

    @Test
    @Config(shadows = [FailingHomePolicy::class])
    fun reportsExceptionAndEffectiveHomeMismatchAndRestoresFreeme() = runBlocking {
        val freeme = prepareOwnerAndHome(context)
        val deployment = ManagedDeployment(context)
        val desktop = ManagedDesktop(context)
        val policy = shadowOf(context.getSystemService(DevicePolicyManager::class.java)) as FailingHomePolicy
        policy.reject = true
        val rejected = deployment.rehearseDevelopment { true } as DesktopResult.Rejected
        assertEquals("写入 Home 策略", rejected.step)
        assertTrue(rejected.reason.contains("SecurityException"))
        assertTrue(ShadowLog.getLogsForTag("NaozhoMode").any { it.throwable is SecurityException })
        policy.reject = false
        val timeout = deployment.enable() as DesktopResult.Rejected
        assertEquals("确认有效 Home", timeout.step)
        assertTrue(timeout.reason.contains(freeme.flattenToShortString()))
        assertEquals(2, policy.fallbackWrites)
        assertEquals(freeme, desktop.effectiveHome())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, desktop.state)
        assertFalse(desktop.permitted)
        assertTrue(desktop.owner)
        val logs = ShadowLog.getLogsForTag("NaozhoMode").map { it.msg }
        assertTrue(logs.any { "goal=clock" in it && "result=unconfirmed" in it })
        assertTrue(logs.any { "goal=freeme" in it && "rollback=true" in it && "result=confirmed" in it })
    }
}

@Implements(className = "android.app.ApplicationPackageManager", isInAndroidSdk = false)
class HomeCandidateGap : ShadowApplicationPackageManager() {
    var omitClock = false
    var omitRawGlobalClock = false
    var omitGlobalCanonicalClock = false
    var omitUnscopedPackage: String? = null
    var launchHomeOverride: ComponentName? = null
    var settingsHomeOverride: ComponentName? = null

    @Implementation
    override fun resolveActivity(intent: Intent, flags: Int): ResolveInfo? {
        if (intent.hasCategory(Intent.CATEGORY_HOME) && intent.`package` == null) {
            val override = if (intent.hasCategory(Intent.CATEGORY_DEFAULT)) settingsHomeOverride else launchHomeOverride
            if (override != null) {
                val scoped = Intent(intent).setPackage(override.packageName)
                return super.queryIntentActivities(scoped, flags).single { it.activityInfo.name == override.className }
            }
        }
        return super.resolveActivity(intent, flags)
    }

    @Implementation
    override fun queryIntentActivities(intent: Intent, flags: Int): List<ResolveInfo> {
        val activities = super.queryIntentActivities(intent, flags)
        if (!intent.hasCategory(Intent.CATEGORY_HOME)) return activities
        return activities.filterNot {
            ((omitClock || (omitRawGlobalClock && flags == 0 && intent.`package` == null &&
                !intent.hasCategory(Intent.CATEGORY_DEFAULT)) || (omitGlobalCanonicalClock && intent.`package` == null &&
                intent.hasCategory(Intent.CATEGORY_DEFAULT))) && it.activityInfo.name == MainActivity::class.java.name) ||
                (intent.`package` == null && it.activityInfo.packageName == omitUnscopedPackage)
        }
    }
}

@Implements(KeyguardManager::class)
class TestSwipeKeyguard : ShadowKeyguardManager() {
    var dismissals = 0
        private set

    @Implementation
    override fun requestDismissKeyguard(activity: Activity, callback: KeyguardManager.KeyguardDismissCallback) {
        dismissals++
        setKeyguardLocked(false)
        callback.onDismissSucceeded()
    }
}

@Implements(DevicePolicyManager::class)
class FailingHomePolicy : ShadowDevicePolicyManager() {
    var reject = false
    var clockWrites = 0
        private set
    var fallbackWrites = 0
        private set

    @Implementation
    override fun addPersistentPreferredActivity(admin: ComponentName, filter: IntentFilter, activity: ComponentName) {
        if (activity.className == MainActivity::class.java.name) {
            clockWrites++
            if (reject) throw SecurityException("fixture denied device policy")
            return
        }
        fallbackWrites++
        super.addPersistentPreferredActivity(admin, filter, activity)
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w360dp-h360dp-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class DevelopmentClockHandoffTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test
    fun enabledClockLocksExitsAndRelocksThroughSeparateLauncherWithoutCredentials() = verifyHandoff(independent = false)

    @Test
    @Config(shadows = [FailingHomePolicy::class])
    fun foregroundLockSurvivesHomeFailureAndRelocksFromFreemeIcon() = verifyHandoff(independent = true)

    @Test
    fun focusChangesNeverStopAGenuinelyLockedTaskWhenLocalDeploymentIsMissing() {
        val context = RuntimeEnvironment.getApplication()
        val desktop = ManagedDesktop(context)
        val mode = ModeState(context)
        compose.runOnIdle {
            prepareOwnerAndHome(context)
            shadowOf(context.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
            assertTrue(context.getSharedPreferences("permission_setup", 0).edit().putBoolean("completed", true).commit())
        }
        assertEquals(DesktopResult.Applied, runBlocking { ManagedDeployment(context).lockCurrentClock() })
        compose.activityRule.scenario.recreate()
        val activity = compose.activity
        compose.runOnIdle { activity.onWindowFocusChanged(true) }
        awaitHandoff { desktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED }
        compose.runOnIdle {
            assertTrue(mode.saveDeployment(false, DesktopMode.CLOCK))
            activity.onWindowFocusChanged(false)
            activity.onWindowFocusChanged(true)
        }
        assertClockStillLocked(desktop, mode)
    }

    @Test
    @Config(shadows = [TestSwipeKeyguard::class])
    fun managedClockWaitsForSecureKeyguardAndCanDismissAnUnsecuredSwipeBeforeLocking() {
        val context = RuntimeEnvironment.getApplication()
        val keyguard = Shadow.extract<TestSwipeKeyguard>(context.getSystemService(KeyguardManager::class.java))
        compose.runOnIdle {
            prepareOwnerAndHome(context)
            keyguard.setIsDeviceSecure(true)
            keyguard.setKeyguardLocked(true)
            assertTrue(context.getSharedPreferences("clock_display", 0).edit().putBoolean("showOnLockScreen", false).commit())
        }
        assertEquals(DesktopResult.Applied, runBlocking { ManagedDeployment(context).enable() })
        compose.activityRule.scenario.recreate()
        val now = compose.activity
        compose.runOnIdle {
            now.onWindowFocusChanged(true)
            assertTrue(shadowOf(now).showWhenLocked)
            assertFalse(shadowOf(now).turnScreenOn)
            assertEquals(0, keyguard.dismissals)
            assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, ManagedDesktop(context).state)
            keyguard.setIsDeviceSecure(false)
            now.onWindowFocusChanged(true)
        }
        awaitHandoff { ManagedDesktop(context).state == ActivityManager.LOCK_TASK_MODE_LOCKED }
        assertEquals(1, keyguard.dismissals)
    }

    private fun verifyHandoff(independent: Boolean) {
        val welcome = compose.onAllNodesWithText("进入时钟")
        if (welcome.fetchSemanticsNodes().isNotEmpty()) welcome[0].performClick()
        val context = RuntimeEnvironment.getApplication()
        val desktop = ManagedDesktop(context)
        val mode = ModeState(context)
        lateinit var freeme: ComponentName
        compose.runOnIdle {
            freeme = prepareOwnerAndHome(context)
            shadowOf(context.getSystemService(KeyguardManager::class.java)).apply {
                setIsDeviceSecure(true)
                setKeyguardLocked(false)
            }
            assertTrue(context.getSharedPreferences("permission_setup", 0).edit().putBoolean("completed", true).commit())
        }
        val credentialPrefs = context.getSharedPreferences("mode_credentials", 0)
        assertTrue(credentialPrefs.edit().putString("recovery_hash", "legacy-fixture").commit())
        val credentialsBefore = credentialPrefs.all.toMap()
        val deployment = ManagedDeployment(context)
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, ClockDeviceAdmin::class.java)
        val expectedFlags = 80
        if (independent) {
            val policy = shadowOf(context.getSystemService(DevicePolicyManager::class.java)) as FailingHomePolicy
            policy.reject = true
            assertTrue(runBlocking { deployment.enable() } is DesktopResult.Rejected)
            assertFalse(mode.managedLock())
            assertFalse(desktop.permitted)
            assertEquals(DesktopResult.Applied, runBlocking { deployment.lockCurrentClock() })
            assertTrue(mode.independentLock())
            assertFalse(mode.managesHome())
            assertEquals(1, policy.clockWrites)
            assertEquals(1, policy.fallbackWrites)
            assertEquals(freeme, desktop.effectiveHome())
        } else assertEquals(DesktopResult.Applied, runBlocking { deployment.enable() })
        compose.activityRule.scenario.recreate()
        val activity = compose.activity
        compose.runOnIdle { activity.onWindowFocusChanged(true) }
        awaitHandoff { desktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED }
        assertEquals(expectedFlags, dpm.getLockTaskFeatures(admin))
        assertEquals(setOf(context.packageName), dpm.getLockTaskPackages(admin).toSet())
        compose.runOnIdle {
            val window = activity.window
            assertEquals(WindowInsetsControllerCompat.BEHAVIOR_DEFAULT,
                WindowCompat.getInsetsController(window, window.decorView).systemBarsBehavior)
        }

        for (count in listOf(1, 2, 5)) {
            compose.onRoot().performTouchInput {
                repeat(count) {
                    swipeUp(startY = bottom - 1f, endY = top + 1f, durationMillis = 72)
                    advanceEventTime(16)
                }
            }
            assertClockStillLocked(desktop, mode)
            compose.onNodeWithText("开发退出").performTouchInput { click() }
            compose.onNodeWithText("确认退出").assertIsDisplayed()
            compose.onNodeWithText("取消").performTouchInput { click() }
            assertClockStillLocked(desktop, mode)
        }
        compose.onNodeWithText("开发退出").performTouchInput {
            swipeUp(startY = centerY, endY = -height.toFloat(), durationMillis = 72)
        }
        assertClockStillLocked(desktop, mode)
        compose.runOnIdle { activity.onBackPressedDispatcher.onBackPressed() }
        assertClockStillLocked(desktop, mode)

        compose.onNodeWithText("开发退出").assertIsDisplayed().performClick()
        compose.onNodeWithText("确认退出").assertIsDisplayed()
        assertEquals(ActivityManager.LOCK_TASK_MODE_LOCKED, desktop.state)
        compose.onNodeWithText("取消").performClick()
        assertClockStillLocked(desktop, mode)

        compose.onNodeWithText("开发退出").performClick()
        compose.onNodeWithText("确认退出").assertIsDisplayed()
        compose.runOnIdle { ShadowDialog.getLatestDialog().onBackPressed() }
        assertClockStillLocked(desktop, mode)

        compose.onNodeWithText("开发退出").assertIsDisplayed().performClick()
        compose.onNodeWithText("确认退出").assertIsDisplayed().performClick()
        awaitHandoff { mode.current() == DesktopMode.ANDROID && desktop.effectiveHome() == freeme }
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, desktop.state)
        assertTrue(desktop.permitted)
        assertTrue(ShadowLog.getLogsForTag("NaozhoMode").any { "stopLockTask requested reason=desktop-handoff" in it.msg })
        assertEquals(credentialsBefore, credentialPrefs.all)
        awaitHandoff { shadowOf(activity).peekNextStartedActivity()?.component == freeme }
        compose.runOnIdle {
            assertEquals(freeme, shadowOf(activity).nextStartedActivity.component)
            val entry = Robolectric.buildActivity(ClockLauncherActivity::class.java).create().get()
            val launch = shadowOf(entry).nextStartedActivity
            assertTrue(entry.isFinishing)
            InstrumentationRegistry.getInstrumentation().callActivityOnNewIntent(activity, launch)
        }
        awaitHandoff { desktop.state == ActivityManager.LOCK_TASK_MODE_LOCKED }
        assertEquals(expectedFlags, dpm.getLockTaskFeatures(admin))
        assertEquals(setOf(context.packageName), dpm.getLockTaskPackages(admin).toSet())
        compose.onNodeWithContentDescription("显示设置").assertIsDisplayed()
        val names = "GLOBAL_ACTIONS|BLOCK_ACTIVITY_START_IN_TASK"
        assertTrue(ShadowLog.getLogsForTag("NaozhoMode").count {
            "state=LOCKED independent=$independent flags=$expectedFlags ($names) allowlist=[${context.packageName}]" in it.msg
        } >= 2)
        assertEquals(if (independent) freeme else desktop.clockHome, desktop.effectiveHome())
        assertEquals(DesktopMode.CLOCK, mode.current())
        assertTrue(desktop.owner)
        assertEquals(credentialsBefore, credentialPrefs.all)
        if (independent) {
            val policy = shadowOf(context.getSystemService(DevicePolicyManager::class.java)) as FailingHomePolicy
            assertEquals(1, policy.clockWrites)
            assertEquals(1, policy.fallbackWrites)
        }
    }

    private fun assertClockStillLocked(desktop: ManagedDesktop, mode: ModeState) {
        compose.onNodeWithText("确认退出").assertDoesNotExist()
        compose.onNodeWithContentDescription("显示设置").assertIsDisplayed()
        assertEquals(ActivityManager.LOCK_TASK_MODE_LOCKED, desktop.state)
        assertEquals(DesktopMode.CLOCK, mode.current())
        assertTrue(desktop.permitted)
        assertTrue(ShadowLog.getLogsForTag("NaozhoMode").none { "stopLockTask requested reason=desktop-handoff" in it.msg })
    }

    private fun awaitHandoff(complete: () -> Boolean) {
        compose.waitUntil(10_000) {
            compose.waitForIdle()
            complete()
        }
    }
}

@Suppress("DEPRECATION")
private fun prepareOwnerAndHome(context: Context, clockFirst: Boolean = false): ComponentName {
    val policy = context.getSystemService(DevicePolicyManager::class.java)
    assertTrue(shadowOf(policy).setDeviceOwner(ComponentName(context, ClockDeviceAdmin::class.java)))
    val freeme = ComponentName("com.droiclaw.launcher3", "com.freeme.launcher.FreemeLauncher")
    val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    listOf(freeme, ComponentName(context, MainActivity::class.java)).forEach { home ->
        val activity = ActivityInfo().apply {
            packageName = home.packageName
            name = home.className
            enabled = true
            exported = true
            applicationInfo = ApplicationInfo().apply {
                packageName = home.packageName
                if (home == freeme) flags = ApplicationInfo.FLAG_SYSTEM
            }
        }
        val resolved = ResolveInfo().apply {
            activityInfo = activity
            isDefault = true
            priority = if ((home != freeme) == clockFirst) 10 else 0
            nonLocalizedLabel = home.packageName
            filter = IntentFilter(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
            }
        }
        val pm = shadowOf(context.packageManager)
        pm.addResolveInfoForIntent(homeIntent, resolved)
        val canonical = Intent(homeIntent).addCategory(Intent.CATEGORY_DEFAULT)
        pm.addResolveInfoForIntent(canonical, resolved)
        if (home == freeme) {
            pm.addResolveInfoForIntent(Intent(homeIntent).setPackage(home.packageName), resolved)
            pm.addResolveInfoForIntent(Intent(canonical).setPackage(home.packageName), resolved)
        }
    }
    Settings.Global.putInt(context.contentResolver, Settings.Global.BOOT_COUNT, 1)
    assertTrue(ModeState(context).saveHome(freeme))
    return freeme
}
