package com.naozho.clock.alarm

import android.util.Log
import androidx.room.withTransaction
import com.naozho.clock.data.AlarmDatabase
import com.naozho.clock.data.AlarmEvent
import com.naozho.clock.data.AlarmPlan
import java.time.ZoneId
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal enum class Recovery { RESTORE, CLOCK_CHANGED, REBOOT }

internal class AlarmRepository(
    private val database: AlarmDatabase,
    private val scheduler: AlarmScheduler,
    private val notificationsAllowed: () -> Boolean,
    private val wall: () -> Long,
    private val elapsed: () -> Long,
    private val zone: () -> ZoneId,
) {
    private val dao = database.alarms()
    private val lock = Mutex()
    val plans = dao.observe()
    val active = dao.active()
    val events = dao.events()

    suspend fun save(input: AlarmPlan) = lock.withLock {
        require(input.hour in 0..23 && input.minute in 0..59 &&
            input.weekdays in 0..127 && input.snoozeMinutes in 1..120)
        val previous = dao.find(input.id)
        val now = wall()
        val timeChanged = previous == null || previous.hour != input.hour ||
            previous.minute != input.minute || previous.weekdays != input.weekdays ||
            previous.enabled != input.enabled
        val oneShotDay = when {
            input.weekdays != 0 || !input.enabled -> null
            timeChanged -> AlarmTimes.onceDay(input, now, zone())
            else -> previous?.onceDay
        }
        val draft = input.copy(
            onceDay = oneShotDay,
            lastDay = if (timeChanged) null else previous?.lastDay,
            snoozeAt = null,
            snoozeElapsed = null,
            snoozeRegistered = false,
            activeAt = null,
            startedAt = null,
        )
        val next = AlarmTimes.next(draft, now, zone())
        val updated = draft.copy(enabled = draft.enabled && next != null,
            nextAt = next, nextRegistered = false)
        database.withTransaction {
            dao.save(updated)
            record(updated.id, if (updated.enabled) "saved" else "disabled", next)
        }
        cancelChanged(previous, updated)
        register(updated, now)
    }

    suspend fun setEnabled(id: String, enabled: Boolean) = lock.withLock {
        val previous = dao.find(id) ?: return@withLock
        val now = wall()
        val draft = previous.copy(
            enabled = enabled,
            onceDay = if (enabled && previous.weekdays == 0) {
                AlarmTimes.onceDay(previous, now, zone())
            } else null,
            snoozeAt = null,
            snoozeElapsed = null,
            snoozeRegistered = false,
            activeAt = null,
            startedAt = null,
            lastDay = null,
        )
        val updated = draft.copy(nextAt = AlarmTimes.next(draft, now, zone()), nextRegistered = false)
        database.withTransaction {
            dao.save(updated)
            record(id, if (enabled) "enabled" else "disabled", updated.nextAt)
        }
        cancelChanged(previous, updated)
        register(updated, now)
    }

    suspend fun delete(id: String) = lock.withLock {
        val previous = dao.find(id) ?: return@withLock
        database.withTransaction {
            dao.delete(id)
            record(id, "deleted")
        }
        cancelChanged(previous, null)
    }

    suspend fun recover(reason: Recovery) = lock.withLock {
        val now = wall()
        val currentZone = zone()
        dao.all().forEach { previous ->
            val recomputeRegular = reason == Recovery.CLOCK_CHANGED
            val upcoming = AlarmTimes.next(previous, now, currentZone)
            val recent = AlarmTimes.recent(previous, now, currentZone)
                ?.takeIf { previous.weekdays == 0 || it == previous.nextAt }
            val savedRegular = previous.nextAt?.takeIf { previous.enabled && now - it <= AlarmTimes.LATE_WINDOW }
            val next = if (recomputeRegular) {
                recent ?: upcoming
            } else {
                savedRegular ?: recent ?: upcoming
            }
            val elapsedSnooze = previous.snoozeElapsed?.let { now + (it - elapsed()) }
            val snooze = (if (recomputeRegular && previous.snoozeAt != null) {
                elapsedSnooze ?: previous.snoozeAt
            } else previous.snoozeAt)?.takeIf { now - it <= AlarmTimes.LATE_WINDOW }
            val rebooting = reason == Recovery.REBOOT
            val updated = previous.copy(
                enabled = previous.enabled && next != null,
                nextAt = next,
                nextRegistered = next != null && next == previous.nextAt && previous.nextRegistered,
                snoozeAt = snooze,
                snoozeRegistered = snooze != null && snooze == previous.snoozeAt && previous.snoozeRegistered,
                snoozeElapsed = when {
                    snooze == null -> null
                    rebooting -> elapsed() + (snooze - now)
                    else -> previous.snoozeElapsed
                },
                activeAt = if (rebooting) null else previous.activeAt,
                startedAt = if (rebooting) null else previous.startedAt,
            )
            database.withTransaction {
                if (updated != previous) dao.save(updated)
                if (rebooting && previous.activeAt != null) {
                    record(previous.id, "interrupted_reboot", previous.activeAt)
                }
                if (previous.nextAt != null && now - previous.nextAt > AlarmTimes.LATE_WINDOW) {
                    record(previous.id, "missed", previous.nextAt)
                }
                if (previous.snoozeAt != null && snooze == null) {
                    record(previous.id, "missed", previous.snoozeAt)
                }
            }
            cancelChanged(previous, updated)
            register(updated, now)
        }
    }

    /** Match the persisted slot and consume it before allowing playback. */
    suspend fun receive(occurrence: AlarmOccurrence): Boolean = lock.withLock {
        val previous = dao.find(occurrence.id) ?: return@withLock false
        if (previous.occurrence(occurrence.slot) != occurrence) return@withLock false
        val now = wall()
        if (occurrence.at > now + 1_000L) {
            register(previous, now)
            return@withLock false
        }

        val late = now - occurrence.at > AlarmTimes.LATE_WINDOW
        val alreadyActive = previous.activeAt != null
        val play = !late && !alreadyActive
        val advanced = when (occurrence.slot) {
            AlarmSlot.REGULAR -> {
                val consumed = previous.copy(
                    enabled = previous.weekdays != 0,
                    lastDay = AlarmTimes.localDay(occurrence.at, zone()),
                    nextRegistered = false,
                )
                consumed.copy(nextAt = AlarmTimes.next(consumed, maxOf(now, occurrence.at), zone()))
            }
            AlarmSlot.SNOOZE -> previous.copy(
                snoozeAt = null, snoozeElapsed = null, snoozeRegistered = false,
            )
        }
        val updated = if (play) advanced.copy(activeAt = occurrence.at, startedAt = null) else advanced
        database.withTransaction {
            dao.save(updated)
            val action = when {
                late -> "missed"
                alreadyActive -> "overlap"
                else -> "triggered"
            }
            record(previous.id, action, occurrence.at)
        }
        cancelChanged(previous, updated)
        register(updated, now)
        play
    }

    suspend fun begin(id: String, occurrence: Long): Long? = lock.withLock {
        val plan = dao.find(id)?.takeIf { it.activeAt == occurrence } ?: return@withLock null
        if (plan.startedAt != null) return@withLock plan.startedAt
        val at = wall()
        dao.save(plan.copy(startedAt = at))
        at
    }

    suspend fun finish(id: String, occurrence: Long, action: String) = lock.withLock {
        val previous = dao.find(id)?.takeIf { it.activeAt == occurrence } ?: return@withLock
        val now = wall()
        val snooze = action == "snoozed"
        val delay = previous.snoozeMinutes * 60_000L
        val updated = previous.copy(
            activeAt = null,
            startedAt = null,
            snoozeAt = if (snooze) now + delay else previous.snoozeAt,
            snoozeElapsed = if (snooze) elapsed() + delay else previous.snoozeElapsed,
            snoozeRegistered = if (snooze) false else previous.snoozeRegistered,
        )
        database.withTransaction {
            dao.save(updated)
            record(id, action, if (snooze) updated.snoozeAt else occurrence)
        }
        cancelChanged(previous, updated)
        if (snooze && !register(updated, now).snoozeRegistered) {
            // An unscheduled snooze must stay visible until permissions return or it expires.
            record(id, "snooze_unregistered", updated.snoozeAt)
        }
    }

    suspend fun audit(id: String, action: String, occurrence: Long) = lock.withLock {
        record(id, action, occurrence)
    }

    private fun cancelChanged(previous: AlarmPlan?, updated: AlarmPlan?) {
        for (slot in AlarmSlot.entries) {
            val old = previous?.occurrence(slot) ?: continue
            if (old != updated?.occurrence(slot)) scheduler.cancel(old)
        }
    }

    private suspend fun register(plan: AlarmPlan, now: Long): AlarmPlan {
        val allowed = scheduler.canSchedule() && notificationsAllowed()
        suspend fun slot(slot: AlarmSlot, wasRegistered: Boolean): Boolean {
            val occurrence = plan.occurrence(slot) ?: return false
            val registered = allowed && scheduler.schedule(occurrence, maxOf(now + 500L, occurrence.at))
            if (!registered) scheduler.cancel(occurrence)
            if (registered != wasRegistered) {
                record(plan.id, if (registered) "registered" else "unregistered", occurrence.at)
            } else if (!registered && !wasRegistered) {
                // Permission-denied attempts remain inspectable without silently claiming success.
                record(plan.id, "registration_blocked", occurrence.at)
            }
            return registered
        }
        val updated = plan.copy(
            nextRegistered = slot(AlarmSlot.REGULAR, plan.nextRegistered),
            snoozeRegistered = slot(AlarmSlot.SNOOZE, plan.snoozeRegistered),
        )
        if (updated != plan) dao.save(updated)
        return updated
    }

    private suspend fun record(id: String, action: String, occurrence: Long? = null) {
        dao.event(AlarmEvent(alarmId = id, at = wall(), action = action, occurrence = occurrence))
        dao.pruneEvents()
        Log.i("NaozhoAlarm", "$action id=$id occurrence=$occurrence")
    }

    private fun AlarmPlan.occurrence(slot: AlarmSlot): AlarmOccurrence? = when (slot) {
        AlarmSlot.REGULAR -> nextAt
        AlarmSlot.SNOOZE -> snoozeAt
    }?.let { AlarmOccurrence(id, slot, it) }
}
