package com.naozho.clock.weather

import android.content.SharedPreferences
import androidx.core.content.edit
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject

internal data class WeatherLocation(val label: String, val latitude: Double, val longitude: Double) {
    init {
        require(latitude in -90.0..90.0 && longitude in -180.0..180.0)
    }

    val key: String get() = "$latitude,$longitude"

    companion object {
        fun parse(label: String, latitude: String, longitude: String): WeatherLocation? {
            val lat = latitude.trim().toDoubleOrNull() ?: return null
            val lon = longitude.trim().toDoubleOrNull() ?: return null
            if (lat !in -90.0..90.0 || lon !in -180.0..180.0) return null
            return WeatherLocation(label.trim().take(32), lat, lon)
        }
    }
}

internal data class WeatherReading(val celsius: Double, val code: Int) {
    init {
        require(celsius in -150.0..150.0 && code in 0..999)
    }
}

internal data class CachedWeather(val locationKey: String, val reading: WeatherReading, val updatedAt: Long)

internal fun interface WeatherSource {
    suspend fun fetch(location: WeatherLocation): WeatherReading
}

internal interface WeatherCache {
    fun read(): CachedWeather?
    fun write(cached: CachedWeather)
}

internal class PreferenceWeatherCache(private val prefs: SharedPreferences) : WeatherCache {
    override fun read(): CachedWeather? {
        val raw = prefs.getString("last", null) ?: return null
        return runCatching {
            val json = JSONObject(raw)
            CachedWeather(
                json.getString("location"),
                WeatherReading(json.getDouble("celsius"), json.getInt("code")),
                json.getLong("updatedAt").also { require(it > 0L) },
            )
        }.getOrNull()
    }

    override fun write(cached: CachedWeather) {
        val json = JSONObject().put("location", cached.locationKey)
            .put("celsius", cached.reading.celsius).put("code", cached.reading.code)
            .put("updatedAt", cached.updatedAt)
        prefs.edit { putString("last", json.toString()) }
    }
}

internal data class WeatherState(
    val location: WeatherLocation? = null,
    val last: CachedWeather? = null,
    val cached: Boolean = true,
    val refreshing: Boolean = false,
    val online: Boolean = false,
)

/** Called in order by the visible clock's lifecycle collector. */
internal class WeatherRepository(
    private val source: WeatherSource,
    private val cache: WeatherCache,
    private val now: () -> Long = System::currentTimeMillis,
) {
    private val data = MutableStateFlow(WeatherState())
    val state = data.asStateFlow()

    fun display(location: WeatherLocation?, online: Boolean) {
        val old = data.value
        val sameLocation = location?.key == old.location?.key
        val reading = if (sameLocation) old.last else cache.read()?.takeIf { it.locationKey == location?.key }
        data.value = WeatherState(location, reading, cached = !online || !sameLocation || old.cached, online = online)
    }

    suspend fun refresh(force: Boolean = false) {
        val previous = data.value
        val location = previous.location ?: return
        if (!previous.online || previous.refreshing) return
        val age = previous.last?.let { now() - it.updatedAt }
        if (!force && age != null && age in 0 until REFRESH_INTERVAL) return
        data.value = previous.copy(refreshing = true)
        try {
            val current = CachedWeather(location.key, source.fetch(location), now())
            if (data.value.location?.key != location.key || !data.value.online) return
            cache.write(current)
            data.value = data.value.copy(last = current, cached = false, refreshing = false)
        } catch (cancelled: CancellationException) {
            if (data.value.location?.key == location.key) data.value = data.value.copy(refreshing = false)
            throw cancelled
        } catch (_: Exception) {
            if (data.value.location?.key == location.key) {
                data.value = data.value.copy(cached = true, refreshing = false)
            }
        }
    }

    companion object {
        const val REFRESH_INTERVAL = 15 * 60_000L
    }
}

internal class OpenMeteoSource : WeatherSource {
    override suspend fun fetch(location: WeatherLocation): WeatherReading = withContext(Dispatchers.IO) {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}" +
                "&longitude=${location.longitude}&current=temperature_2m,weather_code&temperature_unit=celsius",
        )
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 5_000
            connection.readTimeout = 5_000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Accept", "application/json")
            if (connection.responseCode != HttpURLConnection.HTTP_OK) throw IOException("Weather response")
            val body = connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (output.size() + count > 65_536) throw IOException("Weather response too large")
                    output.write(buffer, 0, count)
                }
                output.toString(Charsets.UTF_8.name())
            }
            parseCurrent(body)
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        fun parseCurrent(body: String): WeatherReading {
            val current = JSONObject(body).getJSONObject("current")
            return WeatherReading(current.getDouble("temperature_2m"), current.getInt("weather_code"))
        }
    }
}

internal fun weatherDescription(code: Int): String = when (code) {
    0 -> "晴"
    1, 2 -> "多云"
    3 -> "阴"
    45, 48 -> "雾"
    51, 53, 55 -> "毛毛雨"
    56, 57, 66, 67 -> "冻雨"
    61, 63, 65 -> "雨"
    71, 73, 75, 77 -> "雪"
    80, 81, 82 -> "阵雨"
    85, 86 -> "阵雪"
    95, 96, 99 -> "雷雨"
    else -> "未知天气"
}
