package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.PowerManager
import android.os.UserManager

internal enum class PowerDelivery { RESERVE, CHECK, CONSUME }

internal object ClockPowerReturn {
    const val ACTION = "com.naozho.clock.action.CONFIRMED_POWER_DOUBLE"
    const val FIRST = "first_elapsed"
    const val RELEASE = "released_elapsed"
    fun target(context: Context) = ComponentName(context.packageName, "com.naozho.clock.mode.PowerClockEntry")

    fun isPrivateTarget(context: Context, intent: Intent): Boolean =
        intent.action == ACTION && intent.component == target(context)

    fun isEntry(context: Context, intent: Intent): Boolean = intent.action == ACTION || intent.component == target(context)

    fun accept(context: Context, intent: Intent, delivery: PowerDelivery): Boolean {
        if (intent.action != ACTION || !context.isDevelopmentBuild || Build.VERSION.SDK_INT < 28) return false
        if (context.getSystemService(UserManager::class.java)?.isUserUnlocked != true ||
            context.getSystemService(KeyguardManager::class.java)?.isKeyguardLocked != false ||
            context.getSystemService(PowerManager::class.java)?.isInteractive != true) return false
        val audioMode = context.getSystemService(AudioManager::class.java)?.mode
        if (audioMode != AudioManager.MODE_NORMAL) return false
        val desktop = ManagedDesktop(context)
        if (!desktop.owner || !desktop.dedicatedReady || desktop.state != ActivityManager.LOCK_TASK_MODE_NONE) return false
        return ModeState(context).acceptPowerPress(intent.getIntExtra(EXTRA_BOOT_COUNT, -1),
            intent.getLongExtra(FIRST, -1), intent.getLongExtra(RELEASE, -1), delivery)
    }
}
