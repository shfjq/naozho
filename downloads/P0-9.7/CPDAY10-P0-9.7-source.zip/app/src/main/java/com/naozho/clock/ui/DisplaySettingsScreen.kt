package com.naozho.clock.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.naozho.clock.display.DisplaySettings
import com.naozho.clock.display.ScreenCapabilities
import com.naozho.clock.weather.WeatherLocation
import java.util.Locale

@Composable
internal fun DisplaySettingsScreen(
    settings: DisplaySettings,
    capabilities: ScreenCapabilities,
    systemUiAvailable: Boolean,
    close: () -> Unit,
    save: (DisplaySettings) -> Unit,
    chooseHome: () -> Unit,
    openPermissions: () -> Unit,
    systemSettings: () -> Unit,
    admin: () -> Unit,
    lockNow: () -> Unit,
    recovery: () -> Unit,
    notificationSettings: () -> Unit,
) {
    var day by rememberSaveable { mutableStateOf(formatMinutes(settings.dayStart)) }
    var night by rememberSaveable { mutableStateOf(formatMinutes(settings.nightStart)) }
    var brightness by rememberSaveable { mutableStateOf(settings.nightPercent.toString()) }
    var idle by rememberSaveable { mutableStateOf(settings.idleSeconds.toString()) }
    var lockScreen by rememberSaveable { mutableStateOf(settings.showOnLockScreen) }
    var name by rememberSaveable { mutableStateOf(settings.weatherLocation?.label.orEmpty()) }
    var latitude by rememberSaveable { mutableStateOf(settings.weatherLocation?.latitude?.toString().orEmpty()) }
    var longitude by rememberSaveable { mutableStateOf(settings.weatherLocation?.longitude?.toString().orEmpty()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TextButton(close) { Text("返回时钟") }
            Text("显示设置", style = MaterialTheme.typography.headlineMedium)
            if (systemUiAvailable) {
                TextButton(openPermissions) { Text("授权与系统状态") }
            }
            Text("亮度", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(day, { day = it.take(5) }, Modifier.weight(1f),
                    label = { Text("白天 HH:mm") }, singleLine = true)
                OutlinedTextField(night, { night = it.take(5) }, Modifier.weight(1f),
                    label = { Text("夜间 HH:mm") }, singleLine = true)
            }
            OutlinedTextField(brightness, { brightness = it.filter(Char::isDigit).take(2) },
                Modifier.fillMaxWidth(), label = { Text("夜间亮度 5–50%") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            Text("白天沿用系统亮度。夜间只调暗时钟应用窗口。", style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()
            Text("息屏与唤醒", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(idle, { idle = it.filter(Char::isDigit).take(3) },
                Modifier.fillMaxWidth(), label = { Text("空闲息屏秒数，0 为关闭") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            Text(
                when {
                    capabilities.activeAdmin -> "已授权。时钟空闲达到设定时间后锁屏。安全锁仍由系统管理。"
                    capabilities.supportsAdmin -> "当前沿用系统息屏时间。可授权应用在空闲时锁屏。"
                    else -> "此设备未提供设备管理功能，息屏时间由系统管理。"
                },
                style = MaterialTheme.typography.bodySmall,
            )
            if (capabilities.supportsAdmin && !capabilities.deviceOwner) {
                OutlinedButton(admin) {
                    Text(if (capabilities.activeAdmin) "停用应用锁屏授权" else "授权应用锁屏")
                }
            }
            if (capabilities.activeAdmin) {
                TextButton(lockNow) { Text("立即息屏") }
            }
            if (systemUiAvailable) {
                OutlinedButton(chooseHome) {
                    Text(if (capabilities.defaultHome) "更换默认桌面" else "设为默认桌面")
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("锁屏时显示前台时钟", Modifier.weight(1f))
                Switch(lockScreen, { lockScreen = it }, Modifier.semantics { contentDescription = "锁屏显示时钟" })
            }
            Text("时钟在前台时可显示在锁屏上。访问设置或切换桌面仍需通过 Android 解锁。",
                style = MaterialTheme.typography.bodySmall)
            if (systemUiAvailable) {
                TextButton(systemSettings) { Text("打开 Android 设置") }
                TextButton(notificationSettings) { Text("通知隔离") }
            } else {
                Text("受管时钟模式中，请先验证 PIN 进入安卓模式，再打开 Android 设置。")
            }
            TextButton(recovery) { Text("管理员恢复") }

            HorizontalDivider()
            Text("天气", style = MaterialTheme.typography.titleMedium)
            Text("向 Open-Meteo 请求所填坐标的天气。清空经纬度可关闭。",
                style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(name, { name = it.take(32) }, Modifier.fillMaxWidth(),
                label = { Text("地点名称（选填）") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(latitude, { latitude = it.take(16) }, Modifier.weight(1f),
                    label = { Text("纬度") }, singleLine = true)
                OutlinedTextField(longitude, { longitude = it.take(16) }, Modifier.weight(1f),
                    label = { Text("经度") }, singleLine = true)
            }
            if (latitude.isNotBlank() || longitude.isNotBlank()) {
                TextButton({ latitude = ""; longitude = ""; name = "" }) { Text("清空天气地点") }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val d = parseMinutes(day)
                    val n = parseMinutes(night)
                    val level = brightness.toIntOrNull()
                    val seconds = idle.toIntOrNull()
                    val location = WeatherLocation.parse(name, latitude, longitude)
                    error = when {
                        d == null || n == null || d == n -> "请输入不同的白天与夜间起始时间（HH:mm）。"
                        level == null || level !in 5..50 -> "请输入 5–50 的夜间亮度。"
                        seconds == null || (seconds != 0 && seconds !in 10..300) -> "息屏时间须为 10–300 秒，或填 0。"
                        location == null && (latitude.isNotBlank() || longitude.isNotBlank()) ->
                            "请输入有效经纬度（纬度 −90 至 90，经度 −180 至 180）。"
                        else -> null
                    }
                    if (error == null && d != null && n != null && level != null && seconds != null) {
                        save(DisplaySettings(d, n, level, seconds, lockScreen, location))
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
            ) { Text("保存显示设置") }
        }
    }
}

internal fun parseMinutes(text: String): Int? {
    if (!text.matches(Regex("[0-9]{2}:[0-9]{2}"))) return null
    val hour = text.substring(0, 2).toInt()
    val minute = text.substring(3).toInt()
    return if (hour in 0..23 && minute in 0..59) hour * 60 + minute else null
}

private fun formatMinutes(minutes: Int): String =
    String.format(Locale.ROOT, "%02d:%02d", minutes / 60, minutes % 60)
