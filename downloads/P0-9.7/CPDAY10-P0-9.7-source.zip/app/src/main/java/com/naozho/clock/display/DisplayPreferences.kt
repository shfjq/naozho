package com.naozho.clock.display

import android.content.SharedPreferences
import androidx.core.content.edit
import com.naozho.clock.weather.WeatherLocation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

internal data class DisplaySettings(
    val dayStart: Int = 7 * 60,
    val nightStart: Int = 22 * 60,
    val nightPercent: Int = 12,
    val idleSeconds: Int = 30,
    val showOnLockScreen: Boolean = true,
    val weatherLocation: WeatherLocation? = null,
) {
    init {
        require(dayStart in 0..1439 && nightStart in 0..1439 && dayStart != nightStart)
        require(nightPercent in 5..50 && (idleSeconds == 0 || idleSeconds in 10..300))
    }

    fun brightness(minuteOfDay: Int): Float {
        val atNight = if (nightStart < dayStart) minuteOfDay in nightStart until dayStart
        else minuteOfDay >= nightStart || minuteOfDay < dayStart
        return if (atNight) nightPercent / 100f else -1f
    }
}

internal class DisplayPreferences(private val prefs: SharedPreferences) {
    private val data = MutableStateFlow(read())
    val state = data.asStateFlow()

    fun save(settings: DisplaySettings) {
        val location = settings.weatherLocation
        prefs.edit {
            putInt("dayStart", settings.dayStart)
            putInt("nightStart", settings.nightStart)
            putInt("nightPercent", settings.nightPercent)
            putInt("idleSeconds", settings.idleSeconds)
            putBoolean("showOnLockScreen", settings.showOnLockScreen)
            putString("weatherLabel", location?.label)
            putString("weatherLat", location?.latitude?.toString())
            putString("weatherLon", location?.longitude?.toString())
        }
        data.value = settings
    }

    private fun read(): DisplaySettings {
        val defaults = DisplaySettings()
        val day = prefs.getInt("dayStart", defaults.dayStart).takeIf { it in 0..1439 } ?: defaults.dayStart
        val night = prefs.getInt("nightStart", defaults.nightStart).takeIf { it in 0..1439 && it != day }
            ?: if (day == defaults.nightStart) defaults.dayStart else defaults.nightStart
        return DisplaySettings(
            dayStart = day,
            nightStart = night,
            nightPercent = prefs.getInt("nightPercent", defaults.nightPercent).coerceIn(5, 50),
            idleSeconds = prefs.getInt("idleSeconds", defaults.idleSeconds)
                .takeIf { it == 0 || it in 10..300 } ?: defaults.idleSeconds,
            showOnLockScreen = prefs.getBoolean("showOnLockScreen", defaults.showOnLockScreen),
            weatherLocation = WeatherLocation.parse(
                prefs.getString("weatherLabel", "").orEmpty(),
                prefs.getString("weatherLat", "").orEmpty(),
                prefs.getString("weatherLon", "").orEmpty(),
            ),
        )
    }
}
