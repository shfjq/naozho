"""Summarize previously exported CPDAY10 evidence. No device connection required."""

import argparse
import codecs
import hashlib
import json
import re
import shutil
import sqlite3
import tempfile
from contextlib import closing
from pathlib import Path


TABLES = ("t_atlas_policy", "t_atlas_user")
CLOCK = "com.naozho.clock"


def file_digest(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def inspect_database(path):
    if not path.is_file():
        raise FileNotFoundError(path)
    files = {}
    counts = {}
    with tempfile.TemporaryDirectory(prefix="cpday10-snapshot-") as directory:
        local = Path(directory) / "sample.db"
        for suffix in ("", "-wal", "-shm", "-journal"):
            source = path.with_name(path.name + suffix)
            if source.is_file():
                files[suffix or "main"] = file_digest(source)
                # SHM is a transient WAL index. Let SQLite build it in the private directory.
                if suffix != "-shm":
                    shutil.copyfile(source, local.with_name(local.name + suffix))
        if files["main"]["bytes"] < 100:
            raise ValueError("missing SQLite database header")
        with closing(sqlite3.connect(local.resolve().as_uri() + "?mode=ro", uri=True)) as db:
            db.execute("PRAGMA query_only=ON")
            db.execute("PRAGMA trusted_schema=OFF")
            db.execute("BEGIN")
            for table in TABLES:
                schema = db.execute(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)
                ).fetchone()
                if schema is None:
                    counts[table] = {"status": "table_missing"}
                elif not re.match(r"CREATE\s+TABLE\b", schema[0] or "", re.I):
                    counts[table] = {"status": "unsupported_table_type"}
                else:
                    # Only the two constant names above are used in these statements.
                    rows = db.execute('SELECT count(*) FROM "' + table + '"').fetchone()[0]
                    counts[table] = {"status": "counted", "rows": rows}
    return {"file": str(path), "supplied_files": files, "tables": counts}


def inspect_projection(path):
    data = path.read_bytes()
    encoding = "utf-16" if data.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)) else "utf-8-sig"
    lines = [line.strip() for line in data.decode(encoding).splitlines() if line.strip()]
    if lines in (["No result found."], ["No result found"]):
        return {"rows": 0, "distinct_packages": 0, "clock_present": False}
    packages = set()
    for index, line in enumerate(lines):
        match = re.fullmatch(r"Row:\s*(\d+)\s+c_pkg_name=([A-Za-z0-9_.]+)", line)
        if not match or int(match[1]) != index:
            raise ValueError("unrecognized or incomplete projection; expected only c_pkg_name rows starting at 0")
        packages.add(match[2])
    if not lines:
        raise ValueError("empty capture; no evidence of a successful query")
    return {"rows": len(lines), "distinct_packages": len(packages), "clock_present": CLOCK in packages}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", action="append", type=Path, default=[], help="static SQLite export (repeatable)")
    parser.add_argument("--provider", type=Path, help="saved Android content query output, c_pkg_name only")
    args = parser.parse_args()
    if not (args.db or args.provider):
        parser.error("supply --db or --provider")
    results = []
    for path in args.db:
        try:
            results.append(inspect_database(path))
        except (OSError, ValueError, sqlite3.Error) as error:
            results.append({"file": str(path), "error": str(error)})
    if args.provider:
        try:
            results.append({"file": str(args.provider), "projection": inspect_projection(args.provider)})
        except (OSError, ValueError) as error:
            results.append({"file": str(args.provider), "error": str(error)})
    print(json.dumps(results, indent=2))
    return int(any("error" in result for result in results))


if __name__ == "__main__":
    raise SystemExit(main())
