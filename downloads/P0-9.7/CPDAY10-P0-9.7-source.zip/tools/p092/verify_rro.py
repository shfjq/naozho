"""Build and verify the unsigned P0-9.2 overlay on a host. No ADB or device access."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile
from zipfile import ZipFile

EVIDENCE = '0c190b7c33c5fb2a63e0cac2567a80d2760c3c33f98a4e8a3b6172cd242a1950'
FRAMEWORK = '48a3f6912392d1d5fb066be715c3e0f888d9016011cdc9cf50b2609a2c040d02'
ARSC = 'c330c3bf61ac9e381978f2d2e70e37cbc8354342b83a6aabe26ba799097ca088'
STOCK = {
    'FrameworkResOverlay.apk': 'f81064c58a829ce8eee683ef9f79bf686f9388934572513393778ebd46961388',
    'FrameworkResOverlayExt.apk': '8310a4fd8e0687ae50d680c830494ad299451ca6d94269e5f38a48619a6130fd',
    'FrameworkResVendorOverlay.apk': 'ec013cec998277330b80e99626ca6d841e4f6f76eede368c84b78ac2fb1219aa',
    'framework-res__sys_L930E_M41__auto_generated_rro_product.apk':
        '91c53c9ea20d030d64de5a907aa7140a556f42404c8536afb4af0e12ab4b3b78',
}
BEHAVIOR = 'integer/config_doublePressOnPowerBehavior'
TARGET = 'string/config_doublePressOnPowerTargetActivity'
COMPONENT = 'com.naozho.clock/.mode.PowerReturnActivity'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def chunks(blob):
    cursor = 0
    while cursor < len(blob):
        kind, header, size = struct.unpack_from('<HHI', blob, cursor)
        if not 8 <= header <= size <= len(blob) - cursor:
            raise ValueError('Invalid ARSC chunk')
        yield kind, blob[cursor + header:cursor + size]
        cursor += size


def command(*args, check=True):
    return subprocess.run(list(map(str, args)), capture_output=True, text=True, check=check)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('aapt2', 'android-jar', 'idmap2', 'evidence', 'stock-dir', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    result = {}
    if digest(args.evidence.read_bytes()) != EVIDENCE:
        raise ValueError('Evidence ZIP digest mismatch')
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        target = work/'resource-slice.apk'
        with ZipFile(args.evidence) as evidence, ZipFile(target, 'w') as slice_zip:
            assert evidence.testzip() is None
            metadata = json.loads(evidence.read('policy.json'))
            assert metadata['source_apk_sha256'] == FRAMEWORK
            for name in ('AndroidManifest.xml', 'resources.arsc'):
                data = evidence.read('members/' + name)
                assert digest(data) == metadata['members'][name]
                slice_zip.writestr(name, data)
            assert digest(data) == ARSC
            [(root, contents)] = chunks(memoryview(data))
            assert root == 2
            counts = [sum(k == 0x0204 for k, _ in chunks(children))
                      for kind, children in chunks(contents) if kind == 0x0200]
            assert counts == [0] * 7
            result['overlayable_groups_per_package_chunk'] = counts
        command(args.aapt2, 'compile', '--dir', source/'res', '-o', work/'flat.zip')
        apk = work/'power-return-unsigned.apk'
        command(args.aapt2, 'link', '-I', args.android_jar, '--manifest', source/'AndroidManifest.xml',
                '--no-resource-deduping', '--no-resource-removal', '-o', apk, work/'flat.zip')

        def create(overlay, policy, name):
            dest = work/(name+'.idmap')
            proc = command(args.idmap2, 'create', '--target-apk-path', target, '--overlay-apk-path',
                           overlay, '--idmap-path', dest, '--policy', policy, check=False)
            return proc, dest

        denied, _ = create(apk, 'public', 'unqualified')
        assert denied.returncode and 'no resources were overlaid' in denied.stderr, denied.stderr
        result['public_only_rejected'] = True
        mapped, proto = create(apk, 'product', 'experiment')
        assert mapped.returncode == 0, mapped.stderr
        dump = command(args.idmap2, 'dump', '--idmap-path', proto).stdout.split('Mapping:')[-1]
        mapping = [line.strip() for line in dump.splitlines() if ' -> ' in line]
        assert len(mapping) == 2
        assert any('0x010e0085' in line and BEHAVIOR in line for line in mapping)
        assert any('0x0104026b' in line and TARGET in line for line in mapping)
        result['prototype_mapping'] = mapping

        stock = []
        for i, (name, expected) in enumerate(STOCK.items()):
            path = args.stock_dir/name
            assert digest(path.read_bytes()) == expected
            # A qualified offline policy, not an assertion about actual partition or OMS order.
            proc, path_map = create(path, 'product', 'stock'+str(i))
            assert proc.returncode == 0, proc.stderr
            table = command(args.idmap2, 'dump', '--idmap-path', path_map).stdout
            assert BEHAVIOR not in table and TARGET not in table
            stock.append(path_map)
        result['supplied_stock_maps_without_both_names'] = len(stock)

        def lookup(maps, resource):
            paths = [arg for path in maps for arg in ('--idmap-path', path)]
            output = command(args.idmap2, 'lookup', *paths, '--config', '',
                             '--resid', 'android:' + resource).stdout
            return re.search(r'value=(.*)$', output.strip()).group(1).strip('"')

        controls = ['integer/config_shortPressOnPowerBehavior', 'bool/config_shortPressEarlyOnPower',
                    'integer/config_longPressOnPowerBehavior', 'integer/config_veryLongPressOnPowerBehavior',
                    'integer/config_triplePressOnPowerBehavior', 'bool/config_cameraDoubleTapPowerGestureEnabled',
                    'bool/config_emergencyGestureEnabled', 'bool/config_defaultEmergencyGestureEnabled']
        baseline_controls = {r: lookup(stock, r) for r in controls}
        for label, order, expected in (
            ('baseline', stock, ['0', '']), ('prototype_last', stock+[proto], ['3', COMPONENT]),
            ('prototype_first', [proto]+stock[::-1], ['3', COMPONENT]),
            ('removed', stock, ['0', ''])
        ):
            observed = [lookup(order, resource) for resource in (BEHAVIOR, TARGET)]
            assert observed == expected, (label, observed)
            assert {r: lookup(order, r) for r in controls} == baseline_controls
            result[label] = observed
        result['unchanged_control_resources'] = baseline_controls
        args.output.write_bytes(apk.read_bytes())
        result['unsigned_apk_sha256'] = digest(apk.read_bytes())
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
