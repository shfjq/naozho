"""Check decision points in the stock CPDAY10 firmware. No APK or device is executed."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
from zipfile import ZipFile

JAR_SHA = '70fa04e1e51c4008078cdc7fd6c1cc041769e39bd3cce99712ce1d374d81f468'
# Method-relative code-unit offsets. Verify the opcodes as well as the branch destinations.
CHECKS = {
    'com.android.server.GestureLauncherService.interceptPowerKeyDown': {
        '0093': 'mEmergencyGestureEnabled', '0099': 'mHasFeatureWatch', '009b': '#int 5',
        '009c': 'if-eqz v10, 00a0', '00a0': 'move v10, v4', '00a1': 'if-le v2, v10, 00a6',
        '00a3': 'move/from16 v10, v18', '00a7': 'if-ne v2, v11, 011c',
        '011c': 'move v2, v3', '011d': 'goto 0120', '0185': 'if-ne v9, v4, 0190',
        '01f8': 'handleEmergencyGesture', '0230': 'if-eqz v10, 0239',
        '0232': 'isUserSetupComplete', '0238': 'return v4',
    },
    'com.android.server.GestureLauncherService.handleEmergencyGesture': {
        '001a': 'onEmergencyActionLaunchGestureDetected',
    },
    'com.android.server.policy.PhoneWindowManager.handleCameraGesture': {
        '000f': 'interceptPowerKeyDown', '0015': 'if-nez v4, 0018', '0017': 'return v3',
    },
    'com.android.server.policy.PhoneWindowManager.handleKeyGesture': {
        '0022': 'handleCameraGesture', '002a': 'if-eqz v0, 0032', '002e': '.reset:', '0031': 'return-void',
        '0034': 'interceptKey:',
    },
    'com.android.server.policy.PhoneWindowManager.getMaxMultiPressPowerCount': {
        '0012': 'mTriplePressOnPowerBehavior', '0018': 'mDoublePressOnPowerBehavior',
        '001c': '#int 2', '001d': 'return v3',
    },
    'com.android.server.policy.SingleKeyGestureDetector.interceptKeyDown': {
        '014c': 'getMaxMultiPressCount', '017c': 'MessageObject;', '018a': 'sendMessage',
    },
    'com.android.server.policy.PhoneWindowManager.launchTargetActivityOnMultiPressPower': {
        '0011': 'Intent;.<init>:()V', '0016': 'setComponent', '0020': 'resolveActivity',
        '003a': 'startActivityAsUser', '0040': 'dismissKeyguardToLaunch',
    },
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('services_jar', type=Path)
    parser.add_argument('dexdump', type=Path)
    args = parser.parse_args()
    if hashlib.sha256(args.services_jar.read_bytes()).hexdigest() != JAR_SHA:
        raise ValueError('Firmware mismatch')
    checked = {name: set() for name in CHECKS}
    with tempfile.TemporaryDirectory() as temp, ZipFile(args.services_jar) as jar:
        for name in jar.namelist():
            if not re.fullmatch(r'classes\d*\.dex', name):
                continue
            dex = Path(temp)/name
            dex.write_bytes(jar.read(name))
            with subprocess.Popen([str(args.dexdump), '-d', str(dex)], stdout=subprocess.PIPE) as proc:
                method = None
                for line in proc.stdout:
                    if b'|[' in line:
                        method = line.partition(b'] ')[2].partition(b':')[0].decode('ascii', 'replace').strip()
                    elif method in CHECKS and b'|' in line:
                        offset, _, body = line.partition(b'|')[2].partition(b':')
                        pos = offset.decode('ascii', 'replace')
                        if pos in CHECKS[method]:
                            assert CHECKS[method][pos].encode() in body, (method, pos)
                            checked[method].add(pos)
                        if method.endswith('.launchTargetActivityOnMultiPressPower'):
                            assert b'putExtra' not in body and b'putExtras' not in body
                if proc.wait():
                    raise RuntimeError('dexdump failed')
    for method, offsets in CHECKS.items():
        assert set(offsets) == checked[method], (method, set(offsets) - checked[method])
    print(json.dumps({'method_count': len(CHECKS), 'checked_offsets': sum(map(len, checked.values())),
                      'firmware_sha256': JAR_SHA}, indent=2))


if __name__ == '__main__':
    main()
