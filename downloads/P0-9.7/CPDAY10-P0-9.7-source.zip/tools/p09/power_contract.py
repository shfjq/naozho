"""Offline acceptance oracle for a proposed OEM shortcut. Never reads or sends input."""
from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class Context:
    boot: int
    generation: int
    phase: str
    interactive: bool
    user: int = 0
    unlocked: bool = True
    owner: bool = True


@dataclass(frozen=True)
class Gesture:
    # A *completed* series, closed by the original input policy including emergency arbitration.
    original: Context
    edges: Tuple[Tuple[str, int], ...]
    exclusive_double: bool
    stock_action_started: bool = False


def may_request_clock(series: Gesture, now: Context, max_down_interval_ms: int, long_press_ms: int) -> bool:
    if not series.exclusive_double or series.stock_action_started or now != series.original:
        return False
    if now.phase != "ANDROID" or not now.interactive or not now.unlocked or not now.owner or now.user != 0:
        return False
    if now.boot < 0 or now.generation < 0:
        return False
    if tuple(kind for kind, _ in series.edges) != ("down", "up", "down", "up"):
        return False
    first, release, second, end = (tick for _, tick in series.edges)
    return (0 <= first < release < second < end and second - first < max_down_interval_ms
            and max(release - first, end - second) < long_press_ms)


class ShortcutArbiter:
    """Single-threaded replay oracle. Timestamps use milliseconds since the same boot."""
    def __init__(self):
        self.last_dispatched = (-1, -1)

    def admit(self, series, now, max_down_interval_ms, long_press_ms):
        if not may_request_clock(series, now, max_down_interval_ms, long_press_ms):
            return False
        key = (now.boot, series.edges[-1][1])
        if key <= self.last_dispatched:
            return False
        self.last_dispatched = key
        return True
