"""Read-only CPDAY10 user-0 snapshot. Python 3.8+ and platform-tools on PATH."""
import argparse
import datetime
import json
import re
import subprocess
from pathlib import Path


def shell_reader(serial):
    adb = ["adb"] + (["-s", serial] if serial else [])
    def read(args, pattern=None):
        try:
            p = subprocess.run(adb + ["shell"] + args.split(), capture_output=True,
                               timeout=15, encoding="utf-8", errors="replace")
        except subprocess.TimeoutExpired:
            return {"command": args, "status": "timeout"}
        lines = (p.stdout + "\n" + p.stderr).strip().splitlines()
        error = any(re.match(r"^(?:Error:|Exception|Security exception|Unknown command|adb:|Permission Denial)", line)
                    for line in lines)
        if pattern and not error and not p.returncode:
            lines = [line.strip() for line in lines if re.search(pattern, line, re.I)]
        return {"command": args, "status": "error" if error or p.returncode else "ok", "lines": lines}
    return read


def snapshot(read):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    boot = "settings get global boot_count"
    checks = {}
    def check(key, cmd, pattern=None):
        checks[key] = read(cmd, pattern)
    check("boot_before", boot)
    check("current_user", "am get-current-user")
    check("user0", "am get-started-user-state 0")
    check("build", "getprop ro.build.fingerprint")
    check("services", "sha256sum /system/framework/services.jar")
    check("owner", "dpm list-owners")
    check("version", "dumpsys package com.naozho.clock", r"versionCode=|versionName=")
    check("enforcement", "getenforce")
    check("lockscreen_setting", "locksettings get-disabled --user 0")
    check("window_policy", "dumpsys window policy",
          r"keyguard|occluded|showing=|bouncer|PowerBehavior|PowerDoublePress|shortPressEarly")
    check("window", "dumpsys window windows", r"mCurrentFocus=|mFocusedApp=")
    check("activity", "dumpsys activity activities", r"mLockTaskModeState=|topResumedActivity|mResumedActivity")
    check("device_policy", "dumpsys device_policy", r"locktask|mflags=|com\.naozho\.clock|FreemeLauncher")
    check("power", "dumpsys power", r"mWakefulness=|Display Power: state=")
    check("role_home", "dumpsys role", r"android\.app\.role\.HOME|com\.droiclaw\.launcher3|com\.naozho\.clock")
    intent = "-a android.intent.action.MAIN -c android.intent.category.HOME"
    for key, scope in (("home_global", ""), ("home_clock", " -p com.naozho.clock")):
        check(key, "cmd package query-activities --components --user 0 --query-flags 0 " + intent + scope)
    check("resolved_home", "cmd package resolve-activity --brief --user 0 --query-flags 66560 " + intent)
    for name in ("integer/config_doublePressOnPowerBehavior", "string/config_doublePressOnPowerTargetActivity",
                 "bool/config_shortPressEarlyOnPower", "integer/config_triplePressOnPowerBehavior",
                 "integer/config_longPressOnPowerBehavior", "bool/config_cameraDoubleTapPowerGestureEnabled",
                 "integer/config_doubleTapPowerGestureMode", "integer/config_doubleTapPowerGestureMultiTargetDefaultAction",
                 "bool/config_emergencyGestureEnabled"):
        check(name, "cmd overlay lookup --user 0 android android:" + name)
    for name in ("camera_double_tap_power_gesture_disabled", "double_tap_power_button_gesture_enabled",
                 "double_tap_power_button_gesture", "emergency_gesture_enabled", "multi_press_timeout"):
        check(name, "settings --user 0 get secure " + name)
    for name in ("power_button_double_press", "power_button_short_press", "power_button_long_press",
                 "power_button_triple_press"):
        check(name, "settings get global " + name)
    check("clock_log", "logcat -d -t 250 -v monotonic -s NaozhoMode:I NaozhoModuleBoot:I",
          r"Independent boot|clockEntry=|stationPhase=|Clock window focused|Lock Task after start|result=")
    check("user_after", "am get-current-user")
    check("boot_after", boot)
    def value(key):
        item = checks[key]
        return item.get("lines", []) if item["status"] == "ok" else []
    initial = value("boot_before")
    consistent = (len(initial) == 1 and initial[0].isdigit() and initial == value("boot_after")
                  and value("current_user") == value("user_after") == ["0"])
    return {"utc_start": start, "utc_finish": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "same_boot_user0": consistent, "checks": checks}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--serial", help="ADB serial if multiple authorized devices are connected")
    parser.add_argument("output", type=Path, help="new local JSON file")
    args = parser.parse_args()
    try:
        adb = ["adb"] + (["-s", args.serial] if args.serial else [])
        connected = subprocess.run(adb + ["get-state"], capture_output=True, timeout=10,
                                   encoding="utf-8", errors="replace")
        if connected.returncode or connected.stdout.strip() != "device":
            parser.exit(1, (connected.stderr.strip() or "Select one authorized ADB device.") + "\n")
        result = snapshot(shell_reader(args.serial))
        with args.output.open("x", encoding="utf-8") as out:
            json.dump(result, out, ensure_ascii=False, indent=2)
            out.write("\n")
    except (OSError, subprocess.TimeoutExpired) as err:
        parser.exit(1, str(err) + "\n")
    print(args.output, "same_boot_user0=" + str(result["same_boot_user0"]))
    return 0 if result["same_boot_user0"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
