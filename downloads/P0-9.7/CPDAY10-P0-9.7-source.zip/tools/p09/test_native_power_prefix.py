"""Off-device counterexamples for the actionless native target and the OEM contract."""
import unittest
from dataclasses import replace
from power_contract import Context, Gesture, ShortcutArbiter


class NativePowerPrefixTest(unittest.TestCase):
    def setUp(self):
        self.android = Context(1, 1, "ANDROID", True)
        self.prefix = (("down", 1000), ("up", 1040), ("down", 1200))
        self.android_double = self.prefix + (("up", 1240),)
        self.series = Gesture(self.android, self.android_double, exclusive_double=True)

    def test_second_down_does_not_distinguish_double_hold_or_sos(self):
        hold = self.prefix + (("up", 1860),)
        sos = self.android_double + tuple(
            event for down in (1400, 1600, 1800) for event in (("down", down), ("up", down + 40))
        )
        for edges in [self.android_double, hold, sos]:
            self.assertEqual(self.prefix, edges[:3])
        self.assertEqual(self.android_double, sos[:4])
        arbiter = ShortcutArbiter()
        for edges in (self.prefix, self.android_double, hold, sos):
            self.assertFalse(arbiter.admit(Gesture(self.android, edges, False), self.android, 300, 500))
        self.assertFalse(arbiter.admit(Gesture(self.android, sos, True, stock_action_started=True),
                                       self.android, 300, 500))
        self.assertTrue(arbiter.admit(self.series, self.android, 300, 500))
        self.assertFalse(arbiter.admit(self.series, self.android, 300, 500))

    def test_pause_and_rearm_invalidates_old_completed_sequence(self):
        paused = replace(self.android, phase="MAINTENANCE_PAUSED", generation=2)
        rearmed = replace(self.android, generation=3)
        arbiter = ShortcutArbiter()
        for context in (paused, rearmed):
            self.assertFalse(arbiter.admit(self.series, context, 300, 500))
        self.assertTrue(arbiter.admit(replace(self.series, original=rearmed), rearmed, 300, 500))
