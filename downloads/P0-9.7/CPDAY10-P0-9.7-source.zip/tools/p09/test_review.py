import unittest
from dataclasses import replace
from collect import snapshot
from power_contract import Context, Gesture, ShortcutArbiter, may_request_clock


class PowerContractTest(unittest.TestCase):
    def setUp(self):
        self.android = Context(10, 3, "ANDROID", interactive=True)
        self.edges = (("down", 100), ("up", 145), ("down", 300), ("up", 355))
        self.double = Gesture(self.android, self.edges, exclusive_double=True)

    def accepts(self, series, now=None):
        return may_request_clock(series, now or self.android, 300, 500)

    def test_two_distinct_releases_with_exclusive_system_decision(self):
        self.assertTrue(self.accepts(self.double))

    def test_requires_stock_arbitration_and_no_competing_action(self):
        self.assertFalse(self.accepts(replace(self.double, exclusive_double=False)))
        self.assertFalse(self.accepts(replace(self.double, stock_action_started=True)))

    def test_must_begin_and_finish_in_same_eligible_context(self):
        for change in (dict(phase="CLOCK"), dict(phase="MAINTENANCE_PAUSED"), dict(phase="BOOT_PENDING"),
                       dict(interactive=False), dict(unlocked=False), dict(owner=False), dict(user=10)):
            other = replace(self.android, **change)
            with self.subTest(change=change):
                self.assertFalse(self.accepts(replace(self.double, original=other), other))
                self.assertFalse(self.accepts(replace(self.double, original=other)))
        for other in (replace(self.android, generation=4), replace(self.android, boot=11)):
            self.assertFalse(self.accepts(self.double, other))

    def test_reject_single_long_repeat_cancel_triple_and_emergency_sequences(self):
        for edges in (self.edges[:2], self.edges[:3], self.edges[:-1] + (("up", 800),),
                      self.edges[:1] + (("repeat", 110),) + self.edges[1:],
                      self.edges[:-1] + (("cancel", 355),),
                      self.edges + (("down", 400), ("up", 440)),
                      self.edges + (("down", 400), ("up", 440)) * 3):
            with self.subTest(edges=edges):
                self.assertFalse(self.accepts(replace(self.double, edges=edges)))

    def test_single_admission_per_completed_series_and_boot(self):
        arbiter = ShortcutArbiter()
        self.assertTrue(arbiter.admit(self.double, self.android, 300, 500))
        self.assertFalse(arbiter.admit(self.double, self.android, 300, 500))
        older = tuple((kind, tick - 10) for kind, tick in self.edges)
        self.assertFalse(arbiter.admit(replace(self.double, edges=older), self.android, 300, 500))
        later_boot = replace(self.android, boot=11)
        self.assertTrue(arbiter.admit(replace(self.double, original=later_boot), later_boot, 300, 500))

    def test_outside_window_and_malformed_times(self):
        for edges in (self.edges[:2] + (("down", 400), ("up", 430)),
                      self.edges[:2] + (("down", 141), ("up", 240))):
            self.assertFalse(self.accepts(replace(self.double, edges=edges)))


class SnapshotTest(unittest.TestCase):
    def fake(self, boots, users):
        def read(cmd, pattern=None):
            if cmd == "settings get global boot_count":
                value = next(boots)
            elif cmd == "am get-current-user":
                value = next(users)
            else:
                value = "fixture"
            return {"status": "ok", "command": cmd, "lines": [value]}
        return snapshot(read)

    def test_snapshot_records_scoped_and_global_queries_and_effective_controls(self):
        sample = self.fake(iter(["12", "12"]), iter(["0", "0"]))
        self.assertTrue(sample["same_boot_user0"])
        checks = sample["checks"]
        self.assertNotIn(" -p ", checks["home_global"]["command"])
        self.assertIn(" -p com.naozho.clock", checks["home_clock"]["command"])
        self.assertIn("power_button_double_press", checks)
        self.assertIn("string/config_doublePressOnPowerTargetActivity", checks)

    def test_cross_boot_or_user_not_comparable(self):
        for boots, users in ((["12","13"], ["0","0"]), (["12","12"], ["0","10"]), (["null","null"], ["0","0"])):
            self.assertFalse(self.fake(iter(boots), iter(users))["same_boot_user0"])


if __name__ == "__main__":
    unittest.main()
