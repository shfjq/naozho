项目源码提交 4636d5b4c0dee650dfd41042ffff803fb8e3d320。日常模块构建、离线测试及权限范围见 tools/p097/REPORT.md；部署、停用及验收见 tools/p097/DSH.md。本次仅构建 KernelSU 模块，保留既有 0.6.13-dev / 28 APK。
