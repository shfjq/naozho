package com.naozho.clock.weather

import android.Manifest
import android.app.Application
import android.content.Context
import android.location.Address
import android.location.Location
import android.location.LocationManager
import android.os.SystemClock
import com.naozho.clock.display.DisplayPreferences
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowGeocoder
import java.time.Duration
import java.util.Locale
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class CityLocatorTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val locationManager: LocationManager get() = checkNotNull(app.getSystemService(LocationManager::class.java))

    @Test
    fun permissionDenialReturnsWithoutAccessingPosition() = runBlocking {
        shadowOf(app).denyPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        val offline = NetworkCitySource { _, _, _ -> throw AssertionError("unexpected network lookup") }
        assertEquals(CityResult.PermissionMissing, CityLocator(app, reverse(offline)).resolve())
    }

    @Test
    fun disabledSystemLocationDoesNotUsePassiveProvider() = runBlocking {
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        shadowOf(locationManager).setLocationEnabled(false)
        assertFalse(CityLocator(app).serviceEnabled())
        assertEquals(CityResult.ServiceDisabled, CityLocator(app).resolve())
    }

    @Test
    fun cacheUsesMonotonicAgeAndRejectsStaleFutureOrUndatedFixes() {
        val now = TimeUnit.HOURS.toNanos(20)
        val edge = fix(now - TimeUnit.HOURS.toNanos(6))
        val newer = fix(now - 1).apply { time = 1L }
        val stale = fix(edge.elapsedRealtimeNanos - 1).apply { time = Long.MAX_VALUE }
        val future = fix(now + 1)
        assertNull(newestWeatherFix(listOf(stale, future, fix(0)), now, CityLocator.STALE_AFTER_MS))
        assertSame(edge, newestWeatherFix(listOf(edge, stale), now, CityLocator.STALE_AFTER_MS))
        assertSame(newer, newestWeatherFix(listOf(edge, newer, future), now, CityLocator.STALE_AFTER_MS))
    }

    @Test
    fun availablePlatformCityAvoidsNetwork() = runBlocking {
        val expectedFix = setupLiveFix()
        ShadowGeocoder.setIsPresent(true)
        val offline = NetworkCitySource { _, _, _ -> throw AssertionError("unexpected network lookup") }
        val locator = CityLocator(app, reverse(offline)) { locale ->
            android.location.Geocoder(app, locale).also { geocoder ->
                val city = Address(locale).apply { locality = "本地城市" }
                shadowOf(geocoder).setFromLocation(listOf(city))
            }
        }
        val resolved = locator.resolve() as CityResult.Resolved
        assertEquals("本地城市", resolved.location.label)
        assertEquals(expectedFix.time, resolved.resolvedAt)
    }

    @Test
    fun recentCurrentFixUsesNetworkWhenPlatformServiceIsAbsent() = runBlocking {
        val expectedFix = setupLiveFix()
        ShadowGeocoder.setIsPresent(false)
        var requests = 0
        val source = NetworkCitySource { lat, lon, _ ->
            assertEquals("31.00", lat)
            assertEquals("121.00", lon)
            requests++
            "上海"
        }
        val locator = CityLocator(app, reverse(source))
        assertEquals(CityResult.Resolved(WeatherLocation("上海", 31.0, 121.0), expectedFix.time), locator.resolve())
        assertEquals(CityResult.Resolved(WeatherLocation("上海", 31.0, 121.0), expectedFix.time), locator.resolve())
        assertEquals(1, requests)
    }

    @Test
    fun missingCityKeepsValidCoordinatesWithoutInventingCityName() = runBlocking {
        val expectedFix = setupLiveFix()
        ShadowGeocoder.setIsPresent(false)
        val locator = CityLocator(app, reverse(NetworkCitySource { _, _, _ -> null }))
        assertEquals(CityResult.NoCity(WeatherLocation("", 31.0, 121.0), expectedFix.time), locator.resolve())
    }

    @Test
    fun cityProviderParsingUsesAdministrativeFallbackAndRejectsCoordinates() {
        assertEquals("香港", BigDataCloudCitySource.parseCity("""{"city":" 香港 ","locality":"中西区"}"""))
        assertEquals("市辖区", BigDataCloudCitySource.parseCity("""{"city":null,"locality":"市辖区"}"""))
        assertEquals("北京市", BigDataCloudCitySource.parseCity("""{"city":"","locality":"","principalSubdivision":"北京市"}"""))
        assertNull(BigDataCloudCitySource.parseCity("""{"city":"31.00,121.00","locality":null}"""))
    }

    @Test
    fun cityCacheIsPrivateToCoordinatesAndBacksOffOnProviderLimit() = runBlocking {
        var now = 100_000L
        var requests = 0
        val names = reverse(NetworkCitySource { _, _, _ ->
            if (++requests == 2) throw CitySourceRateLimited(120_000L)
            "上海"
        }) { now }
        assertNull(names.city(31.0, 121.0, Locale.CHINA, allowNetwork = false))
        assertEquals("上海", names.city(31.0, 121.0, Locale.CHINA, allowNetwork = true))
        assertNull(names.city(32.0, 122.0, Locale.CHINA, allowNetwork = true))
        now += 60_000L
        assertNull(names.city(32.0, 122.0, Locale.CHINA, allowNetwork = true))
        now += 60_000L
        assertNull(names.city(32.0, 122.0, Locale.CHINA, allowNetwork = true))
        assertEquals("上海", names.city(31.0, 121.0, Locale.CHINA, allowNetwork = false))
        assertEquals(2, requests)
    }

    private fun reverse(source: NetworkCitySource, now: () -> Long = System::currentTimeMillis) =
        CityReverseGeocoder(app.getSharedPreferences("test-city", Context.MODE_PRIVATE), source, now)

    private fun setupLiveFix(): Location {
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        val shadow = shadowOf(locationManager)
        shadow.setLocationEnabled(true)
        shadow.setProviderEnabled(LocationManager.NETWORK_PROVIDER, true)
        org.robolectric.shadows.ShadowSystemClock.advanceBy(Duration.ofSeconds(1))
        return fix(SystemClock.elapsedRealtimeNanos()).also {
            shadow.setLastKnownLocation(LocationManager.NETWORK_PROVIDER, it)
        }
    }

    @Test
    fun cityLabelPrefersLocalityAndNeverUsesCoordinatesAsName() {
        val address = Address(Locale.CHINA).apply { latitude = 31.0; longitude = 121.0 }
        assertNull(weatherCity(address))
        address.adminArea = " 省 "
        address.subAdminArea = " 市 "
        assertEquals("市", weatherCity(address))
        address.locality = "城区"
        assertEquals("城区", weatherCity(address))
    }

    @Test
    fun existingWeatherPrefsAndNewAutoLocationSurviveReload() {
        val prefs = app.getSharedPreferences("weather-test", Context.MODE_PRIVATE)
        prefs.edit().putString("weatherLabel", "旧城").putString("weatherLat", "31")
            .putString("weatherLon", "121").commit()
        val display = DisplayPreferences(prefs)
        val before = display.state.value
        assertEquals("旧城", before.weatherLocation?.label)
        assertFalse(before.weatherAuto)
        val next = before.copy(weatherLocation = WeatherLocation("新城", 32.0, 122.0),
            weatherAuto = true, weatherResolvedAt = 123_456L)
        display.save(next)
        assertEquals(next, DisplayPreferences(prefs).state.value)
    }

    private fun fix(elapsed: Long) = Location(LocationManager.NETWORK_PROVIDER).apply {
        latitude = 31.0
        longitude = 121.0
        elapsedRealtimeNanos = elapsed
        time = System.currentTimeMillis()
    }
}
