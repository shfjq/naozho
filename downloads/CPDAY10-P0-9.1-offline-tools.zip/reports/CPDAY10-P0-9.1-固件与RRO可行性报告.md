# CPDAY10 P0-9.1 固件与 RRO 可行性报告

**决策：HOME 优先走厂商支持的登记；电源双击优先走 Android 原生策略与独立 RRO 的离线资格验证。** 已审查的 CPDAY10 固件将 HOME 名单直接编入 DEX；电源双击行为和目标组件则确实来自两个独立的框架资源。HOME 用 RRO 不成立。电源用 RRO 已在 Android 16 参考资源上得到有效映射，本机能否同时映射两项、以及双击能否完整满足产品操作矩阵，仍待证实。

**本轮范围**　分析运行在独立开发环境。没有安装 0.6.10、执行设备命令或重启手机。应用源码、services.jar、naozho_boot、HOME、Owner、Lock Task 和 Keyguard 均未变更。

## 1　证据与缺件

| 证据 | 核对结果及用途 |
| --- | --- |
| 历史 CPDAY10 原厂文件 | P0-4 采集说明记录的系统指纹为 `CPDAY10 / Android 16（构建指纹已在原工作区核对）`，vendor 指纹为 `M41 / Android 16（vendor 指纹已在原工作区核对）`。其 /system/framework/services.jar 实测 SHA-256 为 `70fa04e1e51c4008078cdc7fd6c1cc041769e39bd3cce99712ce1d374d81f468`，与 DSH 同批设备端校验记录一致。本轮从 JAR 的三个 DEX 重新提取指定方法。 |
| P0-9 设计、DSH 手册、测试报告、采集器 | 审查包 SHA-256 为 `8ca4f845e994edeb804d10ff09d815bf44fdbcf1235d1d1960d2b315c29bbf15`，已读取并逐项复算包内清单。单独交付的架构文档与 ZIP 内文件相同。各文件摘要见证据包。 |
| 回滚 APK | 已离线验签。包名 com.naozho.clock，0.6.9-rollback-dev / 25，文件 SHA-256 为 `d5c3f60ae1549abed6f1d85184748875ed52b1e5d78637ea617082602d38c4ee`，证书 SHA-256 为 `801bc9dd5ea1144377f8e4520e1bb8bf6950e9e8d22733bba0465076df1c9578`。现场设备版本按用户提供的 0.6.9-dev / 24 评估。 |
| 本轮用户提供的实测摘要 | Android 16，Freeme 为 HOME，Device Owner 保留，LOCKED + 80，无系统凭据；电源双击行为资源为 0，目标字符串为空，multi_press_timeout 为 300ms，相机双击已关闭。引用这些读数时保留来源。 |
| 缺少的本机原件 | 本次附件区、工作区、共享下载目录、原 P0-9 审查 ZIP 和 GitHub 项目的可见分支/发行条目中，未取得 p09-before.json、supplement/ 的本机 framework-res.apk 与生效 RRO APK、电源键补采截图及说明。因此无法把新采集与旧 JAR 做同指纹复核，也无法判定本机每项资源的 overlayable 组、分区授权、覆盖顺序及当前全局行为覆盖值。 |
| 独立对照 | 从本地 SDK 的 API 36 x86_64 系统镜像静态提取 framework-res.apk 和 idmap2。参考指纹为 `Android/sdk_phone64_x86_64/emu64x:16/BE2A.250530.026.D1/13818094:userdebug/test-keys`，参考 framework-res.apk 的 SHA-256 为 `a6033fac5714f67ec165b7a71399aaf45c06108884f37228e00184bbc429627c`。未运行模拟器，未使用 CPDAY10 配置替代参考输入。 |

补件只需上传**已经采集**的原件，可打成一个 ZIP。若已有采集清单、overlay list/dump 或 overlay 配置文件，请随附。收到后由 Codex 对照同一 user 0、boot_count、整机指纹和 JAR 摘要，再按具体 APK 检查两项资源。本阶段无需 DSH 编写程序或变更手机。

## 2　独立方案一：HOME 接管

### 2.1 系统选择与偏好顺序

1. 默认显示器正常启动时，RootWindowContainer.startHomeOnTaskDisplayArea → ActivityTaskManagerService.getHomeIntent → RootWindowContainer.resolveHomeActivity。普通隐式 HOME 走 ActivityTaskSupervisor.resolveIntent 和包管理解析；系统已给定显式组件时是另一分支。最终由 ActivityStartController.startHomeActivity 启动选中的组件。
2. 在本次隐式查询路径，ResolveIntentHelper.resolveIntentInternal → ComputerEngine.queryIntentActivitiesInternal，收集符合用户、组件、解锁状态、Intent 的初始结果。本机 DEX 的 queryIntentActivitiesInternal 在该路径的 0x01ea 调用 applyPostResolutionFilter。查询用 Flags 与 Intent.getFlags 分开；单包查询、显式 am start 或应用可见性声明，都不能证明全局 HOME 合格。
3. ResolveIntentHelper.chooseBestActivity 对**已过滤列表**选择。如果仅有一个候选，可直接返回；前两名 priority、preferredOrder 或 isDefault 不同时，也可直接选第一名。需比较偏好时，PreferredActivityHelper.findPreferredActivityNotLocked → ComputerEngine.findPreferredActivityInternal → findPreferredActivityBody。后者先查 findPersistentPreferredActivity，在传入列表内匹配组件，再考虑普通首选。写入持久偏好与开机实际解析分属两个时刻。
4. 默认 HOME 角色保存包级归属。DefaultAppProvider.getDefaultHome 对接 ROLE_HOME。更新偏好与角色时，PreferredActivityHelper.updateDefaultHomeNotLocked 会检查系统就绪，再重新查询该用户的 HOME 候选和可解析偏好，必要时同步默认桌面。ROLE_HOME 持有者、Device Owner 的 persistentPreferredActivity、当前 HOME 解析与前台焦点分别取证。记录了时钟策略或收到 SET 回调都不能为已过滤组件补一个候选。[Android 16 解析器](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/services/core/java/com/android/server/pm/ResolveIntentHelper.java) · [偏好与角色同步](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/services/core/java/com/android/server/pm/PreferredActivityHelper.java)

### 2.2 完整方法与数据来源

**实际位置**为 services.jar → classes2.dex → com.android.server.pm.ComputerEngine.applyPostResolutionFilter(List, String, boolean, int, boolean, int, Intent)。classes2.dex 的 SHA-256 为 `113041258d67a89a7229e268f305b07cd02b25d7f4c8e3a424cf5015eddd082a`。证据包附该方法从 0x0000 到 0x0246 的完整反汇编。以下按执行顺序说明各段。

| 方法内偏移 | 实际行为 |
| --- | --- |
| 0x0000–0x0032 | 确认网页 Intent 与 instant app 开关，倒序处理候选，移除被禁用的 instant 网页结果。 |
| 0x0033–0x00bd | 对尚未安装的动态 split 做处理。无合适安装器、或被相应 instant 限制时移除；符合条件时用安装器 ResolveInfo 替换，并带回目标包、版本和 split 等信息。 |
| 0x00be–0x0127 | 普通调用者按启动查询/可见性过滤；instant 调用者可保留本包、符合条件的外部网页或标记可见的组件。处理完成后才进入厂商的桌面筛选。 |
| 0x0129–0x0197 | 读取布尔属性 persist.paios.launcher.debug，取 Intent 的 action、categories、package。在 **0x013d 的 const-string** 直接装入 `com.android.settings,com.freeme.setupwizard,com.droiclaw.launcher3,com.freeme.superpowersaver`。布尔属性控制诊断日志。名单没有来自资源、XML、Provider 或属性的加载调用。 |
| 0x0198–0x01ee | 检查 Intent 未限定包名、有 categories 和 action、categories 含 HOME、action 包含 MAIN、名单非空。满足条件时进入厂商循环。指定包名的查询跳过该循环。 |
| 0x01ef–0x0246 | 倒序读取剩余 ResolveInfo 的组件包名；0x0205 在上面的内置字符串执行 contains，未命中走 0x0240 的 List.remove，最终返回处理后的列表。这段只有包名匹配及日志，未检查 FLAG_SYSTEM、FLAG_UPDATED_SYSTEM_APP、priv-app、平台签名或桌面应用优先级。 |

FreemeLauncher 与 FallbackHome 分别属于名单里的 DroiClaw 和 Android Settings。时钟与之前的对照包均不在其中。**把同包名同签名时钟移入 priv-app，仍会在这段逻辑被删除。** 一般系统应用权限、签名或 package visibility 可能影响更早的检查，但无法让原包名通过这里的最后一轮。调试属性也不是名单开关。

### 2.3 路线与恢复

| 路线 | 对当前目标的判断 |
| --- | --- |
| A　厂商登记 | 优先向厂商确认这一**具体构建**是否有受支持的专机 HOME 登记/早期 HOME 选择，或含此能力的同型号签名更新。已读方法未暴露可写名单接口。普通 ROLE_HOME 请求或重复写 DPM 不足以解决原委。 |
| B　HOME RRO | 在已核对的 JAR 上不可行。目标是 DEX 常量，没有可供 idmap 映射的 HOME 名单资源。 |
| C　KernelSU 可撤销配置 | 模块可承载厂商已经支持的配置；当前未发现这个读取点。挂载 APK、追加特权权限名单或 boot-completed 后再次拉起时钟，都不能满足“系统第一次即选时钟”。保留现有模块作备用。 |
| D　厂商框架改造 | 若 A 无入口，建议由固件提供方改 ComputerEngine.applyPostResolutionFilter 的厂商尾段，让已获授权、可按用户撤销的专机 HOME 与原四包共同进入正常解析；前面的包可见性、用户与 Direct Boot 筛选保留。在普通双向 HOME 切换仍不能保证冷启动时，才需要另行设计 RootWindowContainer.startHomeOnTaskDisplayArea / resolveHomeActivity 所用的早期专机选择。先验证实际解析，不能直接硬编码 startActivity。 |

即使成为候选，**运行期退出时持久 HOME 已切回 Freeme**，重启时它仍可能先被系统选中。要让开机首屏必为时钟，早期选择必须在默认显示器第一次决定 HOME 前就知道部署/维护暂停意图。开机录像应分别从 CLOCK、当次开机主动退出后的 ANDROID 和维护暂停开始。静态放行、有效 HOME、窗口可见和触摸通过是四项独立验收。

## 3　独立方案二：原生双击电源键

### 3.1 真实固件调用链

FreemePhoneWindowManager.interceptKeyBeforeQueueing 调用父类。普通按键路径进入 PhoneWindowManager.interceptKeyBeforeQueueing → handleKeyGesture。组合键可先消费；电源键按下还会经 handleCameraGesture → GestureLauncherService.interceptPowerKeyDown，此处同时有相机、钱包和紧急操作处理。若这个分支处理了手势，SingleKeyGestureDetector 会重置。其余事件由 SingleKeyGestureDetector 识别，PowerKeyRule.onMultiPress → PhoneWindowManager.powerPress。在 count 为 2 时，固件 0x0058 读 mDoublePressOnPowerBehavior，0x005a 调用 powerMultiPressAction。另有 interceptPowerKeyDown/Up 负责正常唤醒、释放等。单次短按还会经过 Freeme 的 handlePowerShortPressBeforeDefaultAction。[Android 16 按键策略](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/services/core/java/com/android/server/policy/PhoneWindowManager.java) · [单键识别器](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/services/core/java/com/android/server/policy/SingleKeyGestureDetector.java)

| 值 | MULTI_PRESS_POWER 行为 | 在此分支的结果 |
| ---: | --- | --- |
| 0 | NOTHING | 无多击附加动作，其他原厂按键路径仍存在。 |
| 1 | THEATER_MODE | 在满足设置向导等条件时切换影院模式，并按原配置处理显示。 |
| 2 | BRIGHTNESS_BOOST | 临时增强亮度，条件满足时可唤醒。 |
| 3 | LAUNCH_TARGET_ACTIVITY | 调用 launchTargetActivityOnMultiPressPower，按指定组件解析并启动。 |
 
该 CPDAY10 方法只识别上述四种语义，未知整数不执行新的目标动作。相机、钱包、SOS 与长按菜单有独立处理路径。

**行为值。** PhoneWindowManager.updateSettings 在 0x00b5–0x00c9 先读 integer 资源 ID `0x010e0085` 作默认值，再用 Settings.Global.getInt 读取 power_button_double_press 并缓存到 mDoublePressOnPowerBehavior。如果 Global 明确为 0，即使资源已覆盖为 3，运行值仍可为 0。null 和 0 必须分开记录。

**目标值。** PhoneWindowManager.init 的 0x02bc–0x02c7 从 `0x0104026b` 读字符串，经 ComponentName.unflattenFromString 缓存为 mPowerDoublePressTargetActivity。空串没有可启动目标；合法简写 `com.naozho.clock/.MainActivity` 会指向现有导出组件。行为 3 创建无 action 的显式 Intent，resolveActivity 检查后加 NEW_TASK 与 RESET_TASK_IF_NEEDED；正常路径以当前用户启动，Keyguard 正显示时走系统 dismissKeyguardToLaunch 分支。目标应用无需接收 KEYCODE_POWER、注入输入或持有平台签名。Owner 与已生效的允许名单仍是应用进入真正 LOCKED 的条件。更新资源后的 lookup 结果与 system_server 初始化时缓存的目标可能不同，必须分别取证。

**为什么不能直接以 MainActivity 作最终产品入口。** 现场 0.6.9 会把“无 action 且显式指向 MainActivity”的 Intent 当作现有闹钟详情入口，调用 enterClock。维护暂停能阻止后台恢复和重新锁定，但这个显式启动仍可能把时钟带到前台。目标 Activity 也拿不到第一次按下前的亮屏状态。单一静态 RRO 不按 CLOCK/ANDROID/暂停动态选择目标。功能验证可用此组件证明系统能否启动目标；正式设计应让系统在分发前检查状态，或由厂商提供等价的条件化快捷方式。独立入口可减少错误切换，却无法撤回原厂已经消费的电源键行为。

**手势冲突。** 300ms 描述的是候选窗口，不代表系统确认了两次完整短按。SingleKeyGestureDetector 处理按下、释放、长按及重复。达到其最大计数时可能在第二次按下即派发；config_shortPressEarlyOnPower 和 PowerKeyRule.onKeyUp 会影响第一次释放是否已熄屏。powerPress 内判断的当前 awake 与序列起始亮屏不同，行为 3 本身没有以初始亮屏作门控。相机关掉也不等于钱包或 SOS 关掉；紧急计数与普通多击可并行。两击路径不能依赖屏蔽长按、改变全局超时或降低紧急优先级来取得独占。保留原厂单击息屏/唤醒、长按菜单及来电/紧急情形。涉及真实报警的验证仅在厂商非呼叫测试环境做。

**原生 RRO 未满足全部条件时的顺序。** 先向厂商核实有无按用户设置、尊重维护暂停且可恢复原行为的电源快捷入口。若没有，再评估由固件方在现有 WindowManagerPolicy 扩展接入：沿用系统检测器与 GestureLauncherService 对紧急手势的仲裁，使用第一次按下前的 interactive 状态，仅在 ANDROID 模式接受一次返回请求；其它状态交回原厂策略。需要改动 system_server 时，沿用下文的备用机、签名固件、回滚和 OTA 验收条件。KernelSU 适合承载已获准的独立 overlay，单靠开机脚本没有可用的按键仲裁接口。本轮没有输入驱动、全局输入监听或框架补丁交付。

## 4　RRO 可覆盖资源、离线试验与 KernelSU

| 项目 | 是否存在可映射资源 | CPDAY10 结论 |
| --- | --- | --- |
| 全局 HOME 包名过滤名单 | 否，CPDAY10 classes2.dex 常量 | RRO 无法覆盖。 |
| android:integer/config_doublePressOnPowerBehavior | 有，固件从框架资源读行为默认值 | 用户报告当前为 0。本机能否被候选 RRO 覆盖待查资源表、policy 和实际覆盖顺序；还受 Global 覆盖。 |
| android:string/config_doublePressOnPowerTargetActivity | 有，固件从框架资源读组件名 | 用户报告当前为空。本机 idmap 是否包含这一独立资源、系统初始化是否读取新值，均待验证。 |
| multi_press_timeout | 该识别路径取 Settings.Secure / ViewConfiguration 的值，有平台默认值 | 当前报告为 300ms。它不是上述 RRO 的第三个目标。相机、SOS、长按、单击的配置也不列入原型。 |

**离线真工具结果。** 使用 SDK API 36 android.jar 及 AAPT2 编译无代码、未签名的两项 RRO 原型，在主机调用参考镜像自带的 Android 16 idmap2，保持 overlayable 校验。参数中的 product 表示模型假设满足的策略；真实设备由 OMS 根据扫描与签名状态计算，不能用离线参数证明设备授权。

| 用例 | 实际结果 |
| --- | --- |
| 参考框架，无目标项覆盖 | 两项读回 0、空串。 |
| 普通 public 策略 | 创建失败，报告 no resources were overlaid。 |
| 模拟满足 product 策略 | 两项均进入 idmap；分别回读 3 与 com.naozho.clock/.MainActivity。参考资源 ID 为 0x010e0084、0x01040269，与 CPDAY10 JAR 所用 ID 不同。 |
| 两份对照 overlay 交换装载顺序 | 同一配置下，后者生效。交换后，结果在“两项指定值”和“2、测试组件”间切换。这里直接指定查找顺序，尚未模拟厂商 OMS 的排序。 |
| 从离线查找序列移除原型 | 两项回到 0、空串。只是资源恢复，不涉及设备重启和 system_server 缓存。 |
| 合成目标只允许覆盖整数、没有授权目标字符串 | idmap 创建成功，但 dump 只有整数。此反例说明必须逐项检查映射，不能用“overlay 已启用”验收这两个配置。 |

**本机逐项判定办法。** 核对 framework-res.apk、活动 overlay 的哈希与同次快照，用资源表把两个 OEM ID 对回名称；检查 targetPackage、targetName、resourcesMap 或同名映射、资源限定符及签名。若目标包定义了 overlayable，所需资源必须属于相应组且 fulfilled policies 与其允许策略相交；若整个目标包没有声明 overlayable，Android 16 的默认规则允许某些预装分区或特定签名策略，不能据此推定任意 /data APK 可覆盖。读出实际 idmap 的两条记录，最后比较各自的生效值与运行中电源策略。[idmap2 逐项判定](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/cmds/idmap2/libidmap2/ResourceMapping.cpp) · [OMS 计算策略](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/services/core/java/com/android/server/om/IdmapManager.java)

**覆盖顺序与稳定性。** 检查所在分区的 overlay/config/config.xml（含 merge）、是否 mutable、启用用户和覆写同项的其它包。在配置文件内后列的具有较高优先级；Android 16 参考代码的默认跨分区顺序由低到高为 system、vendor、odm、oem、product、system_ext，本机还要核对厂商是否定义 /product/overlay/partition_order.xml。Manifest priority 不能单独证明胜出。不同资源限定符也会影响运行配置下的选择。确认静态文件后还须经批准验证实际 OMS 顺序、两项 lookup、初始化后的行为以及多次开机稳定性。[Android OverlayConfig](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/core/java/com/android/internal/content/om/OverlayConfig.java) · [Android RRO 文档](https://source.android.com/docs/core/runtime/rros)

**KernelSU 承载方式。** 若上述两项均有受支持的策略，可评审独立资源模块，保留现有 naozho_boot。v3.3.1 的 systemless 文件挂载需要提供挂载能力的 metamodule；旧模块含 skip_mount，现有工作机制仅需开机脚本。新资源必须在 PackageManager/OMS 扫描和 WindowManager 策略初始化前可见，被识别为设计所需分区；在 boot-completed 阶段才复制资源太晚。部署权限由模块安装与 Android overlay 策略分别决定。正常时钟 Activity 无需新增系统权限。系统现有的 Root、普通管理员或 Device Owner 都不会自动授予 RRO 签名或分区资格。若某资源只允许厂商签名/actor，走厂商签发渠道。[KernelSU v3.3.1 模块生命周期](https://github.com/tiann/KernelSU/blob/v3.3.1/website/docs/guide/module.md)

## 5　统一双模式架构

一个按用户的状态写入者协调 HOME 与电源请求。部署意图要持久化，当前窗口、Owner、实际 HOME 和 LOCKED 必须向系统读回。现有 0.6.9 的 desktop_mode 位于 CE；0.6.10 审查包里派生出的阶段也没有把设备数据迁到 DE。正式的首屏方案需要在系统选首个 HOME 前读到最小部署记录，优先用厂商专机管理接口提供给系统；App 私有 DE 不会自动成为 system_server 可读取的受支持配置。

| 状态或转换 | HOME、输入与确认 |
| --- | --- |
| BOOT_PENDING | 已武装、未暂停的新 boot 进入该阶段。按 user、boot 与模式代次最多受理一次恢复意图。系统自然启动 HOME 时不另起 Activity；未首次解锁且 CE 不可用时，只使用 DE 可读数据与真正可操作的启动界面。候选尚未就绪或路由失败时不能标记 CLOCK。 |
| CLOCK | 系统实际 HOME 为时钟，MainActivity 已 resumed、有焦点，Owner、LOCKED、flags=80、名单仅时钟全部读回。触摸由现场验收。只有独立锁定而 HOME 仍为 Freeme，应记录部分成功。 |
| CLOCK → ANDROID | 确认退出后停止锁定，读回 NONE，恢复 Freeme、前台稳定。持久化当次 boot 的退出意图并使过期请求失效。已武装时下次正常开机仍应在选 HOME 前进入 BOOT_PENDING。 |
| ANDROID → CLOCK | 由系统先仲裁亮屏开始的双击，再校验 user、代次和部署状态；一次请求走既有时钟入口。显式打开图标仍是用户主动入口。锁定失败保持可维护状态，不重试抢前台。 |
| MAINTENANCE_PAUSED | 主动暂停时先提交高优先级暂停意图、作废旧代次，完成止锁与 Freeme 恢复并核对。模块、按键与重启均尊重暂停。用户明确恢复才重新武装。 |

最小 DE 内容可包括 schema、用户、是否启用/维护暂停、模式代次、退出与恢复请求所属 boot、未完成转换。策略操作与落盘并非同一事务，重启时需按暂停优先原则，结合系统读回继续或回退。缺失/损坏或跨版本迁移未完成时保留正常安卓恢复入口。凭据、个人设置继续保存在 CE/Keystore。无系统凭据且 CE 自动解锁、Keyguard 不可见、时钟是首个可触摸界面仍是不同验收项。

## 6　建议实验、停止条件及回滚（待单独批准）

1. **现在只补原件。** 上传已有 p09-before.json、supplement/、截图/说明。Codex 离线裁决电源两项的 overlayable 组、授权、顺序和实际 Global 对照。若全局设置已明确覆盖资源、只有一项获准、或资源包和 JAR 不属同一构建，先停止这一路实验。
2. **电源实验宜先于 HOME 实施。** 若离线资格与故障恢复路径均成立，另提针对同构建测试机的独立资源模块。先记录原 Global 值（区分 null 与 0）、OMS 列表、原厂手势、模块与系统策略；确保在时钟和图形界面都不可用时仍能独立停用该模块。变更后先读实际两条映射与运行值，再在 Android 模式的 Freeme、设置、普通应用测试双击。同时验证首击熄屏、原先息屏时按键及长按、暂停后不出现时钟界面、无相机钱包竞争。出现额外唤醒、黑屏闪现、重复启动或紧急功能干扰则停止。相机已关闭不构成豁免。
3. **HOME 实验独立进行。** 厂商登记能力可用后，在可恢复的 NONE 条件下验证全局候选、有效 HOME、回到 Freeme，再测试完整锁定。外部摄像连续记录三次正常重启、一次完整冷启动，包括从 ANDROID 退出状态重启；任何一次出现可见 Freeme、滑动锁屏、不可交互占位页，或需要手动唤醒才能看到首屏，均单列失败。备用广播、Job 与模块不计为系统自然选择 HOME 的证明。
4. **回滚。** 只读阶段无需设备回滚。将来的 RRO 实验优先停用/移除单独实验模块，恢复原有其它 overlay 顺序和启用状态；若另行批准过 Settings 变更，再恢复逐项原值。经批准的维护重启后核对两条 lookup、运行中电源策略、单击/长按、原始双击选择与 Freeme。保留现有 KSU 备用模块和 Owner。HOME 变更先走正常维护退出，撤销时钟的受管偏好、恢复 Freeme、保留用户原有其它策略。若 UI 不可用，须按**事先在该机型演练**的独立救援路径恢复；没有演练通过之前，不上主机。
5. **OTA 与框架风险。** 资源 ID、overlayable、厂商名单、读取时机、模块挂载点和键策略都可能改变。升级前撤下依赖构建的实验模块并记录基线，升级后重新核对整机指纹、JAR 和资源摘要。若只能采用路线 D，要求厂商提供原签名、同版本可恢复的整套系统交付、独立救援通道和已实际恢复过的备用机。system_server 加载失败可能影响整机开机或全局输入，禁用时钟 APK 不能撤销该层修改。

## 7　交付文件与验证边界

- 本报告与离线证据 ZIP 是本轮新增的交付文件。ZIP 包含完整 HOME 方法反汇编、指定电源方法反汇编、制品哈希清单、仅供主机编译的 RRO XML/Manifest 与可重复运行的参考实验、idmap 结果 JSON。
- 报告检验的是提供的固件方法、已交付 APK 的身份，以及参考资源表的映射语义。当前 CPDAY10 的完整 RRO 资格、动态优先级、开机首帧、实体键冲突、OTA 与模块禁用后的设备恢复，仍需对应原件或经批准的实机实验。
