# CPDAY10 P0-9.1　拆包复核与实施方案

**HOME 可以结束应用侧排查。电源双击可以进入同固件资源验证，尚未达到部署条件。** 本次快照已经与此前分析的原厂 DEX 对上。最低风险的组合是保留 Freeme 和已通过验收的独立锁定，向厂商核实第一屏的登记能力，另行验证原生双击能否安全指向一个受维护状态控制的入口。两项分别验收。开机模块后来拉起了时钟，仍须记录开机时第一屏实际显示了什么。

## 本次补包解决了什么

| 项目 | 独立复核结果 |
| --- | --- |
| 资料身份 | 三个 ZIP 均通过 CRC 检查。分别复算 BASIC 清单的 14 项、RRO 清单的 4 项和 RESOURCE-ANALYSIS 清单的 19 项，文件大小和 SHA-256 全部一致。拆包说明记录的原始大 ZIP 未提供，本轮核验针对收到的三个包。 |
| 设备与固件 | 快照开始、结束均为同一次启动、user 0，状态 RUNNING_UNLOCKED。系统指纹为 `CPDAY10 / Android 16（构建指纹已在原工作区核对）`。设备读到的 services.jar SHA-256 和云端原件复算值均为 `70fa04e1e51c4008078cdc7fd6c1cc041769e39bd3cce99712ce1d374d81f468`。 |
| 设备基线 | 应用 0.6.9-dev / 24，Device Owner 保留，SELinux Enforcing。补采前后均有 LOCKED、flags=80 和时钟焦点记录。截图 02 虽名为 Freeme，画面有锁屏快捷按钮，退出后同段焦点记录为 NotificationShade。它可用于核对退出过程，不能单独证明 Freeme 是那个瞬间的可交互窗口。以 HOME 解析读数证明默认桌面。 |
| 系统资源 | 设备侧记录 framework-res.apk 为 20,865,405 字节，SHA-256 为 `48a3f6912392d1d5fb066be715c3e0f888d9016011cdc9cf50b2609a2c040d02`。云端已读其完整资源文本，收到并直接解析了四个原厂 RRO APK。本机目标二进制资源表仍在 DSH 电脑上。 |
| 设置入口 | 已查看两张 720×720 设置截图。「快速打开相机」和「按住电源按钮」页都未显示目标 Activity 选择器，DSH 的页面遍历也未找到亮屏条件开关。 |

## 方案一　第一屏与 HOME

同一 boot 中，系统全局 HOME 候选只有 FreemeLauncher 与 Settings/FallbackHome，限定 com.naozho.clock 后能找到 MainActivity；HOME role 和实际解析均指向 Freeme。已核对同哈希 classes2.dex 中的执行顺序：

1. 默认显示器首次启动 HOME，经 RootWindowContainer.startHomeOnTaskDisplayArea、resolveHomeActivity 及隐式 Intent 解析，进入 ComputerEngine.queryIntentActivitiesInternal、applyPostResolutionFilter。
2. 后者在方法内偏移 0x013d 直接装入四个包组成的字符串：com.android.settings、com.freeme.setupwizard、com.droiclaw.launcher3、com.freeme.superpowersaver。在未限定包、含 HOME 的 MAIN 查询中，0x0205 检查候选组件包名，未匹配者到 0x0240 从结果中移除。本段不读取资源、注册表、Provider、平台签名或 priv-app 标志。persist.paios.launcher.debug 只控制日志。
3. chooseBestActivity 在这个结果集上选择，需要比较偏好时才核对 persistentPreferredActivity 等。标准 ROLE_HOME、Owner 持久偏好和全局有效 HOME 各有独立状态。即使策略 SET 成功，也无法把时钟加回已经删去的候选。
4. 完整资源表中的 config_secondaryHomePackage 为 com.android.launcher3，针对次级 HOME。此前 DEX 命中的 DroiClaw AI_KEY 和侧栏 Provider 分属其它代码路径。它们都没有写入上述名单的调用证据。

**最低风险决策。** 当前构建的普通主屏解析路径没有可用的厂商配置/登记入口证据。HOME RRO、挪入 priv-app、重复申请角色或调整 Manifest，均无理由再试。现有材料不能排除厂商另有企业接口、独立的开机首屏路由或签名更新。给厂商的问题可精确限定为：该构建有无按 user 登记第三方主屏的正式接口；它是否在首次选择主屏前生效；能否保留 Freeme 并在维护暂停时恢复。需要接口文档或同构建可复核的结果，才能转入实施。厂商若只支持启动一个应用，分别验收「启动时钟」「第一屏」「实际 HOME」三项。

若厂商没有现成入口且必须实现真正 HOME，再单独评审厂商签名的最小固件变更：保留原包和其它用户筛选，仅让已授权专机包参与主屏解析，并在首次解析前读取按用户持久化的专机/暂停意图。原厂签名交付、同版本完整恢复包和独立救援通道是该路线的前提。本轮没有制作框架补丁。

**验收与回滚。** 将来批准后先在 NONE 下验证时钟进入全局候选，双向切换两次并核对实际 HOME；再验 LOCKED + 80、焦点和真实触摸。分别从 CLOCK、当次启动已退出的 ANDROID、持续维护暂停冷启动或重启，外部录像从系统动画结束连续记录到首次能操作的应用，记录 Freeme/锁屏闪现、首次解锁和首次触摸时刻。任一条件失败，保留可恢复的 Freeme 配置，撤销本项目的登记，确认 NONE、有效 HOME 及 Freeme 可操作，再按需使用原有独立锁定。设备已有 Owner 和其它应用偏好应保留。

## 方案二　使用原生电源双击

| 关键量 | 同固件证据 | 实施含义 |
| --- | --- | --- |
| 双击行为 | integer/config_doublePressOnPowerBehavior 为 0x010e0085，基值与有效值均为 0。Global.power_button_double_press 明确返回 null，运行中的 mDoublePressOnPowerBehavior 为 NOTHING。 | PhoneWindowManager.updateSettings 此时采用资源默认值。当前没有显式 Global 值遮住 RRO，无需写 Global。 |
| 目标组件 | string/config_doublePressOnPowerTargetActivity 为 0x0104026b，基值为空；DSH 复查有效查询退出码为 0，返回空行。 | PhoneWindowManager.init 解析扁平组件名并缓存。值 3 时走 LAUNCH_TARGET_ACTIVITY，固件用显式、无 action 的 Intent 执行 resolveActivity(intent, 0)，解析成功才走启动或系统 Keyguard 分支。0、1、2 分别对应无附加动作、影院模式、亮度增强。 |
| 单击与时间 | 当前短按为 GO_TO_SLEEP，shortPressEarlyOnPower=false，Secure.multi_press_timeout=300ms。 | 保持系统对单击、唤醒和组合键的归属。增加一个多击行为可能改变短按确认的时机；验收要比较真实单击的延迟和屏幕状态。 |
| 长按 | longPress=100，veryLongPress=GLOBAL_ACTIONS。实际 DEX 中 getResolvedLongPressOnPowerBehavior 按厂商 AI 配置等解析 100；powerLongPress 含 AI 助手和电源菜单的条件分支。 | 保留原厂长按、超长按及现有电源菜单入口。设置页标题不能证明每次普通长按都直接打开电源菜单。 |
| 相机与 SOS | 相机双击资源 false，doubleTapPowerGestureMode=0。紧急手势资源 true，user 0 的 emergency_gesture_enabled=null；基础资源 config_defaultEmergencyGestureEnabled=true。 | null 表示按默认处理。不要打开、关闭或改派相机、钱包、SOS；如用户已启用相机等同键快捷方式，让既有原厂行为优先。 |

**两项资源能够表达“启动指定 Activity”。当前状态机还需要单独的快捷入口。** 0.6.9 的 MainActivity.handleEntry 把显式、无 action 的启动当成 alarmDetails，然后调用 enterClock。直接把它填入生产配置会给维护暂停引入另一条前台入口。系统按键代码也没有把首击时亮屏与否、或后续是否还有紧急连击传给目标 Activity。

**可审查的应用设计。** 将来如获批，另设仅处理“从已武装的 ANDROID 返回时钟”的 Activity，建议名 PowerReturnActivity；它目前不存在。原图标、MainActivity、管理恢复与开机入口各自保留。新组件默认禁用，可采用无界面、无历史记录的短生命周期入口；不接受外部指定目标或任意管理命令。由系统启动的显式入口需要对该系统调用者可解析，可在设计验证时用系统调用者确实持有的受保护权限限制其它应用。切勿把普通显式调用当作实体按键的证明。

| 模式或转换 | 对双击的处理 |
| --- | --- |
| ANDROID、专机已武装、当前 user 正确 | 正常开发退出先完成 NONE 和 Freeme 交接，再启用专用组件。双击入口读回部署意图、用户和状态代次，只提交一次返回请求。MainActivity 在前台有焦点后，复用已验收的独立锁定，再核对 LOCKED、flags=80、名单和触摸。普通退出本身不触发返回。 |
| CLOCK 或 BOOT_PENDING | 快捷组件保持关闭，已有时钟或进行中的恢复不另开任务。首次开机首屏由 HOME 方案单独处理。 |
| 进入 MAINTENANCE_PAUSED | 首先持久化暂停并推进状态代次，再禁用本应用的快捷组件，放弃所有旧请求，之后完成退出和 Freeme 交接。核对目标在 user 0 已不可解析、前台无时钟且为 NONE，再显示暂停完成。组件禁用不改 HOME、桌面图标或管理接收器。 |
| 暂停与快捷键并发、应用崩溃或系统升级 | 入口与时钟实际切换前均在同一协调器内重新检查暂停和代次；记录损坏、不可读或用户不匹配时直接终止。DE 只存部署开关、暂停、代次及必要的开机标记；敏感内容不迁入 DE。后续发现磁盘状态与组件启用状态不一致时以暂停优先，恢复部署必须是显式操作。 |

**可保证的范围。** 持久暂停加自有组件禁用，能够为普通暂停场景建立“系统解析不到快捷入口”的条件。单靠静态 RRO 和 Activity 仍不能保证首击起于亮屏、阻止已排队启动在并发时产生短暂切换，或恢复系统已经消费的按键序列。产品若要求暂停时电源键时间行为也完全等同原厂，或严格要求息屏起始绝不触发，首选厂商提供的条件化按键入口，在策略分发前按初始 interactive、用户和暂停状态仲裁。没有这种入口时，RRO 只进入受控实验。

**紧急手势是部署门槛。** 系统先经过组合键及 GestureLauncherService，再由 SingleKeyGestureDetector、PowerKeyRule、powerPress 处理普通多击。该固件在非手表分支中先看三击与双击行为：三击为 0、双击配置为 3 时，getMaxMultiPressPowerCount 可返回 2，先于其末尾的紧急手势判断。检测器达到最大计数时可以在第二次按下就派发，而独立的 SOS 检测还可能在等待后续按键。若此时新 Activity 立即进入 Lock Task，就可能和紧急界面的启动竞争。“保留 SOS 开关”不足以证明安全。未经厂商无呼叫环境或受控策略测试验证，不批准双击后立即锁定。不要靠在应用内延迟 300ms 来推断 SOS 已结束；该入口看不到整段按键序列。实装验收须保留单击息屏/唤醒、原厂长按与超长按、相机启用时的优先权、来电和紧急 UI；不以拨打真实紧急电话作测试。

## 原厂 RRO 与空 overlayable 输出的判定

直接用 AAPT2 读取四个原始 overlay。四者都 target android、targetSdk 36、isStatic=true，无 targetName 和 resourcesMap。对原包资源名逐项检查，结果如下。

| overlay 包名 | Manifest priority | 资源数 | 两项双击资源 |
| --- | ---: | ---: | --- |
| com.mediatek.frameworkresoverlay | 1 | 19 | 均未定义。该包已有短按行为和电源菜单数组。 |
| com.mediatek.FrameworkResOverlayExt | 2 | 4 | 均未定义 |
| android.auto_generated_rro_product__ | 1 | 43 | 均未定义 |
| freeme.overlay.framework.vendor | 10 | 6 | 均未定义 |

user 0 另启用了 gestural 导航 overlay 和 SystemUI neutral/accent/dynamic 三项。当前运行值已测到，但同值不能证明哪一个 overlay 赢得资源选择。跨分区顺序、OverlayConfig、用户与资源限定条件不能只看 Manifest 的 priority；isStatic 本身也不足以确定 Android 16 下最终的可变性。

从本机 classes2.dex 新提取 **IdmapManager.enforceOverlayable**：0x0000–0x0009 对 targetSdk ≥ 29 返回 true。**createIdmap** 在 0x0011、0x0015 获取实际 fulfilled policies 与 enforce 标志，传给 IdmapDaemon.verifyIdmap/createIdmap。**calculateFulfilledPolicies** 在 0x003d–0x0045 对实际被识别为 product 的包加入 0x08。四个原厂 overlay 具备现成映射的证据支持继续验证预装配置路线，但它们的安装身份和局部映射不能转授给新包。它们自己的 ARSC 中零个 overlayable 组，仅描述它们作为 *target* 时的声明。

本机 framework 目标的 AAPT2 空输出未被用作判据。下列决策使用二进制资源表和逐项 idmap 校验：

| 本机目标表的结果 | 后续决策 |
| --- | --- |
| android 包没有 0x0204 overlayable group | 按 Android 16 标准 idmap2 的无组规则验证可信预装分区或合格签名。普通 public 权限不足。以两项映射和两个 lookup 都正确为离线门槛。 |
| 有组，两项均在获准的组内 | 使用真实 targetName，检查两项允许的 policy 与候选实际身份。两项若属不同组，一个 overlay 不能以同一 targetName 覆盖两组；评估两个独立映射的可回滚性与同时生效条件。 |
| 存在组但任一项未列入，或仅允许无法获得的签名或 actor | 停止该 RRO 方案，转厂商授权配置。不得通过忽略 overlayable 检查让实验“通过”。 |
| 两项映射均存在且可读 | 只证明资源层可行。进入按键实验前仍需核对 OEM 的实际 OMS 优先级与缓存时机，以及维护暂停、原厂手势仲裁和独立回滚能力。 |

参考依据为 Android 16 的 [资源表格式](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/libs/androidfw/include/androidfw/ResourceTypes.h)、[组和 policy 的读取](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/libs/androidfw/LoadedArsc.cpp)、[idmap2 的逐资源判定](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/cmds/idmap2/libidmap2/ResourceMapping.cpp)及 [Android 的 RRO 配置说明](https://source.android.com/docs/core/runtime/rros)。

## DSH 只需执行的一项本地操作

将随附的 cpday10_power_resource_slice.py 放在任意可写目录。在该目录打开 Windows PowerShell，把下方路径换成电脑上已有的文件。需要 Python 3.8 或更新版本，仅使用标准库，可断开手机执行。

```powershell
py -3 .\cpday10_power_resource_slice.py "D:\P09\supplement\framework-res.apk"
```

回传生成的 **CPDAY10-framework-policy-evidence.zip** 即可。工具首先校验本机固件对应的完整 APK 哈希，然后从该 APK 提取原始 resources.arsc、二进制 AndroidManifest.xml 和一份 policy.json。JSON 记录组、actor、策略位及目标资源 ID 的成员关系。只保留这两个原始成员是为了让 Codex 重放参考 idmap2 的 create、dump、lookup，并保持组和资源 ID 完整。现有结果文件不会被覆盖。遇到摘要不符，保留错误信息供复核即可。

已在开发主机用 API 36 参考 framework 验证两个原始成员可复现两项映射的 lookup；public-only 被拒，模拟 product 时取得指定的 3 和组件名。另以真实 AAPT2 编译只授权整数的对照包，正确识别组、actor、product|signature 及未列入的字符串。工具通过错误哈希、畸形 chunk 和已有输出文件检查。上述试验未使用 CPDAY10 的未上传原件；收到切片后将按本机数据复核，无需 DSH 再跑 idmap2。

## 后续批准与回滚

1. **电源实验的最小变更**是两个资源（行为和专用入口），外加应用自身的入口与暂停检查。在有厂商支持时优先使用正式配置载体。若评审可撤销的 KernelSU 载体，应独立于 naozho_boot，只容纳已获准的 RRO，核实开机扫描前的挂载、识别分区和 user 0 的顺序。此前通过的独立锁定和 Owner 组件继续沿用。
2. **验收次序**为离线双映射与反向恢复、受控测试系统中的按键仲裁、最后另行批准 CPDAY10 实验。先验证未锁定环境的目标分发，再验证 ANDROID 返回 LOCKED + 80。分别测试暂停、退出和双击并发、连续多击、第二击按住、息屏起始、相机启用时竞争；对 SOS 使用无呼叫测试环境。出现时钟抢占原厂紧急或相机入口、暂停时弹时钟、单击/长按异常，停止晋级。
3. **电源回滚**先让应用保持暂停、禁用独立快捷入口，保留原应用图标和维护退出；撤销独立实验 overlay/载体，经批准在可独立救援的测试机上按原缓存生命周期重新初始化。核对两项 lookup 为 0 和空串、Global 仍未设置、运行中双击为 NOTHING、单击、长按、相机及紧急行为均恢复。仅禁用目标组件不能恢复系统多击计数。若必须回滚应用，先核对签名、版本覆盖及数据兼容性；无需卸载、清除 Owner 或恢复出厂。
4. **OTA** 后必须重核固件指纹、services.jar、目标表、资源 ID、OMS 规则与按键优先级。第一屏、实体键、应用窗口焦点、冷启动回滚都属于真机验收。本次使用的是离线资料，未向手机发送命令或部署任何模块。
