# DSH Windows 操作说明

本工具只处理电脑上已经提取的 CPDAY10 framework-res.apk。推荐使用 Python 3.8 或更新版本，手机可保持断开。

1. 从固定提交的 GitHub Raw 链接下载 ZIP 并解压，或直接下载同一提交的 cpday10_power_resource_slice.py。将脚本放在可写的工作目录。
2. 在该目录打开 PowerShell，执行下方命令。输入电脑上已有的 APK 完整路径，可直接粘贴“复制文件地址”所得的路径。

```powershell
$ErrorActionPreference = 'Stop'
$tool = '.\cpday10_power_resource_slice.py'
$expected = '98075c77573b2206fc1fc178c34ab871795d183703f5aeb70b1f75925d8d7d3b'
if ((Get-FileHash -LiteralPath $tool -Algorithm SHA256).Hash -ne $expected) { throw '脚本 SHA-256 不符' }
$apk = (Read-Host '本地 framework-res.apk 完整路径').Trim().Trim('"')
py -3 $tool $apk
if ($LASTEXITCODE -ne 0) { throw '提取未完成，请保留错误信息' }
```

3. 成功后，脚本会输出 CPDAY10-framework-policy-evidence.zip 的实际路径与 SHA-256。通过原私有协作渠道回传给 Codex。该结果含原厂的两个资源成员，请勿放到公开 GitHub 下载分支。若同名输出已存在，另选空目录或传入 `--out` 指定新文件名。
4. 分析以 reports 中的《拆包复核与实施方案》为准。《固件与RRO可行性报告》记录补件前的初审，其中的历史补件请求已由复核报告更新。两份报告保留全部技术章节，公开副本略去设备构建指纹和本次启动序号。报告中提到的旧工作区取证包属于原审查资料。validation 目录保留已完成的离线验证结果。
