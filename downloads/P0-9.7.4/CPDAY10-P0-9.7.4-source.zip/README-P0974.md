项目源码提交 353682c7a24defd5e01a34c2984458f6926df1cd。日常模块构建、离线测试及权限范围见 tools/p097/P0974-report.md；部署、停用及验收见 tools/p097/P0974-DSH.md。本次仅构建 KernelSU 模块，保留既有 0.6.13-dev / 28 APK。
