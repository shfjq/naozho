package com.naozho.power;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Desktop harness compiled only against the fixed 1.0.3 archive, with the capture's focus. */
public final class Replay103 {
    public static void main(String[] args) throws Exception {
        Path dir=Path.of(args[0]);
        String raw=Files.readString(dir.resolve("window-visible-raw.txt"));
        String environment=Files.readString(dir.resolve("采集环境与设备状态.txt"));
        Matcher observation=Pattern.compile("(?m)^mCurrentFocus *: *(mCurrentFocus=Window\\{[^\\r\\n]+\\})\\r?$").matcher(environment);
        if (!observation.find()) throw new AssertionError("missing capture focus");
        String id=Foreground.rawFocusId(observation.group(1));
        boolean control=args[1].equals("without_banner");
        if (control) raw=raw.substring(raw.indexOf('\n')+1);
        Foreground.Windows windows=new Foreground.Windows();
        try {
            // Board.command in 1.0.3 decodes UTF-8 and applies trim(). Both operations
            // happen before the actual release projector and foreground classifier below.
            windows=Foreground.inspectSnapshot(VisibleWindowDump.project(raw.trim()),id);
            Foreground.verify(windows,TrialChecks.FREEME);
        } catch (TrialChecks.Refused refused) {
            windows.reject(refused.getMessage());
        }
        System.out.println("decision="+(windows.veto==null?"ordinary_freeme":windows.veto)+windows.totals());
        for (String row:windows.rows) System.out.println(row);
        System.out.println("window_rows="+windows.rows.size());
        if (control ? windows.veto!=null : !"window_snapshot_header".equals(windows.veto)) throw new AssertionError("unexpected replay result");
    }
}
