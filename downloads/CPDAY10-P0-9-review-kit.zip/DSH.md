# CPDAY10 P0-9 现场核对、安装与回滚

**第一步只需当前 0.6.9 和一台已授权 ADB 的电脑。** 本轮可交付 0.6.10-dev 审查候选 APK，便于核对入口与模式日志；尚未接入原厂全局电源快捷键，也未改变系统 HOME 候选。只有后续厂商集成经审查后，才进行两项产品验收。P0-8 已确认能自动拉起时钟并锁定，曾出现 Keyguard、Freeme 后再进入时钟。

## 现在执行的只读采集

1. 保持手机现状，用 Windows 终端执行 `adb devices -l`。在解压后的审查包目录执行下面命令。文件名每次换新。脚本只调用 ADB 读取系统状态，在电脑创建 JSON。没有 Python 时使用后面的 PowerShell 命令。不要发送个人凭据、账号、整份未筛选的私人日志。

   ```powershell
   py -3 .\collect.py .\p09-before.json
   # 有多台设备时
   py -3 .\collect.py --serial <CPDAY10的ADB序列号> .\p09-device.json
   ```

2. 记录 Android 设置中屏幕锁定方式是「无」还是「滑动」、电源键快捷方式菜单是否有可选目标（尤其能否选指定应用并只在亮屏时生效）。不要在此轮采样中改值。若当前被锁定，先归档锁定读数，按已验证的开发退出到 Freeme 后再查看设置。
3. JSON 中 same_boot_user0 应为 true。核对设备当前 services.jar 哈希、原生 HOME、全局候选与限定候选、实际 Lock Task。对照窗口策略字段、global power_button_double_press、整型行为资源、字符串目标资源、相机/钱包/紧急相关配置。null 表示未设该 Settings 值；命令错误或资源缺失记为未知。dumpsys role 筛出的相邻行仅作线索，如角色归属不明确，另采 HOME 角色对应的小段。将新快照给 Codex 分析。
4. 如值无法确定，提供本机 `adb shell pm path android` 返回的 framework-res.apk，以及 `adb shell cmd overlay list --user 0 android` 中对 android 生效、涉及电源资源的 overlay APK（先用 `adb shell pm path 包名` 取对应路径）。用 `adb pull 设备返回路径` 提取。动态 fabricated overlay 没有普通 APK 时提供该 overlay 标识、`cmd overlay dump 标识` 与 lookup 原文。services.jar 哈希与审查报告不同时另提取 `/system/framework/services.jar`。若厂商有专机配置/快捷键手册一并提供。DSH 无需开发程序。

只读 PowerShell 备选命令：

```powershell
adb shell sha256sum /system/framework/services.jar
adb shell getprop ro.build.fingerprint
adb shell am get-started-user-state 0
adb shell locksettings get-disabled --user 0
adb shell dpm list-owners
adb shell cmd package query-activities --components --user 0 --query-flags 0 -a android.intent.action.MAIN -c android.intent.category.HOME
adb shell cmd package query-activities --components --user 0 --query-flags 0 -a android.intent.action.MAIN -c android.intent.category.HOME -p com.naozho.clock
adb shell cmd package resolve-activity --brief --user 0 --query-flags 66560 -a android.intent.action.MAIN -c android.intent.category.HOME
adb shell settings get global power_button_double_press
adb shell cmd overlay lookup --user 0 android android:integer/config_doublePressOnPowerBehavior
adb shell cmd overlay lookup --user 0 android android:string/config_doublePressOnPowerTargetActivity
adb shell dumpsys window policy | Select-String 'Keyguard|occluded|PowerBehavior|PowerDoublePress'
adb shell dumpsys window windows | Select-String 'mCurrentFocus|mFocusedApp'
adb shell dumpsys activity activities | Select-String 'mLockTaskModeState|topResumedActivity'
adb shell dumpsys device_policy | Select-String 'LockTask|mFlags|com.naozho.clock'
```

## 经批准后安装应用审查版

- 核对收件清单和 SHA-256。正常「开发退出」并确认停在 Freeme，核实 Owner 仍为 user 0 的 com.naozho.clock/.display.ClockDeviceAdmin。记录现有独立部署、维护暂停、锁屏、有效 HOME 和模块 OBSERVE/REQUEST 状态。
- 覆盖安装 `adb install -r .\naozho-0.6.10-dev-debug.apk`。核对 adb 返回 Success 后再读包信息，应为 0.6.10-dev / 25。保留数据、原桌面和既有管理身份。发生签名或版本拒绝时保留错误。此步没有新系统模块要安装。
- 从 Freeme 图标测试已配置的专机。原有 1.0.0 模块若此前是 REQUEST，会照常作为 P0-8 备用恢复。验证**系统第一屏**时先记录原值、将其单独切到 OBSERVE，查清系统启动时钟的来源。仅切到 OBSERVE 不会自动停用早先登记的 Job 或广播路径。保留同一 boot 的日志及录像。
- 0.6.10 的 NaozhoMode 日志含 clockEntry=home-intent / boot-request / launcher、boot、生命周期、stationPhase 与页面。home-intent 仅表示收到此类 Intent，要与真实系统 HOME 解析、系统启动记录和外拍交叉核对。当前固件仍全局排除时钟时直接记录该阻塞，保留已有独立模式。
- 现阶段 UI 沿用开发版原有退出/维护流程。Android 系统的「无」由用户在正常设置中选择。若仍有无凭据滑动页，可在记录基线且获准后，单独验证已有「关闭无凭据的滑动锁屏」；有安全凭据或 Device Owner/状态不符时即停止这项配置。

## 最终验收矩阵（待正式系统集成，全部由 DSH 执行）

| 场景 | 操作与取证 | 通过条件 |
| --- | --- | --- |
| 第一屏 | 用另一台设备连续拍摄 3 次正常重启、1 次完整关机再开。至少有一次从正常开发退出后的 Android 模式重启。记录按键、开机动画结束、第一帧、第一笔触摸及实际耗时；不用 ADB 启动时钟。 | 首个可交互窗口是时钟，第一笔点击有效。不出现 Keyguard/滑动、Freeme、临时设置页或简易不可操作页面。 |
| 系统锁定 | HOME 全局候选、解析和真实焦点核对为 MainActivity；分别上滑 1、2、5 次、返回、Home、最近任务、熄屏再亮，打开退出框验证触摸。 | 实际 LOCKED + 80，允许名单仅时钟。取消退出仍锁定可触摸；确认退出为 NONE、Freeme 可停留。 |
| 安卓模式双击 | 在 Freeme、设置、两个不同普通前台 Activity 分别从亮屏开始，记录单击、双击和长按的物理操作、屏幕和系统日志。记录两次独立释放、转场时间和有无相机/钱包/息屏竞争。 | 仅已启用专机的安卓模式双击回时钟并获得 LOCKED + 80；单击熄屏、长按保留原菜单。屏幕初始关闭时保留原行为。 |
| 模式往返 | 确认退出、取消退出、图标返回、双击返回，重复多轮；在 CLOCK / 维护暂停下测试双击，维护暂停后重启，再主动恢复并重启。 | 同次开机不会被后台拉回；维护暂停跨重启保持 Freeme，与旧模块投递无关；恢复后自动回时钟。同一串不重复启动。 |
| 紧急及其它功能 | 区分二击、长按第二击和更多按压。本轮用离线模型验证多击边界；涉及 SOS 的真实序列仅在厂商提供的非呼叫测试环境验收，以免触发真实报警。 | 保留紧急仲裁、电源菜单及日常单击。复测 Wi-Fi、蓝牙、充电、普通应用和 vivo 健康后台。 |

每次记录固件指纹、boot_count、测试起始状态、HOME、窗口焦点、锁定与触摸结果、外拍与日志文件名。只收到 SET/201、画面最终显示时间或模拟按键成功，都不能通过首屏或实体键验收。

## 停用与回滚

1. 日常回 Freeme 使用「开发退出」并确认。需跨重启暂停时，使用「暂停专机并恢复原桌面」，复核 NONE、Freeme、Owner 保留。若使用过 Keyguard 管理开关，在 NONE 下点「恢复系统锁屏」并通过系统设置恢复用户原选择。
2. 恢复备用模块的原观察/请求设置。要停止其请求，可切 OBSERVE 或在 KernelSU 管理器停用该模块后正常重启。若原为维护暂停，保持暂停。旧模块不替代真实系统 HOME。
3. 若需撤回审查 APK，从审查包的 rollback 目录覆盖安装随附的 `naozho-0.6.9-rollback-dev.apk`。它从原 79954aa 源码构建，只有版本元数据调整为 0.6.9-rollback-dev / 25，与候选版同版本码、同签名，避免常规安装降级到 24。安装命令为 `adb install -r .\rollback\naozho-0.6.9-rollback-dev.apk`。该包与候选包都使用原数据格式。确认版本、Owner、Freeme、原模块状态、可退出及独立锁定。若 OEM 拒绝覆盖，保留现状与错误，使用维护暂停；不通过卸载清数据解决。真机覆盖及回滚尚待验证。
4. 系统 HOME、紧急手势和框架文件在本轮没有部署变更。未来系统级方案需另有经过同型号验证的恢复路径，能在时钟和 Android UI 都不可用时独立停用。OTA 前应先撤销按构建匹配的集成，记录原配置，更新后重做固件及单击/紧急手势验收。
