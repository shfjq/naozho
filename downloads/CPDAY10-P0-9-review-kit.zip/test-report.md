# P0-9 应用审查版测试与交付记录

## 构建与验证

| 实际执行 | 结果 |
| --- | --- |
| assembleDevelopment | 通过，com.naozho.clock，0.6.10-dev / 25，minSdk 23，targetSdk 35 |
| testDebugUnitTest | 106 通过，失败/错误/跳过均为 0 |
| testDevelopmentUnitTest | 130 通过，失败/错误/跳过均为 0 |
| lintDevelopment | 0 错误，10 项警告 |
| P0-9 离线按键模型及采集器单测 | 8 通过 |
| 既有 naozho_boot 脚本回归 | 12 通过，主机 shell 与替身系统命令 |
| 二进制 Manifest、权限与签名 | 对两份 APK 验签，通过。对比 0.6.9-dev / 24 的最终 Manifest，除版本字段外一致。逐包读取 ZIP 完整性通过。 |

两套 Gradle 任务包含共享用例，分开计数。新增用例验证模式/暂停跨重启、受理有效入口时旧页面让位、同次开机重建可保留设置、过期/未武装请求拒绝；其中一项使用 Robolectric 创建真实 MainActivity 并保存读回页面。首轮该 JUnit 用例返回了控制器对象，修正测试签名为 Unit 后重新完成验证。现有交接、锁定和恢复回归继续通过。

离线按键模型覆盖两个短按和松开、竞态/已执行原厂动作、长按与重复、乱序、重复提交、屏幕关闭、暂停及启动编号变化。其系统独占仲裁输入由测试提供。采集器仅做只读 ADB 查询，跨开机或非 user 0 样本会标示无效。本轮没有在手机或 Android 16 模拟器运行该候选版，未执行实体按键、首次可见帧、系统覆盖或回滚安装验收。

## 制品

| 文件 | 字节 | SHA-256 |
| --- | ---: | --- |
| naozho-0.6.10-dev-debug.apk | 11665582 | `4b480523b77ce877edb5825fb3a20b1d2f0aaac424e6a074944cb93e9214cb5c` |
| rollback/naozho-0.6.9-rollback-dev.apk | 11467766 | `d5c3f60ae1549abed6f1d85184748875ed52b1e5d78637ea617082602d38c4ee` |
| naozho-ksu-boot-1.0.0.zip（原有备用模块） | 3566 | `ad7973a9deb07d0084ec5b135c0378f24e8b94e1672e1f94262a9a0250cbc9cb` |

0.6.9 原件、候选包和回滚包签名证书 SHA-256 均为 `801bc9dd5ea1144377f8e4520e1bb8bf6950e9e8d22733bba0465076df1c9578`。回滚包使用 79954aa 全部源文件，除 app/build.gradle.kts 的 versionCode=25 和 versionName=0.6.9-rollback 外没有改动。审查包用于相同版本码覆盖。待 DSH 验证本机安装器及数据保留。

## 修改文件

- app/build.gradle.kts 提升候选版本。
- MainActivity.kt 记录启动入口、记录页面所属开机，修正有效跨开机入口恢复旧页面，并记录实际时钟/焦点/策略状态。
- mode/ModeState.kt 统一派生专机阶段及恢复页决策。mode/ManagedDeployment.kt 记录成功的维护暂停与桌面交接。development 的 mode/ModuleBootReceiver.kt 读取同一状态。
- testDevelopment 的 mode/DevelopmentModeTest.kt 增加回归用例。
- tools/p09 下 collect.py 是 Windows 可用的只读采集器，power_contract.py 是主机判定模型，test_review.py 是对应测试。
- docs 下 cpday10-p09-architecture.md、cpday10-p09-dsh.md 与本报告分别提供设计、现场/回滚步骤和验证记录。没有改动 HOME Manifest、输入策略、已有模块或凭据存储。

## 权限

原有 uses-permission 为 INTERNET、ACCESS_NETWORK_STATE、USE_BIOMETRIC、SCHEDULE_EXACT_ALARM、POST_NOTIFICATIONS、USE_FULL_SCREEN_INTENT、RECEIVE_BOOT_COMPLETED、FOREGROUND_SERVICE、FOREGROUND_SERVICE_MEDIA_PLAYBACK、WAKE_LOCK、ACCESS_NOTIFICATION_POLICY，以及 AndroidX 合并的应用私有 DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION。development 保留应用签名级 REQUEST_BOOT_RECOVERY。BIND_DEVICE_ADMIN、BIND_JOB_SERVICE、BIND_CONDITION_PROVIDER_SERVICE 保护相应组件。没有新增系统特权、输入监听或无障碍权限。应用继续用原包名、原签名及 .display.ClockDeviceAdmin 组件。

## 构建复核

独立开发分支使用项目固定依赖，在现有缓存和 JDK 17 下执行 assembleDevelopment、testDevelopmentUnitTest、testDebugUnitTest、lintDevelopment。Linux 主机运行 `python3 -B -m unittest discover -s tools/p09 -v` 与 `python3 -B -m unittest discover -s kernelsu/tests -v`。真机判据与待收集证据见随附 DSH 手册。
