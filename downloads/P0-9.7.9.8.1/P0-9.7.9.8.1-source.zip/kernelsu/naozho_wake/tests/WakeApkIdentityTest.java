package com.naozho.power;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import java.nio.file.StandardOpenOption;

public final class WakeApkIdentityTest {
    private static final String PKG = "com.naozho.clock";
    private static final String SIGNER = "801bc9dd5ea1144377f8e4520e1bb8bf6950e9e8d22733bba0465076df1c9578";
    private static final int APP_UID = 10191;
    private static int checks;

    private static void check(boolean condition) {
        if (!condition) throw new AssertionError();
        checks++;
    }

    private static void refuses(String reason, DailyBoard.Check operation) throws Exception {
        try {
            operation.run();
        } catch (TrialChecks.Refused failure) {
            if (!reason.equals(failure.getMessage())) throw failure;
            checks++;
            return;
        }
        throw new AssertionError("expected " + reason);
    }

    private static WakeApkIdentity.Installed apk(Path path, int code) {
        return new WakeApkIdentity.Installed(PKG, code, "0.6." + (code - 15) + "-dev",
                path.toString(), SIGNER, APP_UID);
    }

    private static final class Dispatch implements WakeDispatch.PipelinedPorts {
        private final WakeApkIdentity verifier;
        WakeApkIdentity.Installed current, captured, replaceAfterReturn;
        int formal, commit, launch, cleanup;
        int sender = 0;
        Dispatch(WakeApkIdentity verifier, WakeApkIdentity.Installed current) {
            this.verifier = verifier;
            this.current = current;
        }
        public void guard() throws Exception {
            verifier.verify(current);
            if (captured == null) captured = current;
            else captured.requireSame(current);
        }
        public void dispatchFormal() throws Exception {
            guard();
            formal++;
            if (replaceAfterReturn != null) current = replaceAfterReturn;
        }
        public int proveFormal() { return sender; }
        public void publishReceipt() throws Exception { guard(); }
        public int confirmOnce() throws Exception { guard(); commit++; return sender; }
        public void launchReservedClock() throws Exception { guard(); launch++; }
        public boolean clockFocusedAndLocked() throws Exception { guard(); return true; }
        public void clearReceipt() { cleanup++; }
    }

    public static void main(String[] args) throws Exception {
        WakeApkIdentity verifier = new WakeApkIdentity(Files.readString(Path.of(args[0])));
        Path root = Files.createTempDirectory("wake-installed");
        Path old = Files.createDirectory(root.resolve("old")).resolve("base.apk");
        Path next = Files.createDirectory(root.resolve("new")).resolve("base.apk");
        Path backup = Files.createDirectory(root.resolve("rollback")).resolve("base.apk");
        try {
            Files.copy(Path.of(args[1]), old);
            Files.copy(Path.of(args[2]), next);
            Files.copy(Path.of(args[1]), backup);
            var v35 = apk(old, 35);
            var v36 = apk(next, 36);
            for (var bootIdentity : new WakeApkIdentity.Installed[]{v35, v36, apk(backup, 35)}) {
                verifier.verify(bootIdentity);
                Dispatch wake = new Dispatch(verifier, bootIdentity);
                check(WakeDispatch.run(wake, 0).equals("CLOCK_FOCUSED"));
                check(wake.formal == 1 && wake.commit == 1 && wake.launch == 1 && wake.cleanup == 1);
            }
            refuses("apk_version_unapproved", () -> verifier.verify(apk(old, 37)));
            refuses("apk_signer_mismatch", () -> verifier.verify(new WakeApkIdentity.Installed(PKG, 35,
                    "0.6.20-dev", old.toString(), "0".repeat(64), APP_UID)));
            refuses("apk_uid_mismatch", () -> WakeApkIdentity.checkUid(APP_UID, APP_UID + 1));
            refuses("apk_uid_mismatch", () -> WakeApkIdentity.checkUid(110191, 110191));
            refuses("apk_uid_mismatch", () -> v35.requireSame(new WakeApkIdentity.Installed(PKG, 35,
                    "0.6.20-dev", old.toString(), SIGNER, APP_UID + 1)));
            refuses("apk_changed", () -> verifier.verify(apk(old, 36)));
            Dispatch duringReturn = new Dispatch(verifier, v35);
            duringReturn.replaceAfterReturn = v36;
            refuses("apk_replaced_during_request", () -> WakeDispatch.run(duringReturn, 0));
            check(duringReturn.formal == 1 && duringReturn.commit == 0 && duringReturn.launch == 0);
            Dispatch unknown = new Dispatch(verifier, apk(old, 37));
            refuses("apk_version_unapproved", () -> WakeDispatch.run(unknown, 0));
            check(unknown.formal == 0 && unknown.commit == 0 && unknown.launch == 0);
            Dispatch badSender = new Dispatch(verifier, v36);
            badSender.sender = 2000;
            check(WakeDispatch.run(badSender, 0).equals("REFUSED_FORMAL_UID") && badSender.commit == 0);
            // In-place byte change invalidates any cached result, even if mtime is restored.
            verifier.verify(v36);
            var originalTime = Files.getLastModifiedTime(next);
            try (var channel = FileChannel.open(next, StandardOpenOption.WRITE)) {
                channel.write(ByteBuffer.wrap(new byte[]{0}), 0);
            }
            Files.setLastModifiedTime(next, originalTime);
            refuses("apk_changed", () -> verifier.verify(v36));
            Files.copy(Path.of(args[2]), next, StandardCopyOption.REPLACE_EXISTING);
            verifier.verify(v36);
            refuses("apk_allowlist_invalid", () -> new WakeApkIdentity("bad"));
        } finally {
            for (Path path : new Path[]{old, next, backup}) {
                Files.deleteIfExists(path);
                Files.delete(path.getParent());
            }
            Files.delete(root);
        }
        System.out.println("wake identity and dispatch assertions passed=" + checks);
    }
}
