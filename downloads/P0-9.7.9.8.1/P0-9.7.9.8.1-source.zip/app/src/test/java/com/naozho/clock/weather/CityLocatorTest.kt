package com.naozho.clock.weather

import android.Manifest
import android.app.Application
import android.content.Context
import android.location.Address
import android.location.Location
import android.location.LocationManager
import android.os.SystemClock
import com.naozho.clock.display.DisplayPreferences
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowGeocoder
import java.time.Duration
import java.util.Locale
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class CityLocatorTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val locationManager: LocationManager get() = checkNotNull(app.getSystemService(LocationManager::class.java))

    @Test
    fun permissionDenialReturnsWithoutAccessingPosition() = runBlocking {
        shadowOf(app).denyPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        assertEquals(CityResult.PermissionMissing, CityLocator(app).resolve())
    }

    @Test
    fun disabledSystemLocationDoesNotUsePassiveProvider() = runBlocking {
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        shadowOf(locationManager).setLocationEnabled(false)
        assertFalse(CityLocator(app).serviceEnabled())
        assertEquals(CityResult.ServiceDisabled, CityLocator(app).resolve())
    }

    @Test
    fun cacheUsesMonotonicAgeAndRejectsStaleFutureOrUndatedFixes() {
        val now = TimeUnit.HOURS.toNanos(20)
        val edge = fix(now - TimeUnit.HOURS.toNanos(6))
        val newer = fix(now - 1).apply { time = 1L }
        val stale = fix(edge.elapsedRealtimeNanos - 1).apply { time = Long.MAX_VALUE }
        val future = fix(now + 1)
        assertNull(newestWeatherFix(listOf(stale, future, fix(0)), now, CityLocator.STALE_AFTER_MS))
        assertSame(edge, newestWeatherFix(listOf(edge, stale), now, CityLocator.STALE_AFTER_MS))
        assertSame(newer, newestWeatherFix(listOf(edge, newer, future), now, CityLocator.STALE_AFTER_MS))
    }

    @Test
    fun recentFixWithUnavailableGeocoderReturnsExplicitFailure() = runBlocking {
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        val shadow = shadowOf(locationManager)
        shadow.setLocationEnabled(true)
        shadow.setProviderEnabled(LocationManager.NETWORK_PROVIDER, true)
        org.robolectric.shadows.ShadowSystemClock.advanceBy(Duration.ofSeconds(1))
        shadow.setLastKnownLocation(LocationManager.NETWORK_PROVIDER, fix(SystemClock.elapsedRealtimeNanos()))
        ShadowGeocoder.setIsPresent(false)
        assertEquals(CityResult.GeocodeFailed, CityLocator(app).resolve())
    }

    @Test
    fun cityLabelPrefersLocalityAndNeverUsesCoordinatesAsName() {
        val address = Address(Locale.CHINA).apply { latitude = 31.0; longitude = 121.0 }
        assertNull(weatherCity(address))
        address.adminArea = " 省 "
        address.subAdminArea = " 市 "
        assertEquals("市", weatherCity(address))
        address.locality = "城区"
        assertEquals("城区", weatherCity(address))
    }

    @Test
    fun existingWeatherPrefsAndNewAutoLocationSurviveReload() {
        val prefs = app.getSharedPreferences("weather-test", Context.MODE_PRIVATE)
        prefs.edit().putString("weatherLabel", "旧城").putString("weatherLat", "31")
            .putString("weatherLon", "121").commit()
        val display = DisplayPreferences(prefs)
        val before = display.state.value
        assertEquals("旧城", before.weatherLocation?.label)
        assertFalse(before.weatherAuto)
        val next = before.copy(weatherLocation = WeatherLocation("新城", 32.0, 122.0),
            weatherAuto = true, weatherResolvedAt = 123_456L)
        display.save(next)
        assertEquals(next, DisplayPreferences(prefs).state.value)
    }

    private fun fix(elapsed: Long) = Location(LocationManager.NETWORK_PROVIDER).apply {
        latitude = 31.0
        longitude = 121.0
        elapsedRealtimeNanos = elapsed
        time = System.currentTimeMillis()
    }
}
