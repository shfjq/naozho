package com.naozho.clock.ui

import com.naozho.clock.ui.TapExitCounter.TapOutcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TapExitCounterTest {

    @Test
    fun sevenQuickTapsComplete() {
        val counter = TapExitCounter()
        var completed = 0
        for (i in 0 until 7) {
            val outcome = counter.tap(1_000L + i * 100L)
            if (outcome is TapOutcome.Completed) completed += 1
        }
        assertEquals(1, completed)
        assertEquals(0, counter.count)
    }

    @Test
    fun sixTapsReportOneRemaining() {
        val counter = TapExitCounter()
        for (i in 0 until 6) counter.tap(i * 100L)
        assertEquals(6, counter.count)
        val last = counter.tap(600L)
        assertTrue(last is TapOutcome.Completed)
    }

    @Test
    fun progressCountsDown() {
        val counter = TapExitCounter()
        assertEquals(TapOutcome.Progress(6, 5_000L), counter.tap(0L))
        assertEquals(TapOutcome.Progress(5, 5_000L), counter.tap(100L))
        assertEquals(TapOutcome.Progress(4, 5_000L), counter.tap(200L))
    }

    @Test
    fun slowTapsResetTheWindow() {
        val counter = TapExitCounter()
        counter.tap(0L)
        counter.tap(1_000L)
        // The first tap sets the deadline.
        assertEquals(TapOutcome.Progress(6, 12_000L), counter.tap(7_000L))
        assertEquals(1, counter.count)
    }

    @Test
    fun leavingThePageResets() {
        val counter = TapExitCounter()
        counter.tap(0L)
        counter.tap(100L)
        counter.reset()
        assertEquals(0, counter.count)
        assertEquals(TapOutcome.Progress(6, 5_200L), counter.tap(200L))
    }

    @Test
    fun completionDoesNotRepeatWithoutNewGesture() {
        val counter = TapExitCounter()
        repeat(7) { counter.tap(it * 100L) }
        // No further completed outcome until a fresh gesture is recorded.
        assertEquals(TapOutcome.Ignored, counter.tap(800L))
    }

    @Test
    fun individuallyCloseTapsStillExpireFiveSecondsAfterFirstTap() {
        val counter = TapExitCounter()
        repeat(6) { counter.tap(it * 900L) }
        assertEquals(TapOutcome.Progress(6, 10_400L), counter.tap(5_400L))
    }

    @Test
    fun seventhTapAtDeadlineCanComplete() {
        val counter = TapExitCounter()
        repeat(6) { counter.tap(it * 100L) }
        assertEquals(TapOutcome.Completed, counter.tap(5_000L))
    }
}
