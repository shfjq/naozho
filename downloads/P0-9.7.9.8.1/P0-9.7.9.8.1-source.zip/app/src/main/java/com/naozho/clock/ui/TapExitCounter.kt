package com.naozho.clock.ui

/**
 * Hidden exit gesture: N taps on the version label within one time window.
 *
 * The gesture is deliberately stateful but side-effect free so it can be unit tested:
 * [tap] returns the remaining taps (or 0 when the gesture just completed).
 */
internal class TapExitCounter(
    private val required: Int = REQUIRED_TAPS,
    private val windowMs: Long = WINDOW_MS,
) {
    init {
        require(required >= 2)
        require(windowMs > 0)
    }

    private var taps = 0
    private var startedAt = 0L
    private var complete = false

    val count: Int get() = taps

    /**
     * Records one tap at [nowMs] (monotonic clock).
     *
     * @return [TapOutcome.Progress] with the number of taps still missing, or
     *         [TapOutcome.Completed] exactly once when the gesture finished.
     */
    fun tap(nowMs: Long): TapOutcome {
        if (complete) return TapOutcome.Ignored
        if (taps > 0 && (nowMs < startedAt || nowMs - startedAt > windowMs)) reset()
        if (taps == 0) startedAt = nowMs
        taps += 1
        if (taps >= required) {
            taps = 0
            complete = true
            return TapOutcome.Completed
        }
        return TapOutcome.Progress(required - taps, startedAt + windowMs)
    }

    /** Reset when the settings page leaves, when the gesture is abandoned, or after completion. */
    fun reset() {
        taps = 0
        startedAt = 0L
        complete = false
    }

    sealed interface TapOutcome {
        data class Progress(val remaining: Int, val deadline: Long) : TapOutcome
        data object Completed : TapOutcome
        data object Ignored : TapOutcome
    }

    companion object {
        const val REQUIRED_TAPS = 7
        const val WINDOW_MS = 5_000L
    }
}
