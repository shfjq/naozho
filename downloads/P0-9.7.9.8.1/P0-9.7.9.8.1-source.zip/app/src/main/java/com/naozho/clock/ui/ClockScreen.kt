package com.naozho.clock.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.naozho.clock.R
import com.naozho.clock.device.ClockSnapshot
import com.naozho.clock.weather.WeatherState
import com.naozho.clock.weather.weatherDescription
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private val Background = Color(0xFF131615)
private val Panel = Color(0xFF212721)
private val PrimaryText = Color(0xFFF2F4E9)
private val SecondaryText = Color(0xFFB5BFB1)
private val Accent = Color(0xFFD6F293)

@Composable
internal fun ClockScreen(
    snapshot: ClockSnapshot,
    alarmStatus: ClockTile = ClockTile(),
    weather: WeatherState = WeatherState(),
    openAlarms: (() -> Unit)? = null,
    openWeather: (() -> Unit)? = null,
    openSettings: (() -> Unit)? = null,
    onClockDrawn: ((hardwareFrame: Boolean) -> Unit)? = null,
    parked: Boolean = false,
    returnPending: Boolean = false,
) {
    BoxWithConstraints(
        // Keep the same composed children on a hot handoff. An unplaced child cannot
        // draw, accept hit tests or provide a ticket's readiness signal.
        modifier = Modifier.fillMaxSize()
            .then(if (parked || returnPending) Modifier.clearAndSetSemantics {} else Modifier)
            .then(if (parked) Modifier.drawWithContent {} else Modifier)
            .layout { measurable, constraints ->
                val child = measurable.measure(constraints)
                layout(child.width, child.height) { if (!parked) child.place(0, 0) }
            }
            .then(if (onClockDrawn == null) Modifier else Modifier.drawWithContent {
                drawContent()
                if (size.width > 0 && size.height > 0) onClockDrawn(drawContext.canvas.nativeCanvas.isHardwareAccelerated)
            })
            .background(Background)
            .safeDrawingPadding(),
    ) {
        val inset = (maxWidth * 0.065f).coerceIn(12.dp, 32.dp)
        val contentWidth = maxWidth - inset * 2
        val density = LocalDensity.current
        val conditions = weatherTile(weather)
        val sideBySide = contentWidth.value / maxOf(1f, density.fontScale) >= 242f
        val fitDetails = sideBySide && maxHeight < 330.dp &&
            (alarmStatus.detail != null || conditions.detail != null)
        val clockWidthRatio = if (fitDetails) 4.2f else 3.4f
        val clockSize = with(density) {
            (contentWidth / clockWidthRatio).toSp().value.coerceAtMost(112f).sp
        }
        val date = stringResource(
            R.string.clock_date,
            snapshot.year,
            snapshot.month,
            snapshot.day,
            stringArrayResource(R.array.weekdays)[snapshot.weekdayIndex],
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .heightIn(min = maxHeight)
                .padding(horizontal = inset, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(
                if (fitDetails) 8.dp else 10.dp,
                Alignment.CenterVertically,
            ),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (openSettings == null) {
                BatteryStatus(snapshot.batteryPercent, Modifier.align(Alignment.End))
            } else {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = openSettings) {
                        Icon(painterResource(R.drawable.ic_display_settings), "显示设置", tint = SecondaryText)
                    }
                    BatteryStatus(snapshot.batteryPercent)
                }
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = snapshot.time,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    color = PrimaryText,
                    fontSize = clockSize,
                    lineHeight = clockSize * 1.12f,
                    maxLines = 1,
                    softWrap = false,
                )
                Text(
                    text = date,
                    color = SecondaryText,
                    fontSize = 16.sp,
                    lineHeight = 23.sp,
                    textAlign = TextAlign.Center,
                )
            }

            val alarm = stringResource(R.string.next_alarm)
            val weatherTitle = stringResource(R.string.weather)
            if (sideBySide) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatusPanel(alarm, Modifier.weight(1f), alarmStatus, openAlarms)
                    StatusPanel(weatherTitle, Modifier.weight(1f), conditions, openWeather)
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatusPanel(alarm, Modifier.fillMaxWidth(), alarmStatus, openAlarms)
                    StatusPanel(weatherTitle, Modifier.fillMaxWidth(), conditions, openWeather)
                }
            }
        }
    }
}

@Composable
private fun BatteryStatus(percent: Int?, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Canvas(Modifier.size(width = 23.dp, height = 13.dp)) {
            val stroke = 1.dp.toPx()
            val bodyWidth = size.width - 4.dp.toPx()
            val outline = if (percent == null) SecondaryText else Accent
            drawRoundRect(
                color = outline,
                topLeft = Offset(stroke, stroke),
                size = Size(bodyWidth - stroke, size.height - stroke * 2),
                cornerRadius = CornerRadius(3.dp.toPx()),
                style = Stroke(width = stroke),
            )
            drawRoundRect(
                color = outline,
                topLeft = Offset(bodyWidth + stroke, size.height * 0.32f),
                size = Size(2.dp.toPx(), size.height * 0.36f),
                cornerRadius = CornerRadius(stroke),
            )
            if (percent != null && percent > 0) {
                val innerInset = 3.dp.toPx()
                drawRoundRect(
                    color = Accent,
                    topLeft = Offset(innerInset, innerInset),
                    size = Size(
                        (bodyWidth - innerInset * 2) * percent / 100f,
                        size.height - innerInset * 2,
                    ),
                    cornerRadius = CornerRadius(stroke),
                )
            }
        }
        Text(
            text = if (percent == null) {
                stringResource(R.string.battery_unavailable)
            } else {
                stringResource(R.string.battery_level, percent)
            },
            color = SecondaryText,
            fontSize = 13.sp,
            lineHeight = 18.sp,
        )
    }
}

@Composable
private fun StatusPanel(
    title: String,
    modifier: Modifier = Modifier,
    status: ClockTile = ClockTile(),
    onClick: (() -> Unit)? = null,
) {
    val action = if (onClick == null) Modifier else Modifier.clickable(role = Role.Button, onClick = onClick)
    Column(
        modifier = modifier
            .background(Panel, RoundedCornerShape(16.dp))
            .then(action)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(text = title, color = SecondaryText, fontSize = 13.sp, lineHeight = 18.sp)
        Text(
            text = status.value ?: stringResource(R.string.not_configured),
            color = PrimaryText,
            fontSize = 17.sp,
            lineHeight = 23.sp,
            fontWeight = FontWeight.Medium,
        )
        status.detail?.let {
            Text(it, color = SecondaryText, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

internal data class ClockTile(val value: String? = null, val detail: String? = null)

private val updatedFormat = DateTimeFormatter.ofPattern("M月d日 HH:mm", Locale.SIMPLIFIED_CHINESE)

internal fun weatherTile(state: WeatherState): ClockTile {
    if (state.location == null) return ClockTile()
    val last = state.last ?: return ClockTile(
        if (state.refreshing) "正在更新" else "暂不可用",
        if (!state.online) "无网络" else null,
    )
    val updated = updatedFormat.format(Instant.ofEpochMilli(last.updatedAt).atZone(ZoneId.systemDefault()))
    val detail = if (state.cached) "缓存 · $updated" else "更新 · $updated"
    return ClockTile("${weatherDescription(last.reading.code)} · ${last.reading.celsius.roundToInt()}°C", detail)
}
