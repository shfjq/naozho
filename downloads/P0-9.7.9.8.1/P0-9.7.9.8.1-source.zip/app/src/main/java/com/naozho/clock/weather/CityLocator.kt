package com.naozho.clock.weather

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Looper
import android.os.SystemClock
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Result of one automatic location attempt. */
internal sealed interface CityResult {
    data class Resolved(val location: WeatherLocation, val resolvedAt: Long) : CityResult
    data object PermissionMissing : CityResult
    data object ServiceDisabled : CityResult
    data object NoFix : CityResult
    data object GeocodeFailed : CityResult
}

/**
 * Resolves "where am I" into a displayable city using only platform APIs.
 *
 * Coarse permission is enough: the weather request only needs a city-sized fix. The most recent
 * known fix from any enabled provider is preferred; a single fresh fix is requested only when the
 * cached one is missing or stale. Reverse geocoding uses the platform [Geocoder].
 */
internal class CityLocator(private val context: Context) {

    private val manager: LocationManager? =
        context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    fun hasPermission(): Boolean =
        context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun serviceEnabled(): Boolean = runCatching {
        val m = manager ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) m.isLocationEnabled
        else enabledProviders().any { it != LocationManager.PASSIVE_PROVIDER }
    }.getOrDefault(false)

    /** Providers that are currently enabled, most useful first. */
    private fun enabledProviders(): List<String> {
        val m = manager ?: return emptyList()
        val order = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        return order.filter { provider ->
            runCatching { m.allProviders.contains(provider) && m.isProviderEnabled(provider) }.getOrDefault(false)
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun resolve(maxAgeMs: Long = STALE_AFTER_MS): CityResult {
        if (!hasPermission()) return CityResult.PermissionMissing
        val m = manager ?: return CityResult.ServiceDisabled
        if (!serviceEnabled()) return CityResult.ServiceDisabled
        val providers = enabledProviders()
        if (providers.isEmpty()) return CityResult.ServiceDisabled

        val fixes = providers.mapNotNull { provider ->
            runCatching { m.getLastKnownLocation(provider) }.getOrNull()
        }
        val cached = newestWeatherFix(fixes, SystemClock.elapsedRealtimeNanos(), maxAgeMs)
        val fix = cached ?: freshFix(m, providers) ?: return CityResult.NoFix
        if (fix.latitude !in -90.0..90.0 || fix.longitude !in -180.0..180.0) return CityResult.NoFix
        val label = labelFor(fix) ?: return CityResult.GeocodeFailed
        return CityResult.Resolved(
            WeatherLocation(label.take(32), fix.latitude, fix.longitude),
            System.currentTimeMillis(),
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun freshFix(manager: LocationManager, providers: List<String>): Location? =
        withTimeoutOrNull(FIX_TIMEOUT_MS) {
            for ((index, provider) in providers.withIndex()) {
                // Give later providers a chance within the same 12-second budget.
                val location = withTimeoutOrNull(FIX_TIMEOUT_MS / (providers.size - index)) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        awaitSingleFix(manager, provider)
                    } else {
                        awaitLegacySingleFix(manager, provider)
                    }
                }
                if (location != null) return@withTimeoutOrNull location
            }
            null
        }

    @SuppressLint("MissingPermission")
    private suspend fun awaitSingleFix(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { continuation ->
            val signal = CancellationSignal()
            runCatching {
                manager.getCurrentLocation(provider, signal, context.mainExecutor) { location ->
                    if (continuation.isActive) continuation.resume(location)
                }
            }.onFailure { if (continuation.isActive) continuation.resume(null) }
            continuation.invokeOnCancellation { runCatching { signal.cancel() } }
        }

    @SuppressLint("MissingPermission")
    private suspend fun awaitLegacySingleFix(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { continuation ->
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (continuation.isActive) continuation.resume(location)
                }

                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit

                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
            }
            val ok = runCatching {
                manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
                true
            }.getOrDefault(false)
            if (!ok && continuation.isActive) continuation.resume(null)
            continuation.invokeOnCancellation { runCatching { manager.removeUpdates(listener) } }
        }

    private suspend fun labelFor(location: Location): String? = withContext(Dispatchers.IO) {
        if (!Geocoder.isPresent()) return@withContext null
        val geocoder = Geocoder(context, Locale.getDefault())
        val addresses: List<Address>? = runCatching {
            geocoder.getFromLocation(location.latitude, location.longitude, 1)
        }.getOrNull()
        addresses?.firstOrNull()?.let(::weatherCity)
    }

    companion object {
        /** A fix older than this is treated as missing and one fresh fix is requested. */
        const val STALE_AFTER_MS = 6 * 60 * 60 * 1000L
        const val FIX_TIMEOUT_MS = 12_000L
    }
}

internal fun newestWeatherFix(fixes: List<Location>, nowNanos: Long, maxAgeMs: Long): Location? {
    val maxAge = TimeUnit.MILLISECONDS.toNanos(maxAgeMs)
    return fixes.filter { fix ->
        val measured = fix.elapsedRealtimeNanos
        measured > 0 && measured <= nowNanos && nowNanos - measured <= maxAge
    }.maxByOrNull { it.elapsedRealtimeNanos }
}

internal fun weatherCity(address: Address): String? =
    sequenceOf(address.locality, address.subAdminArea, address.adminArea)
        .mapNotNull { it?.trim() }
        .firstOrNull { it.isNotEmpty() }
