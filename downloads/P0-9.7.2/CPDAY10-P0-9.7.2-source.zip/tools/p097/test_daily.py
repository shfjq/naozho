import contextlib
import copy
import io
import unittest
from cpday10_daily import assess,battery_values,get_policy,consumption,app_markers

class Readback(unittest.TestCase):
    def setUp(self):
        self.a=dict(device="x",boot=38,uptime_s=3,owner=True,enforcing=True,armed=True,listener_count=1,pid=7,
                    resource=dict(start_ticks=30,cpu_ticks=23),report=dict(probes=1,attempts=2,delivered=2),
                    epoch_us=3000000,markers=[],focus="other",lock="NONE",flags=80,allow_clock_only=True)
        self.b=copy.deepcopy(self.a);self.b.update(uptime_s=10,epoch_us=10000000,markers=[[4000000,"app_requested"],[4200000,"focus_commit"],[4300000,"lock80"]],focus="clock",lock="LOCKED",policy_return=dict(policy_count=2,delivered=3),report={"probes":1,"attempts":3,"delivered":3})
    def test_full_return(self):
        with contextlib.redirect_stdout(io.StringIO()):assess(self.a,self.b,"return",True)
    def test_return_negative(self):
        for change in ({"policy_return":None},{"policy_return":dict(policy_count=1,delivered=3)},{"flags":112},{"markers":[]},{"focus":"other"},{"allow_clock_only":False},{"pid":8},{"armed":False},{"listener_count":2},
                       {"owner":False},{"lock":"PINNED"},{"report":{"attempts":4,"delivered":3}},{"boot":39}):
            with self.subTest(change=change),self.assertRaises(RuntimeError):assess(self.a,dict(self.b,**change),"return",True)
    def test_touch_required(self):
        with self.assertRaises(RuntimeError):assess(self.a,self.b,"return",False)
    def test_no_return(self):
        with contextlib.redirect_stdout(io.StringIO()):assess(self.a,dict(self.a,uptime_s=10),"no-return",False)
        with self.assertRaises(RuntimeError):assess(self.a,self.b,"no-return",False)
    def test_scoped_dpm(self):
        src="  Local Policies:\n    User 0:\n        LockTaskPolicy {mPackages= com.naozho.clock; mFlags= 80 }\n"
        self.assertEqual(80,get_policy(src+src))
        for s in (src.replace("User 0","User 10"),src+src.replace("80","112"),src+src.replace("clock;","clock other;")):
            self.assertIsNone(get_policy(s))
    def test_markers(self):
        self.assertEqual([[1000001,"focus_commit"]],app_markers("1.000001 111 I NaozhoPowerReturn: Double committed on foreground focus"))
    def test_battery(self):
        self.assertEqual(battery_values("  level: 76\n  Charge counter: 1234\n  temperature: 251\n  AC powered: false\n  USB powered: false"),
                         dict(level=76,temperature_tenths_c=251,charge_uah=1234,plugged=False))
        self.assertIsNone(battery_values("")["plugged"])
    def test_measured_intervals(self):
        args=dict(clock_hz=100,log_bytes=135,sys_wakeup_count=12,battery=dict(level=76,charge_uah=40000,plugged=False))
        a=dict(self.a,**args); b=dict(self.a,**args,uptime_s=3603)
        with contextlib.redirect_stdout(io.StringIO()) as out:consumption(a,b)
        self.assertIn('"level_used_per_hour": 0.0',out.getvalue())
        with self.assertRaises(RuntimeError):consumption(a,dict(b,boot=99))

class DiagnosticTests(unittest.TestCase):
    def test_veto_privacy_boundary(self):
        from cpday10_daily import veto_details
        head="last_veto_reason=additional_visible_window last_veto_at=200 extra_windows=2 down_gap_ms=497"
        row="type=SYSTEM_DIALOG owner=com.android.systemui visible=true onscreen=true surface=true focus=false focusable=true touchable=true obscured=false edge=false class=dialog"
        self.assertEqual(veto_details(head+"\n"+row)["windows"][0]["class"],"dialog")
        with self.assertRaises(RuntimeError): veto_details(head+"\n"+row+" title=private")
    def test_native_receipt_edges(self):
        from cpday10_daily import policy_return
        row="window_ms=600 down_gap_ms=599 policy_count=2 delivered=2"
        self.assertEqual(policy_return(row)["down_gap_ms"],599)
        for invalid in (row.replace("599","600"),row.replace("count=2","count=1")):
            with self.assertRaises(RuntimeError): policy_return(invalid)

class WindowSchemaTests(unittest.TestCase):
    counts=" visible_window_count=6 decorative_window_count=4 interactive_window_count=3 blocking_window_count=0 unknown_window_count=0 omitted_rows=0"
    row=("type=NAVIGATION_BAR_PANEL owner=com.android.systemui visible=true onscreen=true surface=true focus=false focusable=false"
         " touchable=false obscured=false edge=true class=decor class_reason=verified_passive_decor parser_source=flags_line_names"
         " field_missing=none focusable_parse_status=parsed touchable_parse_status=parsed geometry_valid=true touch_region=default_frame actual_blocker=false")
    def test_both_diagnostic_consumers(self):
        from cpday10_daily import veto_details,check_details
        for make,prefix in [(veto_details,"last_veto_reason=focus_transition last_veto_at=9 extra_windows=5 down_gap_ms=282"),
                            (lambda s:check_details(s,True),"decision=ordinary_freeme"),
                            (lambda s:check_details(s,False),"checked_at=9 delivered=1")]:
            value=make(prefix+self.counts+"\n"+self.row)
            self.assertEqual(4,value["decorative_window_count"])
            self.assertEqual("false",value["windows"][0]["actual_blocker"])
            with self.assertRaises(RuntimeError): make(prefix+self.counts+"\n"+self.row+" title=invalid")
    def test_one_read_collector_with_actual_producer(self):
        from cpday10_daily import bar_sample,BAR_SLICE
        import subprocess
        class ReadOnly:
            def __init__(self): self.dumps=0
            def shell(self,*args):
                if args==("getprop","ro.product.device"): return "CPDAY10"
                if args==("am","get-current-user"): return "0"
                self.dumps+=1
                selftest.assertEqual(args,("/system/bin/sh","-c",BAR_SLICE))
                sed=BAR_SLICE.split("/system/bin/sed -nE '",1)[1][:-1]
                raw=("  Window #0 Window{000 u0 PRIVATE_TITLE}:\n    mOwnerUid=1 showForAllUsers=false package=com.android.systemui appop=NONE\n"
                     "    mAttrs={(0,0)(fillxfill) ty=NAVIGATION_BAR\n      fl=NOT_FOCUSABLE | VENDOR_PRIVATE}")
                raw+="\n"+raw.replace("NAVIGATION_BAR\n      fl=NOT_FOCUSABLE | VENDOR_PRIVATE","STATUS_BAR flags=0x8").replace("#0","#1")
                raw+="\n    mTouchableInsets=3 mGivenInsetsPending=false\n    touchable region=SkRegion((0,0,720,30))\n  mBlurEnabled=true\n"
                return subprocess.run(["sed","-nE",sed],input=raw,text=True,capture_output=True,check=True).stdout.strip()
        selftest=self; device=ReadOnly()
        result=bar_sample(device)
        self.assertEqual(1,device.dumps)
        self.assertEqual([["INLINE","0x8"]],result["bars"][1]["public_flags"])
        self.assertEqual([["LINE","NOT_FOCUSABLE | <unrecognized>"]],result["bars"][0]["public_flags"])
        self.assertNotIn("PRIVATE",str(result))
