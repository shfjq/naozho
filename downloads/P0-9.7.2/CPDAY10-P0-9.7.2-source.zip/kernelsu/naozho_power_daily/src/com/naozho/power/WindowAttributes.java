package com.naozho.power;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Read only public LayoutParams flags. Private flags and input regions use different namespaces. */
final class WindowAttributes {
    private static final int FOCUS=0x8, TOUCH=0x10, SECURE=0x2000, RELEVANT=FOCUS|TOUCH|SECURE;
    private static final Pattern LINE=Pattern.compile("(?m)^[ \\t]*(?:fl|flags)[ \\t]*=[ \\t]*([^\\r\\n]*)$");
    private static final Pattern INLINE=Pattern.compile("(?m)^[ \\t]*mAttrs=\\{[^\\r\\n}]*?[ \\t](?:fl|flags)[ \\t]*=[ \\t]*(.*?)(?=[ \\t]+[A-Za-z][A-Za-z0-9_]*=|\\}|$)");
    // ExportedProperty flagMapping of WindowManager.LayoutParams.flags on Android 16.
    private static final String OTHER=" ALLOW_LOCK_WHILE_SCREEN_ON DIM_BEHIND BLUR_BEHIND NOT_TOUCH_MODAL TOUCHABLE_WHEN_WAKING KEEP_SCREEN_ON LAYOUT_IN_SCREEN LAYOUT_NO_LIMITS FULLSCREEN FORCE_NOT_FULLSCREEN DITHER SCALED IGNORE_CHEEK_PRESSES LAYOUT_INSET_DECOR ALT_FOCUSABLE_IM WATCH_OUTSIDE_TOUCH SHOW_WHEN_LOCKED SHOW_WALLPAPER TURN_SCREEN_ON DISMISS_KEYGUARD SPLIT_TOUCH HARDWARE_ACCELERATED LOCAL_FOCUS_MODE LAYOUT_IN_OVERSCAN TRANSLUCENT_STATUS TRANSLUCENT_NAVIGATION SLIPPERY LAYOUT_ATTACHED_IN_DECOR DRAWS_SYSTEM_BAR_BACKGROUNDS ";
    final String source, status;
    final int bits;
    private WindowAttributes(String source,String status,int bits) { this.source=source; this.status=status; this.bits=bits; }
    boolean known() { return status.equals("parsed"); }
    boolean secure() { return (bits&SECURE)!=0; }
    String focusable() { return known()?Boolean.toString((bits&FOCUS)==0):"unknown"; }
    String touchable() { return known()?Boolean.toString((bits&TOUCH)==0):"unknown"; }

    static WindowAttributes parse(String body) {
        // A window header or arbitrary string elsewhere must never supply these attributes.
        Matcher attrs=Pattern.compile("(?m)^[ \\t]*mAttrs=\\{").matcher(body);
        if (!attrs.find()) return new WindowAttributes("none","missing_attrs",0);
        int start=attrs.start();
        if (attrs.find()) return new WindowAttributes("none","duplicate_attrs",0);
        String section=body.substring(start);
        Matcher next=Pattern.compile("(?m)^[ ]{0,4}[^ \\t\\r\\n]").matcher(section);
        if (next.find(1)) section=section.substring(0,next.start());
        // Discard siblings after the closing brace. mAttrs itself starts with an opening brace.
        int close=section.indexOf('}');
        if (close>=0) section=section.substring(0,close+1);
        String raw=null, origin="none";
        for (Pattern pattern:new Pattern[]{LINE,INLINE}) {
            Matcher m=pattern.matcher(section);
            while (m.find()) {
                if (raw!=null) return new WindowAttributes("multiple","duplicate_flags",0);
                raw=m.group(1).trim(); origin=pattern==LINE?"flags_line":"attrs_inline";
            }
        }
        if (raw==null) return new WindowAttributes("none","missing_flags",0);
        // Compact vendor LayoutParams can place a sibling on the same line.
        raw=raw.split("[ \\t]+(?:pfl|sysui|vsysui|apr|bhv|fitTypes|fitSides)=",2)[0].trim();
        if (raw.endsWith("}")) raw=raw.substring(0,raw.length()-1).trim();
        if (raw.isEmpty()) return new WindowAttributes(origin,"empty_flags",0);
        int bits=0;
        boolean named=false,numeric=false;
        for (String token:raw.split("(?:[ \\t]+|[ \\t]*[|,][ \\t]*)+")) {
            if (token.startsWith("FLAG_")) token=token.substring(5);
            if (token.equals("NOT_FOCUSABLE")) { bits|=FOCUS; named=true; }
            else if (token.equals("NOT_TOUCHABLE")) { bits|=TOUCH; named=true; }
            else if (token.equals("SECURE")) { bits|=SECURE; named=true; }
            else if (token.matches("[A-Z_]+") && OTHER.contains(" "+token+" ")) named=true;
            else if (token.matches("0[xX][0-9a-fA-F]{1,8}")) {
                bits|=(int)Long.parseLong(token.substring(2),16); numeric=true;
            } else if (token.matches("(?=.*[0-9])(?=.*[A-Fa-f])[A-Fa-f0-9]{1,8}")) {
                bits|=(int)Long.parseLong(token,16); numeric=true;
            } else if (token.matches("-?[0-9]{1,10}")) {
                long decimal=Long.parseLong(token);
                if (decimal<Integer.MIN_VALUE || decimal>0xffffffffL) return new WindowAttributes(origin,"invalid_mask",0);
                // Some formatters emit a bare hex mask, others decimal. Accept only if the
                // interpretation of all three security-relevant bits is unambiguous.
                if (token.charAt(0)!='-' && token.length()<=8 && ((Long.parseLong(token,16)^decimal)&RELEVANT)!=0)
                    return new WindowAttributes(origin,"ambiguous_radix",0);
                bits|=(int)decimal; numeric=true;
            } else return new WindowAttributes(origin,"unknown_token",0);
        }
        if (!named && !numeric || raw.matches(".*[|,]$")) return new WindowAttributes(origin,"invalid_mask",0);
        return new WindowAttributes(origin+"_"+(named?(numeric?"mixed":"names"):"mask"),"parsed",bits);
    }
}
