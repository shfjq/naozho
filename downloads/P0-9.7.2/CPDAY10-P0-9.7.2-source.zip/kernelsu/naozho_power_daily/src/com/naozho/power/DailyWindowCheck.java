package com.naozho.power;

import android.os.Build;

/** Read-only Freeme diagnostic. Independent of arming and timing, with no broadcast sender. */
public final class DailyWindowCheck {
    public static void main(String[] args) {
        try {
            if (args.length!=0 || Build.VERSION.SDK_INT!=36 ||
                !"CPDAY10".equals(DailyBoard.cmd("/system/bin/getprop","ro.product.device"))) throw new TrialChecks.Refused("unsupported_device");
            Board.ownerUser();
            String before=DailyBoard.displayFocus(), id=Foreground.rawFocusId(before);
            Foreground.Windows windows=Foreground.inspectSnapshot(DailyBoard.visibleWindows(),id);
            try {
                String page=Foreground.focus(before);
                if (!page.equals(TrialChecks.FREEME)) throw new TrialChecks.Refused("not_freeme");
                Foreground.verify(windows,page);
                Foreground.confirmFocus(page,id,DailyBoard.displayFocus());
            } catch (TrialChecks.Refused stop) { windows.reject(stop.getMessage()); }
            System.out.println("decision="+(windows.veto==null?"ordinary_freeme":windows.veto)+windows.totals());
            for (String row:windows.rows) System.out.println(row);
        } catch (Exception error) {
            System.err.println("STOP "+DailyPower.reason(error)); System.exit(1);
        }
    }
    private DailyWindowCheck() {}
}
