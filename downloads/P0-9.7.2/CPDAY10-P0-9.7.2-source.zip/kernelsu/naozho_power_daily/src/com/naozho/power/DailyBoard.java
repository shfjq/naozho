package com.naozho.power;

import android.os.Build;
import java.io.InputStream;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;
import com.naozho.power.TrialChecks.Refused;

final class DailyBoard {
    static final Path DIR=Paths.get("/data/adb/modules/naozho_power_daily");
    static final String APK="8bcf50a524f58b6c8180d699f47a18fd096d94b7b12d737d1a60710d189597d4";
    static final String PKG="com.naozho.clock";
    Foreground.Windows windows=new Foreground.Windows();
    private final Map<String,String> verified=new HashMap<>();
    private static final String FIRST="^package:(/[^\\s]+/base\\.apk)$";

    static String generation;
    static boolean enabled() { return SessionLease.enabled(DIR,generation); }

    static String cmd(String... args) throws Exception { return Board.command(1800, 3*1024*1024,args); }

    // Filter potentially private system diagnostics at the producer. The DEX only receives
    // the EventHub device inventory or numeric call states. No shell interpolation.
    static String filtered(String constant) throws Exception {
        return Board.command(2500,128*1024,"/system/bin/sh","-c",constant);
    }
    static boolean verifyInputMap(Path node) throws Exception {
        String hub=filtered("dumpsys input | /system/bin/sed -nE '/^Event Hub State:/,/^[^[:space:]]/{ /^Event Hub State:|^    -?[0-9]+: |^[[:space:]]*(Path|Enabled|KeyLayoutFile|KeyCharacterMapFile):/p; }'");
        TrialChecks.Layout entry=TrialChecks.layout(hub, Board.node(node));
        String kl=Board.layoutFile(entry.kl,"keylayout","kl");
        String kcm=entry.kcm.isEmpty() ? "" : Board.layoutFile(entry.kcm,"keychars","kcm");
        if (!TrialChecks.powerMapping(kl,kcm)) throw new Refused("keymap_unverified");
        return java.util.regex.Pattern.compile("(?m)^\\s*(?:map\\s+)?key\\s+usage\\b").matcher(kl+"\n"+kcm).find();
    }

    void clockIdentity() throws Exception {
        verifyApk(PKG,APK);
        String owner=cmd("/system/bin/dpm","list-owners");
        if (!owner.matches("(?s).*User\\s+0:\\s+admin=com\\.naozho\\.clock/\\.display\\.ClockDeviceAdmin,DeviceOwner(?:,|\\s|$).*"))
            throw new Refused("owner_unconfirmed");
    }

    static void environment() throws Exception {
        if (!enabled() || android.os.Process.myUid()!=0 || Build.VERSION.SDK_INT!=36 ||
                !cmd("/system/bin/getprop","ro.product.device").equals("CPDAY10") ||
                !cmd("/system/bin/getprop","sys.boot_completed").equals("1") ||
                !cmd("/system/bin/getenforce").equals("Enforcing")) throw new Refused("unsupported_environment");
        if (Files.exists(Board.MODULE.resolve("module.prop"))) throw new Refused("trial_module_present");
        Board.verifyFramework();
    }

    static String sha(Path path) throws Exception {
        MessageDigest d=MessageDigest.getInstance("SHA-256");
        try (InputStream in=Files.newInputStream(path)) {
            byte[] buf=new byte[65536];
            for (int n; (n=in.read(buf))!=-1;) d.update(buf,0,n);
        }
        StringBuilder out=new StringBuilder(64);
        for (byte b:d.digest()) out.append(String.format(java.util.Locale.ROOT,"%02x",b));
        return out.toString();
    }

    private void verifyApk(String pkg,String digest) throws Exception {
        String raw=cmd("/system/bin/pm","path","--user","0",pkg);
        if (raw.contains("\n")) throw new Refused("split_apk_unreviewed");
        String base=TrialChecks.one(raw,FIRST,"apk_unconfirmed");
        String key=base+"|"+digest;
        if (key.equals(verified.get(pkg))) return;
        if (!sha(Paths.get(base)).equals(digest)) throw new Refused("apk_changed");
        verified.put(pkg,key);
    }

    static void androidMode(long first) throws Exception {
        String rows=cmd("/system/bin/run-as",PKG,"/system/bin/grep","-E",
                "^ *<(boolean|long) name=\"(managed_lock|managed_home|android|mode_since)\"",
                "shared_prefs/desktop_mode.xml");
        Foreground.mode(rows,first);
    }

    private void allowPage(String page) throws Exception {
        if (page.equals(TrialChecks.FREEME) || Foreground.settingsHome(page)) return;
        if (page.startsWith(PKG+"/") || page.startsWith("com.android.") || page.startsWith("android/") ||
                page.toLowerCase(java.util.Locale.ROOT).matches(".*(?:emergency|incall|dialer|keyguard|credential|biometric|password|recovery|authenticator|permissioncontroller).*"))
            throw new Refused("protected_page");
        if (page.equals(Foreground.CALC_PAGE)) { verifyApk(Foreground.CALC,Foreground.CALC_SHA); return; }
        Path list=DIR.resolve("pages");
        if (Files.isRegularFile(list)) {
            String hash=null;
            for (String row:Board.text(list,4096).split("\n")) {
                String[] pair=row.split(" ",-1);
                if (pair.length==2 && page.equals(pair[0]) && pair[1].matches("[0-9a-f]{64}")) {
                    if (hash!=null) throw new Refused("ambiguous_page");
                    hash=pair[1];
                }
            }
            if (hash!=null) {
                String pkg=page.substring(0,page.indexOf('/'));
                String installed=cmd("/system/bin/cmd","package","list","packages","-3","--user","0",pkg);
                if (java.util.Arrays.asList(installed.split("\n")).contains("package:"+pkg)) {
                    String role=cmd("/system/bin/cmd","role","get-role-holders","--user","0","android.app.role.DIALER");
                    if (!role.matches("[a-zA-Z0-9_.]+(?:\n[a-zA-Z0-9_.]+)*") ||
                            java.util.Arrays.asList(role.split("\n")).contains(pkg)) throw new Refused("dialer_or_role_unknown");
                    verifyApk(pkg,hash); return;
                }
            }
        }
        throw new Refused("unreviewed_page");
    }

    static String displayFocus() throws Exception {
        return filtered("dumpsys window displays | /system/bin/sed -nE '/^[[:space:]]*m(CurrentFocus|FocusedApp)=/p'");
    }
    static String visibleWindows() throws Exception {
        // Android mksh pipefail propagates a truncated/failed dumpsys even when sed exits normally.
        return filtered("set -o pipefail; dumpsys window -a visible | /system/bin/sed -nE '"+Foreground.WINDOW_FILTER+"'");
    }

    private static void powerReceipt(long first,long second,int window) throws Exception {
        if (!Integer.toString(window).equals(TimingSetup.current())) throw new Refused("timing_setting_changed");
        String pid=cmd("/system/bin/pidof","system_server");
        if (!pid.matches("[1-9][0-9]{0,8}")) throw new Refused("policy_pid_unknown");
        String extract="/system/bin/logcat -b system -d -t 180 -v raw --pid="+pid+
                " -s WindowManager:D | /system/bin/sed -nE '/^powerPress: eventTime=("+first+"|"+second+
                ") interactive=(true|false) count=[0-9]+ mShortPressOnPowerBehavior=[0-9]+$/p'";
        String rows=filtered(extract);
        if (rows.isEmpty()) {
            android.os.SystemClock.sleep(35);
            rows=filtered(extract);
        }
        PolicyReceipt.confirm(rows,first,second);
    }

    String foreground(long firstUptime, long firstElapsed,long second,int window) throws Exception {
        // Short-lived, bounded workers keep independent binder reads inside the APK's
        // two-second receipt window. No executor or timer is retained between gestures.
        ExecutorService pool=Executors.newFixedThreadPool(4);
        try {
            Future<Void> receipt=pool.submit(()->{ powerReceipt(firstUptime,second,window); return null; });
            Future<Void> mode=pool.submit(()->{ Board.ownerUser(); androidMode(firstElapsed); return null; });
            Future<Void> power=pool.submit(()->{ Board.awake(firstUptime);
                Foreground.callsIdle(filtered("dumpsys telephony.registry | /system/bin/sed -n 's/^[[:space:]]*mCallState=//p'")); return null; });
            Future<Void> lock=pool.submit(()->{ Foreground.lockAndKeyguard(filtered(
                    "dumpsys activity activities | /system/bin/sed -nE 's/^[[:space:]]*((mLockTaskModeState|isKeyguardShowing|mKeyguardShowing)=.*)$/\\1/p'")); return null; });
            String display=displayFocus();
            String visible=visibleWindows();
            String id=Foreground.rawFocusId(display);
            windows=Foreground.inspectSnapshot(visible,id);
            String page=Foreground.focus(display);
            if (!id.equals(Foreground.focusId(display))) throw new Refused("focus_transition");
            allowPage(page);
            if (Foreground.settingsHome(page)) {
                String route=filtered("dumpsys activity -a activities com.android.settings | /system/bin/sed -nE '"
                        +Foreground.settingsRouteFilter(display)+"'");
                if (!route.equals("ordinary\nroot")) throw new Refused("settings_route_unconfirmed");
            }
            Foreground.verify(windows,page);
            mode.get(); power.get(); lock.get(); receipt.get();
            String after=displayFocus();
            Foreground.confirmFocus(page,id,after);
            return page;
        } catch (ExecutionException e) {
            if (e.getCause() instanceof Exception) throw (Exception)e.getCause();
            throw new Refused("context_unavailable");
        } finally { pool.shutdownNow(); }
    }
}
