package com.naozho.power;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Run the actual producer filter, parser, focus check and deduplicating handoff on the six-window case. */
public final class FreemeWindowsTest {
    static final String SYS="com.android.systemui", PAGE=TrialChecks.FREEME, HEAD="WINDOW MANAGER WINDOWS (dumpsys window windows)\n";
    static final String[] NAMES={"ScreenDecorOverlay","ScreenDecorOverlayBottom","NavBar","StatusBar",PAGE,"wallpaper"};
    static final String[] FLAGS={"NOT_TOUCHABLE NOT_FOCUSABLE","NOT_FOCUSABLE|NOT_TOUCHABLE","0x80000008","NOT_FOCUSABLE | 0x80000000","HARDWARE_ACCELERATED","NOT_FOCUSABLE"};
    static final String[] TYPES={"NAVIGATION_BAR_PANEL","NAVIGATION_BAR_PANEL","NAVIGATION_BAR","STATUS_BAR","BASE_APPLICATION","WALLPAPER"};
    static String filter(String dump) throws Exception {
        Process p=new ProcessBuilder("sed","-nE",Foreground.WINDOW_FILTER).start();
        try(java.io.OutputStream in=p.getOutputStream()) { in.write(dump.getBytes(StandardCharsets.UTF_8)); }
        String result=new String(p.getInputStream().readAllBytes(),StandardCharsets.UTF_8);
        if (p.waitFor()!=0) throw new AssertionError("producer");
        return result;
    }
    static String scene(String[] records) { return HEAD+String.join("",records)+"  mBlurEnabled=true\n"; }
    static String[] records(String fixture) throws Exception {
        // The ordered type and owner come from DSH's transcription. Frames, IDs and public flag
        // spellings below are test encodings. They were not supplied as physical raw lines.
        List<String> types=new ArrayList<>(),owners=new ArrayList<>();
        for(String line:fixture.split("\n")) {
            if (line.trim().startsWith("\"type\": ")) types.add(line.trim().split("\"")[3]);
            if (line.trim().startsWith("\"owner\": ")) owners.add(line.trim().split("\"")[3]);
        }
        if (!types.equals(List.of(TYPES)) || owners.size()!=6) throw new AssertionError("evidence transcription");
        String[] result=new String[6];
        for(int i=0;i<6;i++) {
            String frame=(i==1 || i==2)?"[0,688][720,720]":i<4?"[0,0][720,32]":"[0,0][720,720]";
            result[i]=DailyTest.window(i,Integer.toHexString(i+1),NAMES[i],owners.get(i),types.get(i),FLAGS[i])
                    .replace("[0,0][720,35]",frame);
        }
        return result;
    }
    static Foreground.Windows inspect(String... rows) throws Exception { return Foreground.inspectSnapshot(filter(scene(rows)),"5"); }
    static void fail(String[] base,int index,String change,String label) throws Exception {
        String[] rows=base.clone(); rows[index]=change;
        Foreground.Windows w=inspect(rows);
        DailyTest.ok(label,w.veto!=null && w.blockingCount>0 && w.rows.stream().anyMatch(s->s.endsWith("actual_blocker=true")));
    }
    static final class Device implements DailyReturn.Device {
        String dump, before,after;
        int sends;
        public boolean fresh(long s,long r) {return true;}
        public void identity() {}
        public String foreground(long u,long e) throws Exception {
            String page=Foreground.focus(before);
            Foreground.verify(Foreground.inspectSnapshot(dump,Foreground.focusId(before)),page);
            Foreground.confirmFocus(page,Foreground.focusId(before),after);
            return page;
        }
        public void veto(String reason) {}
        public int probe(){return 17;}
        public boolean send(long first,long up,int uid){sends++; return uid==17;}
    }
    public static void main(String[] args) throws Exception {
        String fixture=Files.readString(Path.of(args[0]));
        String[] rows=records(fixture);
        if (args.length==2 && args[1].equals("emit-test-input")) { System.out.print(scene(rows)); return; }
        String[] unknown=rows.clone();
        for(int i=2;i<=3;i++) unknown[i]=unknown[i].replace("fl="+FLAGS[i],"pfl=0x8");
        Foreground.Windows missing=inspect(unknown);
        DailyTest.ok("supplied unknown values alone block both bars",missing.blockingCount==2 && missing.decorCount==2 &&
                missing.rows.get(2).contains("focusable=unknown") && missing.rows.get(3).contains("actual_blocker=true"));
        DailyTest.ok("incomplete successful prefix cannot stand in for full snapshot",
                Foreground.inspectSnapshot(filter(scene(rows).replace("  mBlurEnabled=true","")),"5").veto.equals("window_snapshot_incomplete"));
        Foreground.Windows normal=inspect(rows); Foreground.verify(normal,PAGE);
        DailyTest.ok("DSH six windows resolved; 4 decorations and no blockers",normal.extras==5 && normal.visibleCount==6 &&
                normal.decorCount==4 && normal.blockingCount==0 && normal.unknownCount==0 && normal.interactiveCount==3);
        DailyTest.ok("actual Freeme foreground",normal.focused.equals(PAGE));
        DailyTest.ok("privacy: no window identities in rows",Arrays.stream(NAMES).filter(n->!n.equals("wallpaper")).noneMatch(normal.rows.toString()::contains));
        for (String flags:List.of("NOT_FOCUSABLE HARDWARE_ACCELERATED","FLAG_NOT_FOCUSABLE | FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS",
                "0x80000008","8","f0000008","-2147483640","NOT_FOCUSABLE, 0x80000000")) {
            String[] copy=rows.clone(); copy[2]=copy[2].replace(FLAGS[2],flags);
            Foreground.verify(inspect(copy),PAGE); DailyTest.ok("numeric and symbolic public flags "+flags,true);
        }
        String[] inline=rows.clone();
        inline[2]=inline[2].replace(" fmt=TRANSLUCENT\n      fl="+FLAGS[2]+"}", " flags=0x8 pfl=0x2000}");
        Foreground.verify(inspect(inline),PAGE); DailyTest.ok("inline public flags separate from private flags",true);
        for (String flags:List.of("0x2008","8200","", "PRIVATE_VENDOR_TOKEN","0x800000000","NOT_FOCUSABLE |")) {
            fail(rows,2,rows[2].replace(FLAGS[2],flags),"invalid/secure/ambiguous flag input "+flags);
        }
        fail(rows,0,rows[0].replace(NAMES[0],"ScreenDecorOverlayUnconfirmed"),"unknown same-type panel");
        fail(rows,1,rows[1].replace("NOT_FOCUSABLE|NOT_TOUCHABLE","NOT_FOCUSABLE"),"touchable decor rejected");
        fail(rows,1,rows[1].replace("mObscured=false","mObscured=true"),"obscured decor rejected");
        fail(rows,1,rows[1].replace("u0 ","u10 "),"wrong user");
        fail(rows,1,rows[1].replace("mDisplayId=0","mDisplayId=2"),"wrong display");
        fail(rows,0,rows[0].replace(SYS,"com.untrusted.app"),"wrong decor owner");
        fail(rows,0,rows[0].replace(" frame=[0,0][720,32]"," frame=[0,0][720,720]"),"fullscreen overlay");
        fail(rows,3,rows[3].replace(" frame=[0,0][720,32]"," frame=[40,40][680,650]"),"floating bar");
        fail(rows,3,rows[3].replace("mObscured=false",""),"missing obscured state");
        fail(rows,2,rows[2].replace("fl="+FLAGS[2],"pfl=0x8"),"missing public flags");
        fail(rows,2,rows[2].replace("fl="+FLAGS[2],"fl="+FLAGS[2]+"\n      flags=0x8"),"duplicate public flag field");
        fail(rows,2,rows[2].replace("mHasSurface=true","mHasSurface=unavailable"),"missing visibility field");
        String custom="    mTouchableInsets=3 mGivenInsetsPending=false\n";
        String region="    touchable region=SkRegion((0,0,720,32))\n";
        for(String good:List.of(region,region.replace("(0,0,720,32)","(0,0,300,32)(400,0,720,32)"),"    touchable region=SkRegion()\n")) {
            String[] copy=rows.clone(); copy[3]+=custom+good;
            Foreground.verify(inspect(copy),PAGE); DailyTest.ok("touchable status bar bounded region",true);
        }
        fail(rows,3,rows[3]+custom,"required region missing");
        fail(rows,3,rows[3]+custom+region.replace("720,32","720,720"),"touchable region covers app");
        fail(rows,3,rows[3]+custom+region.replace("SkRegion","Unknown"),"unsupported region");
        fail(rows,3,rows[3]+custom.replace("false","true")+region,"pending insets");
        for (String[] special:new String[][]{{"NotificationShade","NOTIFICATION_SHADE"},{"ControlCenter","STATUS_BAR_SUB_PANEL"},
                {"InputMethod","INPUT_METHOD"},{"USB private dialog","SYSTEM_DIALOG"},{"permission private","APPLICATION_ATTACHED_DIALOG"},
                {"credential","KEYGUARD_DIALOG"},{"emergency","BASE_APPLICATION"},{"recovery","SYSTEM_ERROR"}}) {
            String[] copy=Arrays.copyOf(rows,7);
            copy[6]=DailyTest.window(6,"7",special[0],SYS,special[1],"0");
            Foreground.Windows result=inspect(copy);
            DailyTest.ok("special surface "+special[1],result.veto!=null && result.blockingCount==1 &&
                    result.rows.get(6).endsWith("actual_blocker=true") && !result.rows.get(6).contains("private"));
        }
        DailyTest.ok("truncated header rejected",Foreground.inspectSnapshot(filter(scene(rows).replace("  mBlurEnabled", "  Window #malformed\n  mBlurEnabled")),"5").veto!=null);
        Device dev=new Device();
        dev.before=" mCurrentFocus=Window{5 u0 "+PAGE+"}\n mFocusedApp=ActivityRecord{b u0 "+PAGE+" t2}";
        dev.after=dev.before.replace("Window{5","Window{7");dev.dump=filter(scene(rows));
        DailyReturn flow=new DailyReturn();
        DailyTest.ok("unstable focus sends zero",!flow.finish(dev,1,1,1,2) && dev.sends==0);
        dev.after=dev.before;
        for(int i=2;i<7;i++) DailyTest.ok("stable Freeme exactly once "+i,flow.finish(dev,i,i,i,i+1) &&
                !flow.finish(dev,i,i,i,i+1) && dev.sends==i-1);
        System.out.println("Freeme JVM cases "+DailyTest.count);
    }
}
