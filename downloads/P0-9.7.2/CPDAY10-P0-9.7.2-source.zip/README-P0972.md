项目源码提交 b0bee7cc15cdca3cafe12c87b2f445b1a04bc3fe。日常模块构建、离线测试及权限范围见 tools/p097/P0972-report.md；部署、停用及验收见 tools/p097/P0972-DSH.md。本次仅构建 KernelSU 模块，保留既有 0.6.13-dev / 28 APK。
