#!/system/bin/sh
mod=/data/adb/modules/naozho_wake
umask 077
touch "$mod/STOP"
rm -f "$mod/armed"
/system/bin/run-as com.naozho.clock /system/bin/rm -f files/wake-epoch.proof files/wake-proof.tmp
echo "Wake return disarmed"
