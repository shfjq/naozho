package com.naozho.power;

import android.os.SystemClock;
import com.naozho.power.TrialChecks.Refused;
import com.naozho.wakeprobe.WakeEpochManager;
import java.nio.file.*;
import java.util.UUID;

final class WakeBoard {
    static final Path DIR = Paths.get("/data/adb/modules/naozho_wake");
    static final String PKG = "com.naozho.clock";
    static final String PREFIX = PKG + ".action.WAKE_EPOCH_";
    static final String MODE = "shared_prefs/desktop_mode.xml";
    static final Path DE = Paths.get("/data/user_de/0/" + PKG + "/shared_prefs");
    final DailyBoard daily = new DailyBoard();
    String generation, bootId, apk;
    volatile String published;
    int boot, uid;

    static boolean deploymentHint() throws Exception {
        String text = Board.text(DE.resolve("primary_home_display.xml"), 4096);
        return "true".equals(TrialChecks.one(text, "^ *<boolean name=\"armed\" value=\"(true|false)\" */> *$",
                "deployment_hint_unknown"));
    }

    void enabled() throws Exception {
        if (!SessionLease.enabled(DIR, generation) || Files.exists(DailyBoard.DIR.resolve("armed")) ||
                Files.exists(Board.MODULE.resolve("module.prop"))) throw new Refused("observer_disabled_or_conflict");
    }

    void init() throws Exception {
        generation = Board.text(DIR.resolve("armed"), 64).trim();
        enabled();
        if (android.os.Process.myUid() != 0 || android.os.Build.VERSION.SDK_INT != 36 ||
                !"CPDAY10".equals(DailyBoard.cmd("/system/bin/getprop", "ro.product.device")) ||
                !"Enforcing".equals(DailyBoard.cmd("/system/bin/getenforce"))) throw new Refused("unsupported_runtime");
        Board.verifyFramework();
        boot = Board.boot();
        bootId = Board.text(Paths.get("/proc/sys/kernel/random/boot_id"), 64).trim();
        if (!UUID.fromString(bootId).toString().equals(bootId)) throw new Refused("boot_uuid");
        apk = Board.text(DIR.resolve("clock.sha256"), 80).trim();
        if (!apk.matches("[0-9a-f]{64}")) throw new Refused("apk_pin");
        daily.clockIdentity(apk);
    }

    static String power() throws Exception {
        String dump = Board.command(950, 256 * 1024, Board.DS, "power");
        if (dump.contains("Permission Denial") || dump.contains("SecurityException"))
            throw new Refused("power_dump_denied");
        return dump;
    }

    void androidMode(long dark) throws Exception {
        Board.ownerUser();
        if (!deploymentHint()) throw new Refused("maintenance_paused");
        String rows = DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/grep", "-E",
                "^ *<(boolean|long|string) name=\"(managed_lock|managed_home|android|mode_since|wake_focused)\"", MODE);
        // A dead clock task may leave desired CLOCK, yet a safe Android page in NONE.
        // Require a well-formed persisted mode; guardedForeground independently checks both.
        Foreground.wakeMode(rows, dark);
    }
    private static String appFile(String file) throws Exception {
        return DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/cat", "files/" + file);
    }
    static void clear() throws Exception {
        DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/rm", "-f", "files/wake-epoch.proof");
    }
    static void revoke(String receipt) throws Exception {
        // A delayed invalidation may arrive after a new wake. Remove only its own receipt.
        DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/sh", "-c",
                "if [ -f files/wake-epoch.proof ] && [ \"$(cat files/wake-epoch.proof)\" = \"$1\" ]; " +
                "then rm -f files/wake-epoch.proof; fi", "wake-revoke", receipt);
    }
    interface Live { void check() throws Exception; }

    String dispatch(WakeEpochManager.Epoch epoch, Live live) throws Exception {
        String id = UUID.randomUUID().toString();
        WakeWire wire = new WakeWire(boot, bootId, epoch.dark, epoch.sequence, epoch.event, uid, id);
        long expires = wire.expires;
        String receipt = wire.receipt();
        class Request implements WakeDispatch.Ports {
            String page;
            void fresh() throws Exception {
                enabled(); live.check();
                if (SystemClock.elapsedRealtime() >= expires || !WakeEpochManager.stillAwake(power(), epoch))
                    throw new Refused("wake_expired_or_changed");
            }
            public void guard() throws Exception {
                daily.clockIdentity(apk);
                String now = daily.guardedForeground(this::fresh, () -> androidMode(epoch.dark), live::check);
                if (page != null && !page.equals(now)) throw new Refused("foreground_changed");
                page = now;
            }
            public int sendFormal() throws Exception {
                attempt();
                return broadcast("RETURN");
            }
            public void publishReceipt() throws Exception {
                published = receipt;
                fresh();
                DailyBoard.cmd("/system/bin/run-as", PKG, "/system/bin/sh", "-c",
                    "umask 077; mkdir -p files && printf %s \"$1\" > files/wake-proof.tmp && mv -f files/wake-proof.tmp files/wake-epoch.proof",
                    "wake-proof", receipt);
            }
            public int confirmOnce() throws Exception {
                fresh();
                androidMode(epoch.dark);
                Foreground.confirmFocus(page, focusId, DailyBoard.displayFocus());
                return broadcast("COMMIT");
            }
            int broadcast(String verb) throws Exception {
                String action = PREFIX + verb;
                String trace = wire.trace(verb);
                Board.dispatch(DeliveryProof.envelope(action,trace,wire.extras()));
                int actual = Board.verifiedSender(action,trace,false);
                WakeDaemon.record(verb + " DELIVERED uid=" + actual + " request=" + id);
                return actual;
            }
            String focusId;
            public boolean clockFocusedAndLocked() throws Exception {
                for (int i = 0; i < 5; i++) {
                    enabled(); live.check();
                    if (!deploymentHint()) return false;
                    try {
                        if (id.equals(appFile("wake-epoch.locked"))) {
                            if (WakeLockReadback.focused(DailyBoard.displayFocus()) && WakeLockReadback.locked()) {
                                saveBudget(0); return true;
                            }
                        }
                    } catch (Refused | java.io.IOException noAckYet) { /* bounded readback only */ }
                    if (i < 4) SystemClock.sleep(200L << i);
                }
                return false;
            }
            public void clearReceipt() throws Exception { try { revoke(receipt); } finally { published = null; } }
        }
        Request request = new Request();
        request.focusId = Foreground.focusId(DailyBoard.displayFocus());
        if (budget() >= 3) return "REFUSED_CRASH_BUDGET";
        return WakeDispatch.run(request, uid);
    }
    int budget() throws Exception {
        Path p = DIR.resolve("attempts");
        if (!Files.exists(p)) return 0;
        String[] values = Board.text(p, 128).trim().split(" ");
        if (values.length != 2) throw new Refused("attempt_store_invalid");
        return values[0].equals(bootId) ? Board.number(values[1], 0, 3, "attempt_store_invalid") : 0;
    }
    private void saveBudget(int count) throws Exception {
        Path tmp = DIR.resolve("attempts.tmp");
        Files.write(tmp, (bootId + " " + count).getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        Files.move(tmp, DIR.resolve("attempts"), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    }
    private void attempt() throws Exception {
        int count = budget();
        if (count >= 3) throw new Refused("crash_budget");
        saveBudget(count + 1);
    }
}
