#!/usr/bin/env python3
from pathlib import Path
import subprocess
import tempfile

root=Path(__file__).resolve().parent
probe=root.parents[1]/"probes/wake-observer"
with tempfile.TemporaryDirectory() as tmp:
    src=[probe/"src/com/naozho/wakeprobe"/name for name in ("WakeCycle.java","PowerEvidence.java")]
    src.extend([root/"src/com/naozho/wakeprobe/WakeEpochManager.java", root/"protocol/com/naozho/power/WakeDispatch.java",
                root/"tests/WakeFlowTest.java", probe/"tests/WakeTests.java"])
    subprocess.run(["javac","--release","11","-d",tmp,*src],check=True)
    for name in ("com.naozho.wakeprobe.WakeTests","com.naozho.power.WakeFlowTest"):
        subprocess.run(["java","-cp",tmp,name],check=True)
for script in (root/"module").glob("*.sh"):
    subprocess.run(["sh","-n",script],check=True)
