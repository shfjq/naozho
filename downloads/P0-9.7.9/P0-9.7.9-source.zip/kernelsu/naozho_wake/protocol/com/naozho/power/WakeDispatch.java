package com.naozho.power;

/** Per-epoch, fail closed. The formal envelope can only open a window after independent AMS proof and a separate commit. No retries of the functional request. */
public final class WakeDispatch {
    public interface Ports {
        void guard() throws Exception;
        int sendFormal() throws Exception;
        void publishReceipt() throws Exception;
        int confirmOnce() throws Exception;
        boolean clockFocusedAndLocked() throws Exception;
        void clearReceipt() throws Exception;
    }
    public static String run(Ports ports, int expectedUid) throws Exception {
        try {
            ports.guard();
            if ((expectedUid != 0 && expectedUid != 2000) || ports.sendFormal() != expectedUid)
                return "REFUSED_FORMAL_UID";
            ports.guard();
            ports.publishReceipt();
            if (ports.confirmOnce() != expectedUid) return "REFUSED_COMMIT_UID";
            return ports.clockFocusedAndLocked() ? "CLOCK_FOCUSED" : "REFUSED_LOCK_OR_FOCUS_UNCONFIRMED";
        } finally { ports.clearReceipt(); }
    }
}
