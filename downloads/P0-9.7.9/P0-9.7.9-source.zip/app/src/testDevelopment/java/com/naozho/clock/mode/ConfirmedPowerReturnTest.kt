package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.Application
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewConfiguration
import com.naozho.clock.MainActivity
import com.naozho.clock.alarm.AlarmRuntime
import com.naozho.clock.display.ClockDeviceAdmin
import com.naozho.station.StationPowerShortcut
import java.time.Duration
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = AlarmRuntime::class)
class ConfirmedPowerReturnTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val mode get() = ModeState(app)
    private val dpm get() = app.getSystemService(DevicePolicyManager::class.java)
    private val tasks get() = app.getSystemService(ActivityManager::class.java)
    private val admin get() = ComponentName(app, ClockDeviceAdmin::class.java)

    @Before fun armAndroid() = runBlocking<Unit> {
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, 9)
        shadowOf(app.getSystemService(UserManager::class.java)).setUserUnlocked(true)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(true)
        assertTrue(shadowOf(dpm).setDeviceOwner(admin))
        assertEquals(DesktopResult.Applied, ManagedDesktop(app).allowClock())
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        advance(5)
    }

    private fun advance(ms: Long) = shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(ms))
    private fun request(): Intent {
        val first = SystemClock.elapsedRealtime()
        advance(120)
        return Intent(ClockPowerReturn.ACTION).setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java))
            .putExtra(EXTRA_BOOT_COUNT, 9).putExtra(ClockPowerReturn.FIRST, first)
            .putExtra(ClockPowerReturn.RELEASE, SystemClock.elapsedRealtime())
    }
    private fun deliver(intent: Intent) = ConfirmedPowerReceiver().onReceive(app, intent)

    private fun wake(): WakeTicket {
        val dark = SystemClock.elapsedRealtime()
        advance(250)
        val event = SystemClock.elapsedRealtime()
        return WakeTicket(9, "beeb1d4e-0f34-4dfa-b066-bc40ce6a67e2", dark, event,
            event + WakeTicket.LIFETIME, 1, java.util.UUID.randomUUID().toString(), 0)
    }

    private fun commit(t: WakeTicket): Intent = t.entry(app).setAction(WakeTicket.COMMIT)
        .setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java)).setIdentifier(t.id + ".commit")
    private fun attest(t: WakeTicket) = java.io.File(app.filesDir, "wake-epoch.proof").writeText(t.receipt)

    @Test fun fullWakeStartsOnceAndReadsBackClockFocusAndExactPolicy() {
        val t = wake()
        val confirmation = commit(t)
        deliver(Intent(confirmation).setAction(WakeTicket.RETURN))
        assertNull(shadowOf(app).nextStartedActivity)
        deliver(confirmation)
        assertNull(shadowOf(app).nextStartedActivity)
        attest(t)
        deliver(confirmation)
        val entry = shadowOf(app).nextStartedActivity
        assertNotNull(entry)
        deliver(confirmation)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(DesktopMode.ANDROID, mode.current())
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).setup()
        ctrl.windowFocusChanged(true)
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(DesktopMode.CLOCK, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_LOCKED, tasks.lockTaskModeState)
        assertEquals(80, dpm.getLockTaskFeatures(admin))
        assertArrayEquals(arrayOf(app.packageName), dpm.getLockTaskPackages(admin))
        assertEquals(t.id, java.io.File(app.filesDir, "wake-epoch.locked").readText())
        deliver(confirmation)
        assertNull(shadowOf(app).nextStartedActivity)
        ctrl.pause().stop().destroy()
    }

    @Test fun wakePauseBetweenReservationAndFocusSurvivesReenable() {
        val t = wake(); attest(t)
        assertTrue(ClockPowerReturn.accept(app, t.entry(app), PowerDelivery.RESERVE))
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        assertFalse(ClockPowerReturn.accept(app, t.entry(app), PowerDelivery.CONSUME))
        advance(1)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        assertFalse(ClockPowerReturn.accept(app, t.entry(app), PowerDelivery.RESERVE))
    }

    @Test fun wakeRejectsStaleWrongBootWrongSourceAndChangedReceipt() {
        val t = wake(); attest(t)
        for (intent in listOf(commit(t).setIdentifier("other"), commit(t).putExtra("source","SCREEN_ON"),
            commit(t).putExtra("boot_id","other"), commit(t).putExtra("sender_uid",10191),
            commit(t).putExtra(EXTRA_BOOT_COUNT,8), commit(t).putExtra("event_timestamp",t.event+1))) {
            deliver(intent)
            assertNull(shadowOf(app).nextStartedActivity)
        }
        advance(WakeTicket.LIFETIME + 1)
        deliver(commit(t))
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun wakeRevocationStopsReservedHandoffAndNoReplayAfterExit() {
        val t = wake(); attest(t)
        assertTrue(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
        assertTrue(java.io.File(app.filesDir,"wake-epoch.proof").delete())
        assertFalse(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.CONSUME))
        attest(t)
        assertTrue(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.CONSUME))
        advance(1)
        mode.set(DesktopMode.ANDROID)
        assertFalse(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
        advance(1)
        val next = wake(); attest(next)
        assertTrue(ClockPowerReturn.accept(app,next.entry(app),PowerDelivery.RESERVE))
    }

    @Test fun clockProcessLossCanRecoverOnFreshWakeButPinnedOrAlreadyLockedCannot() {
        mode.set(DesktopMode.CLOCK)
        advance(2)
        val t = wake(); attest(t)
        for (state in listOf(ActivityManager.LOCK_TASK_MODE_LOCKED, ActivityManager.LOCK_TASK_MODE_PINNED)) {
            shadowOf(tasks).setLockTaskModeState(state)
            assertFalse(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
        }
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_NONE)
        assertTrue(ClockPowerReturn.accept(app,t.entry(app),PowerDelivery.RESERVE))
    }

    @Test fun productionRootProtocolReachesRealReceiverActivityAndLockReadback() {
        val t = wake()
        val wire = com.naozho.power.WakeWire(t.boot,t.bootId,t.dark,t.sequence,t.event,t.sender,t.id)
        fun envelope(verb: String) = Intent("com.naozho.clock.action.WAKE_EPOCH_" + verb).apply {
            component = ComponentName(app, ConfirmedPowerReceiver::class.java)
            identifier = wire.trace(verb)
            for ((kind,key,value) in wire.extras().asList().chunked(3)) {
                when(kind) {
                    "--ei" -> putExtra(key,value.toInt())
                    "--el" -> putExtra(key,value.toLong())
                    "--es" -> putExtra(key,value)
                    else -> error("unknown wire type")
                }
            }
        }
        val file = java.io.File(app.filesDir,"wake-epoch.proof")
        val result = com.naozho.power.WakeDispatch.run(object : com.naozho.power.WakeDispatch.Ports {
            override fun guard() { assertEquals(DesktopMode.ANDROID,mode.current()) }
            override fun sendFormal(): Int {
                deliver(envelope("RETURN")); assertNull(shadowOf(app).nextStartedActivity); return 0
            }
            override fun publishReceipt() { file.writeText(wire.receipt()) }
            override fun confirmOnce(): Int { deliver(envelope("COMMIT")); return 0 }
            override fun clockFocusedAndLocked(): Boolean {
                val controller = Robolectric.buildActivity(MainActivity::class.java, shadowOf(app).nextStartedActivity).setup()
                controller.windowFocusChanged(true); shadowOf(Looper.getMainLooper()).idle()
                val ok = tasks.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_LOCKED &&
                    dpm.getLockTaskFeatures(admin) == 80 && dpm.getLockTaskPackages(admin).toList() == listOf(app.packageName) &&
                    java.io.File(app.filesDir,"wake-epoch.locked").readText() == t.id
                controller.pause().stop().destroy()
                return ok
            }
            override fun clearReceipt() { file.delete() }
        },0)
        assertEquals("CLOCK_FOCUSED",result)
        assertFalse(file.exists())
    }

    @Test fun receiverRequiresSystemPermissionAndClockTargetIsPrivate() {
        val pm = app.packageManager
        val rx = pm.getReceiverInfo(ComponentName(app, ConfirmedPowerReceiver::class.java), 0)
        assertEquals("android.permission.STATUS_BAR_SERVICE", rx.permission)
        assertTrue(rx.exported)
        val entry = pm.getActivityInfo(ClockPowerReturn.target(app), 0)
        assertFalse(entry.exported)
        assertEquals(MainActivity::class.java.name, entry.targetActivity)
    }

    @Test fun adapterSendsOnlyAfterSecondReleaseThenActivityCommitsAndLocksOnFocus() {
        val adapter = StationPowerShortcut(app, Handler(Looper.getMainLooper())) { 4L }
        fun event(action: Int, down: Long) {
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), action, KeyEvent.KEYCODE_POWER, 0), true)
        }
        val first = SystemClock.uptimeMillis()
        event(KeyEvent.ACTION_DOWN, first)
        advance(100)
        event(KeyEvent.ACTION_UP, first)
        advance(89)
        val second = SystemClock.uptimeMillis()
        event(KeyEvent.ACTION_DOWN, second)
        advance(125)
        assertFalse(shadowOf(app).broadcastIntents.any { it.action == ClockPowerReturn.ACTION })
        event(KeyEvent.ACTION_UP, second)
        advance(ViewConfiguration.getMultiPressTimeout().toLong() + 1)
        val signal = shadowOf(app).broadcastIntents.single { it.action == ClockPowerReturn.ACTION }
        // Robolectric records cross-user delivery; execute the protected receiver callback explicitly.
        deliver(signal)
        val entry = shadowOf(app).nextStartedActivity
        assertNotNull(entry)
        assertEquals(DesktopMode.ANDROID, mode.current())
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).setup()
        assertFalse(ctrl.get().isFinishing)
        ctrl.windowFocusChanged(true)
        assertEquals(DesktopMode.CLOCK, mode.current())
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(ActivityManager.LOCK_TASK_MODE_LOCKED, tasks.lockTaskModeState)
        assertEquals(80, dpm.getLockTaskFeatures(admin))
        ctrl.pause().stop().destroy()
    }

    @Test fun dailyAdapterMeasuresDownToDownAndWaitsAfterSecondRelease() {
        var sends = 0
        val adapter = StationPowerShortcut(Handler(Looper.getMainLooper()), { 1L }, 600, 250) { _, _, _, _ ->
            sends++
            true
        }
        fun tap(hold: Long) {
            val now = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(hold)
            adapter.onPowerKey(KeyEvent(now, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
        }
        tap(100)
        advance(500) // full 600 ms from DOWN: this starts a new sequence despite only 500 ms since UP
        tap(100)
        advance(499)
        tap(60)
        advance(599)
        assertEquals(0, sends)
        advance(1)
        assertEquals(1, sends)
        advance(600)
        assertEquals(1, sends)
    }

    @Test fun diagnosticDeliveryCannotInitializeLegacyStateOrOpenAWindow() {
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        assertTrue(prefs.edit().remove("mode_since").commit())
        val before = prefs.all.toMap()
        deliver(Intent("com.naozho.clock.action.P095_PERMISSION_PROBE.offline")
            .setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java)))
        assertEquals(before, prefs.all)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
    }

    @Test fun normalExitInitializesVersion24ModeBoundaryAndPreservesConfiguration() {
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        val home = "com.droiclaw.launcher3/com.freeme.launcher.FreemeLauncher"
        assertTrue(prefs.edit().remove("mode_since").putString("native_home", home).commit())
        assertTrue(mode.set(DesktopMode.CLOCK))
        advance(1)
        assertTrue(mode.set(DesktopMode.ANDROID))
        advance(1)
        val signal = request()
        deliver(signal)
        assertNotNull(shadowOf(app).nextStartedActivity)
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(home, prefs.getString("native_home", null))
        assertTrue(mode.independentLock())
        assertTrue(dpm.isDeviceOwnerApp(app.packageName))
    }

    @Test fun pausedOrAlreadyLockedCannotReserveOrStartClock() {
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        val prefs = app.getSharedPreferences("desktop_mode", 0)
        val before = prefs.all.toMap()
        deliver(request())
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(before, prefs.all)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        shadowOf(tasks).setLockTaskModeState(ActivityManager.LOCK_TASK_MODE_LOCKED)
        val afterRearm = prefs.all.toMap()
        deliver(request())
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(afterRearm, prefs.all)
    }

    @Test fun pauseThenRearmRejectsBothQueuedBroadcastAndPreviouslyDeliveredActivity() {
        val signal = request()
        deliver(signal)
        val pending = shadowOf(app).nextStartedActivity
        assertNotNull(pending)
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        advance(20)
        assertTrue(mode.saveDeployment(true, DesktopMode.ANDROID, false))
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, pending).create()
        assertTrue(ctrl.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        ctrl.destroy()
    }

    @Test fun pauseWhileClockIsBeingCreatedPreventsCommitAtFirstFocus() {
        deliver(request())
        val entry = shadowOf(app).nextStartedActivity
        val ctrl = Robolectric.buildActivity(MainActivity::class.java, entry).create().start()
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertTrue(mode.saveDeployment(false, DesktopMode.ANDROID))
        ctrl.resume().visible().windowFocusChanged(true)
        assertTrue(ctrl.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, tasks.lockTaskModeState)
        ctrl.pause().stop().destroy()
    }

    @Test fun onlyOneWindowRequestCanBeOutstandingAndExpiredDeliveryCannotConsumeANewOne() {
        val first = request()
        deliver(first)
        val firstEntry = shadowOf(app).nextStartedActivity
        assertNotNull(firstEntry)
        val second = request()
        deliver(second)
        assertNull(shadowOf(app).nextStartedActivity)
        advance(2001)
        val third = request()
        deliver(third)
        val thirdEntry = shadowOf(app).nextStartedActivity
        assertNotNull(thirdEntry)
        assertFalse(ClockPowerReturn.accept(app, firstEntry, PowerDelivery.CONSUME))
        assertTrue(ClockPowerReturn.accept(app, thirdEntry, PowerDelivery.CONSUME))
        assertEquals(DesktopMode.CLOCK, mode.current())
    }

    @Test fun staleAndOtherBootDeliveriesDoNotOpenWindows() {
        val old = request()
        advance(2001)
        deliver(old)
        deliver(request().putExtra(EXTRA_BOOT_COUNT, 8))
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(DesktopMode.ANDROID, mode.current())
    }

    @Test fun activityAndPackageCannotSubstituteForThePrivateHandoff() {
        val s = request()
        deliver(s)
        val valid = shadowOf(app).nextStartedActivity
        assertNotNull(valid)
        val forged = Intent(valid).setComponent(ComponentName(app, MainActivity::class.java))
        val controller = Robolectric.buildActivity(MainActivity::class.java, forged).create()
        assertTrue(controller.get().isFinishing)
        assertEquals(DesktopMode.ANDROID, mode.current())
        controller.destroy()
        val wrong = Intent(valid).putExtra(ClockPowerReturn.FIRST, -1L)
        assertFalse(ClockPowerReturn.accept(app, wrong, PowerDelivery.CONSUME))
    }

    @Test fun incomingCallAndKeyguardLeaveAndroidInControl() {
        val signal = request()
        app.getSystemService(AudioManager::class.java).mode = AudioManager.MODE_IN_CALL
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
        app.getSystemService(AudioManager::class.java).mode = AudioManager.MODE_NORMAL
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(true)
        deliver(signal)
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun cancellingOrLosingGenerationBetweenReleasesAndDispatchSendsNothing() {
        var generation = 4L
        val adapter = StationPowerShortcut(app, Handler(Looper.getMainLooper())) { generation }
        repeat(2) {
            var down = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(down, down, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(20)
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
            advance(55)
            down = SystemClock.uptimeMillis()
            adapter.onPowerKey(KeyEvent(down, down, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_POWER, 0), true)
            advance(20)
            adapter.onPowerKey(KeyEvent(down, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_POWER, 0), true)
            if (it == 0) adapter.cancel() else generation++
            advance(ViewConfiguration.getMultiPressTimeout().toLong() + 1)
        }
        assertFalse(shadowOf(app).broadcastIntents.any { it.action == ClockPowerReturn.ACTION })
    }
}
