项目源码提交 5db8441516cea6cbf4c3d29ea3b1b1a96af5f2e6。日常模块构建、离线测试及权限范围见 tools/p097/P0971-report.md；部署、停用及验收见 tools/p097/P0971-DSH.md。本次仅构建 KernelSU 模块，保留既有 0.6.13-dev / 28 APK。
