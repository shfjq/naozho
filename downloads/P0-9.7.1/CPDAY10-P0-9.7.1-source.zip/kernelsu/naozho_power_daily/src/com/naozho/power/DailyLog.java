package com.naozho.power;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;

/** Only bounded outcomes and aggregate counters; no window names, key edges or gesture timestamps. */
final class DailyLog {
    private final Path dir;
    private long lastVeto;
    int probes,attempted,delivered,vetoed;
    DailyLog(Path dir) { this.dir=dir; }
    synchronized void veto(String reason) throws IOException {
        veto(reason,new Foreground.Windows(),-1);
    }
    synchronized void successGap(int window,long gap) throws IOException {
        replace("last-return","window_ms="+window+" down_gap_ms="+gap+" policy_count=2 delivered="+delivered+"\n");
    }
    private void replace(String name,String value) throws IOException {
        Path tmp=dir.resolve(name+".tmp");
        Files.write(tmp,value.getBytes(StandardCharsets.US_ASCII));
        Files.move(tmp,dir.resolve(name),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
    }
    synchronized void veto(String reason,Foreground.Windows windows,long gap) throws IOException {
        vetoed++;
        if (!reason.matches("[A-Za-z0-9_]{1,100}")) reason="unclassified_error";
        replace("last-veto","last_veto_reason="+reason+" last_veto_at="+System.currentTimeMillis()+
                " extra_windows="+windows.extras+" down_gap_ms="+gap+"\n"+String.join("\n",windows.rows)+"\n");
        long now=System.nanoTime();
        if (lastVeto==0 || now-lastVeto>=TimeUnit.MINUTES.toNanos(1)) {
            write("skipped_"+reason); lastVeto=now;
        } else { replace("status",line("skipped_"+reason)); }
    }
    private String line(String reason) {
        if (!reason.matches("[a-zA-Z0-9_]{1,100}")) reason="unclassified_error";
        return "state="+reason+" probes="+probes+" attempts="+attempted+" delivered="+delivered+" skipped="+vetoed+"\n";
    }
    synchronized void write(String reason) throws IOException {
        String line=line(reason);
        Path file=dir.resolve("daily.log");
        long day=TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis());
        if (Files.exists(file) && (Files.size(file)+line.length()>8192 ||
                TimeUnit.MILLISECONDS.toDays(Files.getLastModifiedTime(file).toMillis())!=day))
            Files.move(file,dir.resolve("daily.log.1"),StandardCopyOption.REPLACE_EXISTING);
        byte[] bytes=line.getBytes(StandardCharsets.US_ASCII);
        Files.write(file,bytes,StandardOpenOption.CREATE,StandardOpenOption.APPEND);
        Path tmp=dir.resolve("status.tmp");
        Files.write(tmp,bytes);
        Files.move(tmp,dir.resolve("status"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
    }
}
