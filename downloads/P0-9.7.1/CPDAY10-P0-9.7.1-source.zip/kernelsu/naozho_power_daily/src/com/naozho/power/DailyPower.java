package com.naozho.power;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.view.KeyEvent;
import com.naozho.station.StationPowerShortcut;
import com.naozho.power.TrialChecks.Refused;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/** One opt-in event-driven worker, no wake lock, relaunch timer or background restart loop. */
public final class DailyPower implements DailyReturn.Device {
    private final TimingSample sample=new TimingSample(DailyBoard.DIR);
    private final DailyReturn handoff=new DailyReturn();
    private final DailyBoard board=new DailyBoard();
    private final DailyLog log=new DailyLog(DailyBoard.DIR);
    private final AtomicLong observed=new AtomicLong();
    private final AtomicInteger queued=new AtomicInteger();
    private Path source;
    private long handled, lastDown;
    private int window;
    private int boot;
    private volatile boolean faulted;
    private StationPowerShortcut shortcut;

    static String reason(Exception e) { return e instanceof Refused ? e.getMessage() : e.getClass().getSimpleName(); }

    private void fail(Exception error) {
        faulted=true;
        try { log.write("disabled_"+reason(error)); } catch (Exception ignored) { /* fail closed */ }
        try { if (DailyBoard.enabled()) Files.deleteIfExists(DailyBoard.DIR.resolve("armed")); } catch (Exception ignored) { /* no retry in this process */ }
        System.exit(1);
    }

    @Override public boolean fresh(long serial,long released) {
        long age=SystemClock.elapsedRealtime()-released;
        return DailyBoard.enabled() && observed.get()==serial && age>=0 && age<1500;
    }

    @Override public void identity() throws Exception {
        board.clockIdentity();
        if (!Board.sameSource(source)) throw new Refused("source_changed");
    }
    @Override public String foreground(long up,long first) throws Exception { return board.foreground(up,first,lastDown,window); }
    @Override public void veto(String why) throws Exception { log.veto(why,board.windows,lastGap); }
    @Override public int probe() throws Exception {
        int verified=Board.verifyPermission(false);
        log.probes++;
        log.write("permission_proved");
        return verified;
    }
    @Override public boolean send(long first,long released,int uid) throws Exception {
        if (!fresh(handled,released)) { veto("stale_or_cancelled"); return false; }
        log.attempted++;
        log.write("dispatching");
        if (!fresh(handled,released)) { log.attempted--; veto("stale_or_cancelled"); return false; }
        Board.send(boot,first,released,uid,false);
        log.delivered++;
        log.write("receiver_delivered");
        return true;
    }
    private long lastGap;
    private boolean submit(long firstUp,long lastUp,long first,long released) {
        try {
            lastGap=lastDown-firstUp;
            board.windows=new Foreground.Windows();
            if (released-first>1000) { veto("receiver_sequence_too_long"); return false; }
            boolean returned=handoff.finish(this,handled,firstUp,first,released);
            if (returned) log.successGap(window,lastGap);
            return returned;
        }
        catch (Exception fault) { fail(fault); return false; }
    }

    private void run(boolean manualEnable) throws Exception {
        System.load(DailyBoard.DIR.resolve("libpowerinput.so").toString());
        int watch=DailyInput.watch();
        if (watch<0) throw new Refused("disable_watch_unavailable");
        try {
            DailyBoard.environment();
            board.clockIdentity();
            source=Board.discover();
            if (!"event1".equals(source.getFileName().toString())) throw new Refused("unexpected_power_node");
            boolean usage=DailyBoard.verifyInputMap(source);
            String[] dev=Board.text(source.resolve("dev"),32).split(":");
            if (dev.length!=2) throw new Refused("power_device_identity");
            boot=Board.boot();
            window=TimingLease.active(TimingSetup.DATA.resolve("lease"),TimingSetup.current());
            String hold=DailyBoard.cmd("/system/bin/settings","--user","0","get","secure","long_press_timeout");
            int maxHold=hold.equals("null") ? 250 : Math.min(250,Board.number(hold,100,5000,"unknown_hold_window"));
            if (!DailyBoard.enabled()) return;
            // Warm proof only when the user is already in enabled ANDROID mode. Locked CE,
            // CLOCK or maintenance at boot defer proof until an eligible future gesture.
            boolean warm;
            try { if (manualEnable) DailyBoard.androidMode(SystemClock.elapsedRealtime()); warm=manualEnable; }
            catch (Exception unavailable) { warm=false; }
            if (warm && DailyBoard.enabled()) handoff.prove(this);
            int fd=DailyInput.openPower(Integer.parseInt(dev[0]),Integer.parseInt(dev[1]),usage);
            if (fd<0) throw new Refused("evdev_identity_or_power_filter");
            try { listen(fd,watch,window,maxHold); } finally { DailyInput.closePower(fd); }
        } finally { DailyInput.closePower(watch); }
    }

    private void listen(int fd,int watch,int multi,int maxHold) throws Exception {
        HandlerThread thread=new HandlerThread("clock-power-policy");
        thread.start();
        Handler h=new Handler(thread.getLooper());
        shortcut=new StationPowerShortcut(h,()->DailyBoard.enabled()?1:-1,multi,maxHold,this::submit);
        log.write("listening");
        try {
            while (DailyBoard.enabled()) {
                long packed=DailyInput.next(fd,watch);
                if (packed==-2) break;
                if (packed<0) throw new Refused("input_source_lost");
                long at=packed/4;
                int edge=(int)(packed%4);
                long serial=observed.incrementAndGet();
                if (queued.incrementAndGet()>24) throw new Refused("input_backpressure");
                h.post(()->{
                    queued.decrementAndGet();
                    handled=serial;
                    if (edge==1) lastDown=at;
                    if (!DailyBoard.enabled()) { shortcut.cancel(); return; }
                    try { sample.edge(edge,at,SystemClock.elapsedRealtime(),SystemClock.uptimeMillis(),boot); }
                    catch (java.io.IOException unavailable) { /* Optional measurement; the return gates are independent. */ }
                    int keyAction=edge==0?KeyEvent.ACTION_UP:KeyEvent.ACTION_DOWN;
                    shortcut.onPowerKey(new KeyEvent(at,at,keyAction,KeyEvent.KEYCODE_POWER,edge==2?1:0),true);
                });
            }
        } finally {
            observed.incrementAndGet();
            h.removeCallbacksAndMessages(null);
            thread.quit();
        }
        if (!faulted) log.write("stopped");
    }

    public static void main(String[] args) {
        DailyBoard.generation=SessionLease.token(DailyBoard.DIR.resolve("armed"));
        if (args.length!=1 || (!args[0].equals("enable") && !args[0].equals("boot")) || !DailyBoard.enabled()) return;
        DailyPower service=new DailyPower();
        try (FileChannel lock=FileChannel.open(DailyBoard.DIR.resolve("listener.lock"),
                StandardOpenOption.CREATE,StandardOpenOption.WRITE); FileLock claim=SessionLease.claim(lock,DailyBoard.DIR,DailyBoard.generation)) {
            if (claim==null) return;
            Files.write(DailyBoard.DIR.resolve("running"),DailyBoard.generation.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            // Publish PID only for inspection, never for signaling.
            Files.write(DailyBoard.DIR.resolve("pid"),Integer.toString(android.os.Process.myPid()).getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            try { service.run(args[0].equals("enable")); } finally { Files.deleteIfExists(DailyBoard.DIR.resolve("pid")); }
        } catch (LinkageError unavailable) { service.fail(new Refused("native_or_runtime_unavailable")); }
        catch (Exception e) { service.fail(e); }
        System.exit(0);
    }
}
