package com.naozho.power;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.naozho.power.TrialChecks.Refused;

/** API 36 WindowState.dump and RootWindowContainer.dumpWindowsNoHeader. No UI text or view tree. */
final class Foreground {
    static final String SETTINGS = "com.android.settings";
    static final String CALC = "com.darkempire78.opencalculator";
    static final String CALC_PAGE = CALC + "/" + CALC + ".activities.MainActivity";
    static final String CALC_SHA = "43b6befd1fecc686ba1611bbda18896cc26d966047e788be995def569a4510f3";
    static final String NAME = "[a-zA-Z][a-zA-Z0-9_.$]*";
    private static final Pattern HEADER = Pattern.compile("(?m)^  Window #(\\d+) Window\\{([0-9a-fA-F]+) u(\\d+) ([^\\r\\n{}]+)\\}: *$");
    static String canonical(String c) throws Refused {
        if (!c.matches(NAME + "/" + NAME + "|" + NAME + "/\\." + NAME)) throw new Refused("unclassified_window");
        int sep=c.indexOf('/');
        return c.charAt(sep+1)=='.' ? c.substring(0,sep+1)+c.substring(0,sep)+c.substring(sep+1) : c;
    }

    static String focus(String display) throws Refused {
        String target=canonical(TrialChecks.focus(display));
        String resumed=TrialChecks.one(display,"^ *mFocusedApp=ActivityRecord\\{[^\\s{}]+ u0 ([^\\s{}]+) t[0-9]+[^{}]*\\} *$", "focused_app_unknown");
        if (!target.equals(canonical(resumed))) throw new Refused("focus_transition");
        return target;
    }

    static boolean settingsHome(String c) {
        return c.equals(SETTINGS + "/" + SETTINGS + ".Settings") ||
                c.equals(SETTINGS + "/" + SETTINGS + ".homepage.SettingsHomepageActivity");
    }

    static String settingsRouteFilter(String display) throws Refused {
        String id=TrialChecks.one(display,"^ *mFocusedApp=ActivityRecord\\{([0-9a-fA-F]+) u0 [^{}]+\\} *$","activity_identity_unknown");
        // Only classification bits leave the producer. Shared Settings containers may host
        // security fragments, so reject deep links, extras, dialogs and non-root routes.
        String token="(flg=0x[0-9a-fA-F]+|xflg=0x[0-9a-fA-F]+|pkg=com[.]android[.]settings"
                +"|cat=\\[android[.]intent[.]category[.]LAUNCHER\\]"
                +"|cmp=com[.]android[.]settings\\/(com[.]android[.]settings)?[.](Settings|homepage[.]SettingsHomepageActivity))";
        return "/^[ ]*[*] Hist #[0-9]+: ActivityRecord\\{"+id+" u0 /,/^[ ]*rootOfTask=/ { "
                +"/^[ ]*Intent \\{ act=(android[.]settings[.]SETTINGS|android[.]intent[.]action[.]MAIN)( "+token+")* \\}$/s/.*/ordinary/p; "
                +"/^[ ]*rootOfTask=true /s/.*/root/p; }";
    }

    static void callsIdle(String states) throws Refused {
        if (!states.matches("0(?:\\n0)*")) throw new Refused("call_or_unknown");
    }

    static void lockAndKeyguard(String states) throws Refused {
        if (!TrialChecks.one(states,"^mLockTaskModeState=(?:LOCK_TASK_MODE_)?(\\w+)$","lock_state_unknown").equals("NONE"))
            throw new Refused("task_already_locked");
        boolean known=false;
        for (String line:states.split("\n")) {
            if (line.startsWith("isKeyguardShowing=") || line.startsWith("mKeyguardShowing=")) {
                if (!line.equals("isKeyguardShowing=false") && !line.equals("mKeyguardShowing=false")) throw new Refused("keyguard");
                known=true;
            }
        }
        if (!known) throw new Refused("keyguard_unknown");
    }

    static String focusId(String display) throws Refused {
        return TrialChecks.one(display,"^ *mCurrentFocus=Window\\{([0-9a-fA-F]+) u0 [^\\s{}]+\\} *$","focus_id_unknown");
    }

    static void mode(String rows, long first) throws Refused {
        if (!TrialChecks.one(rows, "^ *<boolean name=\"android\" value=\"(true|false)\" */> *$", "mode_unknown").equals("true") ||
                !TrialChecks.one(rows,"^ *<boolean name=\"managed_lock\" value=\"(true|false)\" */> *$", "lock_unknown").equals("true") ||
                !TrialChecks.one(rows,"^ *<boolean name=\"managed_home\" value=\"(true|false)\" */> *$", "home_unknown").equals("false") ||
                first <= Long.parseLong(TrialChecks.one(rows,"^ *<long name=\"mode_since\" value=\"([0-9]{1,15})\" */> *$", "generation_unknown")))
            throw new Refused("mode_ineligible");
    }

    static String rawFocusId(String display) throws Refused {
        return TrialChecks.one(display,"^ *mCurrentFocus=Window\\{([0-9a-fA-F]+) u0 [^{}\\r\\n]+\\} *$","focus_id_unknown");
    }

    static final class Windows {
        int extras=-1;
        final java.util.List<String> rows=new java.util.ArrayList<>();
        String focused="unknown", veto;
        void reject(String reason) { if (veto==null) veto=reason; }
    }

    private static String field(String body,String regex) {
        try { return TrialChecks.one(body,regex,"missing"); }
        catch (Refused unknown) { return "unknown"; }
    }
    private static String bit(String body,String key) {
        return field(body,"(?:^| )"+key+"=(true|false)(?= |$)");
    }
    private static final String RECT="\\[(-?\\d{1,6}),(-?\\d{1,6})\\]\\[(-?\\d{1,6}),(-?\\d{1,6})\\]";
    private static boolean edgeFrame(String body) {
        Matcher m=Pattern.compile(" display="+RECT+" frame="+RECT+" ").matcher(body);
        if (!m.find()) return false;
        int[] p=new int[8];
        for (int i=0;i<p.length;i++) p[i]=Integer.parseInt(m.group(i+1));
        if (m.find() || p[4]<p[0] || p[5]<p[1] || p[6]>p[2] || p[7]>p[3] || p[6]<=p[4] || p[7]<=p[5]) return false;
        return (p[4]==p[0] || p[6]==p[2]) && 6*(p[6]-p[4])<=p[2]-p[0] ||
               (p[5]==p[1] || p[7]==p[3]) && 6*(p[7]-p[5])<=p[3]-p[1];
    }
    private static boolean flag(String flags,String name) {
        return Pattern.compile("(?:^|[ |])(?:FLAG_)?"+name+"(?:$|[ |])").matcher(flags).find();
    }
    private static boolean bar(String name,String type) {
        return type.equals("STATUS_BAR") && name.equals("StatusBar") ||
                type.equals("NAVIGATION_BAR") && name.matches("Nav(?:igation)?Bar0?") ||
                (type.equals("NAVIGATION_BAR_PANEL") || type.equals("NAVIGATION_BAR")) && name.equals("SecondaryHomeHandle0");
    }

    static Windows inspect(String dump,String focusId) {
        Windows result=new Windows();
        if (!dump.startsWith("WINDOW MANAGER WINDOWS") || dump.contains("Hiding System Alert Windows:") ||
                dump.contains("Windows force removing:")) result.reject("windows_unconfirmed");
        Matcher header=HEADER.matcher(dump);
        boolean seen=false;
        int n=0;
        result.extras=0;
        while (header.find()) {
            if (!Integer.toString(n++).equals(header.group(1)) || !"0".equals(header.group(3))) result.reject("unexpected_window");
            int stop=dump.indexOf("\n  Window #",header.end());
            String body=dump.substring(header.end(),stop<0?dump.length():stop);
            Matcher section=Pattern.compile("(?m)^  [^ \\r\\n]").matcher(body);
            if (section.find()) body=body.substring(0,section.start());
            boolean focused=header.group(2).equals(focusId);
            String name=header.group(4), owner=field(body,"^ *mOwnerUid=\\d+ showForAllUsers=(?:true|false) package=([a-zA-Z0-9_.]{1,160}) .*$");
            String type=field(body,"^ *mAttrs=\\{[^\\r\\n]* ty=([A-Z_]{1,48})\\b[^\\r\\n]*$");
            String flags=field(body,"^ +fl=([^}\\r\\n]+)\\}? *$");
            String visible=bit(body,"isVisible"),onScreen=bit(body,"isOnScreen"),surface=bit(body,"mHasSurface"),covered=bit(body,"mObscured");
            boolean noFocus=flag(flags,"NOT_FOCUSABLE"), noTouch=flag(flags,"NOT_TOUCHABLE");
            boolean sysUi=owner.equals("com.android.systemui");
            boolean platform=owner.equals("android") && body.matches("(?s).*\n *mOwnerUid=1000 .*");
            boolean knownFlags=flags.matches("0|[A-Z][A-Z_0-9]*(?:[ |]+[A-Z][A-Z_0-9]*)*");
            boolean edge=edgeFrame(body);
            String kind;
            if (!body.matches("(?s).*\n *mDisplayId=0 .*") || !knownFlags || owner.equals("unknown") || type.equals("unknown")) {
                kind="unknown"; result.reject("window_metadata_unknown");
            } else if (!focused && visible.equals("false") && onScreen.equals("false") && (surface.equals("false") || body.matches("(?s).* mViewVisibility=0x[48] .*"))) {
                kind="inactive";
            } else if (flag(flags,"SECURE")) {
                kind="secure"; result.reject("secure_window");
            } else if (focused && !seen && type.equals("BASE_APPLICATION") && name.startsWith(owner+"/") &&
                    visible.equals("true") && onScreen.equals("true") && surface.equals("true") && !noFocus && !noTouch) {
                try { result.focused=canonical(name); } catch (Refused ambiguous) { result.reject("focus_identity_unknown"); }
                kind="app";
            } else if (!focused && seen && type.equals("WALLPAPER")) {
                kind="wallpaper";
            } else if (!focused && noFocus && (
                    sysUi && edge && bar(name,type) ||
                    (sysUi || platform) && noTouch && (type.equals("DISPLAY_OVERLAY") || type.equals("SYSTEM_OVERLAY")) &&
                            (name.equals("SysDecor") || name.matches("ScreenDecorOverlay[A-Za-z0-9]*")) && edge)) {
                kind="decor";
            } else if (type.contains("INPUT_METHOD") || type.contains("NOTIFICATION_SHADE") ||
                    name.equals("ControlCenter") || name.equals("NotificationShade")) {
                kind="panel_or_ime"; result.reject("active_panel_or_ime");
            } else if (type.contains("KEYGUARD") || type.contains("ERROR")) {
                kind="protected"; result.reject("protected_system_window");
            } else {
                kind=type.contains("DIALOG")?"dialog":"unclassified";
                result.reject("additional_visible_window");
            }
            String row="type="+type+" owner="+owner+" visible="+visible+" onscreen="+onScreen+" surface="+surface+
                    " focus="+focused+" focusable="+(knownFlags?!noFocus:"unknown")+" touchable="+(knownFlags?!noTouch:"unknown")+
                    " obscured="+covered+" edge="+edge+" class="+kind;
            if (focused) {
                if (seen) result.reject("duplicate_focus_window");
                seen=true;
                if (!kind.equals("app")) result.reject("non_app_focus");
            } else result.extras++;
            // Keep the first offending row even if the cap is exhausted by passive decorations.
            if (result.rows.size()<8) result.rows.add(row);
            else if (!kind.matches("app|inactive|wallpaper|decor") && result.rows.size()==8) result.rows.add(row);
        }
        if (!seen || dump.split("(?m)^  Window #",-1).length-1!=n) result.reject("window_set_incomplete");
        return result;
    }
    static void visible(String dump,String target,String focusId) throws Refused { verify(inspect(dump,focusId),target); }
    static void verify(Windows value,String page) throws Refused {
        if (value.veto!=null) throw new Refused(value.veto);
        if (!value.focused.equals(page)) throw new Refused("window_set_incomplete");
    }
    private Foreground() {}
}
