# CPDAY10 P0-9.3 续做记录

保存日期为北京时间 2026-11-26。手机可关机。云端工作树为 /workspace/naozho-p09，分支 p0-9-system-clock，起点 f583b379daf596602759857aaa4b4631355573ac。查找本轮提交可执行 git log -1 -- docs/cpday10-p093-handoff.md。公开下载分支仅交付审查文件；固定提交与文件校验值在交付消息中。

## 已保存

- 候选 com.naozho.clock 0.6.12-dev / 27。有效主屏跨开机选页、首次聚焦时的允许名单恢复、维护暂停的 DE 显示位、无凭据直接启动的时钟触摸均已编码。独立锁定的 SDK 标志、Owner 组件、明确退出及现有模块继续复用。
- platform/station 中的 Java 按键库和 Android.bp 可供产品平台移植。已实现编号、松开、长按、多击、抢占、有效时间、迟到和暂停处理。Host 方法需由产品平台实现；当前手机的系统不会调用该库。
- 同版本码回滚 APK 基于 79954aa38defd455e5b485626d2019fe20c852f5 的 0.6.9 源码构建。编译版仅调整版本标识；候选/回滚包真实签名与已归档基线已比对。公开审查包内的 validation.json 记录每个文件的 SHA-256、构建元数据和测试计数。
- 本轮没有改动手机、HOME 角色、Owner、已安装的 naozho_boot 或任何系统镜像。两条新增产品路径的 CPDAY10 验收均未执行。
- 固件关键证据已浓缩在 cpday10-p093-product.md。读取了匹配哈希的 services.jar 三个 LockTaskController 方法。原文件、反编译全文及设备记录保留在私有工作区。

## 云端复现

在源码目录和已准备好的云端 JDK/SDK 缓存中运行：

```sh
sh /tmp/naozho-p09/gradle :app:assembleDevelopment :app:testDevelopmentUnitTest :app:lintDevelopment
python3 -B -m unittest discover -s tools/p09 -v
python3 -B -m unittest discover -s kernelsu/tests -v
```

其它开发工作区使用项目 Gradle wrapper 执行相同的任务，沿用原受控签名环境。用 JDK 17 复现独立按键测试：

```sh
mkdir -p /tmp/naozho-power-tests
javac --release 11 -Xlint:all -Werror -d /tmp/naozho-power-tests platform/station/src/com/naozho/station/StationPowerArbiter.java platform/station/tests/com/naozho/station/StationPowerArbiterTest.java
java -cp /tmp/naozho-power-tests com.naozho.station.StationPowerArbiterTest
```

审查包提供源码差异与原始构建的测试摘要。完整已提交的工程另在原云端工作区保存；私有快照和 Git 恢复材料见 /workspace/shared/downloads/P0-9.3-checkpoint/。这里没有为取代原包而新生成签名密钥。

## 下次从这里开始

1. 打开本文件、cpday10-p093-product.md、cpday10-p093-dsh.md 和审查包的验证 JSON。先对照 validation.json 的构建版本、签名和摘要，沿用已有结果。查看 AOSP 模拟器记录，保留实际完成与未完成的界限。
2. 取得与 MT6789 / L930E_M41、目标固件构建匹配的板级产品集成输入：支持标准主屏的配置、可接入原生电源/紧急策略的源码或厂商接口、独立救援及匹配恢复物的验证记录。材料可以离线提供。缺少这些时，不生成可刷的系统镜像或可部署的系统手势模块。
3. 输入就绪后，由 Codex 在独立构建环境实现系统 Host，接入最终手势裁决，验证进行中与已经锁定两种紧急抢占；再验证产品 HOME 首屏。先分别评审、分别回滚，最后组合验收。
4. 当前设备保持现状。以后另行批准真机阶段时 DSH 再按验收单操作。需记录真实首帧、首触、实际锁定、维护退出、硬件功能及紧急界面可操作。任何需要手机在线的尝试均暂停于此。
