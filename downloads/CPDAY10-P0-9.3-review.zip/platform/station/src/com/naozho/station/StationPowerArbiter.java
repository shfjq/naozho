package com.naozho.station;

/**
 * Run from the product's serialized power-policy thread. System policy owns the
 * sequence ID, clocks, stock actions and the exclusive end-of-sequence signal.
 * Observing raw keys never starts an activity and never consumes an input event.
 */
public final class StationPowerArbiter {
    public interface Host {
        /** Negative unless the active user is in eligible, interactive Android mode.
         * The token changes across user/boot, pause, re-arm and every mode change. */
        long eligibleGeneration();

        /** In one serialized transaction, recheck generation, keyguard, pending
         * emergency UI and emergency preemption while LOCKED before delivery. */
        boolean tryReturn(long expectedGeneration);
    }

    private final Host host;
    private final long quietMs;
    private final long longPressMs;
    private final long dispatchGraceMs;
    private long sequence = -1;
    private long generation = -1;
    private long lastEvent;
    private long downAt;
    private int taps;
    private boolean held;
    private boolean rejected = true;

    /** quietMs must cover all participating recognizers, including emergency. */
    public StationPowerArbiter(Host host, long quietMs, long longPressMs, long dispatchGraceMs) {
        if (host == null || quietMs <= 0 || longPressMs <= 0 || dispatchGraceMs < 0) {
            throw new IllegalArgumentException("Missing host or system gesture timeouts");
        }
        this.host = host;
        this.quietMs = quietMs;
        this.longPressMs = longPressMs;
        this.dispatchGraceMs = dispatchGraceMs;
    }

    /** Exactly once on the first non-repeat down. IDs increase on this instance. */
    public void firstDown(long id, long time, boolean interactive) {
        if (id <= sequence || time < 0) {
            if (id == sequence) cancel();
            return;
        }
        sequence = id;
        generation = interactive ? host.eligibleGeneration() : -1;
        held = true;
        downAt = lastEvent = time;
        taps = 0;
        rejected = generation < 0;
    }

    public void nextDown(long id, long time, boolean repeat) {
        if (id != sequence || rejected) return;
        if (repeat || held || taps != 1 || time < lastEvent || time - lastEvent >= quietMs) {
            cancel();
            return;
        }
        held = true;
        downAt = lastEvent = time;
    }

    public void up(long id, long time, boolean cancelled) {
        if (id != sequence || rejected) return;
        if (!held || cancelled || time < lastEvent || time - downAt >= longPressMs) {
            cancel();
            return;
        }
        held = false;
        lastEvent = time;
        taps++;
    }

    /** Includes power menu, emergency, call UI, screen-off, chords, user/mode changes. */
    public void cancel() {
        rejected = true;
    }

    /**
     * Called only by the final system arbitrator after ALL higher priority consumers
     * have relinquished this exact sequence. A timeout alone never finalizes a press.
     * The result is one-shot even when the host rejects delivery.
     */
    public boolean finish(long id, long time, boolean exclusiveDouble) {
        if (id != sequence || rejected) return false;
        rejected = true;
        if (!exclusiveDouble || held || taps != 2 || time < lastEvent ||
                time - lastEvent < quietMs || time - lastEvent - quietMs > dispatchGraceMs ||
                host.eligibleGeneration() != generation) return false;
        return host.tryReturn(generation);
    }
}
