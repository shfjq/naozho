package com.naozho.clock.mode

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import java.io.File

/** The module attests the *source* task only. No field is a launch destination. */
internal object WakeMaskGrant {
    const val PREPARE = "com.naozho.clock.action.WAKE_MASK_PREPARE"
    const val CANCEL = "com.naozho.clock.action.WAKE_MASK_CANCEL"

    fun accepts(context: Context, intent: Intent, sender: Int, now: Long): Boolean {
        // Some Android builds omit sentFromUid. The explicit receiver requires
        // STATUS_BAR_SERVICE; PREPARE additionally needs this boot/task's private grant.
        if (sender >= 0 && sender != 0 && sender != 2000) return false
        val boot = intent.getIntExtra(EXTRA_BOOT_COUNT, -1)
        val dark = intent.getLongExtra("dark_elapsed", -1)
        if (boot < 0 || boot != bootCount(context) || dark !in 1L..now) return false
        if (intent.action == CANCEL) return intent.identifier == "unmask.$boot.$dark"
        if (intent.action != PREPARE || intent.identifier != "mask.$boot.$dark") return false
        val page = intent.getStringExtra("mask_page") ?: return false
        if (page.length !in 3..450 || !component.matches(page) ||
            ComponentName.unflattenFromString(page) == null) return false
        val task = intent.getIntExtra("mask_task", -1)
        val uid = intent.getIntExtra("mask_uid", -1)
        val coordinates = listOf("mask_left", "mask_top", "mask_right", "mask_bottom")
        if (task < 0 || uid < 0 || coordinates.any { !intent.hasExtra(it) }) return false
        val bounds = coordinates.map { intent.getIntExtra(it, -1) }
        if (bounds[0] < 0 || bounds[1] < 0 || bounds[2] <= bounds[0] || bounds[3] <= bounds[1]) return false
        val expected = (listOf(boot, dark, page, task, uid) + bounds).joinToString("|")
        val file = File(context.filesDir, "wake-mask.grant")
        return runCatching {
            file.length() == expected.length.toLong() && file.readText(Charsets.US_ASCII) == expected
        }.getOrDefault(false)
    }

    private val component = Regex("""[A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+""")
}
