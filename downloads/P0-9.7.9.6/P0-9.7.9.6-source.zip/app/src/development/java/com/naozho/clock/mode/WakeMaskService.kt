package com.naozho.clock.mode

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Rect
import android.graphics.Region
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.util.AtomicFile
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import java.io.File
import java.io.IOException

/** Only invoked by the user-enabled system accessibility connection and the authenticated receiver.
 * The service reads window IDs, component metadata and geometry only. No node, content or input
 * observation. The non-focusable shield is parented to the verified OLD application window. */
class WakeMaskService : AccessibilityService() {
    internal data class Key(val boot: Int, val dark: Long) {
        override fun toString() = "$boot.$dark"
    }
    private data class Target(val page: ComponentName, val uid: Int, val task: Int, val bounds: Rect)
    private data class Lease(val key: Key, val target: Target, val id: Int, val surface: WakeMaskSurface,
                             var onDeadline: Long = 0L)

    private val handler = Handler(Looper.getMainLooper())
    private val identities = LinkedHashMap<Int, ComponentName>() // never persisted or logged
    private var lease: Lease? = null
    private var donor: WakeMaskInputHost? = null
    private var screenRegistered = false
    private var displayRegistered = false
    private val prefs get() = getSharedPreferences("desktop_mode", MODE_PRIVATE)
    private val modeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        val l = lease
        if (l != null && !modeStillValid(l.key)) abort("mode_changed")
    }
    private val timeout = Runnable { abort("deadline") }
    private val displayReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val l = lease ?: return
            if (i.action == Intent.ACTION_SCREEN_ON) beginOnDeadline(l)
            else if (l.onDeadline > 0) abort("resleep")
        }
    }
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) = Unit
        override fun onDisplayRemoved(id: Int) { if (id == Display.DEFAULT_DISPLAY) abort("display_removed") }
        override fun onDisplayChanged(id: Int) {
            val l = lease ?: return
            if (id != Display.DEFAULT_DISPLAY) return
            when (displayState()) {
                Display.STATE_ON -> beginOnDeadline(l)
                Display.STATE_OFF -> if (l.onDeadline > 0) abort("resleep")
                else -> abort("aod_or_unknown")
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (connected === this) return
        try {
            donor = WakeMaskInputHost(this)
            registerReceiver(displayReceiver, IntentFilter(Intent.ACTION_SCREEN_ON).apply {
                addAction(Intent.ACTION_SCREEN_OFF)
            }, Context.RECEIVER_NOT_EXPORTED)
            screenRegistered = true
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, handler)
            displayRegistered = true
            prefs.registerOnSharedPreferenceChangeListener(modeListener)
            connected = this
        } catch (e: RuntimeException) {
            disconnect()
            Log.w(TAG, "mask_service_unavailable kind=${e.javaClass.simpleName}")
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val id = e.windowId
        if (id >= 0 && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString()
            val c = e.className?.toString()
            if (!p.isNullOrEmpty() && !c.isNullOrEmpty()) {
                identities[id] = ComponentName.createRelative(p, c)
                if (identities.size > 64) identities.remove(identities.keys.first())
            } else identities.remove(id)
        }
        if (e.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED &&
            e.windowChanges and AccessibilityEvent.WINDOWS_CHANGE_REMOVED != 0) identities.remove(id)
        val l = lease ?: return
        // The new clock is above the old app window. Keep the old shield attached until the
        // root observer verifies frame + focus + LOCKED/80. Never reparent it to the new task.
        if (!modeStillValid(l.key)) { abort("mode_changed"); return }
        if (validatedWindow(l.target) == l.id) return
        // Under the authorized transition MainActivity can become focused before CONSUME has
        // persisted CLOCK. Require both the reserved generation and MainActivity's real identity.
        val changing = windows.filter { it.displayId == Display.DEFAULT_DISPLAY }
        val authorized = prefs.getLong("wake_last", -1) == l.key.dark &&
            (handoff(l.key) || prefs.contains("wake_pending"))
        if (authorized && retainDuringSwitch(changing, identities, packageName)) return
        abort("window_changed")
    }

    override fun onInterrupt() = abort("service_interrupted")
    override fun onUnbind(intent: Intent?): Boolean {
        disconnect()
        return super.onUnbind(intent)
    }
    override fun onDestroy() { disconnect(); super.onDestroy() }

    private fun disconnect() {
        if (connected === this) connected = null
        abort("disconnect")
        prefs.unregisterOnSharedPreferenceChangeListener(modeListener)
        if (screenRegistered) { screenRegistered = false; unregisterReceiver(displayReceiver) }
        if (displayRegistered) {
            displayRegistered = false
            getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener)
        }
        identities.clear()
        donor?.close()
        donor = null
    }

    private fun displayState() = getSystemService(DisplayManager::class.java)
        .getDisplay(Display.DEFAULT_DISPLAY)?.state
    private fun handoff(k: Key) = !prefs.getBoolean("android", true) &&
        prefs.getLong("wake_last", -1) == k.dark && prefs.getLong("mode_since", -1) > k.dark
    private fun modeStillValid(k: Key) = ModeState(this).independentLock() &&
        prefs.getInt("boot", -1) == k.boot && (handoff(k) || (prefs.getBoolean("android", false) &&
        prefs.getLong("mode_since", Long.MAX_VALUE) < k.dark))

    private fun validatedWindow(t: Target) = selectWindow(windows, identities, t.page, t.bounds)

    private fun request(k: Key, intent: Intent) {
        val page = intent.getStringExtra("mask_page")?.let(ComponentName::unflattenFromString)
        val rect = Rect(intent.getIntExtra("mask_left", -1), intent.getIntExtra("mask_top", -1),
            intent.getIntExtra("mask_right", -1), intent.getIntExtra("mask_bottom", -1))
        val uid = intent.getIntExtra("mask_uid", -1)
        val task = intent.getIntExtra("mask_task", -1)
        if (page == null || page.packageName == packageName || uid !in 1000..99999 || task < 0 ||
            rect.isEmpty || rect.left < 0 || rect.top < 0 || rect.right > 16384 || rect.bottom > 16384) {
            trace("MASK_REFUSED_AT", k, "malformed_target")
            return
        }
        val target = Target(page, uid, task, rect)
        val l = lease
        if (l != null && k == l.key) {
            if (l.target != target) abort("target_changed")
            else if (displayState() == Display.STATE_ON) beginOnDeadline(l)
            return
        }
        if (l != null && l.key.boot == k.boot && l.key.dark > k.dark) return
        if (l != null) abort("superseded")
        val state = displayState()
        if (!modeStillValid(k) || handoff(k) || !ManagedDesktop(this).owner ||
            !getSystemService(UserManager::class.java).isUserUnlocked ||
            getSystemService(KeyguardManager::class.java).isKeyguardLocked ||
            getSystemService(ActivityManager::class.java).lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE ||
            !(state == Display.STATE_OFF || (state == Display.STATE_ON &&
                getSystemService(PowerManager::class.java).isInteractive))) {
            trace("MASK_REFUSED_AT", k, "mode_display_guard")
            return
        }
        val id = validatedWindow(target)
        val input = donor
        if (id == null || input == null || runCatching { input.token() }.getOrNull() == null) {
            trace("MASK_REFUSED_AT", k, if (id == null) "window_identity_or_bounds" else "input_host_unavailable")
            return
        }
        val active = Lease(k, target, id, WakeMaskSurface(this, input))
        lease = active
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, DARK_MAX)
        if (state == Display.STATE_ON) beginOnDeadline(active)
        try {
            active.surface.attach(id, rect, { lease === active },
                { trace("MASK_ATTACH_REQUESTED_AT", k) }, { trace("MASK_FRAME_COMMITTED_AT", k) })
        } catch (e: RuntimeException) { abort("attach_${e.javaClass.simpleName}") }
    }

    private fun beginOnDeadline(l: Lease) {
        if (l.onDeadline != 0L) return
        l.onDeadline = SystemClock.elapsedRealtime() + ON_MAX
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, ON_MAX)
    }

    private val detaching = mutableSetOf<Key>()
    private fun abort(reason: String) {
        val l = lease ?: return
        lease = null
        handler.removeCallbacks(timeout)
        closeKey(this, l.key)
        detaching.add(l.key)
        try {
            l.surface.release {
                detaching.remove(l.key)
                receipt(this, l.key, reason)
            }
        } catch (e: RuntimeException) {
            trace("MASK_REFUSED_AT", l.key, "cleanup_${e.javaClass.simpleName}")
        }
    }

    companion object {
        const val PREPARE = "com.naozho.clock.action.WAKE_MASK_PREPARE"
        const val CANCEL = "com.naozho.clock.action.WAKE_MASK_CANCEL"
        private const val TAG = "NaozhoWakePerf"
        private const val ON_MAX = 8000L
        private const val DARK_MAX = 24 * 60 * 60 * 1000L
        private var connected: WakeMaskService? = null

        internal fun receive(context: Context, intent: Intent) {
            val k = Key(intent.getIntExtra(EXTRA_BOOT_COUNT, -1), intent.getLongExtra("dark_elapsed", -1))
            val now = SystemClock.elapsedRealtime()
            if (k.boot < 0 || k.boot != bootCount(context) || k.dark !in 1..now) return
            val s = connected
            when (intent.action) {
                CANCEL -> if (intent.identifier == "unmask.$k") {
                    closeKey(context, k)
                    if (s?.lease?.key == k) s.abort("cancel")
                    else if (s == null || k !in s.detaching) receipt(context, k, "already_absent")
                }
                PREPARE -> if (intent.identifier == "mask.$k" && now - k.dark <= DARK_MAX &&
                    !closed(context, k)) {
                    if (s == null) trace("MASK_REFUSED_AT", k, "service_unavailable")
                    else s.request(k, intent)
                }
            }
        }

        internal fun retainDuringSwitch(windows: List<AccessibilityWindowInfo>, identities: Map<Int, ComponentName>,
                                        clockPackage: String): Boolean {
            if (windows.any { (it.isFocused || it.isActive) && it.type != AccessibilityWindowInfo.TYPE_APPLICATION })
                return false
            val candidates = windows.filter { it.isFocused || it.isActive }
            // WMS can publish a short zero-focus interval while the new task is drawn. The
            // child stays on the old window, never covers another window, and the ON deadline
            // still applies. Seeing any other focused app/dialog ends the lease immediately.
            if (candidates.isEmpty()) return true
            val clock = ComponentName(clockPackage, "com.naozho.clock.MainActivity")
            return candidates.all { identities[it.id] == clock && it.parent == null && !it.isInPictureInPictureMode }
        }

        internal fun selectWindow(windows: List<AccessibilityWindowInfo>, identities: Map<Int, ComponentName>,
                                  page: ComponentName, bounds: Rect): Int? {
            val list = windows.filter { it.displayId == Display.DEFAULT_DISPLAY }
            val old = list.singleOrNull { it.isFocused && it.isActive && it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                ?: return null
            if (identities[old.id] != page || old.isInPictureInPictureMode || old.parent != null) return null
            if (list.any { it.id != old.id && it.layer >= old.layer &&
                        (it.type != AccessibilityWindowInfo.TYPE_SYSTEM || it.isFocused || it.isActive) }) return null
            val rect = Rect()
            old.getBoundsInScreen(rect)
            val region = Region()
            old.getRegionInScreen(region)
            if (!region.isRect || region.bounds != rect || !bounds.contains(rect)) return null
            if (rect == bounds) return old.id
            // WMS has already validated every live bar's owner, type and geometry. Some
            // clients expose only the rectangle left after the system bars are subtracted.
            // Require the exact missing area to be explained by separate noninteractive
            // system edge strips, rather than enlarging an arbitrary clipped app window.
            val missing = Region(bounds).apply { op(rect, Region.Op.DIFFERENCE) }
            for (w in list) {
                if (w.type != AccessibilityWindowInfo.TYPE_SYSTEM || w.isFocused || w.isActive || w.layer <= old.layer) continue
                val strip = Region().also { w.getRegionInScreen(it) }
                if (!strip.isRect) continue
                val r = strip.bounds
                if (!bounds.contains(r) || Rect.intersects(rect, r)) continue
                val horizontal = r.left == bounds.left && r.right == bounds.right &&
                    r.height() <= bounds.height() / 8 && (r.top == bounds.top || r.bottom == bounds.bottom)
                val vertical = r.top == bounds.top && r.bottom == bounds.bottom &&
                    r.width() <= bounds.width() / 8 && (r.left == bounds.left || r.right == bounds.right)
                if (horizontal || vertical) missing.op(r, Region.Op.DIFFERENCE)
            }
            return if (missing.isEmpty) old.id else null
        }

        private fun store(c: Context) = c.getSharedPreferences("wake_mask_generation", MODE_PRIVATE)
        private fun closed(c: Context, k: Key) = store(c).let { it.getInt("boot", -1) == k.boot &&
            it.getLong("dark", -1) >= k.dark }
        private fun closeKey(c: Context, k: Key) {
            if (!closed(c, k)) store(c).edit().putInt("boot", k.boot).putLong("dark", k.dark).commit()
        }
        private fun receipt(c: Context, k: Key, reason: String) {
            val f = AtomicFile(File(c.filesDir, "wake-mask.released"))
            try {
                // Async compositor callbacks and protected cancels can cross generations.
                if (f.baseFile.exists()) {
                    val previous = String(f.readFully(), Charsets.US_ASCII).split('.', limit = 2)
                    if (previous.size == 2 && previous[0].toIntOrNull() == k.boot &&
                        (previous[1].toLongOrNull() ?: -1) > k.dark) return
                }
                val out = f.startWrite()
                try { out.write(k.toString().toByteArray(Charsets.US_ASCII)); f.finishWrite(out) }
                catch (e: IOException) { f.failWrite(out); throw e }
                trace("MASK_RELEASED_AT", k, reason)
            } catch (e: IOException) {
                trace("MASK_REFUSED_AT", k, "receipt_io")
            }
        }
        private fun trace(event: String, k: Key, reason: String = "ok") {
            val at = SystemClock.elapsedRealtime()
            Log.i(TAG, "$at $event boot=${k.boot} dark=${k.dark} at=$at reason=$reason")
        }
    }
}
