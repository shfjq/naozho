package com.naozho.clock.mode

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.MotionEvent
import android.view.SurfaceControl
import android.view.SurfaceControlViewHost
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowManager.LayoutParams

/** The embedded window consumes pointer events in its own opaque rectangle. No event data is read. */
internal class BlackTransitionView(context: Context) : View(context) {
    init {
        setBackgroundColor(Color.BLACK)
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        isFocusable = false
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams) {
        // CPDAY10 API 36 SCVH.setView(view,w,h) passes these same public attributes to
        // ViewRootImpl immediately after this setter. Keep the input channel, never key focus.
        require(params is LayoutParams)
        params.flags = params.flags or LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_NOT_TOUCH_MODAL
        check(params.flags and LayoutParams.FLAG_NOT_TOUCHABLE == 0)
        super.setLayoutParams(params)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = true
}

/** Only the target window receives a visible surface. The token donor is invisible, non-touchable
 * and non-focusable. It lets WMS authorize the embedded channel without internal-system permissions. */
internal class WakeMaskInputHost(private val service: AccessibilityService) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private val tokenView = View(service).apply {
        visibility = View.INVISIBLE
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
    }

    init {
        wm.addView(tokenView, LayoutParams(1, 1, LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_NOT_TOUCHABLE or LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT))
    }
    fun token() = tokenView.rootSurfaceControl?.inputTransferToken
    fun close() = wm.removeViewImmediate(tokenView)
}

internal class WakeMaskSurface(private val service: AccessibilityService, private val input: WakeMaskInputHost) {
    private var host: SurfaceControlViewHost? = null
    private var child: SurfaceControlViewHost.SurfacePackage? = null

    fun attach(id: Int, bounds: Rect, current: () -> Boolean, submitted: () -> Unit, committed: () -> Unit) {
        check(host == null && id >= 0 && !bounds.isEmpty)
        val display = requireNotNull(service.getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY))
        val token = requireNotNull(input.token()) { "missing_input_host" }
        val scvh = SurfaceControlViewHost(service, display, token)
        host = scvh
        val view = BlackTransitionView(service)
        scvh.setView(view, bounds.width(), bounds.height())
        val p = requireNotNull(scvh.surfacePackage)
        child = p
        requireNotNull(p.inputTransferToken) { "missing_embedded_input" }
        val sc = p.surfaceControl
        check(sc.isValid && current())
        // Transaction coordinates are local to the old application window, never the display.
        SurfaceControl.Transaction().use {
            it.setLayer(sc, Int.MAX_VALUE).setPosition(sc, 0f, 0f)
                .setCrop(sc, Rect(0, 0, bounds.width(), bounds.height())).setVisibility(sc, true).apply()
        }
        // No clock/overlay window receives focus, and a new app, security dialog, or the clock
        // is naturally above this old window. Android's public attach call returns no receipt.
        service.attachAccessibilityOverlayToWindow(id, sc)
        submitted()
        view.viewTreeObserver.registerFrameCommitCallback { if (current()) committed() }
        view.invalidate()
    }

    fun release(removed: () -> Unit) {
        val pkg = child
        child = null
        var awaitCommit = false
        try {
            if (pkg != null && pkg.surfaceControl.isValid) {
                SurfaceControl.Transaction().use {
                    it.setVisibility(pkg.surfaceControl, false).reparent(pkg.surfaceControl, null)
                        .addTransactionCommittedListener(service.mainExecutor, removed).apply()
                    awaitCommit = true
                }
            }
        } finally {
            try { host?.release() } finally {
                host = null
                pkg?.release()
            }
        }
        if (!awaitCommit) removed()
    }
}
