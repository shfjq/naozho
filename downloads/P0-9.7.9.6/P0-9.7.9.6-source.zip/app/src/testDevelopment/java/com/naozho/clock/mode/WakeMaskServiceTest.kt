package com.naozho.clock.mode

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.graphics.Region
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityWindowInfo
import android.view.MotionEvent
import android.view.WindowManager.LayoutParams
import java.io.File
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.util.ReflectionHelpers
import org.robolectric.util.ReflectionHelpers.ClassParameter
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLog

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class WakeMaskServiceTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val released get() = File(app.filesDir, "wake-mask.released")
    private val boot = 7

    @Before fun setBoot() {
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, boot)
        SystemClock.sleep(20)
    }
    private fun packet(action: String, dark: Long, b: Int = boot) = Intent(action)
        .putExtra(EXTRA_BOOT_COUNT, b).putExtra("dark_elapsed", dark)
        .setIdentifier((if (action == WakeMaskService.CANCEL) "unmask." else "mask.") + "$b.$dark")

    @Test fun cancelWinsOverLatePrepareAndAppProcessRestart() {
        val dark = SystemClock.elapsedRealtime() - 5
        WakeMaskService.receive(app, packet(WakeMaskService.CANCEL, dark))
        assertEquals("$boot.$dark", released.readText())
        assertEquals(dark, app.getSharedPreferences("wake_mask_generation", 0).getLong("dark", -1))
        WakeMaskService.receive(app, packet(WakeMaskService.PREPARE, dark))
        assertFalse(ShadowLog.getLogsForTag("NaozhoWakePerf").any { "MASK_REFUSED_AT" in it.msg })
    }

    @Test fun invalidIdentityWrongBootAndFutureRequestsHaveNoSideEffect() {
        val now = SystemClock.elapsedRealtime()
        WakeMaskService.receive(app, packet(WakeMaskService.CANCEL, now - 1).setIdentifier("mask.$boot.${now - 1}"))
        WakeMaskService.receive(app, packet(WakeMaskService.CANCEL, now - 1, boot - 1))
        WakeMaskService.receive(app, packet(WakeMaskService.CANCEL, now + 8000))
        assertFalse(released.exists())
    }

    @Test fun unavailableServiceNeverClaimsAttachmentOrLaunchesTheClock() {
        WakeMaskService.receive(app, packet(WakeMaskService.PREPARE, SystemClock.elapsedRealtime() - 1))
        val logs = ShadowLog.getLogsForTag("NaozhoWakePerf")
        assertTrue(logs.any { "MASK_REFUSED_AT" in it.msg && "service_unavailable" in it.msg })
        assertFalse(logs.any { "MASK_ATTACH_REQUESTED_AT" in it.msg })
        assertFalse(app.getSharedPreferences("desktop_mode", 0).contains("wake_pending"))
    }

    @Test fun clockRequiresSystemAccessibilityBindingAndExplicitEnablement() {
        val services = app.packageManager.queryIntentServices(Intent(android.accessibilityservice.AccessibilityService.SERVICE_INTERFACE)
            .setPackage(app.packageName), PackageManager.GET_META_DATA)
        val service = services.single { it.serviceInfo.name == WakeMaskService::class.java.name }.serviceInfo
        assertEquals("android.permission.BIND_ACCESSIBILITY_SERVICE", service.permission)
        assertTrue(service.exported)
        assertNotNull(service.metaData)
    }

    @Test fun lateCleanupOfPreviousDarkCannotOverwriteCurrentReceipt() {
        val dark = SystemClock.elapsedRealtime() - 1
        WakeMaskService.receive(app, packet(WakeMaskService.CANCEL, dark))
        WakeMaskService.receive(app, packet(WakeMaskService.CANCEL, dark - 1))
        assertEquals("$boot.$dark", released.readText())
    }

    @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    @Test fun onlyExactApplicationIdentityAndGeometryCanOwnCover() {
        val page = ComponentName("example.test", "example.test.Reader")
        val bounds = Rect(0, 0, 720, 720)
        val old = AccessibilityWindowInfo()
        shadowOf(old).apply {
            setDisplayId(0); setId(19); setType(AccessibilityWindowInfo.TYPE_APPLICATION)
            setFocused(true); setActive(true); setLayer(4); setBoundsInScreen(bounds)
        }
        ReflectionHelpers.callInstanceMethod<Unit>(old, "setRegionInScreen", ClassParameter.from(Region::class.java, Region(bounds)))
        fun selected(list: List<AccessibilityWindowInfo>, p: ComponentName = page, r: Rect = bounds) =
            WakeMaskService.selectWindow(list, mapOf(19 to page), p, r)
        assertEquals(19, selected(listOf(old)))
        assertNull(selected(listOf(old), ComponentName("other.test", "other.test.Reader")))
        assertNull(selected(listOf(old), r = Rect(0, 0, 710, 720)))
        val popup = AccessibilityWindowInfo()
        shadowOf(popup).apply { setId(20); setDisplayId(0); setType(AccessibilityWindowInfo.TYPE_INPUT_METHOD); setLayer(5) }
        assertNull(selected(listOf(old, popup)))
        val clipped = Rect(0, 44, 720, 720)
        shadowOf(old).setBoundsInScreen(clipped)
        ReflectionHelpers.callInstanceMethod<Unit>(old, "setRegionInScreen", ClassParameter.from(Region::class.java, Region(clipped)))
        assertNull(selected(listOf(old)))
        val bar = Rect(0, 0, 720, 44)
        shadowOf(popup).apply { setType(AccessibilityWindowInfo.TYPE_SYSTEM); setBoundsInScreen(bar) }
        ReflectionHelpers.callInstanceMethod<Unit>(popup, "setRegionInScreen", ClassParameter.from(Region::class.java, Region(bar)))
        assertEquals(19, selected(listOf(old, popup)))
        shadowOf(popup).setActive(true)
        assertNull(selected(listOf(old, popup)))
        shadowOf(old).setDisplayId(1)
        assertNull(selected(listOf(old)))
    }

    @Test fun authorizedTaskSwitchCanWaitThroughNoFocusButNotThroughAnIncomingDialog() {
        val info = AccessibilityWindowInfo()
        shadowOf(info).apply { setId(8); setType(AccessibilityWindowInfo.TYPE_APPLICATION); setActive(true); setFocused(true) }
        val id = mapOf(8 to ComponentName(app.packageName, "com.naozho.clock.MainActivity"))
        assertTrue(WakeMaskService.retainDuringSwitch(emptyList(), id, app.packageName))
        assertTrue(WakeMaskService.retainDuringSwitch(listOf(info), id, app.packageName))
        assertFalse(WakeMaskService.retainDuringSwitch(listOf(info), emptyMap(), app.packageName))
        shadowOf(info).setType(AccessibilityWindowInfo.TYPE_SYSTEM)
        assertFalse(WakeMaskService.retainDuringSwitch(listOf(info), id, app.packageName))
    }

    @Test fun childIsOpaqueReceivesTouchesAndCannotRequestKeyFocus() {
        val v = BlackTransitionView(app)
        val lp = LayoutParams(720, 720, LayoutParams.TYPE_APPLICATION, 0, PixelFormat.TRANSLUCENT)
        v.layoutParams = lp
        assertEquals(Color.BLACK, (v.background as ColorDrawable).color)
        assertTrue(lp.flags and LayoutParams.FLAG_NOT_FOCUSABLE != 0)
        assertTrue(lp.flags and LayoutParams.FLAG_NOT_TOUCH_MODAL != 0)
        assertFalse(lp.flags and LayoutParams.FLAG_NOT_TOUCHABLE != 0)
        assertFalse(v.isFocusable)
        for (action in intArrayOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP)) {
            val event = MotionEvent.obtain(1, 2, action, 1f, 1f, 0)
            try { assertTrue(v.dispatchTouchEvent(event)) } finally { event.recycle() }
        }
    }
}
