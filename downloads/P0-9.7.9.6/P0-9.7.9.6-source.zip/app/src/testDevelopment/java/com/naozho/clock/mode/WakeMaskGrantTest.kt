package com.naozho.clock.mode

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.naozho.clock.alarm.AlarmRuntime
import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = AlarmRuntime::class)
class WakeMaskGrantTest {
    private val app: Context get() = RuntimeEnvironment.getApplication()

    private fun prepare(): Intent {
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, 43)
        return Intent(WakeMaskGrant.PREPARE).setIdentifier("mask.43.17")
            .putExtra(EXTRA_BOOT_COUNT, 43).putExtra("dark_elapsed", 17L)
            .putExtra("mask_page", "example.browser/.Main").putExtra("mask_task", 12)
            .putExtra("mask_uid", 10334).putExtra("mask_left", 0).putExtra("mask_top", 0)
            .putExtra("mask_right", 720).putExtra("mask_bottom", 720)
    }

    @Test fun exactPrivateGrantWorksOnlyForExpectedSourceAndCurrentBoot() {
        val request = prepare()
        val grant = File(app.filesDir, "wake-mask.grant")
        grant.delete()
        assertFalse(WakeMaskGrant.accepts(app, request, 0, 20))
        grant.writeText("43|17|example.browser/.Main|12|10334|0|0|720|720")
        assertTrue(WakeMaskGrant.accepts(app, request, 0, 20))
        assertTrue(WakeMaskGrant.accepts(app, request, -1, 20))
        assertFalse(WakeMaskGrant.accepts(app, request, 10191, 20))
        assertFalse(WakeMaskGrant.accepts(app, Intent(request).putExtra("mask_task", 22), 0, 20))
        assertFalse(WakeMaskGrant.accepts(app, Intent(request).putExtra("mask_right", 700), 0, 20))
        assertFalse(WakeMaskGrant.accepts(app, Intent(request).apply { removeExtra("mask_left") }, 0, 20))
        assertFalse(WakeMaskGrant.accepts(app, request, 0, 16))
        Settings.Global.putInt(app.contentResolver, Settings.Global.BOOT_COUNT, 44)
        assertFalse(WakeMaskGrant.accepts(app, request, 0, 20))
    }

    @Test fun protectedReceiverRoutesOnlyValidatedMaskEnvelopes() {
        val request = prepare().setComponent(ComponentName(app, ConfirmedPowerReceiver::class.java))
        // No formal activity launch or proof is created by this visual request.
        val now = android.os.SystemClock.elapsedRealtime().coerceAtLeast(1L)
        request.putExtra("dark_elapsed", now).setIdentifier("mask.43.$now")
        val grant = File(app.filesDir, "wake-mask.grant")
        grant.delete()
        val trace = { org.robolectric.shadows.ShadowLog.getLogsForTag("NaozhoWakePerf")
            .count { "MASK_REFUSED_AT" in it.msg && "reason=service_unavailable" in it.msg } }
        val before = trace()
        val receiver = ConfirmedPowerReceiver()
        receiver.onReceive(app, request)
        assertTrue(trace() == before)
        grant.writeText("43|$now|example.browser/.Main|12|10334|0|0|720|720")
        receiver.onReceive(app, request)
        assertTrue(trace() == before + 1)
        assertFalse(File(app.filesDir, "wake-epoch.proof").exists())
        assertFalse(app.getSharedPreferences("desktop_mode", 0).contains("wake_pending"))
    }

    @Test fun matchingSafetyCancellationSurvivesRevokedGrant() {
        val cancel = prepare().setAction(WakeMaskGrant.CANCEL).setIdentifier("unmask.43.17")
        File(app.filesDir, "wake-mask.grant").delete()
        assertTrue(WakeMaskGrant.accepts(app, cancel, -1, 20))
        assertFalse(WakeMaskGrant.accepts(app, cancel, 10500, 20))
        assertFalse(WakeMaskGrant.accepts(app, cancel.setIdentifier("unmask.43.16"), 0, 20))
    }
}
