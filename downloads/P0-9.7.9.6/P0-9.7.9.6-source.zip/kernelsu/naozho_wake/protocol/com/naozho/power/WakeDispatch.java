package com.naozho.power;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/** One non-launching formal envelope, one proved sender, at most one launch commit per epoch. */
public final class WakeDispatch {
    public interface Ports {
        void guard() throws Exception;
        int sendFormal() throws Exception;
        void publishReceipt() throws Exception;
        int confirmOnce() throws Exception;
        boolean clockFocusedAndLocked() throws Exception;
        void clearReceipt() throws Exception;
    }

    /** Allows the ordered send to finish before the independent, read-only work overlaps. */
    public interface PipelinedPorts extends Ports {
        void dispatchFormal() throws Exception;
        int proveFormal() throws Exception;
        @Override default int sendFormal() throws Exception {
            dispatchFormal();
            return proveFormal();
        }
    }

    private static boolean guardAndProve(PipelinedPorts ports, int expectedUid) throws Exception {
        ports.dispatchFormal();
        FutureTask<Integer> proof = new FutureTask<>(ports::proveFormal);
        Thread reader = new Thread(proof, "wake-formal-proof");
        reader.setDaemon(true);
        reader.start();
        try {
            ports.guard();
            // A slow/retried AMS history read cannot extend the validity of the window
            // snapshot. If the guard finished first, perform a new full guard after proof.
            boolean finishedDuringGuard = proof.isDone();
            if (proof.get() != expectedUid) return false;
            if (!finishedDuringGuard) ports.guard();
            return true;
        } catch (ExecutionException failed) {
            Throwable why = failed.getCause();
            if (why instanceof Exception) throw (Exception) why;
            if (why instanceof Error) throw (Error) why;
            throw new IllegalStateException("wake_proof_worker_failed", why);
        } finally {
            // This worker only reads AMS; cancellation cannot submit or repeat a broadcast.
            proof.cancel(true);
        }
    }

    public static String run(Ports ports, int expectedUid) throws Exception {
        try {
            if (expectedUid != 0 && expectedUid != 2000) return "REFUSED_FORMAL_UID";
            ports.guard();
            if (ports instanceof PipelinedPorts) {
                if (!guardAndProve((PipelinedPorts)ports, expectedUid)) return "REFUSED_FORMAL_UID";
            } else {
                if (ports.sendFormal() != expectedUid) return "REFUSED_FORMAL_UID";
                ports.guard();
            }
            ports.publishReceipt();
            if (ports.confirmOnce() != expectedUid) return "REFUSED_COMMIT_UID";
            return ports.clockFocusedAndLocked() ? "CLOCK_FOCUSED" : "REFUSED_LOCK_OR_FOCUS_UNCONFIRMED";
        } finally { ports.clearReceipt(); }
    }
}
