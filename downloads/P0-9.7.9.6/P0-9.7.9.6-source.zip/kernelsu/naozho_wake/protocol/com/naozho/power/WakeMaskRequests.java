package com.naozho.power;

import java.util.concurrent.Executor;

/** One OFF preparation and one ON opportunity, independent of the formal dispatch executor. */
final class WakeMaskRequests {
    interface Check { void run() throws Exception; }
    interface Ports {
        Check prepare(long dark, boolean on, Check live) throws Exception;
        void cancel(long dark, String reason) throws Exception;
        boolean released(long dark) throws Exception;
        void report(long dark, String stage, String detail);
    }

    private static final class Session {
        final long dark;
        boolean offOffered, onOffered, attempted, closed;
        String closeReason;
        Session(long dark) { this.dark = dark; }
    }
    private final Executor checks, sends;
    private final Ports ports;
    private Session current, owner;
    private long last = -1;
    private Runnable pendingPrepare;
    private long pendingAckDark;
    private String pendingAck;
    private boolean worker;


    WakeMaskRequests(Executor checks, Executor orderedSends, Ports ports) {
        this.checks = checks;
        this.sends = orderedSends;
        this.ports = ports;
    }

    synchronized void offer(long dark, boolean on, Check live) {
        if (dark < 0 || dark < last) return;
        if (dark > last) {
            if (current != null) finish(current.dark, "superseded");
            current = new Session(dark);
            last = dark;
        }
        Session session = current;
        if (session == null || session.closed || (on ? session.onOffered : session.offOffered)) return;
        if (on) session.onOffered = true; else session.offOffered = true;

        // An OEM service can be slow while the display goes dark. The independent ON
        // guard may supersede it; queued/stale work never obtains the next dark's lease.
        checks.execute(() -> {
            try {
                Check stillCurrent = () -> {
                    synchronized (this) {
                        if (session.closed || (!on && session.onOffered)) throw new Stale();
                    }
                    live.run();
                };
                stillCurrent.run();
                Check send = ports.prepare(dark, on, stillCurrent);
                stillCurrent.run();
                synchronized (this) {
                    if (!session.closed && (on || !session.onOffered)) {
                        pendingPrepare = () -> submit(session, on, stillCurrent, send);
                        kick();
                    }
                }
            } catch (Stale ignored) {
                // Reversal, newer display edge or maintenance owns this session now.
            } catch (Exception unavailable) {
                ports.report(dark, "MASK_PREPARE_SKIPPED", failure(unavailable, on));
            }
        });
    }

    private void submit(Session session, boolean on, Check live, Check send) {
        try {
            live.run();
            synchronized (this) {
                if (session.closed || (!on && session.onOffered)) return;
                session.attempted = true;
                // Only the drain thread changes owner, and it always cancels a closed
                // owner before sending anything for the next target.
                owner = session;
            }
            // Any simultaneous finish queues its CANCEL behind this exact operation.
            send.run();
            ports.report(session.dark, "MASK_PREPARE_SENT_AT", on ? "source=on" : "source=off");
        } catch (Stale ignored) {
        } catch (Exception unavailable) {
            ports.report(session.dark, "MASK_PREPARE_UNCONFIRMED", failure(unavailable, on));
        }
    }

    void finish(long dark, String reason) { finish(dark, reason, null); }

    synchronized void finish(long dark, String reason, String verifiedRequest) {
        String evidence = verifiedRequest == null ? null : "request=" + verifiedRequest;
        if (current == null || current.dark != dark) {
            if (evidence != null) ports.report(dark, "HANDOFF_MASK_UNCONFIRMED", evidence);
            return;
        }
        if (!current.closed) {
            current.closed = true;
            current.closeReason = reason;
            pendingPrepare = null;
        }
        if (evidence != null) {
            if (current.attempted) {
                if (pendingAck != null)
                    ports.report(pendingAckDark, "HANDOFF_MASK_UNCONFIRMED", pendingAck);
                pendingAckDark = dark;
                pendingAck = evidence;
            } else {
                ports.report(dark, "HANDOFF_COMPLETE", evidence + " mask=not_requested");
            }
        }
        if (owner == current || pendingAck != null) kick();
    }

    // All callers hold this monitor. At most one underlying Runnable is queued,
    // plus a single latest prepare and receipt read. Cleanup for the sole owner
    // always goes first and cannot be displaced by a burst of display callbacks.
    private void kick() {
        if (!worker) {
            worker = true;
            sends.execute(this::drain);
        }
    }

    private void drain() {
        while (true) {
            Runnable action;
            synchronized (this) {
                if (owner != null && owner.closed) {
                    Session closing = owner;
                    owner = null;
                    action = () -> cancel(closing);
                } else if (pendingAck != null) {
                    final long dark = pendingAckDark;
                    final String evidence = pendingAck;
                    pendingAck = null;
                    action = () -> confirmRelease(dark, evidence);
                } else if (pendingPrepare != null) {
                    action = pendingPrepare;
                    pendingPrepare = null;
                } else {
                    worker = false;
                    return;
                }
            }
            action.run();
        }
    }

    private void cancel(Session session) {
        try {
            ports.cancel(session.dark, session.closeReason);
            ports.report(session.dark, "MASK_CANCEL_SENT_AT", "reason=" + session.closeReason);
        } catch (Exception unavailable) {
            ports.report(session.dark, "MASK_CANCEL_UNCONFIRMED", "reason=" + session.closeReason);
        }
    }

    private void confirmRelease(long dark, String evidence) {
        try {
            if (ports.released(dark)) {
                ports.report(dark, "HANDOFF_COMPLETE", evidence + " mask=released");
                return;
            }
        } catch (Exception unavailable) { /* No positive receipt; preserve the uncertainty. */ }
        ports.report(dark, "HANDOFF_MASK_UNCONFIRMED", evidence);
    }

    synchronized void abort(String reason) {
        if (current != null) finish(current.dark, reason);
    }

    private static String failure(Exception failure, boolean on) {
        String code = failure.getMessage();
        // System exceptions may embed arbitrary window titles/package names. Only known
        // compact internal reason codes cross into the bounded public diagnostics.
        if (code == null || !code.matches("[a-z_]{1,48}")) code = "backend_unavailable";
        return "source=" + (on ? "on" : "off") + " reason=" + code;
    }
    private static final class Stale extends Exception {}
}
