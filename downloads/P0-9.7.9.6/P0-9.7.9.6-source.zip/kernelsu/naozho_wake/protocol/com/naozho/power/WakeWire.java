package com.naozho.power;

/** User-zero, elapsed-realtime wire schema. The formal and commit traces are independently provable. */
public final class WakeWire {
    private final int boot, uid;
    private final long dark, sequence, event;
    public final long expires;
    private final String bootId, id;

    public WakeWire(int boot, String bootId, long dark, long sequence, long event, int uid, String id) {
        this.boot = boot; this.bootId = bootId; this.dark = dark; this.sequence = sequence;
        this.event = event; this.expires = event + 12_000; this.uid = uid; this.id = id;
    }
    private String epoch() { return bootId + "/" + dark + "/" + sequence; }
    public String receipt() { return id + "|" + boot + "|" + epoch() + "|" + event + "|" + expires + "|" + uid; }
    public String trace(String verb) {
        if ("RETURN".equals(verb)) return id;
        if ("COMMIT".equals(verb)) return id + ".commit";
        throw new IllegalArgumentException("unsupported wake verb");
    }
    public String[] extras() {
        return new String[]{"--ei","boot_count",Integer.toString(boot),"--es","boot_id",bootId,
                "--el","dark_elapsed",Long.toString(dark),"--el","event_timestamp",Long.toString(event),
                "--el","expiry",Long.toString(expires),"--el","sequence",Long.toString(sequence),
                "--es","request_id",id,"--ei","sender_uid",Integer.toString(uid),
                "--es","source","DISPLAY_FULL_WAKE","--es","wake_epoch_id",epoch()};
    }
}
