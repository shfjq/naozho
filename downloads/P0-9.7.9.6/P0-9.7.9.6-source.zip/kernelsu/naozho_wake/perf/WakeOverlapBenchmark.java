package com.naozho.power;

import java.util.Arrays;

/**
 * Same ordered send, same delayed read-only operations, same UID and final readback in both
 * arms. Only their coordinator differs. Measures critical-path scheduling on a host JVM.
 */
public final class WakeOverlapBenchmark {
    static final class Request implements WakeDispatch.PipelinedPorts {
        final int proofMs;
        final int guardMs;
        int guards;
        long commitAt;

        Request(int proofMs, int guardMs) { this.proofMs = proofMs; this.guardMs = guardMs; }
        public void guard() throws Exception {
            guards++;
            // First guard is identical for both arms. Time from first send up to COMMIT.
            if (guards > 1) Thread.sleep(guardMs);
        }
        long dispatchedAt;
        public void dispatchFormal() { dispatchedAt = System.nanoTime(); }
        public int proveFormal() throws InterruptedException { Thread.sleep(proofMs); return 0; }
        public void publishReceipt() {}
        public int confirmOnce() { commitAt = System.nanoTime(); return 0; }
        public boolean clockFocusedAndLocked() { return true; }
        public void clearReceipt() {}
    }
    static WakeDispatch.Ports serialized(Request r) {
        return new WakeDispatch.Ports() {
            public void guard() throws Exception { r.guard(); }
            public int sendFormal() throws Exception { return r.sendFormal(); }
            public void publishReceipt() { r.publishReceipt(); }
            public int confirmOnce() { return r.confirmOnce(); }
            public boolean clockFocusedAndLocked() { return r.clockFocusedAndLocked(); }
            public void clearReceipt() { r.clearReceipt(); }
        };
    }
    public static void main(String[] args) throws Exception {
        for (int[] latency : new int[][]{{30,80},{100,35}}) {
            long[][] elapsedUs = new long[2][7];
            int[][] guards = new int[2][7];
            for (int sample = 0; sample < elapsedUs[0].length; sample++) {
                for (int j = 0; j < 2; j++) {
                    int pipeline = (sample+j) % 2; // Alternate order across pairs.
                    Request r = new Request(latency[0],latency[1]);
                    if (!"CLOCK_FOCUSED".equals(WakeDispatch.run(pipeline == 1 ? r : serialized(r),0)))
                        throw new AssertionError("coordinator failed");
                    elapsedUs[pipeline][sample] = (r.commitAt-r.dispatchedAt)/1000;
                    guards[pipeline][sample] = r.guards;
                }
            }
            Arrays.sort(elapsedUs[0]); Arrays.sort(elapsedUs[1]);
            System.out.println("synthetic_proof_ms=" + latency[0] + " synthetic_guard_ms=" + latency[1]
                    + " dispatch_to_commit_serial_median_us=" + elapsedUs[0][3]
                    + " pipeline_median_us=" + elapsedUs[1][3]
                    + " pipeline_guard_counts=" + Arrays.toString(guards[1]));
        }
    }
}
