package com.naozho.power;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.view.accessibility.AccessibilityManager;
import com.naozho.power.TrialChecks.Refused;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Only the protected clock receiver can accept these two fixed mask verbs. */
final class WakeMaskTransport implements WakeMaskRequests.Ports {
    private final WakeBoard board;
    private final Context context;
    private final WakeSystemFacts facts;
    private final WakeWindowReader windows = new WakeWindowReader();
    private final DailyBoard off = new DailyBoard(), on = new DailyBoard();

    WakeMaskTransport(Context context, WakeBoard board) {
        this.context = context;
        this.board = board;
        facts = new WakeSystemFacts(context);
    }

    private void serviceEnabled() throws Refused {
        AccessibilityManager manager = context.getSystemService(AccessibilityManager.class);
        if (manager != null && manager.isEnabled()) {
            ComponentName target = new ComponentName(WakeBoard.PKG, WakeBoard.PKG + ".mode.WakeMaskService");
            for (AccessibilityServiceInfo service : manager.getEnabledAccessibilityServiceList(
                    AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                if (target.equals(ComponentName.unflattenFromString(service.getId()))) return;
            }
        }
        throw new Refused("mask_service_unavailable");
    }

    @Override public WakeMaskRequests.Check prepare(long dark, boolean interactive,
            WakeMaskRequests.Check live) throws Exception {
        board.enabled();
        serviceEnabled();
        // In both phases take a new, complete ordinary-app snapshot. Verify the same
        // owner/window/Activity/task again immediately before the protected broadcast.
        DailyBoard gate = interactive ? on : off;
        final WakeForeground.Task task;
        synchronized (gate) {
            live.run();
            gate.guardedWakeForeground(live::run, () -> board.androidMode(dark),
                    () -> facts.clockIdentity(gate, board.apk), windows, null, context);
            task = gate.guardedTask;
        }
        if (task == null) throw new Refused("mask_task_unverified");
        String boot = Integer.toString(board.boot);
        String grant = boot + "|" + dark + "|" + task.page + "|" + task.taskId + "|" + task.uid + "|"
                + task.left + "|" + task.top + "|" + task.right + "|" + task.bottom;
        return () -> {
            board.enabled();
            if (!WakeBoard.deploymentHint()) throw new Refused("maintenance_paused");
            task.confirm(windows.focus());
            live.run();
            // stop.sh can recover this exact lease even if the daemon dies during dispatch.
            Path tmp = WakeBoard.DIR.resolve("mask-dark.tmp");
            Files.write(tmp, (boot + " " + dark + "\n").getBytes(StandardCharsets.US_ASCII));
            Files.move(tmp, WakeBoard.DIR.resolve("mask-dark"), StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
            DailyBoard.cmd("/system/bin/run-as", WakeBoard.PKG, "/system/bin/sh", "-c",
                    "umask 077; mkdir -p files && printf %s \"$1\" > files/wake-mask.tmp && " +
                    "mv -f files/wake-mask.tmp files/wake-mask.grant", "wake-mask", grant);
            board.enabled();
            live.run();
            Board.dispatch(DeliveryProof.envelope(WakeBoard.PKG + ".action.WAKE_MASK_PREPARE",
                "mask." + boot + "." + dark, "--ei", "boot_count", boot, "--el", "dark_elapsed", Long.toString(dark),
                "--es", "mask_page", task.page, "--ei", "mask_task", Integer.toString(task.taskId),
                "--ei", "mask_uid", Integer.toString(task.uid),
                "--ei", "mask_left", Integer.toString(task.left), "--ei", "mask_top", Integer.toString(task.top),
                "--ei", "mask_right", Integer.toString(task.right), "--ei", "mask_bottom", Integer.toString(task.bottom)));
        };
    }

    @Override public void cancel(long dark, String reason) throws Exception {
        try {
            Board.dispatch(DeliveryProof.envelope(WakeBoard.PKG + ".action.WAKE_MASK_CANCEL",
                "unmask." + board.boot + "." + dark, "--ei", "boot_count", Integer.toString(board.boot),
                "--el", "dark_elapsed", Long.toString(dark)));
        } finally {
            DailyBoard.cmd("/system/bin/run-as", WakeBoard.PKG, "/system/bin/sh", "-c",
                "if [ -f files/wake-mask.grant ]; then IFS='|' read -r b d rest < files/wake-mask.grant; " +
                "if [ \"$b.$d\" = \"$1\" ]; then rm -f files/wake-mask.grant; fi; fi",
                "wake-unmask", board.boot + "." + dark);
        }
    }

    @Override public boolean released(long dark) throws InterruptedException {
        String expected = board.boot + "." + dark;
        for (int i = 0; i < 3; i++) {
            if (i > 0) Thread.sleep(100L * i);
            try {
                if (expected.equals(Board.rawCommand(550, 80, "/system/bin/run-as", WakeBoard.PKG,
                        "/system/bin/cat", "files/wake-mask.released"))) return true;
            } catch (InterruptedException interrupted) {
                throw interrupted;
            } catch (Exception missing) { /* Compositor receipt can arrive after the ordered broadcast. */ }
        }
        return false;
    }

    @Override public void report(long dark, String stage, String detail) {
        WakeDaemon.record(stage + " boot=" + board.boot + " dark=" + dark + " " + detail);
    }
}
