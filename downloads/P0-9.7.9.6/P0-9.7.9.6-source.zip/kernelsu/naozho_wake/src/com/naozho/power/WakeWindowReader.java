package com.naozho.power;

import android.os.Debug;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;
import com.naozho.power.TrialChecks.Refused;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

/** Fixed WMS dump commands, same production parser; no new command or path supplied by clients. */
final class WakeWindowReader implements DailyBoard.WindowSource {
    interface FixedRead { String dump(boolean focus) throws Exception; }
    private final FixedRead binder;
    private final DailyBoard.WindowSource fallback;

    WakeWindowReader() {
        binder = this::read;
        fallback = DailyBoard.SHELL_WINDOWS;
    }

    WakeWindowReader(FixedRead binder, DailyBoard.WindowSource fallback) {
        this.binder = binder;
        this.fallback = fallback;
    }

    // An unavailable OEM WMS transport should cost at most one failed attempt per
    // kind for this observer (apart from an already in-flight read). Shell remains live.
    private volatile boolean focusUnavailable, visibleUnavailable;
    private final ThreadLocal<String> focusSource = new ThreadLocal<>();
    private final ThreadLocal<String> visibleSource = new ThreadLocal<>();

    String guardSources() {
        return " wm_focus=" + focusSource.get() + " wm_visible=" + visibleSource.get();
    }

    private final ThreadPoolExecutor workers = new ThreadPoolExecutor(0, 2, 2, TimeUnit.SECONDS,
            new SynchronousQueue<>(), job -> {
                Thread thread = new Thread(job, "wake-window-binder");
                thread.setDaemon(true);
                return thread;
            });

    // Bounds include the Binder reply: complete EOF on the RAM pipe alone cannot prove success.
    private String read(boolean focus) throws Exception {
        ParcelFileDescriptor[] pair = ParcelFileDescriptor.createPipe();
        Future<Boolean> sent;
        long deadline = SystemClock.elapsedRealtime() + 500;
        try (InputStream input = new ParcelFileDescriptor.AutoCloseInputStream(pair[0])) {
            try {
                sent = workers.submit(() -> {
                    try (ParcelFileDescriptor out = pair[1]) {
                        String[] args = focus ? new String[]{"displays"} : new String[]{"-a","visible"};
                        return Debug.dumpService("window", out.getFileDescriptor(), args);
                    }
                });
            } catch (RejectedExecutionException full) {
                pair[1].close();
                return null;
            }
            // Keep only two fields from displays. Window titles in visible are transient input to
            // the same classifier as dumpsys; neither reply is persisted or copied to diagnostics.
            WakeFocusProjection projection = focus ? new WakeFocusProjection() : null;
            ByteArrayOutputStream raw = focus ? null : new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            StructPollfd poll = new StructPollfd();
            poll.fd = pair[0].getFileDescriptor();
            poll.events = (short)OsConstants.POLLIN;
            StructPollfd[] polls = {poll};
            int total = 0;
            while (true) {
                if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
                long left = deadline - SystemClock.elapsedRealtime();
                if (left <= 0 || Os.poll(polls, (int)left) == 0) return null;
                int n = input.read(buffer);
                if (n < 0) break;
                total += n;
                if (total > 2*1024*1024) throw new Refused("window_binder_size");
                if (focus) projection.append(buffer,n); else raw.write(buffer,0,n);
            }
            if (!sent.get(Math.max(1,deadline-SystemClock.elapsedRealtime()), TimeUnit.MILLISECONDS)) return null;
            return focus ? projection.finish() : raw.toString(StandardCharsets.UTF_8.name());
        } catch (Refused | InterruptedException denied) {
            throw denied;
        } catch (Exception | LinkageError unavailable) {
            return null;
        }
    }

    @Override public String focus() throws Exception {
        String rows = focusUnavailable ? null : binder.dump(true);
        if (rows == null) focusUnavailable = true;
        focusSource.set(rows == null ? "shell" : "binder");
        return rows == null ? fallback.focus() : rows;
    }

    @Override public Foreground.Windows visible(String id) throws Exception {
        String raw = visibleUnavailable ? null : binder.dump(false);
        if (raw == null) visibleUnavailable = true;
        visibleSource.set(raw == null ? "shell" : "binder");
        return raw == null ? fallback.visible(id) : VisibleWindowDump.inspect(raw,id);
    }
}
