package com.naozho.power;

import com.naozho.wakeprobe.WakeEpochManager;
import java.util.Objects;

public final class WakeFlowTest {
    static int count;
    static final String BOOT = "4c01999f-9e11-438a-b9d6-9d7686510478";
    static void equal(Object a, Object b) {
        if (!Objects.equals(a,b)) throw new AssertionError(a + " != " + b);
        count++;
    }
    static String snapshot(String state, long slept, long woke) {
        return "mWakefulness=" + state + "\nmWakefulnessChanging=false\ndisplayGroupId=0\nmLastSleepTime=" +
                slept + "\nmLastWakeTime=" + woke + "\n";
    }
    static final class Transport implements WakeDispatch.Ports {
        int sender=0, commitSender=0, formal, commits, checks, clean;
        boolean ack=true, paused;
        public void guard() throws Exception {
            if (++checks==2 && paused) throw new Exception("maintenance");
        }
        public int sendFormal() { formal++; return sender; }
        public void publishReceipt() { if (formal!=1 || checks!=2) throw new AssertionError(); }
        public int confirmOnce() { commits++; return commitSender; }
        public boolean clockFocusedAndLocked() { return ack; }
        public void clearReceipt() { clean++; }
    }
    public static void main(String[] args) throws Exception {
        WakeEpochManager manager = new WakeEpochManager(38,BOOT);
        manager.observe(2,true,80,100);
        equal(null,manager.settle(snapshot("Awake",5,60),90,110,true));
        manager.observe(1,false,200,250);
        manager.observe(3,false,230,300);
        manager.observe(4,false,232,310);
        equal(null,manager.settle(snapshot("Dozing",190,60),240,320,true));
        manager.observe(2,true,450,3600000);
        equal(null,manager.settle(snapshot("Dreaming",190,440),460,3600010,false));
        WakeEpochManager.Epoch e=manager.settle(snapshot("Awake",190,440),470,3600020,true);
        equal(BOOT+"/250/1",e.id);
        equal(false,WakeEpochManager.stillAwake(snapshot("Awake",471,480),e));
        equal(false,WakeEpochManager.stillAwake(snapshot("Dreaming",190,440),e));
        equal(true,WakeEpochManager.stillAwake(snapshot("Awake",190,440),e));
        for(int i=0;i<5;i++) {
            manager.observe(2,true,500+i,3600100+i);
            equal(null,manager.settle(snapshot("Awake",190,440),510+i,3600120+i,true));
        }
        manager.observe(1,false,600,3600300);
        manager.observe(2,true,720,3600800);
        equal(BOOT+"/3600300/2",manager.settle(snapshot("Awake",590,710),730,3600810,true).id);
        manager.reset(); manager.observe(2,true,800,3600900);
        equal(null,manager.settle(snapshot("Awake",590,710),810,3600910,true));
        Transport ok = new Transport();
        equal("CLOCK_FOCUSED",WakeDispatch.run(ok,0)); equal(1,ok.formal); equal(1,ok.commits); equal(1,ok.clean);
        Transport untrusted=new Transport(); untrusted.sender=2000;
        equal("REFUSED_FORMAL_UID",WakeDispatch.run(untrusted,0)); equal(0,untrusted.commits);
        Transport altered=new Transport(); altered.commitSender=2000;
        equal("REFUSED_COMMIT_UID",WakeDispatch.run(altered,0)); equal(1,altered.commits);
        Transport lost=new Transport(); lost.ack=false;
        equal("REFUSED_LOCK_OR_FOCUS_UNCONFIRMED",WakeDispatch.run(lost,0)); equal(1,lost.commits);
        Transport paused=new Transport(); paused.paused=true;
        try { WakeDispatch.run(paused,0); throw new AssertionError(); }
        catch(Exception failure) { equal("maintenance",failure.getMessage()); }
        equal(0,paused.commits); equal(1,paused.clean);
        System.out.println("wake flow assertions passed="+count);
    }
}
