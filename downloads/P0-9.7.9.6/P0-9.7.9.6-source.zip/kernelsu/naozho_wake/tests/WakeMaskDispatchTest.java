package com.naozho.power;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

public final class WakeMaskDispatchTest {
    static final class Queue implements Executor {
        final ArrayDeque<Runnable> work = new ArrayDeque<>();
        public void execute(Runnable task) { work.add(task); }
        void runAll() { while (!work.isEmpty()) work.removeFirst().run(); }
    }
    static final class Fake implements WakeMaskRequests.Ports {
        final List<String> log = new ArrayList<>();
        boolean failDark, released;
        public WakeMaskRequests.Check prepare(long dark, boolean on, WakeMaskRequests.Check live) throws Exception {
            live.run();
            if (failDark && !on) throw new Exception("focus_unavailable");
            return () -> log.add("prepare " + dark + " " + on);
        }
        public void cancel(long dark, String reason) { log.add("cancel " + dark + " " + reason); }
        public boolean released(long dark) { return released; }
        public void report(long dark, String stage, String detail) { log.add(stage + " " + detail); }
    }
    static void require(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        Queue checks = new Queue(), sends = new Queue();
        Fake p = new Fake(); WakeMaskRequests q = new WakeMaskRequests(checks,sends,p);
        WakeMaskRequests.Check live = () -> {};
        q.offer(10,false,live);
        q.offer(10,false,live);
        q.finish(10,"maintenance"); checks.runAll(); sends.runAll();
        require(p.log.isEmpty());
        q.offer(10,true,live); require(checks.work.isEmpty());
        p.failDark=true;
        q.offer(20,false,live); checks.runAll(); sends.runAll();
        require(p.log.contains("MASK_PREPARE_SKIPPED source=off reason=focus_unavailable"));
        q.offer(20,true,live); q.offer(20,true,live); checks.runAll(); sends.runAll();
        require(p.log.stream().filter(s->s.startsWith("prepare 20")).count()==1);
        q.offer(30,false,live); q.finish(20,"obsolete"); checks.runAll(); sends.runAll();
        require(p.log.contains("cancel 20 superseded") && !p.log.contains("cancel 30 obsolete"));
        q.finish(30,"clock_verified","B");
        require(p.log.contains("HANDOFF_COMPLETE request=B mask=not_requested"));

        p.failDark=false; p.released=false;
        q.offer(40,false,live); checks.runAll(); sends.runAll(); q.finish(40,"clock_verified","C"); sends.runAll();
        require(p.log.contains("HANDOFF_MASK_UNCONFIRMED request=C"));
        require(!p.log.contains("HANDOFF_COMPLETE request=C mask=released"));
        p.released=true;
        q.offer(50,false,live); checks.runAll(); sends.runAll();
        q.finish(50,"clock_verified","D"); sends.runAll();
        require(p.log.indexOf("cancel 50 clock_verified")<p.log.indexOf("HANDOFF_COMPLETE request=D mask=released"));

        q.offer(60,false,live); checks.runAll();  // OFF payload already queued before ON
        q.offer(60,true,live); checks.runAll(); sends.runAll();
        require(!p.log.contains("prepare 60 false") && p.log.contains("prepare 60 true"));
        q.abort("reversed"); q.offer(60,true,live); checks.runAll(); sends.runAll();
        require(p.log.stream().filter(s->s.equals("cancel 60 reversed")).count()==1);
        q.finish(60,"clock_verified","E"); sends.runAll();
        require(p.log.contains("HANDOFF_COMPLETE request=E mask=released"));

        // Formal FULL_WAKE straight from DOZE: no earlier OFF preflight/lease exists.
        q.offer(70,true,live); q.finish(70,"clock_verified","F"); checks.runAll(); sends.runAll();
        require(p.log.contains("HANDOFF_COMPLETE request=F mask=not_requested"));
        // An early reversal closed this unsubmitted lease; FULL_WAKE later in the same dark still completes.
        q.offer(80,false,live); q.abort("display_reversed"); q.finish(80,"clock_verified","G");
        require(p.log.contains("HANDOFF_COMPLETE request=G mask=not_requested"));
        // Stalled wire with many complete newer guard snapshots: pending work is bounded;
        // cleanup of the actual old owner runs before the latest admissible new prepare.
        q.offer(90,false,live); checks.runAll(); sends.runAll();
        for (long dark=100;dark<500;dark++) { q.offer(dark,true,live); checks.runAll(); }
        require(sends.work.size()==1);
        sends.runAll();
        require(p.log.stream().filter(s->s.equals("cancel 90 superseded")).count()==1);
        require(p.log.indexOf("cancel 90 superseded") < p.log.indexOf("prepare 499 true"));
        require(!p.log.contains("prepare 498 true"));

        String wire = new WakeWire(8,"boot",11,2,52,0,"request").receipt();
        require(WakeHandoffEvidence.matches("request",wire,"request\n"+wire));
        require(!WakeHandoffEvidence.matches("request",wire,"request\n"+wire+"\n"));
        require(!WakeHandoffEvidence.matches("request",wire,"old\n"+wire));
        require(!WakeHandoffEvidence.matches("request",wire,"request\n"+wire.replace("boot/11/2","boot/10/2")));
        System.out.println("WakeMaskDispatchTest passed (generation, bounded submissions, reversal, fallback, release and frame receipts)");
    }
}
