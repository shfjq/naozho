package com.naozho.power;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/** Exercise the actual two-phase coordinator with independently controlled guard and proof timing. */
public final class WakePipelineTest {
    static int assertions;

    static void check(boolean condition, String why) {
        if (!condition) throw new AssertionError(why);
        assertions++;
    }

    static void await(CountDownLatch latch) throws InterruptedException {
        if (!latch.await(3, TimeUnit.SECONDS)) throw new AssertionError("phase timed out");
    }

    static final class Request implements WakeDispatch.PipelinedPorts {
        final CountDownLatch guardStarted = new CountDownLatch(1);
        final CountDownLatch proofStarted = new CountDownLatch(1);
        final CountDownLatch releaseProof = new CountDownLatch(1);
        final CountDownLatch proofInterrupted = new CountDownLatch(1);
        boolean slowProof, pauseDuringGuard, pauseAfterProof, malformed;
        int formalCount, guardCount, receipts, commits, readbacks, cleanup, sender = 0;
        volatile Thread proofThread;

        public void guard() throws Exception {
            guardCount++;
            if (guardCount == 2) {
                guardStarted.countDown();
                await(proofStarted);
                if (pauseDuringGuard) throw new Exception("maintenance");
                if (!slowProof) {
                    proofThread.join(3000);
                    if (proofThread.isAlive()) throw new AssertionError("proof did not overlap second guard");
                }
            }
            if (guardCount == 3 && pauseAfterProof) throw new Exception("changed_window");
        }

        public void dispatchFormal() {
            if (guardCount != 1 || ++formalCount != 1) throw new AssertionError("reordered or duplicate RETURN");
        }

        public int proveFormal() throws Exception {
            proofThread = Thread.currentThread();
            proofStarted.countDown();
            try {
                await(guardStarted);
                if (slowProof) await(releaseProof);
            } catch (InterruptedException interrupted) {
                proofInterrupted.countDown();
                throw interrupted;
            }
            if (malformed) throw new Exception("incomplete_terminal_history");
            return sender;
        }

        public void publishReceipt() {
            if (formalCount != 1 || guardCount < 2 || proofThread.isAlive() && !slowProof)
                throw new AssertionError("receipt before proof/guard");
            receipts++;
        }

        public int confirmOnce() {
            if (receipts != 1 || ++commits != 1) throw new AssertionError("illegal commit");
            return 0;
        }

        public boolean clockFocusedAndLocked() { readbacks++; return true; }
        public void clearReceipt() { cleanup++; }
    }

    static void lateProof(boolean changed) throws Exception {
        Request request = new Request();
        request.slowProof = true;
        request.pauseAfterProof = changed;
        FutureTask<String> observation = new FutureTask<>(() -> {
            try { return WakeDispatch.run(request, 0); }
            catch (Exception failed) { return failed.getMessage(); }
        });
        Thread dispatcher = new Thread(observation, "wake-dispatch-under-test");
        dispatcher.start();
        await(request.guardStarted);
        await(request.proofStarted);
        try {
            // The caller has finished guard #2 and is now waiting in FutureTask.get().
            // Holding the proof until then forces the stale-snapshot ordering deterministically.
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(3);
            while (dispatcher.getState() != Thread.State.WAITING && System.nanoTime() < deadline)
                Thread.sleep(1);
            check(dispatcher.getState() == Thread.State.WAITING, "caller did not wait for terminal proof");
            check(request.receipts == 0 && request.commits == 0, "receipt published before proof");
        } finally { request.releaseProof.countDown(); }
        check((changed ? "changed_window" : "CLOCK_FOCUSED").equals(observation.get(3, TimeUnit.SECONDS)),
                "late proof did not honor fresh guard");
        check(request.guardCount == 3 && request.formalCount == 1 && request.cleanup == 1, "stale guard did not rerun exactly once");
        check(request.receipts == (changed ? 0 : 1) && request.commits == request.receipts
                && request.readbacks == request.receipts, "stale gating leaked a receipt or commit");
    }

    public static void main(String[] args) throws Exception {
        Request valid = new Request();
        check("CLOCK_FOCUSED".equals(WakeDispatch.run(valid, 0)), "two independent checks did not overlap");
        check(valid.guardCount == 2 && valid.formalCount == 1 && valid.commits == 1
                && valid.receipts == 1 && valid.readbacks == 1 && valid.cleanup == 1, "duplicate stage");
        Request alternateUid = new Request();
        alternateUid.sender = 2000;
        check("REFUSED_FORMAL_UID".equals(WakeDispatch.run(alternateUid, 0)), "mixed identities");
        check(alternateUid.receipts == 0 && alternateUid.commits == 0, "mixed UID committed");
        Request invalid = new Request();
        invalid.malformed = true;
        try { WakeDispatch.run(invalid, 0); throw new AssertionError("malformed proof accepted"); }
        catch (Exception e) { check("incomplete_terminal_history".equals(e.getMessage()), "lost proof failure"); }
        check(invalid.receipts == 0 && invalid.commits == 0 && invalid.cleanup == 1, "proof failure committed");
        Request paused = new Request();
        paused.slowProof = true;
        paused.pauseDuringGuard = true;
        try { WakeDispatch.run(paused, 0); throw new AssertionError("guard bypassed"); }
        catch (Exception e) { check("maintenance".equals(e.getMessage()), "lost maintenance refusal"); }
        await(paused.proofInterrupted);
        check(paused.receipts == 0 && paused.commits == 0 && paused.cleanup == 1, "paused request committed");
        lateProof(false);
        lateProof(true);
        System.out.println("wake pipeline assertions passed=" + assertions);
    }
}
