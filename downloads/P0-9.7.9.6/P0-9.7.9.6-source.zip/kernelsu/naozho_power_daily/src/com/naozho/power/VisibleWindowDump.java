package com.naozho.power;

import java.util.regex.Pattern;
import com.naozho.power.TrialChecks.Refused;

/** Boundaries and LayoutParams belong to one completed WMS command. Raw text stays in memory. */
final class VisibleWindowDump {
    private static final String HEADER="WINDOW MANAGER WINDOWS (dumpsys window windows)";
    private static final Pattern TITLE=Pattern.compile("WINDOW[ \\t]+MANAGER[ \\t]+WINDOWS(?:[ \\t]*\\(dumpsys[ \\t]+window[ \\t]+(?:windows|visible)\\))?:?");
    private static final Pattern STAMP=Pattern.compile("Dump time[ \\t]*:[ \\t]*[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\\.[0-9]{3}");
    private static final Pattern FOOTER=Pattern.compile("^  mBlurEnabled=(?:true|false)[ \\t]*$");
    private static final Pattern BLOCK=Pattern.compile("^  Window #[0-9]+ Window\\{[0-9a-fA-F]+ u[0-9]+ [^{}\\r\\n]+\\}:[ \\t]*$");
    private static final Pattern STATE=Pattern.compile("^(?:mOwnerUid|mDisplayId|mActivityRecord|isOnScreen|isVisible|mHasSurface|mViewVisibility|mTouchableInsets|touchable region|Frames: parent)=");
    private static final Pattern ATTR=Pattern.compile("^mAttrs[ \\t]*=[ \\t]*\\{");
    private static final Pattern SECTION=Pattern.compile("^  (?:[A-Z][^=]*:|m[A-Za-z0-9]+=[^ ].*)$");
    private static final Pattern FLAGS=Pattern.compile("^(?:fl|flags)[ \\t]*=");
    private int header,footer,blocks;
    private String first="unavailable", status="not_read";

    String diagnostic() {
        return "snapshot_command=dumpsys_window_-a_visible snapshot_first_line="+first+
                " header_found="+(header>0)+" header_line_number="+header+" footer_found="+(footer>0)+
                " footer_line_number="+footer+" snapshot_parse_status="+status+" window_block_count="+blocks;
    }

    static Foreground.Windows inspect(String raw,String focusId) {
        VisibleWindowDump snapshot=new VisibleWindowDump();
        Foreground.Windows result;
        try {
            String projected=snapshot.read(raw);
            result=Foreground.inspectSnapshot(projected,focusId);
            snapshot.status="parsed";
        } catch (Refused invalid) {
            result=new Foreground.Windows();
            snapshot.status=invalid.getMessage();
            result.reject(snapshot.status);
        }
        result.snapshot=snapshot;
        return result;
    }

    static Foreground.Windows readFailure(String reason) {
        Foreground.Windows w=new Foreground.Windows();
        w.snapshot=new VisibleWindowDump();
        w.snapshot.status=reason;
        w.reject(reason);
        return w;
    }

    static String project(String raw) throws Refused { return new VisibleWindowDump().read(raw); }

    private String read(String raw) throws Refused {
        String[] lines=raw.split("\\r?\\n",-1);
        String line0=lines[0].trim();
        if (STAMP.matcher(line0).matches()) first=line0.replaceAll("[ \\t]+","_");
        else if (TITLE.matcher(line0).matches()) first="window_header";
        else first=line0.isEmpty()?"empty":"redacted_prefix";

        // Never join sections across command output, even if both parts have legal markers.
        for (int i=0;i<lines.length;i++) {
            String t=lines[i].trim();
            if (t.startsWith("DUMP TIMEOUT") || t.startsWith("DUMP FAILED")) throw new Refused("window_command_incomplete");
            if (TITLE.matcher(t).matches()) {
                if (header!=0) throw new Refused("duplicate_snapshot_header");
                header=i+1;
            } else if (FOOTER.matcher(lines[i]).matches()) {
                if (footer!=0) throw new Refused("duplicate_snapshot_footer");
                footer=i+1;
            } else if (header!=0 && footer==0 && (t.startsWith("WINDOW MANAGER ") || STAMP.matcher(t).matches())) {
                throw new Refused("window_snapshot_interrupted");
            }
        }
        if (header==0) throw new Refused("window_snapshot_header");
        if (footer==0) throw new Refused("window_snapshot_footer");
        if (header>=footer) throw new Refused("window_snapshot_order");

        boolean inWindow=false,summaries=false,afterBase=false,hasFields=false;
        int depth=0;
        StringBuilder out=new StringBuilder(HEADER).append('\n');
        for (int i=header;i<footer-1;i++) {
            String line=lines[i],trim=line.trim();
            if (trim.startsWith("Window #")) {
                if (!BLOCK.matcher(line).matches() || summaries) throw new Refused("window_block_boundary");
                if (inWindow && !hasFields) throw new Refused("empty_window_block");
                if (depth>0) out.append("    attrs_incomplete=true\n");
                blocks++;
                out.append("  ").append(trim).append('\n');
                depth=0; afterBase=false; hasFields=false; inWindow=true; continue;
            }
            if (line.startsWith("  Hiding System Alert Windows:") || line.startsWith("  Windows force removing:"))
                throw new Refused("windows_unconfirmed");
            if (!inWindow) continue;
            if (STATE.matcher(trim).find()) {
                if (depth>0) out.append("    attrs_incomplete=true\n");
                hasFields=true; depth=0; afterBase=false;
                out.append("    ").append(trim).append('\n'); continue;
            }
            if (ATTR.matcher(trim).find()) {
                out.append("    attrs_line_number=").append(i+1).append('\n');
                depth=0; afterBase=false; hasFields=true;
                out.append("    ").append(trim).append('\n');
            } else if (depth>0 && !SECTION.matcher(line).matches()) {
                out.append(line).append('\n');
            } else if (FLAGS.matcher(trim).find()) {
                // Only the immediately adjacent standalone field belongs to the closed base
                // object. An orphan, duplicate or ambiguous value still vetoes the window.
                if (afterBase) {
                    out.append("    adjacent_flags_line=").append(i+1).append('\n');
                    out.append("    adjacent_flags_value=").append(trim.substring(trim.indexOf('=')+1)).append('\n');
                } else out.append("    orphan_public_flags=true\n");
                afterBase=false; continue;
            } else {
                afterBase=false;
                if (SECTION.matcher(line).matches()) {
                    if (depth>0) out.append("    attrs_incomplete=true\n");
                    depth=0; summaries=true; inWindow=false;
                }
                continue;
            }
            for (int c=0;c<line.length();c++) {
                char ch=line.charAt(c);
                if (ch=='{') depth++;
                else if (ch=='}') {
                    depth--;
                    if (depth<0) throw new Refused("attrs_brace_mismatch");
                    if (depth==0 && !line.substring(c+1).trim().isEmpty())
                        throw new Refused("attrs_trailing_data");
                }
            }
            afterBase=depth==0;
        }
        if (blocks==0 || !hasFields) throw new Refused("empty_window_block");
        if (depth>0) out.append("    attrs_incomplete=true\n");
        return out.append("WMS_WINDOWS_END").toString();
    }
}
