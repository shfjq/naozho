package com.naozho.power;

import java.nio.file.Files;
import java.nio.file.Path;

/** Calls the production WMS projection, classifier and task binding. No package list is installed. */
public final class WakeOrdinaryTest {
    private static final String HEADER="WINDOW MANAGER WINDOWS (dumpsys window windows)\n";
    private static final String END="  mBlurEnabled=true\n";
    private static final String DIALER="test.system.dialer";

    private static String display(String page) {
        return "  mCurrentFocus=Window{f00 u0 "+page+"}\n  mFocusedApp=ActivityRecord{abc u0 "+page+" t3}";
    }

    private static String body(String page,String flags) {
        String pkg=page.substring(0,page.indexOf('/'));
        String window=DailyTest.window(0,"f00",page,pkg,"BASE_APPLICATION",flags);
        return window.replace("    mAttrs=","    mActivityRecord=ActivityRecord{abc u0 "+page+" t3}\n    mAttrs=")
                .replace("frame=[0,0][720,35]","frame=[0,35][720,680]");
    }

    private static WakeForeground.Task check(String page,String body,String display) throws Exception {
        Foreground.Windows w=VisibleWindowDump.inspect(HEADER+body+END,Foreground.focusId(display));
        WakeForeground.Task task=WakeForeground.verify(display,w,page);
        WakeForeground.ordinaryComponent(page,"test.user.dialer",DIALER,false);
        return task;
    }

    private static String sed(String expression, String text) throws Exception {
        Process cmd=new ProcessBuilder("sed","-nE",expression).redirectErrorStream(true).start();
        try (java.io.OutputStream stdin=cmd.getOutputStream()) {
            stdin.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        String out=new String(cmd.getInputStream().readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);
        if (cmd.waitFor()!=0) throw new AssertionError("invalid producer projection");
        return out.trim();
    }

    private static void sources() throws Exception {
        String manager="CallsManager: \n  mCalls: \n";
        String audio="  mCallAudioManager:\n", idle=manager+audio;
        String expr=WakeForeground.CALLS_PROJECTION;
        WakeForeground.confirmNoTelecomCalls(sed(expr,idle));
        DailyTest.ok("exact live Telecom empty call set",true);
        for (String raw:new String[]{manager+"    active private call record\n"+audio,manager+"  mPendingCall:X\n"+audio,
                manager+"  mPendingRedirectedOutgoingCallInfo:X\n"+audio,manager+"  mPendingUnredirectedOutgoingCallInfo:X\n"+audio,
                manager,idle+idle,"Permission Denial",idle+"DUMP TIMEOUT",manager+"OEM unknown\n"+audio}) {
            String projection=sed(expr,raw);
            DailyTest.ok("projection retains no call metadata",!projection.contains("private") && !projection.contains("X"));
            DailyTest.reject("busy, ambiguous or incomplete Telecom record",()->WakeForeground.confirmNoTelecomCalls(projection));
        }
        for (String name:new String[]{"null","","permission denial","multiple.role\nrole.other","None"})
            DailyTest.ok("missing role not a dialer identity",!WakeForeground.dialerName(name));
        String shared="com.android.settings/com.android.settings.SubSettings";
        String action="Intent { act=android.settings.WIFI_SETTINGS flg=0x10000000 cmp=com.android.settings/.SubSettings }";
        String task="  * Hist #0: ActivityRecord{abc u0 "+shared+" t3}\n    "+action+"\n    rootOfTask=false task=Task{x}\n";
        String project=WakeForeground.settingsProjection("abc");
        DailyTest.ok("bound public settings deep link",sed(project,task).equals("ordinary"));
        WakeForeground.ordinaryComponent(shared,DIALER,DIALER,true);
        for (String row:new String[]{task.replace("abc","abd"),task.replace("WIFI_SETTINGS","SECURITY_SETTINGS"),
                task.replace(" }"," (has extras) }"),task.replace(" flg="," dat=private flg=")})
            DailyTest.ok("reject unsafe or ambiguous shared settings host",sed(project,row).isEmpty());
    }

    public static void main(String[] args) throws Exception {
        sources();
        for (String page:new String[]{"org.example.browser/org.example.browser.Page","com.android.documentsui/com.android.documentsui.files.FilesActivity",
                "com.tencent.mobileqq/com.tencent.mobileqq.activity.SplashActivity","com.android.settings/com.android.settings.Settings",
                "org.game/org.game.UnityPlayerActivity","org.video/org.video.Playback","org.some.newapp/org.some.newapp.Main"}) {
            WakeForeground.Task t=check(page,body(page,"HARDWARE_ACCELERATED"),display(page));
            DailyTest.ok("ordinary foreground uses actual task, owner and bounds",
                    t.page.equals(page) && t.uid==10001 && t.taskId==3 && t.top==35 && t.bottom==680 && t.windowId.equals("f00"));
        }
        String page="org.browser/org.browser.Main", raw=body(page,"HARDWARE_ACCELERATED"), display=display(page);
        for (String flag:new String[]{"SECURE","SHOW_WHEN_LOCKED","DISMISS_KEYGUARD","TURN_SCREEN_ON","0x00080000","400000"})
            DailyTest.reject("protected app window "+flag,()->check(page,body(page,flag),display));
        for (String type:new String[]{"INPUT_METHOD","NOTIFICATION_SHADE","SYSTEM_DIALOG","APPLICATION_OVERLAY"})
            DailyTest.reject(type,()->check(page,raw+DailyTest.window(1,"a00","dialog","example.other",type,"HARDWARE_ACCELERATED"),display));
        DailyTest.reject("incomplete owner evidence",()->check(page,raw.replace("mActivityRecord=","missing="),display));
        DailyTest.reject("visible activity task mismatch",()->check(page,raw.replace("taskId=3","taskId=4"),display));
        DailyTest.reject("foreground changes between window and task samples",()->check(page,raw,display.replace("abc u0","bac u0")));
        DailyTest.reject("other user",()->check(page,raw.replace("abc u0","abc u10"),display));
        DailyTest.reject("other display",()->check(page,raw.replace("mDisplayId=0","mDisplayId=1"),display));
        DailyTest.reject("unknown dialer role",()->WakeForeground.ordinaryComponent(page,null,DIALER,false));
        DailyTest.reject("OEM dialer app with neutral name",()->WakeForeground.ordinaryComponent(page,"org.browser",DIALER,false));
        DailyTest.reject("platform credential UI",()->WakeForeground.ordinaryComponent("sys.vendor/sys.vendor.ConfirmDeviceCredential",DIALER,DIALER,false));
        DailyTest.reject("ambiguous settings fragment",()->WakeForeground.ordinaryComponent("com.android.settings/com.android.settings.SubSettings",DIALER,DIALER,false));
        WakeForeground.Task prior=check(page,raw,display);
        DailyTest.reject("last guard catches reopened same activity class in another task",
                ()->prior.confirm(display.replace(" t3}"," t9}")));
        if (args.length==1) {
            // Optional existing local CPDAY10 capture. Keep raw data and foreground package names out of reports.
            String cp=Files.readString(Path.of(args[0]));
            java.util.regex.Matcher h=java.util.regex.Pattern.compile("(?m)^  Window #\\d+ Window\\{([a-f0-9]+) u0 ([a-z0-9.]+/[^{} ]+)\\}:").matcher(cp);
            if (!h.find()) throw new AssertionError("missing real app window");
            java.util.regex.Matcher a=java.util.regex.Pattern.compile("(?m)^    mActivityRecord=ActivityRecord(\\{[^\\r\\n]+\\})").matcher(cp);
            if (!a.find()) throw new AssertionError("missing real app record");
            String f="  mCurrentFocus=Window{"+h.group(1)+" u0 "+h.group(2)+"}\n  mFocusedApp=ActivityRecord"+a.group(1);
            WakeForeground.Task real=WakeForeground.verify(f,VisibleWindowDump.inspect(cp,h.group(1)),Foreground.focus(f));
            DailyTest.ok("CPDAY10 WindowState owner, ActivityRecord, task and bounds correlate",real.taskId>0 && real.uid>0);
        }
    }
}
