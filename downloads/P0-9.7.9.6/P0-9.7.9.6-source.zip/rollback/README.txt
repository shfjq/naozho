Use a copy of this source tree. Run git apply rollback/d4527f7.patch to restore the verified 0.6.18-dev/33 + 1.3.1 source.
The paired rollback APK distributed here is built from those sources with only versionCode = 34 in app/build.gradle.kts, and its accompanying 1.3.1 module pins that APK. Use the original signing identity.
