package com.naozho.mask.timing;

/**
 * Elapsed-realtime millisecond deadlines for one observer boot, called on one serial executor.
 * The host owns window references, visibility evidence, deadline scheduling, and removal.
 * This class cannot launch a window or manufacture a visibility or handoff receipt.
 */
public final class MaskVisibilityTimer {
    public enum Change {
        NONE, PREPARED, RELEASE_PREVIOUS_AND_PREPARE, SCHEDULE, RELEASE
    }

    private enum Phase { IDLE, DARK, CANDIDATE, WAITING_FOR_WINDOW, VISIBLE }

    public static final long VISIBLE_LIMIT_MS = 5000L;
    // Independent safety deadline if a show request never acknowledges its own visible window.
    public static final long SHOW_ACK_LIMIT_MS = 1500L;
    public static final long NO_DEADLINE = -1L;

    private final int boot;
    private long dark = -1L;
    private long lastSample = -1L;
    private long deadline = NO_DEADLINE;
    private Phase phase = Phase.IDLE;

    public MaskVisibilityTimer(int boot) {
        if (boot < 0) throw new IllegalArgumentException("missing boot count");
        this.boot = boot;
    }

    /** Only live OFF edges. The host removes the previous window before acting on a replacement. */
    public Change onDark(int eventBoot, long eventDark) {
        if (eventBoot != boot || eventDark <= dark || eventDark < 0) return Change.NONE;
        boolean replace = phase != Phase.IDLE;
        dark = eventDark;
        lastSample = eventDark;
        deadline = NO_DEADLINE;
        phase = Phase.DARK;
        return replace ? Change.RELEASE_PREVIOUS_AND_PREPARE : Change.PREPARED;
    }

    public void onCandidate(int eventBoot, long eventDark) {
        if (matches(eventBoot, eventDark) && phase == Phase.DARK) phase = Phase.CANDIDATE;
    }

    /** Immediately before the host requests any visible window. No show command is issued here. */
    public Change onShowRequest(int eventBoot, long eventDark, long now, boolean displayOn) {
        if (!matches(eventBoot, eventDark) || phase != Phase.CANDIDATE || !displayOn)
            return Change.NONE;
        return schedule(Phase.WAITING_FOR_WINDOW, now, SHOW_ACK_LIMIT_MS);
    }

    /**
     * Call only after matching the current window identity. The host must observe display ON,
     * window visibility, and a hardware frame commit for the same window. Do not infer this
     * evidence from Activity.onCreate, Activity.onResume, or an accepted start request.
     */
    public Change onWindowSample(int eventBoot, long eventDark, long now,
            boolean displayOn, boolean windowVisible, boolean frameCommitted) {
        if (!matches(eventBoot, eventDark) || phase != Phase.WAITING_FOR_WINDOW)
            return Change.NONE;
        if (now < lastSample || now >= deadline) return release();
        lastSample = now;
        if (!displayOn || !windowVisible || !frameCommitted) return Change.NONE;
        return schedule(Phase.VISIBLE, now, VISIBLE_LIMIT_MS);
    }

    private Change schedule(Phase next, long now, long limit) {
        if (now < lastSample || now > Long.MAX_VALUE - limit) return release();
        phase = next;
        lastSample = now;
        deadline = now + limit;
        return Change.SCHEDULE;
    }

    /** A delayed or superseded host callback cannot remove a different window. */
    public Change onDeadline(int eventBoot, long eventDark, long scheduledDeadline, long now) {
        if (!matches(eventBoot, eventDark) || scheduledDeadline == NO_DEADLINE ||
                scheduledDeadline != deadline) return Change.NONE;
        if (now < lastSample || now >= deadline) return release();
        lastSample = now;
        return Change.SCHEDULE;
    }

    /** For verified same-request handoff, refusal or safety abort. Completion proof is external. */
    public Change end(int eventBoot, long eventDark) {
        return matches(eventBoot, eventDark) ? release() : Change.NONE;
    }

    public Change stop() { return phase == Phase.IDLE ? Change.NONE : release(); }
    public long deadline() { return deadline; }

    private boolean matches(int eventBoot, long eventDark) {
        return phase != Phase.IDLE && boot == eventBoot && dark == eventDark;
    }

    private Change release() {
        phase = Phase.IDLE;
        deadline = NO_DEADLINE;
        // Keep the last generation so straggling events cannot reopen it.
        return Change.RELEASE;
    }
}
