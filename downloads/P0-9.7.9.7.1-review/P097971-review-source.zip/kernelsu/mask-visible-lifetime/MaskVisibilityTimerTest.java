package com.naozho.mask.timing;

import static com.naozho.mask.timing.MaskVisibilityTimer.*;
import static com.naozho.mask.timing.MaskVisibilityTimer.Change.*;

public final class MaskVisibilityTimerTest {
    private static final int BOOT = 37;
    private static final long DARK = 2500L;
    private static final long ON = DARK + 61_000L;
    private static int assertions;

    private static void eq(Object expected, Object actual) {
        assertions++;
        if (!expected.equals(actual)) throw new AssertionError(expected + " != " + actual);
    }

    private static MaskVisibilityTimer prepared() {
        MaskVisibilityTimer timer = new MaskVisibilityTimer(BOOT);
        eq(PREPARED, timer.onDark(BOOT, DARK));
        eq(NO_DEADLINE, timer.deadline());
        eq(NONE, timer.onShowRequest(BOOT, DARK, ON, true));
        timer.onCandidate(BOOT, DARK);
        eq(NO_DEADLINE, timer.deadline());
        return timer;
    }

    private static void darkAndVisibleTimersAreIndependent() {
        MaskVisibilityTimer timer = prepared();
        eq(NONE, timer.onShowRequest(BOOT, DARK, ON, false));
        eq(SCHEDULE, timer.onShowRequest(BOOT, DARK, ON, true));
        long ackLimit = timer.deadline();
        eq(ON + SHOW_ACK_LIMIT_MS, ackLimit);
        eq(NONE, timer.onWindowSample(BOOT, DARK, ON + 5, false, true, true));
        eq(NONE, timer.onWindowSample(BOOT, DARK, ON + 10, true, false, true));
        eq(NONE, timer.onWindowSample(BOOT, DARK, ON + 20, true, true, false));
        eq(SCHEDULE, timer.onWindowSample(BOOT, DARK, ON + 300, true, true, true));
        long visibleLimit = timer.deadline();
        eq(ON + 5300, visibleLimit);
        eq(NONE, timer.onDeadline(BOOT, DARK, ackLimit, ackLimit));
        eq(NONE, timer.onWindowSample(BOOT, DARK, ON + 400, true, true, true));
        timer.onCandidate(BOOT, DARK);
        eq(NONE, timer.onShowRequest(BOOT, DARK, ON + 410, true));
        eq(SCHEDULE, timer.onDeadline(BOOT, DARK, visibleLimit, visibleLimit - 1));
        eq(visibleLimit, timer.deadline());
        eq(RELEASE, timer.onDeadline(BOOT, DARK, visibleLimit, visibleLimit));
        eq(NONE, timer.onDark(BOOT, DARK));
        eq(NONE, timer.onWindowSample(BOOT, DARK, visibleLimit + 2, true, true, true));
        eq(NO_DEADLINE, timer.deadline());
    }

    private static void missingAcknowledgementCannotLeaveAnUnboundedWindow() {
        MaskVisibilityTimer timer = prepared();
        timer.onShowRequest(BOOT, DARK, ON, true);
        long expected = ON + SHOW_ACK_LIMIT_MS;
        eq(SCHEDULE, timer.onDeadline(BOOT, DARK, expected, expected - 1));
        eq(RELEASE, timer.onDeadline(BOOT, DARK, expected, expected + 1));
        eq(NONE, timer.onWindowSample(BOOT, DARK, expected + 2, true, true, true));
        timer = prepared();
        timer.onShowRequest(BOOT, DARK, ON, true);
        eq(RELEASE, timer.onWindowSample(BOOT, DARK, expected, true, true, true));
    }

    private static void isolation() {
        MaskVisibilityTimer timer = prepared();
        timer.onShowRequest(BOOT, DARK, ON, true);
        timer.onWindowSample(BOOT, DARK, ON + 1, true, true, true);
        long priorDeadline = timer.deadline();
        long nextDark = ON + 200;
        eq(RELEASE_PREVIOUS_AND_PREPARE, timer.onDark(BOOT, nextDark));
        eq(NO_DEADLINE, timer.deadline());
        eq(NONE, timer.end(BOOT, DARK));
        eq(NONE, timer.end(BOOT - 1, nextDark));
        eq(NONE, timer.onDeadline(BOOT, DARK, priorDeadline, priorDeadline));
        eq(NONE, timer.onDark(BOOT, DARK));
        eq(NONE, timer.onDark(BOOT - 1, nextDark + 1));
        timer.onCandidate(BOOT, nextDark);
        timer.onShowRequest(BOOT, nextDark, nextDark + 60, true);
        eq(RELEASE, timer.end(BOOT, nextDark));
        eq(NONE, timer.stop());
        eq(NONE, timer.onWindowSample(BOOT, nextDark, nextDark + 100, true, true, true));
    }

    private static void clockAnomalyAndStop() {
        MaskVisibilityTimer timer = prepared();
        eq(RELEASE, timer.onShowRequest(BOOT, DARK, DARK - 1, true));
        timer = prepared();
        eq(RELEASE, timer.onShowRequest(BOOT, DARK, Long.MAX_VALUE, true));
        timer = prepared();
        timer.onShowRequest(BOOT, DARK, ON, true);
        eq(RELEASE, timer.stop());
        eq(NONE, timer.onShowRequest(BOOT, DARK, ON + 20, true));
    }

    public static void main(String[] args) {
        darkAndVisibleTimersAreIndependent();
        missingAcknowledgementCannotLeaveAnUnboundedWindow();
        isolation();
        clockAnomalyAndStop();
        System.out.println(assertions + " timing assertions passed");
    }
}
