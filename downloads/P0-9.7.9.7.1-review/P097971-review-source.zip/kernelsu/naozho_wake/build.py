#!/usr/bin/env python3
"""Build only the reachable wake observer code using the Android SDK R8. No NDK or Root needed."""
import argparse
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
from zipfile import ZipFile
from importlib.util import spec_from_file_location, module_from_spec

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = spec_from_file_location("daily_archive", HERE.parent / "naozho_power_daily/build.py")
helper = module_from_spec(spec)
spec.loader.exec_module(helper)

def sources():
    probe = ROOT / "probes/wake-observer/src/com/naozho/wakeprobe"
    shared = HERE.parent / "naozho_power/src/com/naozho/power"
    return [*HERE.joinpath("protocol").rglob("*.java"), *HERE.joinpath("src").rglob("*.java"), probe/"WakeCycle.java", probe/"PowerEvidence.java", probe/"PowerRead.java",
            *(shared/name for name in ("Board.java", "DeliveryProof.java", "TrialChecks.java")),
            *HERE.parent.joinpath("naozho_power_daily/src").rglob("*.java"),
            *ROOT.joinpath("platform/station/src").rglob("*.java"),
            *ROOT.joinpath("platform/station/android").rglob("*.java")]

def build(args):
    java = Path(os.environ["JAVA_HOME"])/"bin"
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        classes = work/"classes"
        classes.mkdir()
        subprocess.run([java/"javac","--release","11","-cp",args.sdk,"-d",classes,*sorted(sources())],check=True)
        jar = work/"classes.jar"
        jar.write_bytes(helper.archive({p.relative_to(classes).as_posix():p.read_bytes()
                                        for p in classes.rglob("*.class")}))
        rules = work/"rules"
        rules.write_text("-dontobfuscate\n-dontoptimize\n-keep class com.naozho.power.WakeDaemon "
                         "{ public static void main(java.lang.String[]); }\n")
        dex = work/"wake.jar"
        subprocess.run([java/"java","-cp",args.r8,"com.android.tools.r8.R8","--release","--min-api","34",
                        "--pg-conf",rules,"--lib",args.sdk,"--output",dex,jar],check=True)
        with ZipFile(dex) as z:
            data = z.read("classes.dex")
        for forbidden in (b"multi_press_timeout",b"libpowerinput",b"android.intent.action.SCREEN_ON",b"EVIOCGRAB",
                          b"Lcom/naozho/power/TimingSetup;",b"Lcom/naozho/power/DailyInput;"):
            if forbidden in data:
                raise ValueError("unexpected code retained: "+repr(forbidden))
        files = {p.name:p.read_bytes() for p in (HERE/"module").iterdir() if p.is_file()}
        files["wake.jar"] = helper.archive({"classes.dex":data})
        files["clock.sha256"] = (hashlib.sha256(args.apk.read_bytes()).hexdigest()+"\n").encode()
        args.out.write_bytes(helper.archive(files))
if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    for arg in ("sdk","r8","apk","out"):
        parser.add_argument("--"+arg,required=True,type=Path)
    build(parser.parse_args())
