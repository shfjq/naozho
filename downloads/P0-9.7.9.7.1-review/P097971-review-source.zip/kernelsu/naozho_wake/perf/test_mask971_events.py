"""Offline journal replays. Examples spell the 1.5.0 producer's rows; no phone data."""
import unittest

from mask971_events import audit

REQUEST = 'a5a5a5a5-1234-5678-abcd-0123456789ab'
BOOT_ID = '02697316-12a4-5ffa-abcd-112233445566'
KEY = 'boot=18 dark=100'


def rows():
    req = KEY + ' request=' + REQUEST
    return ['99 DARK DARK_OBSERVED', f'100 DARK_OBSERVED_AT {KEY} at=100',
            f'101 MASK_REFUSED_AT {KEY} phase=off reason=stock_no_source_window_attachment',
            '6510 WAKING WAKE_CANDIDATE', f'6511 WAKE_CANDIDATE_AT {KEY} at=6510',
            f'6530 FULL_WAKE_AT {KEY} epoch={BOOT_ID}/100/1 at=6530 via=binder_proto',
            f'6530 RETURN_PENDING_AT {KEY}', f'6531 CLOCK_PREPARING {KEY}',
            f'6540 GUARD1_READY_AT {req} focus_seed=on_edge', f'6560 RETURN_SEND_AT {req}',
            f'6570 GUARD2_READY_AT {req}', f'6580 RETURN_DELIVERED_AT {req} uid=2000',
            f'6600 COMMIT_SEND_AT {req}', f'6610 COMMIT_DELIVERED_AT {req} uid=2000',
            f'6640 ATM_GUARD_READY_AT {req}', f'6660 ACTIVITY_REQUEST_AT {req}',
            f'6670 ROOT_ATM_ACCEPTED_AT {req}', f'7010 CLOCK_FOCUS_LOCK_VERIFIED_AT {req}',
            f'7010 CLOCK_FOCUSED {req}', f'7010 HANDOFF_COMPLETE {req} mask=not_submitted']


def chunk(records):
    return ('\n'.join(records) + '\n').encode('ascii')


def analyze(records):
    return audit([chunk(records)], 18, 100)


class WakeJournalTest(unittest.TestCase):
    def test_rotated_complete_cycle(self):
        log = rows()
        for split in range(1, len(log)):
            result = audit([chunk(log[:split]), chunk(log[split:])], 18, 100)
            self.assertTrue(result['root_journal_chain_consistent'], result['issues'])
            self.assertTrue(result['off_edge_span_over_5s_without_logged_aod'])
            self.assertEqual(result['off_to_on_edge_ms'], 6410)
            self.assertEqual(result['wake_module_mask_disposition'], 'not_submitted')
            self.assertEqual(result['five_second_visible_timeout'], 'requires_mask_visibility_evidence')

    def test_mask_refusal_separate_from_return(self):
        report = analyze(rows()[:-1])
        self.assertFalse(report['root_journal_chain_consistent'])
        self.assertIn('missing:HANDOFF_COMPLETE', report['issues'])
        self.assertIsNone(report['wake_module_mask_disposition'])

    def test_unscoped_refusal_maintenance_stop_restart_and_new_dark(self):
        for payload in ['STOPPED', 'MAINTENANCE_PAUSED', 'REFUSED display_removed',
                        'observer_ready pid=5', 'power_readback REFUSED REFUSED_not_awake',
                        'DARK_OBSERVED_AT boot=18 dark=6500 at=6500']:
            log = rows()
            log.insert(3, '6500 ' + payload)
            self.assertFalse(analyze(log)['root_journal_chain_consistent'], payload)

    def test_stopped_after_completed_does_not_invalidate_previous_cycle(self):
        self.assertTrue(analyze(rows()+['7100 STOPPED'])['root_journal_chain_consistent'])

    def test_doze_not_continuous_off(self):
        log = rows()
        log.insert(3, '300 DOZE AOD_ENTER')
        result = analyze(log)
        self.assertTrue(result['root_journal_chain_consistent'])
        self.assertFalse(result['off_edge_span_over_5s_without_logged_aod'])

    def test_no_dark_after_rotation_or_partial_line(self):
        log = rows()
        self.assertFalse(analyze(log[3:])['root_journal_chain_consistent'])
        self.assertIn('incomplete_journal_line', audit([chunk(log)[:-1]], 18, 100)['issues'])
        self.assertIn('unrecognized_journal_line', audit([b'\xff\x00\n'+chunk(log)], 18, 100)['issues'])

    def test_no_connecting_two_requests_or_uids(self):
        for label, replacement in [('CLOCK_FOCUSED',lambda x:x.replace(REQUEST,BOOT_ID)),
                                   ('COMMIT_DELIVERED_AT',lambda x:x.replace('uid=2000','uid=0')),
                                   ('FULL_WAKE_AT',lambda x:x.replace('/100/1','/101/1')),
                                   ('ROOT_ATM_ACCEPTED_AT',lambda x:x.replace('boot=18','boot=19'))]:
            log = [replacement(x) if x.split()[1] == label else x for x in rows()]
            self.assertFalse(analyze(log)['root_journal_chain_consistent'], label)

    def test_duplicate_delivery_is_not_deduplicated(self):
        log = rows()
        log.insert(12,log[11])
        self.assertIn('duplicate:RETURN_DELIVERED_AT', analyze(log)['issues'])

    def test_equal_millisecond_reversed_order(self):
        log = rows()
        log[-1],log[-2] = log[-2],log[-1]
        self.assertIn('out_of_order',analyze(log)['issues'])

    def test_empty_payload_and_non_lf_separators(self):
        for unexpected in (b'8000  \n', b'8000 STATUS\r\n', b'8000 STATUS\x0b8001 STATUS\n', b'\n'):
            result = audit([chunk(rows()) + unexpected], 18, 100)
            self.assertIn('unrecognized_journal_line', result['issues'])

    def test_each_delivery_must_record_uid(self):
        for verb in ('RETURN', 'COMMIT'):
            log = [line.replace(' uid=2000', '') if f'{verb}_DELIVERED_AT' in line else line for line in rows()]
            self.assertIn('unconfirmed_sender_uid', analyze(log)['issues'])

    def test_missing_or_future_edge(self):
        for value in ['at=7100', 'at=unknown', 'at=6510 at=6510', '']:
            log = [x.replace('at=6510',value) for x in rows()]
            self.assertFalse(analyze(log)['root_journal_chain_consistent'])


if __name__ == '__main__':
    unittest.main()
