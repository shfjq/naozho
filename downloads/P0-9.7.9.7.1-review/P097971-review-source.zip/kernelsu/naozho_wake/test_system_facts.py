#!/usr/bin/env python3
"""Compile the production wake module against an Android SDK and exercise host-readable identity checks."""
import argparse
from pathlib import Path
import os
import subprocess
import tempfile

import build

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--sdk", required=True, type=Path, help="android.jar (API 36)")
available = ("WakeSystemFactsTest", "WakeWindowPathTest", "PreviewDismissQueueTest")
parser.add_argument("--only", nargs="+", choices=available, help="run only selected regression suites")
args = parser.parse_args()
with tempfile.TemporaryDirectory() as tmp:
    suites = args.only or available
    tests = [build.HERE / "tests" / (name + ".java") for name in suites]
    subprocess.run(["javac", "--release", "11", "-cp", str(args.sdk), "-d", tmp, *build.sources(), *tests],
                   check=True)
    for name in suites:
        subprocess.run(["java", "-cp", os.pathsep.join((tmp, str(args.sdk))), "com.naozho.power." + name],
                       check=True)
