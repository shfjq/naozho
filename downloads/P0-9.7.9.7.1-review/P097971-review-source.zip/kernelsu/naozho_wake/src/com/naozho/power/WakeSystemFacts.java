package com.naozho.power;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.UserManager;

import com.naozho.power.TrialChecks.Refused;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** Read-only replacements for pm path, dpm list-owners and am get-current-user in the wake daemon. */
final class WakeSystemFacts {
    private static final String CLOCK = WakeBoard.PKG;
    private static final String ADMIN_CLASS = CLOCK + ".display.ClockDeviceAdmin";
    private final Context context;
    // A stalled OEM Binder must not stall the wake or create unbounded blocked threads.
    private final ThreadPoolExecutor binders = new ThreadPoolExecutor(0, 2, 2, TimeUnit.SECONDS,
            new SynchronousQueue<>(), task -> {
                Thread t = new Thread(task, "wake-identity");
                t.setDaemon(true);
                return t;
            });

    WakeSystemFacts(Context context) {
        this.context = context;
    }

    void ownerUser() throws Exception {
        Boolean owner = read(() -> {
            UserManager users = context.getSystemService(UserManager.class);
            if (users == null) return null;
            return users.isSystemUser() && users.isUserForeground();
        });
        if (owner == null) Board.ownerUser();
        else if (!owner) throw new Refused("not_owner_user");
    }

    void clockIdentity(DailyBoard verifier, String digest) throws Exception {
        String path = read(this::managedClockPath);
        if (path == null) verifier.clockIdentity(digest);
        else verifier.verifyBase(CLOCK, path, digest);
    }

    private String managedClockPath() throws Exception {
        // This Context must describe the system user, as in pm --user 0 and list-owners User 0.
        UserManager users = context.getSystemService(UserManager.class);
        if (users == null || !users.isSystemUser()) return null;
        DevicePolicyManager policy = context.getSystemService(DevicePolicyManager.class);
        if (policy == null) return null;
        if (!policy.isDeviceOwnerApp(CLOCK)) throw new Refused("owner_unconfirmed");
        // isDeviceOwnerApp() alone verifies a package, not its admin component. With ambiguous
        // active admins use the exact user/component result of the existing command.
        List<ComponentName> admins = policy.getActiveAdmins();
        if (admins == null) return null;
        int samePackage = 0;
        boolean exact = false;
        for (ComponentName admin : admins) {
            if (CLOCK.equals(admin.getPackageName())) {
                ++samePackage;
                exact |= ADMIN_CLASS.equals(admin.getClassName());
            }
        }
        if (!uniqueExactAdmin(samePackage, exact)) return null;
        ApplicationInfo info = context.getPackageManager().getApplicationInfo(CLOCK, 0);
        if (!CLOCK.equals(info.packageName) || !info.enabled ||
                (info.flags & ApplicationInfo.FLAG_INSTALLED) == 0) throw new Refused("apk_unconfirmed");
        if (info.splitSourceDirs != null && info.splitSourceDirs.length != 0) throw new Refused("split_apk_unreviewed");
        return info.sourceDir;
    }

    static boolean uniqueExactAdmin(int samePackage, boolean exact) throws Refused {
        if (!exact || samePackage < 1) throw new Refused("owner_unconfirmed");
        return samePackage == 1;
    }

    // null means the framework read was unavailable. Only a fresh shell read can authorize it.
    <T> T read(Callable<T> query) throws Exception {
        Future<T> result;
        try {
            result = binders.submit(query);
        } catch (RejectedExecutionException busy) {
            return null;
        }
        try {
            return result.get(250, TimeUnit.MILLISECONDS);
        } catch (TimeoutException stalled) {
            return null;
        } catch (ExecutionException failed) {
            Throwable cause = failed.getCause();
            if (cause instanceof RuntimeException || cause instanceof PackageManager.NameNotFoundException) return null;
            if (cause instanceof Exception) throw (Exception)cause;
            throw new Refused("identity_read_failed");
        } finally {
            result.cancel(true);
        }
    }
}
