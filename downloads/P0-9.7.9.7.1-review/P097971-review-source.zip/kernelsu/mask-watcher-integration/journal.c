#define _GNU_SOURCE
#include "journal.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <sys/stat.h>
#include <unistd.h>

/* WakeDaemon.record rotates after 32768 bytes, emits at most 200 characters of
 * payload, and appends an elapsedRealtime prefix plus LF in each write. */
#define JOURNAL_LIMIT 65536
#define ROW_LIMIT 224
#define WATCH_FLAGS (IN_CLOSE_WRITE | IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO | IN_DELETE_SELF | IN_MOVE_SELF)

enum phase { IDLE, DARK, CANDIDATE, FULL, RETURN_SENT, RETURN_PROVED, COMMIT_SENT,
    COMMIT_PROVED, FOCUS_VERIFIED, FOCUSED, HANDOFF };
struct mask_journal {
    int dir, notify, file, boot;
    off_t offset;
    unsigned char tail[32];
    size_t tail_size;
    char row[ROW_LIMIT];
    size_t used;
    bool skip_line;
    enum phase phase;
    int sender_uid;
    int64_t dark, latest, dark_at, candidate_at;
    char request[37];
};
const char *mask_audit_name(enum mask_audit_state state) {
    static const char *const names[] = {"DARK_OBSERVED", "WAKE_CANDIDATE", "FULL_WAKE",
        "CLOCK_FOCUSED", "HANDOFF_COMPLETE", "REFUSED", "STOPPED", "JOURNAL_GAP"};
    return (unsigned)state < sizeof(names)/sizeof(*names) ? names[state] : "UNKNOWN";
}
static void invalidate(struct mask_journal *j, mask_audit_sink sink, void *arg, enum mask_audit_state why) {
    j->phase = IDLE;
    j->request[0] = 0;
    j->sender_uid = -1;
    sink(arg, why);
}
static bool number(const char *s, int64_t *out) {
    int64_t n = 0;
    if (!s || !*s || (s[0] == '0' && s[1])) return false;
    for (; *s; s++) {
        if (*s < '0' || *s > '9' || n > (INT64_MAX-(*s-'0')) / 10) return false;
        n = n * 10 + (*s-'0');
    }
    *out = n;
    return true;
}
static const char *value(char *field, const char *prefix) {
    size_t n = strlen(prefix);
    return field && !strncmp(field,prefix,n) ? field+n : NULL;
}
static bool uuid(const char *s) {
    if (!s || strlen(s) != 36) return false;
    for (int i=0; i<36; i++) {
        if (i==8||i==13||i==18||i==23) { if (s[i]!='-') return false; }
        else if (!(s[i]>='0' && s[i]<='9') && !(s[i]>='a' && s[i]<='f')) return false;
    }
    return true;
}
static bool epoch_id(char *field, int64_t dark) {
    char *s = (char *)value(field,"epoch=");
    if (!s) return false;
    char *first = strchr(s,'/');
    if (!first) return false;
    *first++ = 0;
    char *second = strchr(first,'/');
    if (!second) return false;
    *second++ = 0;
    int64_t d, seq;
    return uuid(s) && number(first,&d) && d==dark && number(second,&seq) && seq>0;
}
/* Positive evidence is a strict subset of the real producer's messages,
 * not a protocol the caller supplies to a privileged actuator. */
static void consume(struct mask_journal *j, mask_audit_sink sink, void *arg) {
    char *words[12], *pos=j->row;
    size_t n=0;
    if (!j->used || pos[0]==' ' || pos[j->used-1]==' ' || strstr(pos,"  ")) goto gap;
    while (pos && n<12) { words[n++]=pos; pos=strchr(pos,' '); if (pos) *pos++=0; }
    int64_t when;
    if (n<2 || !number(words[0],&when) || when<j->latest) goto gap;
    j->latest=when;
    const char *op=words[1];
    if (!strcmp(op,"observer_ready") || !strcmp(op,"STOPPED") ||
        !strcmp(op,"observer_unregistered") || !strcmp(op,"MAINTENANCE_PAUSED")) {
        invalidate(j,sink,arg,MASK_AUDIT_STOPPED); return;
    }
    if (!strcmp(op,"REFUSED") || !strncmp(op,"REFUSED_",8) || !strcmp(op,"ALREADY_CLOCK") ||
        (n>=3 && !strcmp(op,"power_readback") && !strcmp(words[2],"REFUSED"))) {
        invalidate(j,sink,arg,MASK_AUDIT_REFUSED); return;
    }
    if ((!strcmp(op,"DOZE") || !strcmp(op,"DOZE_SUSPEND") || !strcmp(op,"DARK") ||
         (!strcmp(op,"WAKING") && n>=3 && !strcmp(words[2],"ON_WITHOUT_DARK"))) &&
        j->phase>=CANDIDATE && j->phase<HANDOFF) {
        invalidate(j,sink,arg,MASK_AUDIT_REFUSED); return;
    }
    struct step { const char *name; enum phase after; };
    static const struct step steps[]={
        {"DARK_OBSERVED_AT",DARK},{"WAKE_CANDIDATE_AT",CANDIDATE},{"FULL_WAKE_AT",FULL},
        {"RETURN_SEND_AT",RETURN_SENT},{"RETURN_DELIVERED_AT",RETURN_PROVED},
        {"COMMIT_SEND_AT",COMMIT_SENT},{"COMMIT_DELIVERED_AT",COMMIT_PROVED},
        {"CLOCK_FOCUS_LOCK_VERIFIED_AT",FOCUS_VERIFIED},{"CLOCK_FOCUSED",FOCUSED},
        {"HANDOFF_COMPLETE",HANDOFF}
    };
    size_t i=0;
    while (i<sizeof(steps)/sizeof(*steps) && strcmp(op,steps[i].name)) i++;
    if (i==sizeof(steps)/sizeof(*steps)) return; /* includes stock MASK_REFUSED_AT */
    enum phase next=steps[i].after;
    int64_t boot,dark,at;
    if (n<5 || !number(value(words[2],"boot="),&boot) || boot>INT_MAX ||
        !number(value(words[3],"dark="),&dark) || dark>when ||
        (j->boot>=0 && j->boot!=boot)) goto gap;
    if (next==DARK) {
        if (n!=5 || !number(value(words[4],"at="),&at) || at<dark || at>when) goto gap;
        if (dark==j->dark) return;
        if (dark<j->dark) goto gap;
        j->boot=(int)boot; j->dark=dark; j->dark_at=at; j->phase=DARK; j->request[0]=0;
        sink(arg,MASK_AUDIT_DARK); return;
    }
    if (j->phase==IDLE || dark<j->dark) return;
    if (dark!=j->dark || next!=j->phase+1) goto gap;
    if (next==CANDIDATE) {
        if (n!=5 || !number(value(words[4],"at="),&at) || at<j->dark_at || at>when) goto gap;
        j->candidate_at=at;
        sink(arg,MASK_AUDIT_CANDIDATE);
    } else if (next==FULL) {
        if (n!=7 || !epoch_id(words[4],dark) || !number(value(words[5],"at="),&at) ||
            at<j->candidate_at || at>when || (strcmp(words[6],"via=binder") &&
            strcmp(words[6],"via=binder_proto") && strcmp(words[6],"via=dumpsys"))) goto gap;
        sink(arg,MASK_AUDIT_FULL);
    } else {
        const char *req=value(words[4],"request=");
        if (!uuid(req) || (next!=RETURN_SENT && strcmp(j->request,req))) goto gap;
        if (next==RETURN_SENT) memcpy(j->request,req,37);
        if (next==RETURN_PROVED || next==COMMIT_PROVED) {
            int64_t uid;
            if (n!=6 || !number(value(words[5],"uid="),&uid) || (uid!=0 && uid!=2000)) goto gap;
            if (next==COMMIT_PROVED && uid!=j->sender_uid) goto gap;
            j->sender_uid=(int)uid;
        } else if (next==HANDOFF) {
            if (n!=6 || strcmp(words[5],"mask=not_submitted")) goto gap;
            sink(arg,MASK_AUDIT_HANDOFF);
        } else if (n!=5) goto gap;
        if (next==FOCUSED) sink(arg,MASK_AUDIT_FOCUSED);
    }
    j->phase=next; return;
gap:
    invalidate(j,sink,arg,MASK_AUDIT_GAP);
}
static int secure_file(struct mask_journal *j,const char *name) {
    int fd=openat(j->dir,name,O_RDONLY|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK);
    struct stat st;
    if (fd<0) return -1;
    if (fstat(fd,&st)<0 || !S_ISREG(st.st_mode) || st.st_uid!=geteuid() || (st.st_mode&022)) {
        close(fd); errno=EPERM; return -1;
    }
    return fd;
}
static bool same_file(int a,int b) {
    struct stat x,y;
    return a>=0 && b>=0 && !fstat(a,&x) && !fstat(b,&y) && x.st_ino==y.st_ino && x.st_dev==y.st_dev;
}
static int remember(struct mask_journal *j) {
    j->tail_size=j->offset<(off_t)sizeof(j->tail)?(size_t)j->offset:sizeof(j->tail);
    return !j->tail_size || pread(j->file,j->tail,j->tail_size,j->offset-(off_t)j->tail_size)==(ssize_t)j->tail_size ? 0:-1;
}
static int attach(struct mask_journal *j,int newfd,bool skip) {
    if (j->file>=0) close(j->file);
    j->file=newfd; j->used=0; j->offset=0; j->skip_line=false; j->tail_size=0;
    if (newfd<0 || !skip) return 0;
    j->offset=lseek(newfd,0,SEEK_END);
    if (j->offset<0 || remember(j)<0) return -1;
    j->skip_line=j->tail_size && j->tail[j->tail_size-1]!='\n';
    return 0;
}
static int read_available(struct mask_journal *j,mask_audit_sink sink,void *arg) {
    struct stat st;
    unsigned char verify[32],buf[4096];
    if (fstat(j->file,&st)<0) return -1;
    if (st.st_size<j->offset || st.st_size-j->offset>JOURNAL_LIMIT ||
        (j->tail_size && (pread(j->file,verify,j->tail_size,j->offset-(off_t)j->tail_size)!=(ssize_t)j->tail_size ||
                           memcmp(verify,j->tail,j->tail_size)))) {
        invalidate(j,sink,arg,MASK_AUDIT_GAP);
        j->used=0; j->offset=st.st_size;
        if (remember(j)<0) return -1;
        j->skip_line=j->tail_size && j->tail[j->tail_size-1]!='\n';
        return 0;
    }
    while (j->offset<st.st_size) {
        size_t want=(size_t)(st.st_size-j->offset);
        if (want>sizeof(buf)) want=sizeof(buf);
        ssize_t count=pread(j->file,buf,want,j->offset);
        if (count<=0) return -1;
        for (ssize_t i=0;i<count;i++) {
            unsigned char c=buf[i];
            if (c=='\n') {
                if (!j->skip_line) { j->row[j->used]=0; consume(j,sink,arg); }
                j->used=0; j->skip_line=false;
            } else if (!j->skip_line) {
                if (c<32 || c>126 || j->used+1>=sizeof(j->row)) {
                    invalidate(j,sink,arg,MASK_AUDIT_GAP); j->skip_line=true; j->used=0;
                } else j->row[j->used++]=(char)c;
            }
        }
        j->offset+=count;
    }
    return remember(j);
}
void mask_journal_close(struct mask_journal *j) {
    if (!j) return;
    if (j->file>=0) close(j->file);
    if (j->dir>=0) close(j->dir);
    if (j->notify>=0) close(j->notify);
    free(j);
}
struct mask_journal *mask_journal_open(const char *path,int expected_boot) {
    struct mask_journal *j=calloc(1,sizeof(*j));
    if (!j) return NULL;
    j->file=-1; j->notify=-1; j->boot=expected_boot; j->dark=-1; j->latest=-1;
    j->dir=open(path,O_DIRECTORY|O_RDONLY|O_NOFOLLOW|O_CLOEXEC);
    struct stat st;
    if (j->dir<0 || fstat(j->dir,&st)<0 || st.st_uid!=geteuid() || (st.st_mode&022)) goto fail;
    j->notify=inotify_init1(IN_NONBLOCK|IN_CLOEXEC);
    if (j->notify<0 || inotify_add_watch(j->notify,path,WATCH_FLAGS|IN_ONLYDIR|IN_DONT_FOLLOW)<0) goto fail;
    struct stat watched;
    if (lstat(path,&watched)<0 || st.st_ino!=watched.st_ino || st.st_dev!=watched.st_dev) goto fail;
    int fd=secure_file(j,"events");
    if (fd<0 && errno!=ENOENT) goto fail;
    if (attach(j,fd,true)<0) goto fail;
    return j;
fail:
    mask_journal_close(j); return NULL;
}
int mask_journal_fd(const struct mask_journal *j) { return j->notify; }
int mask_journal_drain(struct mask_journal *j,mask_audit_sink sink,void *arg) {
    union { struct inotify_event align; unsigned char bytes[16384]; } buf;
    bool changed=false,created=false,ambiguous=false;
    unsigned rotations=0;
    for (int batches=0;;batches++) {
        ssize_t n=read(j->notify,buf.bytes,sizeof(buf.bytes));
        if (n<0 && errno==EINTR) continue;
        if (n<0 && errno==EAGAIN) break;
        if (n<=0 || batches>=32) goto fail;
        for (size_t i=0;i<(size_t)n;) {
            struct inotify_event *e=(void *)(buf.bytes+i);
            if (e->mask&(IN_Q_OVERFLOW|IN_UNMOUNT|IN_IGNORED|IN_DELETE_SELF|IN_MOVE_SELF)) goto fail;
            if (e->len && !strcmp(e->name,"events")) {
                changed=true;
                if (e->mask&IN_CREATE) created=true;
                if (e->mask&IN_MOVED_FROM) rotations++;
                if (e->mask&(IN_DELETE|IN_MOVED_TO)) ambiguous=true;
            }
            i+=sizeof(*e)+e->len;
        }
    }
    if (!changed) return 0;
    int now=secure_file(j,"events");
    if (now<0 && errno!=ENOENT) goto fail;
    if (rotations>1) ambiguous=true;
    if (j->file>=0 && !same_file(j->file,now) && !ambiguous) {
        int previous=secure_file(j,"events.1");
        if (!same_file(j->file,previous)) ambiguous=true;
        if (previous>=0) close(previous);
    }
    if (ambiguous) {
        invalidate(j,sink,arg,MASK_AUDIT_GAP);
        return attach(j,now,true);
    }
    if (j->file>=0 && read_available(j,sink,arg)<0) {
        if (now>=0) close(now);
        goto fail;
    }
    if (now<0) return 0; /* rotation gap: keep old descriptor until successor arrives */
    if (same_file(j->file,now)) { close(now); return 0; }
    if (j->used || j->skip_line || !created) {
        invalidate(j,sink,arg,MASK_AUDIT_GAP);
        return attach(j,now,true);
    }
    if (attach(j,now,false)<0 || read_available(j,sink,arg)<0) goto fail;
    return 0;
fail:
    invalidate(j,sink,arg,MASK_AUDIT_GAP);
    return -1;
}
