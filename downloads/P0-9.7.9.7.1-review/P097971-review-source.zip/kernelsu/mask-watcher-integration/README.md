# KernelSU 观察进程的生命周期验证

本目录是 P0-9.7.9.7.1 的离线开发件，用于验证启动、唯一实例、关闭和异常退出。它通过 inotify 观察现有 `/data/adb/modules/naozho_wake/events`，从启动时文件末尾开始处理新行，记录脱敏阶段及计数。不会复制原始事件行。完整事件审查工具见 `../naozho_wake/perf/mask971_events.py`。

## 启动与停止

已核对 KernelSU v3.3.1 模块手册。只有已启用的模块才会执行 `service.sh`，该阶段与余下开机过程并行。本组件在该入口调用固定程序。程序打开根用户所有且不可由组或其他用户写入的模块目录，要求同样受保护的 `audit.enabled` 文件，取得独占文件锁，再 fork、setsid、关闭标准输入输出。父启动程序随即退出；子进程拥有自己的会话，单独负责监督观察进程。纯用户态实现不会绕开内核 cgroup 或 SELinux。必须由 KernelSU 自己的启动阶段提供执行上下文；从 ADB 启动时 setsid 无法改变其 cgroup 来源。[KernelSU v3.3.1 官方模块手册](https://github.com/tiann/KernelSU/blob/v3.3.1/website/docs/guide/module.md#boot-scripts)

控制进程阻塞等待 inotify 和 signalfd。对模块的 `disable`、`remove`、`audit.stop`、删除 `audit.enabled`、模块目录移动/删除、inotify 溢出或关闭均停止。子观察进程异常退出后，同一监督进程生命期内最多启动三次；监督进程死亡时，内核的父进程死亡信号结束其子进程。正常停止路径会回收子进程。状态文件只保存最后一次固定格式状态，不积累历史。重新开机时由 KernelSU 重新执行 service 阶段。

`stop-audit.sh` 调用程序唯一支持的参数 `--stop`，撤销审查标记并等待监督进程回收子进程和释放锁。等待超过 3 秒会报告失败。真正的黑屏 owner 仍须执行现有 HIDE，并保有独立的可见阶段超时。这里不注册 Android 组件，不显示窗口，也不产生 RETURN。该目录没有 module.prop，不应打包部署为 naozho_mask 更新。集成到真实模块前需匹配已验证的 watcher、SHOW/HIDE 调用方式、模块原有禁用卸载钩子及黑屏 APK 的可见证明。

## 离线复现

在有 C 编译器的 Linux 主机上运行：

```sh
python3 -B test_lifecycle.py -v
```

生命周期测试使用与 Android 版本相同的 C 代码，主机限定开关只允许使用临时目录和当前 UID。测试包括 12 个并发启动、结束启动进程组后的独立观察、禁用/移除/撤销、异常重试上限及父进程死亡。运行时内核、UID 和 SELinux 域属于测试主机。没有在 CPDAY10 上验证 KSU 开机执行、重启恢复、息屏超过 5 秒或触摸。

使用 Android NDK r27d 构建独立的 arm64 可执行文件：

```sh
"$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android35-clang" \
  -std=c11 -Wall -Wextra -Werror -Os -fPIE -pie -Wl,-z,max-page-size=16384 \
  -Wl,-z,relro,-z,now watcher.c journal.c -o watcher-audit
```

实际产物为 Android API 35 AArch64 PIE，由 `/system/bin/linker64` 加载，依赖系统的 libdl 与 libc。本轮仅验证编译及 ELF 格式，未推送至设备。
