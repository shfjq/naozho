#ifndef NAOZHO_MASK_JOURNAL_H
#define NAOZHO_MASK_JOURNAL_H

/* Metadata-only observations of naozho_wake 1.5.0. None authorize a window,
 * prove a visible mask, or provide a command interface. */
enum mask_audit_state {
    MASK_AUDIT_DARK, MASK_AUDIT_CANDIDATE, MASK_AUDIT_FULL, MASK_AUDIT_FOCUSED,
    MASK_AUDIT_HANDOFF, MASK_AUDIT_REFUSED, MASK_AUDIT_STOPPED, MASK_AUDIT_GAP
};
struct mask_journal;
typedef void (*mask_audit_sink)(void *arg, enum mask_audit_state state);
const char *mask_audit_name(enum mask_audit_state state);
/* The live cursor starts at EOF. -1 pins the first fresh boot_count observed.
 * Only the root-owned, fixed module path is passed by the on-device caller. */
struct mask_journal *mask_journal_open(const char *dir, int expected_boot);
int mask_journal_fd(const struct mask_journal *j);
/* Poll fd for POLLIN. Zero on success, -1 on unhealthy transport (reopen at EOF). */
int mask_journal_drain(struct mask_journal *j, mask_audit_sink sink, void *arg);
void mask_journal_close(struct mask_journal *j);
#endif
