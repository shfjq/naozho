#!/system/bin/sh
# Hook from the verified module's own stop/uninstall path before removal.
# Existing mask HIDE and its independent visible lease remain its responsibility.
umask 077
exec /data/adb/modules/naozho_mask/bin/watcher-audit --stop
