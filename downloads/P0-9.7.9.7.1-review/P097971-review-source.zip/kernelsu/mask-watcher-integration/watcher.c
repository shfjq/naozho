/* KSU integration harness. Fixed read-only observer; no IPC from applications,
 * no signals to arbitrary PIDs, no shell execution and no window operations. */
#define _GNU_SOURCE
#include "journal.h"
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/inotify.h>
#include <sys/prctl.h>
#include <sys/signalfd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define WATCH_MASK (IN_CREATE | IN_CLOSE_WRITE | IN_DELETE | IN_MOVED_TO | IN_MOVED_FROM | IN_DELETE_SELF | IN_MOVE_SELF)
static int module;
static const char *wake_dir = "/data/adb/modules/naozho_wake";
static const char *module_dir = "/data/adb/modules/naozho_mask";
static uid_t owner;

static bool regular_private_file(const char *name) {
    struct stat st;
    return fstatat(module, name, &st, AT_SYMLINK_NOFOLLOW) == 0 &&
        S_ISREG(st.st_mode) && st.st_uid == owner && !(st.st_mode & 022);
}

static bool absent(const char *name) {
    struct stat st;
    return fstatat(module, name, &st, AT_SYMLINK_NOFOLLOW) < 0 && errno == ENOENT;
}

static bool enabled(void) {
    return regular_private_file("audit.enabled") && absent("disable") && absent("remove") && absent("audit.stop");
}

/* Each file has one writer. Never accumulate raw journal lines or unbounded logs. */
static bool status(const char *name, const char *phase, pid_t child, unsigned count) {
    const char *tmp = strcmp(name, "audit.status") == 0 ? ".audit.status.tmp" : ".audit.worker.tmp";
    int fd = openat(module, tmp, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return false;
    int n = dprintf(fd, "%s pid=%d child=%d count=%u\n", phase, (int)getpid(), (int)child, count);
    int rc = close(fd);
    return n > 0 && rc == 0 && renameat(module, tmp, module, name) == 0;
}

static int watch_directory(const char *dir, uint32_t mask) {
    int fd = inotify_init1(IN_CLOEXEC);
    if (fd >= 0 && inotify_add_watch(fd, dir, mask | IN_ONLYDIR | IN_DONT_FOLLOW) >= 0) return fd;
    if (fd >= 0) close(fd);
    return -1;
}

static bool control_marker(const char *name) {
    return !strcmp(name, "disable") || !strcmp(name, "remove") ||
        !strcmp(name, "audit.stop") || !strcmp(name, "audit.enabled");
}

static bool control_events(int fd) {
    union { struct inotify_event alignment; char bytes[4096]; } batch;
    ssize_t n = read(fd, batch.bytes, sizeof(batch.bytes));
    if (n < 0 && errno == EINTR) return true;
    if (n <= 0) return false;
    for (size_t i = 0; i < (size_t)n;) {
        const struct inotify_event *ev = (const void *)(batch.bytes + i);
        if (ev->mask & (IN_DELETE_SELF | IN_MOVE_SELF | IN_Q_OVERFLOW | IN_IGNORED | IN_UNMOUNT)) return false;
        if (ev->len && control_marker(ev->name)) {
            /* A rapid disable/enable must retire the existing generation too. */
            if ((!strcmp(ev->name, "audit.enabled") && (ev->mask & (IN_DELETE | IN_MOVED_FROM))) ||
                (strcmp(ev->name, "audit.enabled") && (ev->mask & (IN_CREATE | IN_MOVED_TO))) ||
                !enabled()) return false;
        }
        i += sizeof(*ev) + ev->len;
    }
    return true;
}

struct audit_state {
    unsigned count;
    bool healthy;
};

static void record_stage(void *context, enum mask_audit_state stage) {
    struct audit_state *audit = context;
    if (audit->healthy)
        audit->healthy = status("audit.worker", mask_audit_name(stage), 0, ++audit->count);
}

static int worker(pid_t expected_parent) {
    /* Reenable normal process termination after fork, including graceful stop
     * if the supervisor is killed between fork and PR_SET_PDEATHSIG. */
    if (prctl(PR_SET_PDEATHSIG, SIGTERM) < 0 || getppid() != expected_parent) return 1;
    sigset_t empty;
    sigemptyset(&empty);
    if (sigprocmask(SIG_SETMASK, &empty, NULL)) return 1;
    if (!enabled()) return 1;
    struct mask_journal *journal = mask_journal_open(wake_dir, -1);
    if (!journal) return 1;
    struct audit_state audit = {0, status("audit.worker", "LISTENING", 0, 0)};
    struct pollfd fd = {mask_journal_fd(journal), POLLIN, 0};
    while (audit.healthy) {
        int n = poll(&fd, 1, -1);
        if (n < 0 && errno == EINTR) continue;
        if (n < 0 || fd.revents != POLLIN) break;
        if (mask_journal_drain(journal, record_stage, &audit) < 0) break;
    }
    mask_journal_close(journal);
    return 1;
}

static bool stopping(struct pollfd *fds, int timeout, bool *child_changed) {
    *child_changed = false;
    int n;
    do { n = poll(fds, 2, timeout); } while (n < 0 && errno == EINTR);
    if (n < 0) return true;
    if (n == 0) return false;
    if ((fds[0].revents | fds[1].revents) & (POLLHUP | POLLERR | POLLNVAL)) return true;
    if ((fds[0].revents & POLLIN) && !control_events(fds[0].fd)) return true;
    if (fds[1].revents & POLLIN) {
        struct signalfd_siginfo info;
        if (read(fds[1].fd, &info, sizeof(info)) != sizeof(info)) return true;
        if (info.ssi_signo != SIGCHLD) return true;
        *child_changed = true;
    }
    return !enabled();
}

static int supervise(int lock, int watch, int signals) {
    struct pollfd fds[] = {{watch, POLLIN, 0}, {signals, POLLIN, 0}};
    unsigned starts = 0;
    pid_t child = 0, parent = getpid();
    bool child_changed, exhausted = false;
    while (enabled()) {
        if (!child) {
            if (starts >= 3) { exhausted = true; break; }
            child = fork();
            if (child < 0) break;
            if (!child) {
                close(lock); close(watch); close(signals);
                _exit(worker(parent));
            }
            starts++;
            if (!status("audit.status", "WATCHING", child, starts)) break;
        }
        if (stopping(fds, -1, &child_changed)) break;
        if (child_changed) {
            pid_t done;
            do { done = waitpid(child, NULL, WNOHANG); } while (done < 0 && errno == EINTR);
            if (done < 0) break;
            if (done == child) {
                child = 0;
                if (!status("audit.status", "CHILD_EXITED", 0, starts)) break;
            }
        }
    }
    if (child > 0) {
        /* Our child has no asynchronous cleanup or display resource. SIGKILL
         * also terminates a stopped/wedged audit worker. The real mask owner
         * must supply its own independent visibility expiry and HIDE. */
        kill(child, SIGKILL);
        while (waitpid(child, NULL, 0) < 0 && errno == EINTR) {}
    }
    status("audit.status", exhausted ? "RETRY_LIMIT" : "STOPPED", 0, starts);
    return exhausted ? 1 : 0;
}

static int open_lock(void) {
    struct stat st;
    int fd = openat(module, ".audit.lock", O_CREAT | O_CLOEXEC | O_NOFOLLOW | O_RDWR, 0600);
    if (fd >= 0 && fstat(fd, &st) == 0 && S_ISREG(st.st_mode) && st.st_uid == owner)
        return fd;
    if (fd >= 0) close(fd);
    return -1;
}

static int stop_audit(void) {
    int marker = openat(module, "audit.stop", O_WRONLY | O_CREAT | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK, 0600);
    if (marker < 0) return 2;
    close(marker);
    if (unlinkat(module, "audit.enabled", 0) && errno != ENOENT) return 2;
    /* Signal only the supervisor's filesystem gate. Wait for its own child to
     * be reaped and its exclusive lock released before reporting a clean stop. */
    int lock = open_lock();
    struct timespec start, now, pause = {.tv_nsec = 50000000};
    if (lock < 0 || clock_gettime(CLOCK_MONOTONIC, &start)) return 2;
    /* Bounded waiting only for the stop command. The live daemon always blocks
     * on events; it has no heartbeat or wake timer. */
    while (flock(lock, LOCK_EX | LOCK_NB) < 0) {
        if (errno != EWOULDBLOCK && errno != EINTR) return 2;
        if (clock_gettime(CLOCK_MONOTONIC, &now)) return 2;
        if (now.tv_sec > start.tv_sec + 3 ||
            (now.tv_sec == start.tv_sec + 3 && now.tv_nsec >= start.tv_nsec)) return 2;
        nanosleep(&pause, NULL);
    }
    close(lock);
    return 0;
}

int main(int argc, char **argv) {
    bool stop;
    owner = geteuid();
#ifdef HOST_TEST
    if (argc != 3 && !(argc == 4 && !strcmp(argv[3], "--stop"))) return 2;
    stop = argc == 4;
    module_dir = argv[1];
    wake_dir = argv[2];
#else
    if (owner != 0 || (argc != 1 && !(argc == 2 && !strcmp(argv[1], "--stop")))) return 2;
    stop = argc == 2;
#endif
    umask(077);
    module = open(module_dir, O_DIRECTORY | O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
    struct stat st;
    if (module < 0) return stop && errno == ENOENT ? 0 : 2;
    if (fstat(module, &st) || st.st_uid != owner || (st.st_mode & 022)) return 2;
    if (stop) return stop_audit();
    if (!enabled()) return 0;
    int lock = open_lock();
    if (lock < 0) return 2;
    if (flock(lock, LOCK_EX | LOCK_NB) < 0) return errno == EWOULDBLOCK ? 0 : 2;
    /* Install watch before rechecking flags. The lock remains inherited across
     * the fork until the daemon owns it, including while the launcher exits. */
    int watch = watch_directory(module_dir, WATCH_MASK);
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGTERM); sigaddset(&set, SIGHUP); sigaddset(&set, SIGINT); sigaddset(&set, SIGCHLD);
    if (watch < 0 || sigprocmask(SIG_BLOCK, &set, NULL)) return 2;
    int signals = signalfd(-1, &set, SFD_CLOEXEC);
    if (signals < 0 || !enabled()) return 2;
    pid_t pid = fork();
    if (pid < 0) return 2;
    if (pid > 0) return 0;
    if (setsid() < 0 || chdir("/") < 0) return 2;
    int null = open("/dev/null", O_RDWR | O_CLOEXEC);
    if (null < 0) return 2;
    for (int i = 0; i <= 2; i++) if (dup2(null, i) < 0) return 2;
    if (null > 2) close(null);
    return supervise(lock, watch, signals);
}
