"""Exercise the actual fork/setsid/flock/inotify code on Linux; no device access."""
import ctypes
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time
import unittest

HERE = Path(__file__).resolve().parent


def until(predicate, seconds=3):
    limit = time.monotonic() + seconds
    while time.monotonic() < limit:
        value = predicate()
        if value:
            return value
        time.sleep(.01)
    raise AssertionError(f"Timed out waiting for {predicate}")


def live(pid):
    try:
        return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[0] != "Z"
    except FileNotFoundError:
        return False


class ServiceLifecycle(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Adopt detached test children so tests don't depend on the container's PID 1.
        if ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0):
            raise RuntimeError("PR_SET_CHILD_SUBREAPER failed")
        cls.tmp = tempfile.TemporaryDirectory()
        cls.binary = Path(cls.tmp.name) / "test-watch"
        subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-O2", "-DHOST_TEST",
                        HERE / "watcher.c", HERE / "journal.c", "-o", cls.binary], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def setUp(self):
        self.root = tempfile.TemporaryDirectory()
        self.mod = Path(self.root.name) / "module"
        self.journal = Path(self.root.name) / "wake"
        self.mod.mkdir(mode=0o700)
        self.journal.mkdir(mode=0o700)
        (self.mod / "audit.enabled").touch(mode=0o600)
        self.cmd = [self.binary, self.mod, self.journal]

    def tearDown(self):
        if self.mod.exists():
            (self.mod / "audit.stop").touch()
        # Detached process exits once control event is observed.
        deadline = time.monotonic() + 2
        while True:
            try:
                pid, _ = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if not pid:
                if time.monotonic() >= deadline:
                    self.fail("test left a live child")
                time.sleep(.01)
        self.root.cleanup()

    def read_status(self, name):
        try:
            stage, *pairs = (self.mod / name).read_text().strip().split()
            return stage, dict(pair.split("=") for pair in pairs)
        except FileNotFoundError:
            return "", {}

    def state(self, stage):
        def match():
            text, fields = self.read_status("audit.status")
            return fields if text == stage else None
        return until(match)

    def launch(self):
        subprocess.run(self.cmd, check=True)
        fields = self.state("WATCHING")
        until(lambda: self.read_status("audit.worker")[0] == "LISTENING")
        return int(fields["pid"]), int(fields["child"])

    def test_start_session_exit_same_observer_still_observes(self):
        shell = subprocess.Popen(["sh", "-c", '"$@"; exec sleep 30', "test", *self.cmd],
                                 start_new_session=True)
        try:
            fields = self.state("WATCHING")
            parent = int(fields["pid"])
            until(lambda: self.read_status("audit.worker")[0] == "LISTENING")
            self.assertEqual(os.getsid(parent), parent)
            self.assertNotEqual(os.getsid(parent), shell.pid)
        finally:
            os.killpg(shell.pid, signal.SIGHUP)
            shell.wait(timeout=2)
        with (self.journal / "events").open("a") as log:
            log.write("23998 private-content-never-recorded\n")
            log.write("24001 DARK_OBSERVED_AT boot=38 dark=24000 at=24000\n")
        until(lambda: self.read_status("audit.worker")[0] == "DARK_OBSERVED")
        with (self.journal / "events").open("a") as log:
            log.write("33001 WAKE_CANDIDATE_AT boot=38 dark=24000 at=33000\n")
        until(lambda: self.read_status("audit.worker")[0] == "WAKE_CANDIDATE")
        self.assertTrue(live(parent))
        self.assertNotIn("private-content", (self.mod / "audit.worker").read_text())

    def test_ignore_history_at_start(self):
        events = self.journal / "events"
        events.write_text("23001 DARK_OBSERVED_AT boot=38 dark=23000 at=23000\n")
        self.launch()
        with events.open("a") as log:
            log.write("35001 WAKE_CANDIDATE_AT boot=38 dark=23000 at=35000\n")
        # A new fresh DARK serves as a barrier after the unmatched candidate.
        with events.open("a") as log:
            log.write("39001 DARK_OBSERVED_AT boot=38 dark=39000 at=39000\n")
        until(lambda: self.read_status("audit.worker")[0] == "DARK_OBSERVED")
        self.assertEqual(self.read_status("audit.worker")[1]["count"], "1")

    def test_concurrent_starts_own_one_lock(self):
        ps = [subprocess.Popen(self.cmd) for _ in range(12)]
        self.assertEqual([p.wait(timeout=2) for p in ps], [0] * len(ps))
        fields = self.state("WATCHING")
        for _ in range(3):
            subprocess.run(self.cmd, check=True)
        self.assertEqual(self.read_status("audit.status")[1], fields)
        self.assertEqual(fields["count"], "1")

    def check_marker(self, name):
        parent, child = self.launch()
        (self.mod / name).touch()
        self.state("STOPPED")
        until(lambda: not live(parent) and not live(child))
        subprocess.run(self.cmd, check=True)
        self.assertEqual(self.read_status("audit.status")[0], "STOPPED")

    def test_kernel_manager_disable(self):
        self.check_marker("disable")

    def test_kernel_manager_uninstall_remove(self):
        self.check_marker("remove")

    def test_explicit_stop(self):
        self.check_marker("audit.stop")

    def test_stop_command_waits_for_worker_reap(self):
        _, child = self.launch()
        subprocess.run([*self.cmd, "--stop"], check=True, timeout=4)
        self.assertFalse(live(child))
        self.assertEqual(self.read_status("audit.status")[0], "STOPPED")
        self.assertFalse((self.mod / "audit.enabled").exists())
        subprocess.run([*self.cmd, "--stop"], check=True, timeout=4)

    def test_revoke_audit_opt_in(self):
        parent, child = self.launch()
        (self.mod / "audit.enabled").unlink()
        self.state("STOPPED")
        until(lambda: not live(parent) and not live(child))

    def test_worker_failure_has_hard_budget(self):
        parent, child = self.launch()
        for expected in (2, 3):
            os.kill(child, signal.SIGKILL)
            def next_worker():
                stage, fields = self.read_status("audit.status")
                if stage == "WATCHING" and int(fields["count"]) == expected:
                    return int(fields["child"])
                return 0
            child = until(next_worker)
        os.kill(child, signal.SIGKILL)
        self.assertEqual(self.state("RETRY_LIMIT")["count"], "3")
        until(lambda: not live(parent))

    def test_unexpected_supervisor_death_stops_worker(self):
        parent, child = self.launch()
        os.kill(parent, signal.SIGKILL)
        until(lambda: not live(parent) and not live(child))

    def test_removed_module_directory_stops_processes(self):
        parent, child = self.launch()
        self.mod.rename(self.mod.with_name("removed"))
        until(lambda: not live(parent) and not live(child))

    def test_wrong_permission_marker_is_not_opt_in(self):
        (self.mod / "audit.enabled").chmod(0o666)
        subprocess.run(self.cmd, check=True)
        self.assertFalse((self.mod / "audit.status").exists())


if __name__ == "__main__":
    unittest.main()
