/* Host regression uses the same cursor and parser objects as the ARM64 worker. */
#define _GNU_SOURCE
#include "journal.h"
#include <assert.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int root;
static char path[]="/tmp/naozho-journal-XXXXXX";
static struct mask_journal *journal;
static enum mask_audit_state seen[32];
static unsigned used;
#define UUID "ac0b1465-58c4-4ed6-86de-1585f39634a0"
#define REQ "c8745c77-8deb-4768-8233-e3029beb9847"
static void write_to(const char *name,const char *content,int flags) {
    int fd=openat(root,name,O_WRONLY|O_CREAT|flags,0600);
    assert(fd>=0);
    size_t len=strlen(content);
    assert(write(fd,content,len)==(ssize_t)len);
    assert(!close(fd));
}
static void append(const char *content) { write_to("events",content,O_APPEND); }
static void record(void *arg,enum mask_audit_state state) {
    (void)arg; assert(used<32); seen[used++]=state;
}
static void drain(void) {
    struct pollfd p={.fd=mask_journal_fd(journal),.events=POLLIN};
    assert(poll(&p,1,100)==1);
    assert(!mask_journal_drain(journal,record,NULL));
}
static void expected(const enum mask_audit_state *s, size_t n) {
    assert(n==used); assert(!n || !memcmp(s,seen,n*sizeof(*s))); used=0;
}
#define EXPECT(...) do { const enum mask_audit_state a[]={__VA_ARGS__}; expected(a,sizeof(a)/sizeof(*a)); } while(0)
#define NONE() expected(NULL,0)
static void open_at_tail(void) {
    mask_journal_close(journal);
    journal=mask_journal_open(path,38); assert(journal);
}
static void rotate(void) { assert(!renameat(root,"events",root,"events.1")); }
static void scope(const char *kind,int now,int dark,const char *fields) {
    char row[240];
    int len=snprintf(row,sizeof(row),"%d %s boot=38 dark=%d %s\n",now,kind,dark,fields);
    assert(len>=0 && (size_t)len<sizeof(row)); append(row);
}
static void proof(int dark,int now) {
    scope("RETURN_SEND_AT",now++,dark,"request=" REQ);
    scope("RETURN_DELIVERED_AT",now++,dark,"request=" REQ " uid=0");
    scope("COMMIT_SEND_AT",now++,dark,"request=" REQ);
    scope("COMMIT_DELIVERED_AT",now++,dark,"request=" REQ " uid=0");
    scope("CLOCK_FOCUS_LOCK_VERIFIED_AT",now++,dark,"request=" REQ);
    scope("CLOCK_FOCUSED",now++,dark,"request=" REQ);
    scope("HANDOFF_COMPLETE",now,dark,"request=" REQ " mask=not_submitted");
}
int main(void) {
    assert(mkdtemp(path));
    root=open(path,O_RDONLY|O_DIRECTORY);
    assert(root>=0);
    append("1 DARK_OBSERVED_AT boot=38 dark=1 at=1\n2 WAKE_CANDID");
    open_at_tail();
    append("ATE_AT boot=38 dark=1 at=2\n3 FULL_WAKE_AT boot=38 dark=1 epoch=" UUID "/1/1 at=3 via=binder_proto\n");
    drain(); NONE(); /* never replay a partial/final line already in the file */
    append("10 DARK_OBSERVED_AT boot=38 dark=10"); drain(); NONE();
    append(" at=10\n11 MASK_REFUSED_AT boot=38 dark=10 phase=off reason=stock_no_source_window_attachment\n");
    drain(); EXPECT(MASK_AUDIT_DARK);
    rotate(); drain(); NONE(); /* the new events file does not exist yet */
    append("10010 WAKE_CANDIDATE_AT boot=38 dark=10 at=10010\n");
    drain(); EXPECT(MASK_AUDIT_CANDIDATE); /* 10s darkness does not expire */
    append("10020 FULL_WAKE_AT boot=38 dark=10 epoch=" UUID "/10/1 at=10020 via=binder_proto\n");
    proof(10,10021); drain();
    EXPECT(MASK_AUDIT_FULL,MASK_AUDIT_FOCUSED,MASK_AUDIT_HANDOFF);
    open_at_tail();
    scope("HANDOFF_COMPLETE",10040,10,"request=" REQ " mask=not_submitted"); drain(); NONE();

    append("11000 DARK_OBSERVED_AT boot=38 dark=11000 at=11000\n");
    rotate();
    append("11020 WAKE_CANDIDATE_AT boot=38 dark=11000 at=11020\n11021 REFUSED display_removed\n");
    drain(); EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_CANDIDATE,MASK_AUDIT_REFUSED);
    scope("FULL_WAKE_AT",11023,11000,"epoch=" UUID "/11000/2 at=11023 via=binder"); drain(); NONE();

    append("12000 DARK_OBSERVED_AT boot=38 dark=12000 at=12000\n12001 WAKE_CANDIDATE_AT boot=38 dark=12000 at=12001\n");
    scope("FULL_WAKE_AT",12002,12000,"epoch=" UUID "/12000/3 at=12002 via=dumpsys");
    scope("RETURN_SEND_AT",12003,12000,"request=" REQ);
    scope("RETURN_DELIVERED_AT",12004,12000,"request=" UUID " uid=0");
    drain(); EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_CANDIDATE,MASK_AUDIT_FULL,MASK_AUDIT_GAP);
    proof(12000,12005); drain(); NONE();
    append("13000 DARK_OBSERVED_AT boot=38 dark=13000 at=13000\n13001 STOPPED\n");
    drain(); EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_STOPPED);
    append("13002 WAKE_CANDIDATE_AT boot=38 dark=13000 at=13002\n"); drain(); NONE();

    append("14000 DARK_OBSERVED_AT boot=38 dark=14000 at=14000\n"); drain(); EXPECT(MASK_AUDIT_DARK);
    write_to("events","14001 WAKE_CANDIDATE_AT boot=38 dark=14000 at=14001\n",O_TRUNC);
    drain(); EXPECT(MASK_AUDIT_GAP);
    scope("FULL_WAKE_AT",14002,14000,"epoch=" UUID "/14000/4 at=14002 via=binder"); drain(); NONE();
    append("15000 DARK_OBSERVED_AT boot=38 dark=15000 at=15000\n");
    rotate();
    append("15001 WAKE_CANDIDATE_AT boot=38 dark=15000 at=15001\n");
    rotate();
    scope("FULL_WAKE_AT",15002,15000,"epoch=" UUID "/15000/5 at=15002 via=binder");
    drain(); EXPECT(MASK_AUDIT_GAP);
    append("16000 DARK_OBSERVED_AT boot=38 dark=16000 at=16000\n");
    append("16001 WAKING WAKE_CANDIDATE\n16002 WAKE_CANDIDATE_AT boot=38 dark=16000 at=16001\n");
    append("16003 DOZE WAKING_REVERSED_TO_AOD\n"); drain();
    EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_CANDIDATE,MASK_AUDIT_REFUSED);
    append("17000 DARK_OBSERVED_AT boot=37 dark=17000 at=17000\n"); drain(); EXPECT(MASK_AUDIT_GAP);
    append("18000 DARK_OBSERVED_AT boot=38 dark=18000 at=18000\n");
    append("18001 WAKE_CANDIDATE_AT boot=38 dark=18000 at=18001\n");
    scope("FULL_WAKE_AT",18002,18000,"epoch=" UUID "/18000/6 at=18002 via=dumpsys");
    scope("RETURN_SEND_AT",18003,18000,"request=" REQ);
    scope("RETURN_DELIVERED_AT",18004,18000,"request=" REQ " uid=0");
    scope("COMMIT_SEND_AT",18005,18000,"request=" REQ);
    scope("COMMIT_DELIVERED_AT",18006,18000,"request=" REQ " uid=2000");
    drain(); EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_CANDIDATE,MASK_AUDIT_FULL,MASK_AUDIT_GAP);
    append("19000 DARK_OBSERVED_AT boot=38 dark=19000 at=19000\n"); drain(); EXPECT(MASK_AUDIT_DARK);
    scope("HANDOFF_COMPLETE",19001,19000,"request=" REQ " mask=not_submitted"); drain(); EXPECT(MASK_AUDIT_GAP);

    mask_journal_close(journal);
    assert(!unlinkat(root,"events",0));
    assert(!symlinkat("events.1",root,"events"));
    assert(!mask_journal_open(path,38));
    assert(!unlinkat(root,"events",0));
    journal=mask_journal_open(path,-1); assert(journal);
    append("20000 DARK_OBSERVED_AT boot=38 dark=20000 at=20000\n");
    drain(); EXPECT(MASK_AUDIT_DARK);
    append("20001 MAINTENANCE_PAUSED\n"); drain(); EXPECT(MASK_AUDIT_STOPPED);
    append("21000 DARK_OBSERVED_AT boot=38 dark=21000 at=21000\n");
    append("21009 WAKE_CANDIDATE_AT boot=38 dark=21000 at=21007\n");
    scope("FULL_WAKE_AT",21010,21000,"epoch=" UUID "/21000/7 at=21006 via=binder_proto");
    drain(); EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_CANDIDATE,MASK_AUDIT_GAP);
    append("22000 DARK_OBSERVED_AT boot=38 dark=22000 at=22000\n22005 observer_ready pid=456\n");
    scope("WAKE_CANDIDATE_AT",22006,22000,"at=22006"); drain();
    EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_STOPPED);
    append("23000 DARK_OBSERVED_AT boot=38 dark=23000 at=23000\n23001  REFUSED display_removed\n");
    scope("WAKE_CANDIDATE_AT",23002,23000,"at=23002"); drain();
    EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_GAP);
    append("24000 DARK_OBSERVED_AT boot=38 dark=24000 at=24000\n24001 observer_unregistered\n");
    drain(); EXPECT(MASK_AUDIT_DARK,MASK_AUDIT_STOPPED);
    mask_journal_close(journal); assert(!unlinkat(root,"events",0)); assert(!unlinkat(root,"events.1",0));
    close(root); assert(!rmdir(path));
    puts("Live journal cursor, producer framing, rotation, correlation, refusal and gap checks passed");
    return 0;
}
