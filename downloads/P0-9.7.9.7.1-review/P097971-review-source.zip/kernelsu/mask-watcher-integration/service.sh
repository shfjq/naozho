#!/system/bin/sh
# KernelSU late_start service integration candidate, deliberately audit-only.
# basename and worker path are fixed; no client, ADB bootstrap, or command IPC.
umask 077
exec /data/adb/modules/naozho_mask/bin/watcher-audit </dev/null >/dev/null 2>&1
