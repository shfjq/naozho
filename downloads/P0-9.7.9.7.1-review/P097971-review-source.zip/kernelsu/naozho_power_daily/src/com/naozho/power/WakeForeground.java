package com.naozho.power;

import com.naozho.power.TrialChecks.Refused;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Positive WMS evidence of an ordinary, stable user-0 activity. No reviewed-app registry. */
final class WakeForeground {
    private static final String RECORD = "ActivityRecord\\{([0-9a-fA-F]+) u0 ([^\\s{}]+) t([0-9]{1,9})(?: [^{}\\r\\n]*)?\\}";
    // WindowState.dump prints both references; matching only a package in the title is insufficient.
    private static final Pattern TOKEN=field("mBaseLayer=[0-9]+ mSubLayer=0[ \t]+mToken=" + RECORD);
    private static final Pattern FOCUSED = field("mFocusedApp=" + RECORD);
    private static final Pattern WINDOW = field("mActivityRecord=" + RECORD);
    private static final Pattern TASK = field("mDisplayId=0 taskId=([0-9]{1,9})(?: [^\\r\\n]*)?");
    private static final Pattern UID = field("mOwnerUid=([0-9]{1,9}) showForAllUsers=(?:false|true) package=[^ \\r\\n]+(?: [^\\r\\n]*)?");
    private static final String PIXEL = "(-?[0-9]{1,6})";
    private static final Pattern FRAME = field("Frames: parent=[^\\r\\n]*? display=\\[[^\\r\\n ]+ frame=\\["
            + PIXEL + "," + PIXEL + "\\]\\[" + PIXEL + "," + PIXEL + "\\](?: [^\\r\\n]*)?");
    private static final Pattern SPECIAL = Pattern.compile("emergency|incall|dialer|keyguard|credential|biometric|"
            + "fingerprint|password|passkey|confirmdevice|confirmlock|cryptkeeper|recovery|"
            + "authenticator|permissioncontroller|grantpermissions|managepermissions|"
            + "packageinstaller|securitysettings|systemupdate|rescueparty|setupwizard|provisioning|"
            + "chooseractivity|resolveractivity|usbpermission|usbaccessory|mediaprojection");

    private static Pattern field(String pattern) {
        return Pattern.compile("(?m)^[ \\t]*" + pattern + "[ \\t]*$");
    }

    private static String[] unique(Pattern field, String rows) throws Refused {
        Matcher match=field.matcher(rows);
        if (!match.find()) throw new Refused("wake_task_evidence_missing");
        String[] groups=new String[match.groupCount()];
        for (int i=0;i<groups.length;i++) groups[i]=match.group(i+1);
        if (match.find()) throw new Refused("wake_task_ambiguous");
        return groups;
    }

    static final class Task {
        final String page, windowId, activityId;
        final int taskId, uid, left, top, right, bottom;
        final java.util.Set<Integer> startingWindowOwners=new java.util.HashSet<>();
        Task(String page,String windowId,String activityId,int taskId,int uid,String[] frame) {
            this.page=page; this.windowId=windowId; this.activityId=activityId; this.taskId=taskId; this.uid=uid;
            left=Integer.parseInt(frame[0]); top=Integer.parseInt(frame[1]);
            right=Integer.parseInt(frame[2]); bottom=Integer.parseInt(frame[3]);
        }

        void confirmStartingOwners(int systemUiUid) throws Refused {
            for (int owner:startingWindowOwners) {
                if (owner!=1000 && owner!=systemUiUid) throw new Refused("wake_starting_window_owner");
            }
        }

        void confirm(String display) throws Refused {
            if (!page.equals(focusedPage(display)) || !windowId.equals(Foreground.rawFocusId(display)))
                throw new Refused("focus_transition");
            String[] record=unique(FOCUSED,display);
            if (!activityId.equals(record[0]) || !page.equals(Foreground.canonical(record[1])) ||
                    taskId!=Integer.parseInt(record[2])) throw new Refused("wake_task_transition");
        }
    }

    static String focusedPage(String display) throws Refused {
        return Foreground.canonical(unique(FOCUSED,display)[1]);
    }

    // The z-ordered window dump is the source of both records. Keep these tokens in memory only.
    static Task member(String id,String body,boolean requireToken) throws Refused {
        String[] rec=unique(WINDOW,body);
        String page=Foreground.canonical(rec[1]);
        int taskId=Integer.parseInt(unique(TASK,body)[0]);
        int uid=Integer.parseInt(unique(UID,body)[0]);
        if (taskId<=0 || taskId!=Integer.parseInt(rec[2]) || uid<1000 || uid>=100000)
            throw new Refused("wake_task_owner_unconfirmed");
        if (requireToken) {
            String[] token=unique(TOKEN,body);
            if (!token[0].equals(rec[0]) || !Foreground.canonical(token[1]).equals(page) ||
                    !token[2].equals(rec[2])) throw new Refused("wake_task_token_mismatch");
        }
        return new Task(page,id,rec[0],taskId,uid,unique(FRAME,body));
    }

    // Only application-level windows can be siblings. A subwindow/dialog in the very same
    // package and task can carry an unrelated security or permission prompt.
    static boolean sibling(Task focused,Task child,boolean below,boolean covered,String type,
            boolean inert,String childOwner,java.util.Set<Integer> externalOwners) {
        String pkg=focused.page.substring(0,focused.page.indexOf('/'));
        String childPkg=child.page.substring(0,child.page.indexOf('/'));
        if (focused.windowId.equals(child.windowId) || !pkg.equals(childPkg) || focused.taskId!=child.taskId ||
            child.left<focused.left || child.top<focused.top || child.right>focused.right || child.bottom>focused.bottom ||
            SPECIAL.matcher(child.page.toLowerCase(Locale.ROOT)).find() ||
            (sharedSettingsHost(child.page) && !child.activityId.equals(focused.activityId))) return false;
        // Behind the foreground, a previous full app window may retain focusable flags.
        // It must already be obscured, or have no keyboard or pointer input of its own.
        if (type.equals("BASE_APPLICATION")) {
            return below && (covered || inert) && child.uid==focused.uid && childOwner.equals(pkg);
        }
        if (!type.equals("APPLICATION_STARTING") || !inert || !child.activityId.equals(focused.activityId) ||
                !child.page.equals(focused.page)) return false;
        if (child.uid==focused.uid) return childOwner.equals(pkg);
        // SplashScreen is often owned by WMShell/SystemUI. Check this UID against the
        // package manager in checkPublicActivity, never authorize from title/owner text alone.
        if (!childOwner.equals(pkg) && !childOwner.equals("android") && !childOwner.equals("com.android.systemui")) return false;
        externalOwners.add(child.uid);
        return true;
    }

    static Task verify(String display, Foreground.Windows windows, String page) throws Refused {
        Foreground.verify(windows,page);
        if (windows.lockscreenCapable) throw new Refused("lockscreen_capable_activity");
        String body=windows.focusedMetadata;
        if (body==null || windows.interactiveCount!=1) throw new Refused("wake_app_window_unconfirmed");
        Task task=member(Foreground.rawFocusId(display),body,false);
        if (!page.equals(task.page)) throw new Refused("wake_task_owner_unconfirmed");
        task.startingWindowOwners.addAll(windows.startingWindowOwners);
        task.confirm(display);
        return task;
    }

    // Android 16 CallsManager.dump writes mCalls entries and any pending-call fields *before*
    // mCallAudioManager. Return classification atoms only; callers, numbers and history stay in dumpsys.
    static final String CALLS_PROJECTION =
            "/^CallsManager:[[:space:]]*$/ { s/.*/manager/p; n; /^  mCalls:[[:space:]]*$/ { s/.*/calls/p; n; "
            + "/^  mCallAudioManager:[[:space:]]*$/s/.*/idle/p; }; }; "
            + "/Permission Denial|DUMP TIMEOUT|DUMP FAILED/s/.*/error/p";
    static void confirmNoTelecomCalls(String projection) throws Refused {
        if (!"manager\ncalls\nidle".equals(projection)) throw new Refused("telecom_busy_or_unknown");
    }

    static boolean dialerName(String value) {
        return value!=null && value.length()<=255 &&
                value.matches("[a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z][a-zA-Z0-9_]*)+");
    }
    static boolean sharedSettingsHost(String page) {
        return page.startsWith(Foreground.SETTINGS + "/") && (page.endsWith(".SubSettings") ||
                page.endsWith(".SettingsActivity") || page.endsWith(".SettingsPanelActivity"));
    }
    static String settingsProjection(String token) throws Refused {
        if (!token.matches("[0-9a-fA-F]+")) throw new Refused("activity_identity_unknown");
        // For ambiguous fragment containers accept only a known public harmless entry action and a
        // plain Intent. No extras/fragment arguments, selectors, data URI, flags from unknown keys.
        String actions="(WIFI_SETTINGS|BLUETOOTH_SETTINGS|DISPLAY_SETTINGS|SOUND_SETTINGS|"
                + "LOCALE_SETTINGS|DATE_SETTINGS|WIFI_IP_SETTINGS|WIRELESS_SETTINGS|NFC_SETTINGS)";
        String keys="(flg=0x[0-9a-fA-F]+|xflg=0x[0-9a-fA-F]+|pkg=com[.]android[.]settings|"
                + "cmp=com[.]android[.]settings/(com[.]android[.]settings)?[.](SubSettings|SettingsActivity|SettingsPanelActivity))";
        return "/^[ ]*[*] Hist #[0-9]+: ActivityRecord\\{"+token+" u0 /,/^[ ]*rootOfTask=/ { "
                + "/^[ ]*Intent \\{ act=android[.]settings[.]"+actions+"( "+keys.replace("/","\\/")+")* \\}$/s/.*/ordinary/p; }";
    }

    /** WMS has already rejected secure windows, attached dialogs, IME, shades and overlays. */
    static void ordinaryComponent(String page,String defaultDialer,String systemDialer,boolean ordinarySettingsRoute) throws Refused {
        String pkg=page.substring(0,page.indexOf('/'));
        // A transition Activity can become the only focused app. It cannot attest
        // which ordinary task was underneath it before the transition.
        if (pkg.equals("com.naozho.mask")) throw new Refused("mask_is_not_source");
        if (!dialerName(defaultDialer) || !dialerName(systemDialer)) throw new Refused("dialer_role_unknown");
        if (pkg.equals(defaultDialer) || pkg.equals(systemDialer) || pkg.equals("android") ||
                pkg.equals("com.naozho.clock") || pkg.equals("com.android.phone") || pkg.equals("com.android.server.telecom") ||
                pkg.equals("com.android.systemui") || SPECIAL.matcher(page.toLowerCase(Locale.ROOT)).find())
            throw new Refused("protected_page");
        // These generic fragment hosts can display credential or security settings using intent extras.
        // A dedicated, named settings activity still qualifies under the same window/role guards.
        if (sharedSettingsHost(page) && !ordinarySettingsRoute)
            throw new Refused("settings_route_unconfirmed");
    }

    private WakeForeground() {}
}
