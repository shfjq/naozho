package com.naozho.power;

import java.nio.file.Files;
import java.nio.file.Path;

/** Calls the production WMS projection, classifier and task binding. No package list is installed. */
public final class WakeOrdinaryTest {
    private static final String HEADER="WINDOW MANAGER WINDOWS (dumpsys window windows)\n";
    private static final String END="  mBlurEnabled=true\n";
    private static final String DIALER="test.system.dialer";

    private static String display(String page) {
        return "  mCurrentFocus=Window{f00 u0 "+page+"}\n  mFocusedApp=ActivityRecord{abc u0 "+page+" t3}";
    }

    private static String body(String page,String flags) {
        String pkg=page.substring(0,page.indexOf('/'));
        String window=DailyTest.window(0,"f00",page,pkg,"BASE_APPLICATION",flags);
        return window.replace("    mAttrs=","    mActivityRecord=ActivityRecord{abc u0 "+page+" t3}\n    mAttrs=")
                .replace("frame=[0,0][720,35]","frame=[0,35][720,680]");
    }

    private static WakeForeground.Task check(String page,String body,String display) throws Exception {
        Foreground.Windows w=VisibleWindowDump.inspectWake(HEADER+body+END,Foreground.rawFocusId(display));
        WakeForeground.Task task=WakeForeground.verify(display,w,page);
        WakeForeground.ordinaryComponent(page,"test.user.dialer",DIALER,false);
        return task;
    }

    private static String sed(String expression, String text) throws Exception {
        Process cmd=new ProcessBuilder("sed","-nE",expression).redirectErrorStream(true).start();
        try (java.io.OutputStream stdin=cmd.getOutputStream()) {
            stdin.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        String out=new String(cmd.getInputStream().readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);
        if (cmd.waitFor()!=0) throw new AssertionError("invalid producer projection");
        return out.trim();
    }

    private static void sources() throws Exception {
        String manager="CallsManager: \n  mCalls: \n";
        String audio="  mCallAudioManager:\n", idle=manager+audio;
        String expr=WakeForeground.CALLS_PROJECTION;
        WakeForeground.confirmNoTelecomCalls(sed(expr,idle));
        DailyTest.ok("exact live Telecom empty call set",true);
        for (String raw:new String[]{manager+"    active private call record\n"+audio,manager+"  mPendingCall:X\n"+audio,
                manager+"  mPendingRedirectedOutgoingCallInfo:X\n"+audio,manager+"  mPendingUnredirectedOutgoingCallInfo:X\n"+audio,
                manager,idle+idle,"Permission Denial",idle+"DUMP TIMEOUT",manager+"OEM unknown\n"+audio}) {
            String projection=sed(expr,raw);
            DailyTest.ok("projection retains no call metadata",!projection.contains("private") && !projection.contains("X"));
            DailyTest.reject("busy, ambiguous or incomplete Telecom record",()->WakeForeground.confirmNoTelecomCalls(projection));
        }
        for (String name:new String[]{"null","","permission denial","multiple.role\nrole.other","None"})
            DailyTest.ok("missing role not a dialer identity",!WakeForeground.dialerName(name));
        String shared="com.android.settings/com.android.settings.SubSettings";
        String action="Intent { act=android.settings.WIFI_SETTINGS flg=0x10000000 cmp=com.android.settings/.SubSettings }";
        String task="  * Hist #0: ActivityRecord{abc u0 "+shared+" t3}\n    "+action+"\n    rootOfTask=false task=Task{x}\n";
        String project=WakeForeground.settingsProjection("abc");
        DailyTest.ok("bound public settings deep link",sed(project,task).equals("ordinary"));
        WakeForeground.ordinaryComponent(shared,DIALER,DIALER,true);
        for (String row:new String[]{task.replace("abc","abd"),task.replace("WIFI_SETTINGS","SECURITY_SETTINGS"),
                task.replace(" }"," (has extras) }"),task.replace(" flg="," dat=private flg=")})
            DailyTest.ok("reject unsafe or ambiguous shared settings host",sed(project,row).isEmpty());
    }

    private static String member(String page,String id,String activity,int index,String type,String flags,boolean covered) {
        String record="ActivityRecord{"+activity+" u0 "+page+" t3}";
        return body(page,flags).replace("Window #0 Window{f00","Window #"+index+" Window{"+id)
                .replace("mActivityRecord=ActivityRecord{abc u0 "+page+" t3}",
                        "mBaseLayer=21000 mSubLayer=0    mToken="+record+"\n    mActivityRecord="+record)
                .replace("ty=BASE_APPLICATION","ty="+type)
                .replace("mObscured=false","mObscured="+covered);
    }

    private static void taskWindows() throws Exception {
        String page="org.example.browser/org.example.browser.Reader";
        String splash="org.example.browser/org.example.browser.SplashActivity";
        String focus=member(page,"f00","abc",0,"BASE_APPLICATION","HARDWARE_ACCELERATED",false);
        String behind=member(splash,"cab","c01",1,"BASE_APPLICATION","HARDWARE_ACCELERATED",true);
        String disp=display(page);
        WakeForeground.Task resolved=check(page,focus+behind,disp);
        DailyTest.ok("covered same-task splash and base form one foreground task",resolved.taskId==3);
        DailyTest.reject("daily power parser remains conservative",()->
                Foreground.verify(VisibleWindowDump.inspect(HEADER+focus+behind+END,"f00"),page));
        DailyTest.reject("unobscured interactive second Activity",()->check(page,focus+behind.replace("mObscured=true","mObscured=false"),disp));
        DailyTest.reject("splash sharing package in another task",()->check(page,focus+behind.replace("taskId=3","taskId=4").replace(" t3}"," t4}"),disp));
        DailyTest.reject("splash sharing package but wrong uid",()->check(page,focus+behind.replace("mOwnerUid=10001","mOwnerUid=10555"),disp));
        DailyTest.reject("different uid-mapped package in same task",()->check(page,focus+behind.replace("org.example.browser","org.example.other"),disp));
        DailyTest.reject("same-task credential component",()->check(page,focus+behind.replace("SplashActivity","ConfirmDeviceCredential"),disp));
        DailyTest.reject("secure covered activity",()->check(page,focus+behind.replace("fl=HARDWARE","fl=SECURE HARDWARE"),disp));
        DailyTest.reject("lockscreen capable covered activity",()->check(page,focus+behind.replace("fl=HARDWARE","fl=SHOW_WHEN_LOCKED HARDWARE"),disp));
        DailyTest.reject("wrong token compared to per-window ActivityRecord",()->check(page,focus+behind.replace("mToken=ActivityRecord{c01","mToken=ActivityRecord{b00"),disp));
        DailyTest.reject("unbounded sibling",()->check(page,focus+behind.replace("frame=[0,35]","frame=[0,22]"),disp));
        DailyTest.reject("unknown popup in same task",()->check(page,focus+behind.replace("ty=BASE_APPLICATION","ty=APPLICATION"),disp));
        DailyTest.reject("missing token on the source of a group",()->check(page,focus.replace("mToken=","unknown=")+behind,disp));

        String start=member(page,"b00","abc",0,"APPLICATION_STARTING","NOT_FOCUSABLE NOT_TOUCHABLE",false)
                .replace(" u0 "+page+"}:", " u0 Splash Screen org.example.browser}:");
        String under=focus.replace("Window #0","Window #1").replace("mObscured=false","mObscured=true");
        DailyTest.ok("real inert Android starting window may cover its own focused Activity",
                check(page,start+under,disp).windowId.equals("f00"));
        DailyTest.reject("starting surface which can receive touch",()->check(page,start.replace(" NOT_TOUCHABLE","")+under,disp));
        DailyTest.reject("starting window for a different ActivityRecord",()->check(page,start.replace("{abc u0","{aaa u0")+under,disp));
        DailyTest.reject("starting window does not explain full obscuration",()->check(page,start.replace("frame=[0,35]","frame=[10,35]")+under,disp));
        DailyTest.reject("similar window title from unrelated activity token",()->check(page,start.replace("mToken=ActivityRecord{abc","mToken=ActivityRecord{cad")+under,disp));
        WakeForeground.Task external=check(page,start.replace("mOwnerUid=10001","mOwnerUid=10138")+under,disp);
        external.confirmStartingOwners(10138);
        DailyTest.ok("OS-owned starting surface owner must be resolved by package manager",
                external.startingWindowOwners.contains(10138));
        DailyTest.reject("unrelated UID posing as a splash provider",()->external.confirmStartingOwners(10139));
        check(page,start.replace("mOwnerUid=10001","mOwnerUid=1000")+under,disp).confirmStartingOwners(10138);
        DailyTest.ok("system-server owned inert starting window",true);
        DailyTest.ok("noncomponent window title validated from actual activity token",
                check(page,focus.replace(" u0 "+page+"}:"," u0 Browser Window}:"),disp.replace("f00 u0 "+page,"f00 u0 Browser Window")).page.equals(page));
        String unknownTitle=focus.replace(" u0 "+page+"}:"," u0 Browser Window}:");
        DailyTest.reject("generic title without validated window token",()->check(page,unknownTitle.replace("mToken=","unknown="),disp));
        String overlay=member(page,"ccc","abc",2,"APPLICATION_OVERLAY","NOT_FOCUSABLE",false);
        DailyTest.reject("trusted splash does not hide concurrent unrelated overlay",()->check(page,start+under+overlay,disp));
    }

    public static void main(String[] args) throws Exception {
        sources();
        taskWindows();
        String mask="com.naozho.mask/com.naozho.mask.TestWindow";
        DailyTest.reject("focused transition app cannot stand in for the original browser",
                ()->check(mask,body(mask,"HARDWARE_ACCELERATED"),display(mask)));
        for (String page:new String[]{"org.example.browser/org.example.browser.Page","com.android.documentsui/com.android.documentsui.files.FilesActivity",
                "com.tencent.mobileqq/com.tencent.mobileqq.activity.SplashActivity","com.android.settings/com.android.settings.Settings",
                "org.game/org.game.UnityPlayerActivity","org.video/org.video.Playback","org.some.newapp/org.some.newapp.Main"}) {
            WakeForeground.Task t=check(page,body(page,"HARDWARE_ACCELERATED"),display(page));
            DailyTest.ok("ordinary foreground uses actual task, owner and bounds",
                    t.page.equals(page) && t.uid==10001 && t.taskId==3 && t.top==35 && t.bottom==680 && t.windowId.equals("f00"));
        }
        String page="org.browser/org.browser.Main", raw=body(page,"HARDWARE_ACCELERATED"), display=display(page);
        for (String flag:new String[]{"SECURE","SHOW_WHEN_LOCKED","DISMISS_KEYGUARD","TURN_SCREEN_ON","0x00080000","400000"})
            DailyTest.reject("protected app window "+flag,()->check(page,body(page,flag),display));
        for (String type:new String[]{"INPUT_METHOD","NOTIFICATION_SHADE","SYSTEM_DIALOG","APPLICATION_OVERLAY"})
            DailyTest.reject(type,()->check(page,raw+DailyTest.window(1,"a00","dialog","example.other",type,"HARDWARE_ACCELERATED"),display));
        DailyTest.reject("incomplete owner evidence",()->check(page,raw.replace("mActivityRecord=","missing="),display));
        DailyTest.reject("visible activity task mismatch",()->check(page,raw.replace("taskId=3","taskId=4"),display));
        DailyTest.reject("foreground changes between window and task samples",()->check(page,raw,display.replace("abc u0","bac u0")));
        DailyTest.reject("other user",()->check(page,raw.replace("abc u0","abc u10"),display));
        DailyTest.reject("other display",()->check(page,raw.replace("mDisplayId=0","mDisplayId=1"),display));
        DailyTest.reject("unknown dialer role",()->WakeForeground.ordinaryComponent(page,null,DIALER,false));
        DailyTest.reject("OEM dialer app with neutral name",()->WakeForeground.ordinaryComponent(page,"org.browser",DIALER,false));
        DailyTest.reject("platform credential UI",()->WakeForeground.ordinaryComponent("sys.vendor/sys.vendor.ConfirmDeviceCredential",DIALER,DIALER,false));
        DailyTest.reject("ambiguous settings fragment",()->WakeForeground.ordinaryComponent("com.android.settings/com.android.settings.SubSettings",DIALER,DIALER,false));
        WakeForeground.Task prior=check(page,raw,display);
        DailyTest.reject("last guard catches reopened same activity class in another task",
                ()->prior.confirm(display.replace(" t3}"," t9}")));
        if (args.length==1) {
            // Optional existing local CPDAY10 capture. Keep raw data and foreground package names out of reports.
            String cp=Files.readString(Path.of(args[0]));
            java.util.regex.Matcher h=java.util.regex.Pattern.compile("(?m)^  Window #\\d+ Window\\{([a-f0-9]+) u0 ([a-z0-9.]+/[^{} ]+)\\}:").matcher(cp);
            if (!h.find()) throw new AssertionError("missing real app window");
            java.util.regex.Matcher a=java.util.regex.Pattern.compile("(?m)^    mActivityRecord=ActivityRecord(\\{[^\\r\\n]+\\})").matcher(cp);
            if (!a.find()) throw new AssertionError("missing real app record");
            String f="  mCurrentFocus=Window{"+h.group(1)+" u0 "+h.group(2)+"}\n  mFocusedApp=ActivityRecord"+a.group(1);
            WakeForeground.Task real=WakeForeground.verify(f,VisibleWindowDump.inspect(cp,h.group(1)),Foreground.focus(f));
            DailyTest.ok("CPDAY10 WindowState owner, ActivityRecord, task and bounds correlate",real.taskId>0 && real.uid>0);
        }
    }
}
