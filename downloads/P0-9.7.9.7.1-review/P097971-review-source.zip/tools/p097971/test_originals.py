import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

from check_originals import apk_identity, module_identity


class OriginalArtifacts(unittest.TestCase):
    def test_separate_apk(self):
        content = ('<manifest xmlns:android="http://schemas.android.com/apk/res/android" '
                   'package="com.naozho.mask" android:versionName="1.0.0" android:versionCode="4"/>')
        self.assertEqual(apk_identity(content)["versionCode"], "4")
        with self.assertRaises(ValueError):
            apk_identity(content.replace("com.naozho.mask", "com.naozho.clock"))

    def test_separate_module(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "original.zip"
            for module, valid in (("id=naozho_mask", True), ("id=naozho_wake", False),
                                  ("id=naozho_wake\nid=naozho_mask", False)):
                with ZipFile(path, "w") as archive:
                    archive.writestr("module.prop", module + "\nversion=1.0.0\nversionCode=9\n")
                if valid:
                    self.assertEqual(module_identity(path)["versionCode"], "9")
                else:
                    with self.assertRaises(ValueError):
                        module_identity(path)


if __name__ == "__main__":
    unittest.main()
