package com.naozho.station;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.UserHandle;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.ViewConfiguration;

/** Adapter for an Android product's serialized power policy, scoped to the CPDAY10 owner user. */
public final class StationPowerShortcut implements StationPowerArbiter.Host {
    public interface Policy {
        /** Negative outside eligible foreground user 0 / default display. Change this token on
         * user/display/policy changes. Veto active calls, dialer, keyguard, power menu and chords. */
        long currentGeneration();
    }

    private final Context context;
    private final Handler handler;
    private final Policy policy;
    private final StationPowerArbiter keys;
    private final int interval;
    private long sequence;
    private long lastInput = -1;
    private long firstElapsed;
    private long releaseElapsed;
    private Runnable pending;

    public StationPowerShortcut(Context context, Handler policyHandler, Policy policy) {
        this.context = context;
        this.handler = policyHandler;
        this.policy = policy;
        interval = ViewConfiguration.getMultiPressTimeout();
        keys = new StationPowerArbiter(this, interval, ViewConfiguration.getLongPressTimeout(), 100);
    }

    /** Call inline for ordered trusted physical POWER events from this product's policy.
     * The platform still owns sleep/wake, calls, power menu and the normal single-press timer. */
    public void onPowerKey(KeyEvent event, boolean interactive) {
        requirePolicyThread();
        if (event.getKeyCode() != KeyEvent.KEYCODE_POWER) return;
        long time = event.getEventTime();
        long uptime = SystemClock.uptimeMillis();
        if (time < lastInput || time > uptime || uptime - time > 100 || event.isCanceled()) {
            cancel();
            lastInput = Math.max(lastInput, time <= uptime ? time : uptime);
            return;
        }
        boolean fresh = lastInput < 0 || time - lastInput >= interval;
        lastInput = time;
        int action = event.getAction();
        if (!interactive || eligibleGeneration() < 0) {
            cancel();
        } else if (action == KeyEvent.ACTION_DOWN) {
            removePending();
            if (fresh && event.getRepeatCount() == 0) {
                sequence++;
                firstElapsed = SystemClock.elapsedRealtime() - (uptime - time);
                keys.firstDown(sequence, time, true);
            } else {
                keys.nextDown(sequence, time, event.getRepeatCount() != 0);
            }
        } else if (action == KeyEvent.ACTION_UP && keys.up(sequence, time, false)) {
            releaseElapsed = SystemClock.elapsedRealtime() - (uptime - time);
            final long id = sequence;
            pending = () -> {
                pending = null;
                keys.finish(id, SystemClock.uptimeMillis(), eligibleGeneration() >= 0);
            };
            handler.postAtTime(pending, time + interval);
        }
    }

    /** Use for display off, keyguard, chords, call/dialer, menu or foreground user changes. */
    public void cancel() {
        requirePolicyThread();
        removePending();
        keys.cancel();
    }

    private void requirePolicyThread() {
        if (handler.getLooper() != Looper.myLooper()) throw new IllegalStateException("Expected policy looper");
    }

    private void removePending() {
        if (pending != null) handler.removeCallbacks(pending);
        pending = null;
    }

    @Override public long eligibleGeneration() { return policy.currentGeneration(); }

    @Override public boolean tryReturn(long generation, long firstDown, long lastUp) {
        if (eligibleGeneration() != generation || releaseElapsed <= firstElapsed ||
                Math.abs((releaseElapsed - firstElapsed) - (lastUp - firstDown)) > 5) return false;
        int boot = Settings.Global.getInt(context.getContentResolver(), Settings.Global.BOOT_COUNT, -1);
        if (boot < 0) return false;
        String clock = "com.naozho.clock";
        Intent intent = new Intent("com.naozho.clock.action.CONFIRMED_POWER_DOUBLE")
                .setComponent(new ComponentName(clock, clock + ".mode.ConfirmedPowerReceiver"))
                .putExtra("boot_count", boot)
                .putExtra("first_elapsed", firstElapsed)
                .putExtra("released_elapsed", releaseElapsed)
                .addFlags(Intent.FLAG_RECEIVER_FOREGROUND);
        try {
            context.sendBroadcastAsUser(intent, UserHandle.getUserHandleForUid(0));
            return true;
        } catch (RuntimeException error) {
            Log.w("StationPower", "System return delivery rejected", error);
            return false;
        }
    }
}
