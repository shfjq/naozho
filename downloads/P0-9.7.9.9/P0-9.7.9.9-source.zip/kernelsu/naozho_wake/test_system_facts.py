#!/usr/bin/env python3
"""Compile the production wake module against an Android SDK and exercise host-readable identity checks."""
import argparse
from pathlib import Path
import os
import subprocess
import tempfile

import build

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--sdk", required=True, type=Path, help="android.jar (API 36)")
standard = ("WakeSystemFactsTest", "WakeWindowPathTest", "PreviewDismissQueueTest")
identity = "WakeApkIdentityTest"
available = (*standard, identity)
parser.add_argument("--only", nargs="+", choices=available, help="run only selected regression suites")
parser.add_argument("--apk", action="append", type=Path, metavar="FILE",
                    help="for WakeApkIdentityTest, provide original 35, 36, then 37")
args = parser.parse_args()
suites = args.only or ((*standard, identity) if args.apk else standard)
if identity in suites and len(args.apk or []) != 3:
    parser.error("WakeApkIdentityTest needs the original 35, 36, and 37 APKs")
with tempfile.TemporaryDirectory() as tmp:
    tests = [build.HERE / "tests" / (name + ".java") for name in suites]
    subprocess.run(["javac", "--release", "11", "-cp", str(args.sdk), "-d", tmp, *build.sources(), *tests],
                   check=True)
    for name in suites:
        inputs = [build.HERE / "module/clock-identities.tsv", *args.apk] if name == identity else []
        subprocess.run(["java", "-cp", os.pathsep.join((tmp, str(args.sdk))), "com.naozho.power." + name, *inputs],
                       check=True)
