package com.naozho.clock.weather

import android.content.SharedPreferences
import androidx.core.content.edit
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject

internal fun interface NetworkCitySource {
    suspend fun lookup(latitude: String, longitude: String, language: String): String?
}

/**
 * Used only by foreground city resolution. The single cached result is private to the app,
 * separate from weather readings, and keyed by the rounded request coordinates and language.
 */
internal class CityReverseGeocoder(
    private val prefs: SharedPreferences,
    private val source: NetworkCitySource = BigDataCloudCitySource(),
    private val now: () -> Long = System::currentTimeMillis,
) {
    suspend fun city(latitude: Double, longitude: Double, locale: Locale, allowNetwork: Boolean): String? = gate.withLock {
        val lat = rounded(latitude)
        val lon = rounded(longitude)
        val language = locale.language.lowercase(Locale.ROOT).takeIf { it.matches(Regex("[a-z]{2,3}")) } ?: "en"
        val key = "$lat,$lon/$language"
        val time = now()
        val cached = prefs.getString("city", null)?.let(::cityName)
        if (cached != null && key == prefs.getString("key", null) &&
            time - prefs.getLong("resolved", 0) in 0 until CITY_CACHE_MS
        ) return@withLock cached
        if (!allowNetwork) return@withLock null
        val lastAttempt = prefs.getLong("attempt", 0)
        val sinceAttempt = time - lastAttempt
        val retryUntil = prefs.getLong("retryUntil", 0)
        if (lastAttempt != 0L && sinceAttempt in 0 until MIN_REQUEST_INTERVAL_MS ||
            retryUntil - time in 1..MAX_BACKOFF_MS
        ) return@withLock null

        prefs.edit { putLong("attempt", time) }
        try {
            source.lookup(lat, lon, language)?.let(::cityName)?.also { label ->
                prefs.edit {
                    putString("key", key)
                    putString("city", label)
                    putLong("resolved", now())
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (limited: CitySourceRateLimited) {
            prefs.edit { putLong("retryUntil", now() + limited.retryMs.coerceIn(MIN_REQUEST_INTERVAL_MS, MAX_BACKOFF_MS)) }
            null
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private val gate = Mutex()
        private const val MIN_REQUEST_INTERVAL_MS = 60_000L
        private const val CITY_CACHE_MS = 7 * 24 * 60 * 60_000L
        private const val MAX_BACKOFF_MS = 24 * 60 * 60_000L

        internal fun rounded(value: Double): String =
            String.format(Locale.ROOT, "%.2f", value).let { if (it == "-0.00") "0.00" else it }
    }
}

internal class CitySourceRateLimited(val retryMs: Long) : IOException("city_provider_rate_limited")

internal class BigDataCloudCitySource : NetworkCitySource {
    override suspend fun lookup(latitude: String, longitude: String, language: String): String? =
        withContext(Dispatchers.IO) {
            val url = URL("https://api.bigdatacloud.net/data/reverse-geocode-client" +
                "?latitude=$latitude&longitude=$longitude&localityLanguage=$language")
            val connection = url.openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = 4_000
                connection.readTimeout = 4_000
                connection.instanceFollowRedirects = false
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("User-Agent", "NaozhoCPDAY10/1.0 (+https://github.com/shfjq/naozho)")
                val status = connection.responseCode
                if (status == 429 || status == 503) {
                    throw CitySourceRateLimited(retryDelay(connection.getHeaderField("Retry-After")))
                }
                if (status != HttpURLConnection.HTTP_OK) throw IOException("city_provider_response")
                val output = ByteArrayOutputStream()
                val limit = android.os.SystemClock.elapsedRealtime() + 5_000L
                connection.inputStream.use { stream ->
                    val buffer = ByteArray(4096)
                    while (true) {
                        val count = stream.read(buffer)
                        if (count < 0) break
                        if (output.size() + count > 49_152 || android.os.SystemClock.elapsedRealtime() > limit)
                            throw IOException("city_provider_body_limit")
                        output.write(buffer, 0, count)
                    }
                }
                parseCity(output.toString(Charsets.UTF_8.name()))
            } finally {
                connection.disconnect()
            }
        }

    companion object {
        fun parseCity(body: String): String? {
            val root = JSONObject(body)
            return sequenceOf("city", "locality", "principalSubdivision")
                .mapNotNull { field -> (root.opt(field) as? String)?.let(::cityName) }
                .firstOrNull()
        }

        private fun retryDelay(header: String?): Long {
            val text = header?.trim() ?: return 300_000L
            val seconds = text.toLongOrNull()
            if (seconds != null) return seconds.coerceIn(1L, 86_400L) * 1000L
            return runCatching {
                ZonedDateTime.parse(text, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() -
                    System.currentTimeMillis()
            }.getOrDefault(300_000L).coerceIn(1_000L, 86_400_000L)
        }
    }
}

internal fun cityName(value: String): String? =
    value.trim().filterNot(Char::isISOControl).take(32).takeIf { text -> text.any(Char::isLetter) }
