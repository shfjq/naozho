Use a copy of this source tree. Run git apply rollback/14bdaec.patch to restore the verified 0.6.16-dev/31 + 1.2.0 source.
The paired rollback APK distributed here is built from those sources with only versionCode = 32 in app/build.gradle.kts, and its accompanying 1.2.0 module pins that APK. Use the original signing identity.
