package com.naozho.clock.mode

import android.app.Activity
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.util.Log
import android.view.Display
import android.view.View
import android.widget.RemoteViews
import com.naozho.clock.R
import java.io.File

/** The launcher renders these RemoteViews within a user-placed HOME widget. No WindowManager or
 * input token, focus, Return, LockTask, shell access or PendingIntent in either widget layout. */
class WakePreviewWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        manager.updateAppWidget(ids, views(context, false))
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        val left = approved(context) - ids.map(Int::toString).toSet()
        store(context).edit().putStringSet(IDS, left).commit()
        if (left.isEmpty()) {
            present(context).delete()
            clear(context)
        }
    }

    override fun onDisabled(context: Context) {
        clear(context)
        present(context).delete()
        store(context).edit().remove(IDS).commit()
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == EXPIRY) {
            dismiss(context, intent.getIntExtra(EXTRA_BOOT_COUNT, -1), intent.getLongExtra("dark_elapsed", -1))
        } else super.onReceive(context, intent)
    }

    companion object {
        private const val HOME = "com.droiclaw.launcher3"
        private const val IDS = "approved_home_widget_ids"
        private const val EXPIRY = "com.naozho.clock.action.EXPIRE_HOME_PREVIEW"
        private const val TTL_MS = 2500L
        private val main = Handler(Looper.getMainLooper())
        private var waiting: Watch? = null
        private var observedPrefs: SharedPreferences? = null
        private var modeListener: SharedPreferences.OnSharedPreferenceChangeListener? = null

        private data class Key(val boot: Int, val dark: Long)
        private fun store(c: Context) = c.getSharedPreferences("home_visual_preview", Context.MODE_PRIVATE)
        private fun approved(c: Context) = store(c).getStringSet(IDS, emptySet()).orEmpty()
        private fun present(c: Context) = File(c.createDeviceProtectedStorageContext().filesDir, "wake-preview-widget.present")
        private fun component(c: Context) = ComponentName(c, WakePreviewWidget::class.java)
        internal fun views(c: Context, shown: Boolean): RemoteViews =
            if (shown) clockLayout(c, View.VISIBLE) else RemoteViews(c.packageName, R.layout.wake_preview_empty)

        private fun clockLayout(c: Context, visibility: Int) =
            RemoteViews(c.packageName, R.layout.wake_preview_clock).apply {
                setViewVisibility(R.id.wake_preview_root, visibility)
            }

        private fun mainThread(action: () -> Unit) {
            val guarded = Runnable {
                try { action() } catch (e: RuntimeException) {
                    Log.w("NaozhoWakePreview", "Home preview unavailable: " + e.javaClass.simpleName)
                }
            }
            if (Looper.myLooper() == Looper.getMainLooper()) guarded.run() else main.post(guarded)
        }

        private fun freeme(c: Context): Boolean {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            return c.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == HOME
        }

        private fun homeCategory(mgr: AppWidgetManager, id: Int): Boolean =
            mgr.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_HOST_CATEGORY,
                AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) == AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN

        internal fun bind(c: Context, caller: String?, id: Int): Boolean {
            if (Build.VERSION.SDK_INT < 34 || caller != HOME || id <= 0 || !freeme(c)) {
                Log.i("NaozhoWakePreview", "Home widget configuration refused: host_or_home")
                return false
            }
            val mgr = AppWidgetManager.getInstance(c)
            if (id !in mgr.getAppWidgetIds(component(c)) || !homeCategory(mgr, id)) {
                Log.i("NaozhoWakePreview", "Home widget configuration refused: binding_or_category")
                return false
            }
            mgr.updateAppWidget(id, views(c, false))
            if (!store(c).edit().putStringSet(IDS, approved(c) + id.toString()).commit()) return false
            return try { present(c).createNewFile(); true } catch (e: java.io.IOException) {
                store(c).edit().putStringSet(IDS, approved(c) - id.toString()).commit()
                false
            }
        }

        private fun hostIds(c: Context): IntArray {
            val ids = approved(c)
            if (ids.isEmpty() || !freeme(c)) return intArrayOf()
            val mgr = AppWidgetManager.getInstance(c)
            return mgr.getAppWidgetIds(component(c)).filter { it.toString() in ids && homeCategory(mgr, it) }.toIntArray()
        }

        private fun modeAllows(c: Context, key: Key): Boolean {
            if (!c.getSystemService(UserManager::class.java).isUserUnlocked || !ModeState(c).independentLock()) return false
            val mode = c.getSharedPreferences("desktop_mode", 0)
            return mode.getBoolean("android", false) && mode.getInt("boot", -1) == key.boot &&
                mode.getLong("mode_since", Long.MAX_VALUE) < key.dark
        }

        private fun active(c: Context): Key? {
            val p = store(c)
            return if (p.contains("visible_dark")) Key(p.getInt("visible_boot", -1), p.getLong("visible_dark", -1)) else null
        }

        /** Read the current durable generation; callbacks for reserve/check alone do not touch the widget. */
        fun watchMode(context: Context) = mainThread {
            val c = context.applicationContext
            if (Build.VERSION.SDK_INT < 34 || observedPrefs != null || !present(c).exists() || (waiting == null && active(c) == null)) return@mainThread
            val p = c.getSharedPreferences("desktop_mode", 0)
            val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, field ->
                if (field == null || field in setOf("android", "boot", "mode_since", "dev_rehearsal", "managed_home", "managed_lock")) {
                    mainThread {
                        val key = waiting?.key ?: active(c)
                        if (key != null && !modeAllows(c, key)) dismiss(c, key.boot, key.dark)
                    }
                }
            }
            p.registerOnSharedPreferenceChangeListener(listener)
            modeListener = listener
            observedPrefs = p
        }

        fun arm(context: Context, boot: Int, dark: Long) = mainThread {
            val c = context.applicationContext
            if (Build.VERSION.SDK_INT < 34 || !present(c).exists() || !ClockPrewarm.eligible(c, boot, dark)) return@mainThread
            val key = Key(boot, dark)
            val p = store(c)
            if (waiting?.key == key || (p.getInt("closed_boot", -1) == boot && dark <= p.getLong("closed_dark", -1))) return@mainThread
            if (!modeAllows(c, key)) return@mainThread
            val ids = hostIds(c)
            if (ids.isEmpty()) return@mainThread
            clear(c)
            // Freeme may inflate this non-visible tree now. The first ON update uses
            // the same layout id and only changes visibility, allowing host-side reapply.
            // An evicted host view can still inflate the complete, current-time layout.
            AppWidgetManager.getInstance(c).updateAppWidget(ids, clockLayout(c, View.INVISIBLE))
            val next = Watch(c, key)
            waiting = next
            watchMode(c)
            try {
                next.start()
                if (waiting === next) trace("PREVIEW_ARMED_AT", key)
            } catch (e: RuntimeException) {
                dismiss(c, boot, dark)
                throw e
            }
        }

        fun clear(context: Context) = mainThread {
            val c = context.applicationContext
            val key = waiting?.key ?: active(c) ?: return@mainThread
            retract(c, key)
        }

        /** A late terminal broadcast must neither resurrect an old arm nor clear a newer clock. */
        fun dismiss(context: Context, boot: Int, dark: Long) = mainThread {
            val c = context.applicationContext
            if (Build.VERSION.SDK_INT < 34 || boot < 0 || dark <= 0 || dark > SystemClock.elapsedRealtime() ||
                (!present(c).exists() && waiting == null && active(c) == null) || bootCount(c) != boot) return@mainThread
            val p = store(c)
            if (p.getInt("closed_boot", -1) != boot || p.getLong("closed_dark", -1) < dark) {
                p.edit().putInt("closed_boot", boot).putLong("closed_dark", dark).commit()
            }
            val current = waiting?.key ?: active(c)
            if (current != null && (current.boot != boot || current.dark <= dark)) retract(c, current)
        }

        private fun retract(c: Context, key: Key) {
            val p = store(c)
            if (waiting?.key == key) {
                val old = waiting
                waiting = null
                old?.close()
            }
            if (active(c) == key) {
                // Clear every previously approved slot, even if the user has since switched HOME.
                val ids = approved(c).mapNotNull(String::toIntOrNull).toIntArray()
                if (ids.isNotEmpty()) AppWidgetManager.getInstance(c).updateAppWidget(ids, views(c, false))
                p.edit().remove("visible_boot").remove("visible_dark").commit()
                c.getSystemService(AlarmManager::class.java).cancel(expiry(c, key))
                trace("PREVIEW_CLEARED_AT", key)
            }
            if (waiting == null && active(c) == null) {
                modeListener?.let { observedPrefs?.unregisterOnSharedPreferenceChangeListener(it) }
                observedPrefs = null
                modeListener = null
            }
        }

        private fun expiry(c: Context, key: Key): PendingIntent {
            val intent = Intent(c, WakePreviewWidget::class.java).setAction(EXPIRY)
                .setData(Uri.parse("naozho-preview://expiry/${key.boot}/${key.dark}"))
                .putExtra(EXTRA_BOOT_COUNT, key.boot).putExtra("dark_elapsed", key.dark)
            return PendingIntent.getBroadcast(c, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        private fun trace(stage: String, key: Key) = Log.i("NaozhoWakePerf",
            "${SystemClock.elapsedRealtime()} $stage boot=${key.boot} dark=${key.dark} pid=${android.os.Process.myPid()}")

        private class Watch(val c: Context, val key: Key) : DisplayManager.DisplayListener {
            val displays = c.getSystemService(DisplayManager::class.java)
            private var seenOn = false
            private var showing = false
            private val expire = Runnable { dismiss(c, key.boot, key.dark) }
            private val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) { sample() }
            }

            fun start() {
                displays.registerDisplayListener(this, main)
                c.registerReceiver(receiver, IntentFilter().apply {
                    addAction(Intent.ACTION_SCREEN_ON)
                    addAction(Intent.ACTION_SCREEN_OFF)
                }, Context.RECEIVER_NOT_EXPORTED)
                sample()
            }

            override fun onDisplayChanged(id: Int) { if (id == Display.DEFAULT_DISPLAY) sample() }
            override fun onDisplayAdded(id: Int) { if (id == Display.DEFAULT_DISPLAY) sample() }
            override fun onDisplayRemoved(id: Int) { if (id == Display.DEFAULT_DISPLAY) expire.run() }

            fun sample() {
                if (waiting !== this) return
                try { readDisplay() } catch (e: RuntimeException) {
                    Log.w("NaozhoWakePreview", "Display evidence unavailable: " + e.javaClass.simpleName)
                    expire.run()
                }
            }

            private fun readDisplay() {
                val state = displays.getDisplay(Display.DEFAULT_DISPLAY)?.state
                if (state != Display.STATE_ON) {
                    if (seenOn || state !in setOf(Display.STATE_OFF, Display.STATE_DOZE, Display.STATE_DOZE_SUSPEND)) expire.run()
                    return
                }
                seenOn = true
                if (!c.getSystemService(PowerManager::class.java).isInteractive) {
                    if (showing) expire.run()
                    return
                }
                if (!modeAllows(c, key) || c.getSystemService(KeyguardManager::class.java).isKeyguardLocked ||
                    c.getSystemService(AudioManager::class.java).mode != AudioManager.MODE_NORMAL ||
                    c.getSystemService(ActivityManager::class.java).lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE ||
                    !c.getSystemService(DevicePolicyManager::class.java).isDeviceOwnerApp(c.packageName)) {
                    expire.run()
                    return
                }
                if (showing) return
                val ids = hostIds(c)
                val alarm = c.getSystemService(AlarmManager::class.java)
                if (ids.isEmpty() || !alarm.canScheduleExactAlarms()) {
                    val reason = if (ids.isEmpty()) "no_eligible_home_widget" else "exact_cleanup_unavailable"
                    Log.i("NaozhoWakePreview", "Home preview skipped: $reason")
                    expire.run()
                    return
                }
                val deadline = SystemClock.elapsedRealtime() + TTL_MS
                try {
                    // Independent, non-wakeup system cleanup survives loss of this application process.
                    alarm.setExact(AlarmManager.ELAPSED_REALTIME, deadline, expiry(c, key))
                    if (!store(c).edit().putInt("visible_boot", key.boot).putLong("visible_dark", key.dark).commit()) {
                        expire.run(); return
                    }
                    AppWidgetManager.getInstance(c).updateAppWidget(ids, views(c, true))
                    showing = true
                    trace("PREVIEW_SUBMITTED_AT", key)
                    main.postDelayed(expire, (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(0L))
                } catch (_: RuntimeException) { expire.run() }
            }

            fun close() {
                main.removeCallbacks(expire)
                displays.unregisterDisplayListener(this)
                runCatching { c.unregisterReceiver(receiver) }
            }
        }
    }
}

/** Require the real HOME launching for result, and verify system binding before recording the id. */
class WakePreviewConfiguration : Activity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        val ok = intent.action == AppWidgetManager.ACTION_APPWIDGET_CONFIGURE &&
            runCatching { WakePreviewWidget.bind(this, callingPackage, id) }.getOrDefault(false)
        if (ok) setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)) else setResult(RESULT_CANCELED)
        finish()
    }
}
