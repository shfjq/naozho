package com.naozho.clock.mode

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.os.UserManager
import android.util.Log
import android.view.Display
import com.naozho.clock.R
import com.naozho.clock.alarm.AlarmRuntime
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex

/** Best effort only. No Activity, service, WakeLock, mode write, alarm scheduling or UI. */
internal object ClockPrewarm {
    const val ACTION = "com.naozho.clock.action.WAKE_DARK_PREWARM"
    private val worker = Mutex()
    private var initialized = false
    private var lastDark = -1L

    internal fun eligible(ctx: Context, boot: Int, dark: Long): Boolean {
        val now = SystemClock.elapsedRealtime()
        return ctx.isDevelopmentBuild && dark > 0 && dark <= now && now - dark <= 5000 &&
            boot >= 0 && boot == bootCount(ctx) &&
            ctx.getSystemService(UserManager::class.java).isUserUnlocked &&
            !ctx.getSystemService(PowerManager::class.java).isInteractive &&
            ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.state == Display.STATE_OFF &&
            ctx.getSystemService(DevicePolicyManager::class.java).isDeviceOwnerApp(ctx.packageName) &&
            ModeState(ctx).independentLock() && ctx.getSharedPreferences("desktop_mode", Context.MODE_PRIVATE).getBoolean("android", false)
    }

    fun request(context: Context, intent: Intent) {
        val app = context.applicationContext as? AlarmRuntime ?: return
        val boot = intent.getIntExtra(EXTRA_BOOT_COUNT, -1)
        val dark = intent.getLongExtra("dark_elapsed", -1)
        if (android.os.Build.VERSION.SDK_INT < 34) return
        if (intent.identifier != "warm.$boot.$dark") return
        // Return from the broadcast immediately. A cold process may be reclaimed; the formal
        // receiver always works without waiting for this job or a PREWARM_READY receipt.
        app.background.launch { prepare(app, boot, dark) }
    }

    internal suspend fun prepare(app: AlarmRuntime, boot: Int, dark: Long): Boolean {
        if (!worker.tryLock()) return false
        try {
            if (dark <= lastDark || !eligible(app, boot, dark)) return false
            lastDark = dark
            // Only a user-placed HOME widget can arm; a missing widget never delays
            // the formal wake path. Android policy still owns the foreground window.
            try { WakePreviewWidget.arm(app, boot, dark) }
            catch (unavailable: RuntimeException) { Log.w("NaozhoWakePreview", "Home preview unavailable") }
            val reused = initialized
            if (!initialized) {
                app.getSharedPreferences("clock_display", Context.MODE_PRIVATE).contains("brightness")
                app.getSharedPreferences("clock_weather", Context.MODE_PRIVATE).contains("updated")
                app.resources.getStringArray(R.array.weekdays)
                app.repository.warmConnection()
                initialized = true
            }
            if (!eligible(app, boot, dark)) return false
            Log.i("NaozhoWakePerf",
                "${SystemClock.elapsedRealtime()} PREWARM_READY_AT boot=$boot dark=$dark pid=${Process.myPid()} reused=$reused")
            return true
        } catch (e: Exception) {
            Log.i("NaozhoWakePerf", "${SystemClock.elapsedRealtime()} PREWARM_UNAVAILABLE boot=$boot dark=$dark")
            return false
        } finally { worker.unlock() }
    }
}
