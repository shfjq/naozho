package com.naozho.clock.mode

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log

/** Explicit system delivery. No input event listener or receiver-supplied launch target. */
class ConfirmedPowerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val receivedAt = SystemClock.elapsedRealtime()
        if (intent.component != ComponentName(context, ConfirmedPowerReceiver::class.java)) return
        try {
            if (intent.action == ClockPrewarm.ACTION) { ClockPrewarm.request(context, intent); return }
            if (intent.action == DISMISS) {
                if (android.os.Build.VERSION.SDK_INT < 34) return
                val sender = sentFromUid
                // Android can omit broadcaster identity. This explicit component always
                // requires STATUS_BAR_SERVICE; the delivery can only hide a matching tile.
                if (sender >= 0 && sender != 0 && sender != 2000) return
                val boot = intent.getIntExtra(EXTRA_BOOT_COUNT, -1)
                val dark = intent.getLongExtra("dark_elapsed", -1)
                if (boot < 0 || boot != bootCount(context) || dark !in 1L..receivedAt ||
                    intent.identifier != "dismiss.$boot.$dark") return
                WakePreviewWidget.dismiss(context, boot, dark)
                return
            }
            // The root sender must verify the full formal delivery in AMS before it publishes
            // the private receipt. The later commit authorizes that same request only.
            if (intent.action == WakeTicket.RETURN) return
            val entry: Intent
            if (intent.action == WakeTicket.COMMIT) {
                if (android.os.Build.VERSION.SDK_INT < 34) return
                val ticket = WakeTicket.read(intent) ?: return
                val actual = sentFromUid
                if ((actual >= 0 && actual != ticket.sender) || intent.identifier != ticket.id + ".commit") return
                if (!ClockPowerReturn.acceptWake(context, ticket, PowerDelivery.RESERVE)) {
                    Log.i("NaozhoPowerReturn", "Wake rejected at receiver; no activity requested")
                    return
                }
                // A cold process can receive COMMIT after its prewarm process died.
                // Reattach the optional desktop tile observer to the persisted mode.
                try { WakePreviewWidget.watchMode(context) }
                catch (unavailable: RuntimeException) { Log.w("NaozhoWakePreview", "Host observation unavailable") }
                entry = ticket.entry(context).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                ticket.trace("COMMIT_RECEIVED_AT", receivedAt)
                ticket.trace("ACTIVITY_REQUEST_AT")
            } else {
                if (!ClockPowerReturn.accept(context, intent, PowerDelivery.RESERVE)) {
                    Log.i("NaozhoPowerReturn", "Double rejected at receiver; no activity requested")
                    return
                }
                entry = Intent(ClockPowerReturn.ACTION).setComponent(ClockPowerReturn.target(context))
                    .putExtra(EXTRA_BOOT_COUNT, intent.getIntExtra(EXTRA_BOOT_COUNT, -1))
                    .putExtra(ClockPowerReturn.FIRST, intent.getLongExtra(ClockPowerReturn.FIRST, -1))
                    .putExtra(ClockPowerReturn.RELEASE, intent.getLongExtra(ClockPowerReturn.RELEASE, -1))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(entry)
            Log.i("NaozhoPowerReturn", "Protected request delivered; awaiting foreground and lock readback")
        } catch (error: RuntimeException) {
            Log.w("NaozhoPowerReturn", "Confirmed double unavailable", error)
        }
    }
    internal companion object {
        const val DISMISS = "com.naozho.clock.action.WAKE_PREVIEW_DISMISS"
    }
}
