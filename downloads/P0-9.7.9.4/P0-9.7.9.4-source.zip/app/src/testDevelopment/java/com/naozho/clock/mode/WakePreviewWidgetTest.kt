package com.naozho.clock.mode

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.Application
import android.app.KeyguardManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.view.Display
import android.view.View
import android.widget.TextClock
import com.naozho.clock.R
import java.time.Duration
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlarmManager
import org.robolectric.shadows.ShadowLog

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class WakePreviewWidgetTest {
    private val app: Application get() = RuntimeEnvironment.getApplication()
    private val widgets get() = AppWidgetManager.getInstance(app)
    private val alarms get() = app.getSystemService(AlarmManager::class.java)
    private val display get() = app.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
    private val provider get() = ComponentName(app, WakePreviewWidget::class.java)
    private val id = 17
    private val home = "com.droiclaw.launcher3"
    private val looper get() = shadowOf(Looper.getMainLooper())

    @Before fun setup() {
        prepareOwnerAndHome(app)
        shadowOf(app.getSystemService(UserManager::class.java)).setUserUnlocked(true)
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        ShadowAlarmManager.setCanScheduleExactAlarms(true)
        shadowOf(widgets).addBoundWidget(id, AppWidgetProviderInfo().apply {
            provider = this@WakePreviewWidgetTest.provider
            initialLayout = R.layout.wake_preview_empty
        })
        assertTrue(ModeState(app).saveDeployment(true, DesktopMode.ANDROID, false))
        looper.idleFor(Duration.ofMillis(25))
    }

    private fun startDark(): Long {
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(false)
        shadowOf(display).setState(Display.STATE_OFF)
        looper.idleFor(Duration.ofMillis(5))
        return SystemClock.elapsedRealtime().also { WakePreviewWidget.arm(app, 1, it); looper.idle() }
    }
    private fun screen(state: Int, interactive: Boolean) {
        shadowOf(display).setState(state)
        shadowOf(app.getSystemService(PowerManager::class.java)).setIsInteractive(interactive)
        app.sendBroadcast(Intent(if (state == Display.STATE_ON) Intent.ACTION_SCREEN_ON else Intent.ACTION_SCREEN_OFF))
        looper.idle()
    }
    private fun shown(): Boolean {
        val root = shadowOf(widgets).getViewFor(id) ?: return false
        return root.findViewById<TextClock>(R.id.wake_preview_time) != null && root.visibility == View.VISIBLE
    }
    private fun active() = assertTrue(WakePreviewWidget.bind(app, home, id))
    private fun submits() = ShadowLog.getLogsForTag("NaozhoWakePerf").count { "PREVIEW_SUBMITTED_AT" in it.msg }

    @Test fun onlyConfiguredBoundFreemeHomeSlotMayReceivePreview() {
        assertFalse(WakePreviewWidget.bind(app, null, id))
        assertFalse(WakePreviewWidget.bind(app, "com.android.systemui", id))
        assertFalse(WakePreviewWidget.bind(app, home, 999))
        widgets.updateAppWidgetOptions(id, Bundle().apply {
            putInt(AppWidgetManager.OPTION_APPWIDGET_HOST_CATEGORY, AppWidgetProviderInfo.WIDGET_CATEGORY_KEYGUARD)
        })
        assertFalse(WakePreviewWidget.bind(app, home, id))
        startDark(); screen(Display.STATE_ON, true)
        assertEquals(0, submits())
    }

    @Test fun darkAndAodStayBlankOnlyOneNonInteractiveHomePreviewThenTimeout() {
        active()
        val dark = startDark()
        val hidden = shadowOf(widgets).getViewFor(id)
        assertEquals(View.INVISIBLE, hidden.visibility)
        val prepared = hidden.findViewById<TextClock>(R.id.wake_preview_time)
        assertNotNull(prepared)
        assertFalse(shown())
        screen(Display.STATE_DOZE, false)
        assertFalse(shown())
        screen(Display.STATE_ON, false)
        assertFalse(shown())
        screen(Display.STATE_ON, true)
        assertTrue(shown())
        val view = shadowOf(widgets).getViewFor(id)
        assertFalse(view.isClickable)
        assertFalse(view.isFocusable)
        val clock = view.findViewById<TextClock>(R.id.wake_preview_time)
        assertSame(prepared, clock)
        assertFalse(clock.isClickable)
        assertFalse(clock.isFocusable)
        assertEquals("HH:mm", clock.format24Hour)
        assertNull(shadowOf(app).nextStartedActivity)
        assertEquals(ActivityManager.LOCK_TASK_MODE_NONE, app.getSystemService(ActivityManager::class.java).lockTaskModeState)
        assertFalse(app.getSharedPreferences("desktop_mode", 0).contains("wake_pending"))
        screen(Display.STATE_ON, true)
        assertEquals(1, submits())
        val backup = shadowOf(alarms).scheduledAlarms.single()
        assertEquals(AlarmManager.ELAPSED_REALTIME, backup.type)
        assertEquals(ComponentName(app, WakePreviewWidget::class.java), shadowOf(backup.operation).savedIntent.component)
        looper.idleFor(Duration.ofMillis(2501))
        assertFalse(shown())
        assertTrue(ShadowLog.getLogsForTag("NaozhoWakePerf").any { "PREVIEW_CLEARED_AT boot=1 dark=$dark" in it.msg })
    }

    @Test fun rejectionBeforeArmCannotResurrectAndOldRejectionLeavesNewCycleAlone() {
        active()
        val first = startDark()
        WakePreviewWidget.dismiss(app, 1, first)
        WakePreviewWidget.arm(app, 1, first)
        screen(Display.STATE_ON, true)
        assertFalse(shown())
        val second = startDark()
        screen(Display.STATE_ON, true)
        assertTrue(shown())
        WakePreviewWidget.dismiss(app, 1, first)
        assertTrue(shown())
        WakePreviewWidget.dismiss(app, 1, second)
        assertFalse(shown())
    }

    @Test fun keyguardOrMissingIndependentCleanupRefusesPreview() {
        active()
        startDark()
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(true)
        screen(Display.STATE_ON, true)
        assertFalse(shown())
        shadowOf(app.getSystemService(KeyguardManager::class.java)).setKeyguardLocked(false)
        ShadowAlarmManager.setCanScheduleExactAlarms(false)
        startDark(); screen(Display.STATE_ON, true)
        assertFalse(shown())
        assertEquals(0, submits())
    }

    @Test fun maintenanceRetractsAndRearmDoesNotReplayIlluminatedScreen() {
        active()
        startDark(); screen(Display.STATE_ON, true)
        assertTrue(shown())
        ModeState(app).saveDeployment(false, DesktopMode.ANDROID, false)
        looper.idle()
        assertFalse(shown())
        ModeState(app).saveDeployment(true, DesktopMode.ANDROID, false)
        screen(Display.STATE_ON, true)
        assertEquals(1, submits())
    }

    @Test fun explicitExpiryAfterLossOfRuntimeSubscriptionsClearsPersistedHostPixels() {
        active()
        // Model the system's retained RemoteViews and the application's durable receipt
        // after process loss; no in-process watcher is armed in this test.
        val dark = SystemClock.elapsedRealtime()
        assertTrue(app.getSharedPreferences("home_visual_preview", 0).edit()
            .putInt("visible_boot", 1).putLong("visible_dark", dark).commit())
        widgets.updateAppWidget(id, WakePreviewWidget.views(app, true))
        assertTrue(shown())
        val expiry = Intent(app, WakePreviewWidget::class.java)
            .setAction("com.naozho.clock.action.EXPIRE_HOME_PREVIEW")
            .putExtra(EXTRA_BOOT_COUNT, 1).putExtra("dark_elapsed", dark)
        WakePreviewWidget().onReceive(app, expiry)
        assertFalse(shown())
        assertNull(shadowOf(app).nextStartedActivity)
    }
}
