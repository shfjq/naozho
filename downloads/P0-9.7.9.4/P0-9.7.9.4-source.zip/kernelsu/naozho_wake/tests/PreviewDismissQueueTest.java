package com.naozho.power;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Exercises the actual dismissal transport scheduler, including delayed work from old cycles. */
public final class PreviewDismissQueueTest {
    public static void main(String[] args) throws Exception {
        if (!Arrays.asList(PreviewDismissQueue.envelope(6, 721)).equals(Arrays.asList(
                "/system/bin/am","broadcast","--user","0","--receiver-foreground","--exclude-stopped-packages",
                "-n",TrialChecks.RECEIVER,"-a","com.naozho.clock.action.WAKE_PREVIEW_DISMISS",
                "-i","dismiss.6.721","--ei","boot_count","6","--el","dark_elapsed","721"))) {
            throw new AssertionError("the preview cancel has a single fixed target and carries no return ticket");
        }
        CountDownLatch started = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        List<Long> sent = Collections.synchronizedList(new ArrayList<>());
        PreviewDismissQueue queue = new PreviewDismissQueue((boot,dark) -> {
            if (boot != 6) throw new AssertionError("unexpected boot");
            sent.add(dark);
            if (dark == 721L) {
                started.countDown();
                if (!release.await(3,TimeUnit.SECONDS)) throw new AssertionError("stuck scheduler");
            }
        });
        queue.dismiss(-1,1);
        queue.dismiss(6,-1);
        queue.dismiss(6,721);
        if (!started.await(2,TimeUnit.SECONDS)) throw new AssertionError("no dispatch");
        queue.dismiss(6,722);
        queue.dismiss(6,720);
        queue.dismiss(6,723);
        queue.dismiss(6,723);
        release.countDown();
        queue.close();
        queue.dismiss(6,724);
        if (!sent.equals(Arrays.asList(721L,723L))) throw new AssertionError("stale/duplicate cancel: " + sent);
        System.out.println("preview dismissal: fixed protected target, bounded queue, stale/duplicate and close passed");
    }
}
