import csv
from pathlib import Path
import tempfile
import unittest

from timeline import add_observations, read_cycles, summaries, write_sheet


def rows(boot=1, dark=100, details=True, ready_pid=18, entry="on_new_intent", retained="true"):
    # Relative stages from the protocol. Display, AMS and the app maintain separate logs.
    base = [
        (0, "DARK_OBSERVED_AT"), (2, "PREWARM_START_AT"), (64, "PREWARM_READY_AT"),
        (4900, "WAKE_CANDIDATE_AT"), (4930, "FULL_WAKE_AT"), (4940, "RETURN_PENDING_AT"),
        (5080, "RETURN_DELIVERED_AT"), (5310, "COMMIT_DELIVERED_AT"),
        (5140, "ACTIVITY_START_AT"), (5200, "ACTIVITY_READY_AT"),
        (5180, "CLOCK_FOCUSED_AT"), (5240, "LOCKED_CONFIRMED_AT"), (5320, "CLOCK_FOCUSED")]
    extras = [(4960, "GUARD1_READY_AT"), (4990, "RETURN_SEND_AT"), (5040, "GUARD2_READY_AT"),
              (5090, "GUARD2_REFRESH_AT"), (5100, "COMMIT_SEND_AT"), (5110, "COMMIT_RECEIVED_AT"),
              (5120, "ACTIVITY_REQUEST_AT")] if details else []
    lines = []
    for offset, stage in base + extras:
        payload = f"boot={boot} dark={dark}"
        if stage == "FULL_WAKE_AT":
            payload += f" epoch=epoch-{boot}-{dark}"
        if offset > 4940 and stage != "CLOCK_FOCUSED":
            payload += f" request=req{boot}.{dark}"
        if stage == "ACTIVITY_START_AT":
            payload += " pid=18"
            if details:
                payload += f" entry={entry} retained_clock={retained}"
        if stage == "PREWARM_READY_AT":
            payload += f" pid={ready_pid}"
        lines.append(f"{dark+offset} {stage} {payload}")
    return lines


def cycle(lines):
    return next(read_cycles("\n".join(lines)))


class PerfTest(unittest.TestCase):
    def test_late_power_sample_is_diagnostic_only(self):
        trace = rows()
        sample = ("5100 PMS_SAMPLE boot=1 dark=100 slot=1 due=5003 start=5011 "
                  "end=5028 decision_at=5030 via=binder_proto result=FULL_WAKE")
        measured = cycle(trace + [sample, sample])
        power, = measured["power_samples"]
        self.assertEqual((8, 17, 2), tuple(power[k] for k in
                         ("scheduler_delay_ms", "service_read_ms", "callback_delay_ms")))
        self.assertEqual([], measured["issues"])
        refused = cycle([sample.replace("decision_at=5030", "decision_at=5000")])
        self.assertIsNone(refused["power_samples"][0]["service_read_ms"])
        self.assertIn("incomplete", refused["issues"])

    def test_independent_proof_frame_and_focus_clocks(self):
        lines = rows()
        result = cycle(reversed(lines + lines[:3]))
        self.assertEqual(result["issues"], [])
        self.assertEqual(result["detail_missing"], [])
        self.assertEqual(result["epoch"], "epoch-1-100")
        self.assertEqual(result["on_to_first_clock_draw_ms"], 300)
        self.assertEqual(result["on_to_focus_ms"], 280)
        self.assertEqual(result["activity_request_to_start_ms"], 20)
        self.assertEqual(result["return_send_to_proof_ms"], 90)
        self.assertEqual(result["proof_remaining_after_guard2_ms"], 40)
        self.assertEqual(result["prewarm_ms"], 62)
        self.assertEqual(result["warm"], "ready_same_process")
        self.assertEqual(result["activity_entry"], "on_new_intent")
        self.assertEqual(result["retained_clock"], "true")
        self.assertEqual(result["touch"], "requires_user")
        self.assertEqual(result["freeme_flash"], "requires_observation")

    def test_launcher_submission_can_precede_root_on_and_stands_apart_from_the_app(self):
        lines = rows() + ["4990 PREVIEW_SUBMITTED_AT boot=1 dark=100 pid=18",
                          "5350 PREVIEW_CLEARED_AT boot=1 dark=100 pid=18"]
        result = cycle(lines)
        self.assertEqual(result["issues"], [])
        self.assertEqual(result["preview"]["submission_minus_on_callback_ms"], -10)
        self.assertEqual(result["preview"]["clear_minus_submission_ms"], 360)
        self.assertEqual(result["on_to_first_clock_draw_ms"], 300)
        self.assertNotIn("physical_observation", result)

        # No widget or an incomplete widget log must not alter an authenticated return.
        self.assertFalse(cycle(rows())["preview"]["submission_recorded"])
        no_submit = cycle(rows() + [lines[-1]])
        self.assertEqual(no_submit["preview"]["issues"], ["clear_without_prior_submission"])
        self.assertEqual(no_submit["on_to_focus_ms"], 280)
        duplicate = cycle(lines + ["4995 PREVIEW_SUBMITTED_AT boot=1 dark=100 pid=18"])
        self.assertIsNone(duplicate["preview"]["submission_minus_on_callback_ms"])
        self.assertEqual(duplicate["issues"], [])

        # Preview by itself cannot complete a wake transaction or imply an early draw.
        only_preview = cycle(lines[-2:])
        self.assertIn("incomplete", only_preview["issues"])
        self.assertIsNone(only_preview["on_to_first_clock_draw_ms"])

    def test_readback_path_and_physical_baseline_split(self):
        lines = [s + " wm_focus=binder wm_visible=shell focus_seed=on_edge" if "GUARD1_READY_AT" in s
                 else s + " via=binder_pms" if "FULL_WAKE_AT" in s else s for s in rows()]
        result = cycle(lines)
        self.assertEqual(result["window_evidence"]["GUARD1_READY_AT"],
                         {"focus": "binder", "visible": "shell", "focus_seed": "on_edge"})
        self.assertEqual(result["power_evidence_source"], "binder_pms")
        self.assertEqual(result["full_to_return_proof_ms"], 150)
        self.assertEqual(result["guard2_ready_to_commit_receiver_ms"], 70)

    def test_video_worksheet_boundaries_and_unique_cycle(self):
        cycles = [cycle(rows()), cycle(rows(dark=200))]
        with tempfile.TemporaryDirectory() as directory:
            sheet = Path(directory) / "witness.csv"
            write_sheet(sheet, cycles)
            with self.assertRaises(FileExistsError):
                write_sheet(sheet, cycles)
            with sheet.open(encoding="utf-8-sig", newline="") as stream:
                headings, blank, other = list(csv.reader(stream))
            def rewrite(*fields):
                with sheet.open("w", encoding="utf-8-sig", newline="") as stream:
                    csv.writer(stream).writerows([headings, *fields])
            add_observations(sheet, cycles)
            self.assertNotIn("physical_observation", cycles[0])
            rewrite(blank[:2] + [999, "launcher_widget", "yes", "responded", 2000], other)
            add_observations(sheet, cycles)
            observed = cycles[0]["physical_observation"]
            self.assertIs(observed["clock_visible_under_1s"], True)
            self.assertIs(observed["responsive_by_2s_witnessed"], True)
            self.assertNotIn("physical_observation", cycles[1])
            rewrite(blank[:2] + [1000, "unknown", "unknown", "responded", 2550])
            add_observations(sheet, cycles)
            self.assertFalse(cycles[0]["physical_observation"]["clock_visible_under_1s"])
            self.assertIsNone(cycles[0]["physical_observation"]["responsive_by_2s_witnessed"])
            for invalid in (
                    [blank, blank], [[99, 300, "", "", "", "", ""]],
                    [blank[:2] + [99, "unknown", "no", "responded", 90]],
                    [blank[:2] + [99, "unknown", "no", "failed", 440]],
                    [blank[:2] + [-1, "", "", "", ""]]):
                rewrite(*invalid)
                with self.assertRaises(ValueError):
                    add_observations(sheet, cycles)

    def test_proof_before_guard_without_refresh(self):
        lines = [s.replace("5140 GUARD2_READY_AT", "5185 GUARD2_READY_AT") for s in rows()
                 if "GUARD2_REFRESH_AT" not in s]
        result = cycle(lines)
        self.assertEqual(result["issues"], [])
        self.assertEqual(result["proof_remaining_after_guard2_ms"], 0)
        self.assertIsNone(result["guard2_refresh_to_commit_send_ms"])

    def test_draw_can_precede_focus_but_neither_can_precede_lifecycle_entry(self):
        base = rows()
        self.assertEqual(cycle([s.replace("5280 CLOCK_FOCUSED_AT", "5340 CLOCK_FOCUSED_AT")
                                for s in base])["issues"], [])
        result = cycle([s.replace("5300 ACTIVITY_READY_AT", "5210 ACTIVITY_READY_AT") for s in base])
        self.assertIn("invalid_order_ACTIVITY_START_AT_ACTIVITY_READY_AT", result["issues"])
        self.assertIsNone(result["on_to_first_clock_draw_ms"])

    def test_baseline_1_1_0_keeps_old_metrics_without_detailed_handoffs(self):
        result = cycle(rows(details=False))
        self.assertEqual(result["issues"], [])
        self.assertEqual(result["on_to_activity_ms"], 240)
        self.assertEqual(result["activity_entry"], "unreported")
        self.assertIn("COMMIT_SEND_AT", result["detail_missing"])
        self.assertIsNone(result["commit_send_to_receiver_ms"])

    def test_new_pid_or_new_activity_are_distinct(self):
        changed = cycle(rows(ready_pid=17, entry="on_create", retained="false"))
        self.assertEqual(changed["warm"], "process_changed")
        self.assertEqual(changed["retained_clock"], "false")
        new_activity = cycle(rows(entry="on_create", retained="false"))
        self.assertEqual(new_activity["warm"], "ready_same_process")
        self.assertEqual(new_activity["activity_entry"], "on_create")
        self.assertIn("inconsistent_retained_lifecycle", cycle(rows(entry="on_create"))["issues"])
        self.assertEqual(cycle([s.replace("164 PREWARM_READY_AT", "5060 PREWARM_READY_AT")
                                for s in rows()])["warm"], "late")

    def test_group_with_missing_conflicting_or_duplicate_data_is_excluded(self):
        dataset = rows() + rows(dark=300)[:-7]
        dataset.append("5650 ACTIVITY_START_AT boot=1 dark=300 request=mismatched")
        dataset.extend(rows(boot=2, dark=100, ready_pid=23, entry="on_create", retained="false"))
        dataset.append("9000 WAKE_CANDIDATE_AT boot=3 dark=40")
        result = list(read_cycles("\n".join(dataset)))
        self.assertEqual(len(result), 4)
        self.assertIsNone(result[1]["on_to_focus_ms"])
        self.assertIn("duplicate_ACTIVITY_START_AT", result[1]["issues"])
        self.assertIn("request_id_missing_or_conflicting", result[1]["issues"])
        self.assertIn("incomplete", result[-1]["issues"])
        summary = list(summaries(result))
        self.assertEqual(sum(group["complete"] for group in summary), 2)
        self.assertEqual(sum(group["observed_groups"] for group in summary), 4)

    def test_same_boot_group_distribution_and_partial_logs(self):
        lines = rows() + rows(dark=10000) + rows(boot=2)
        result = list(summaries(list(read_cycles("\n".join(lines)))))
        self.assertEqual([s["complete"] for s in result], [2, 1])
        self.assertEqual(result[0]["elapsed_ms"]["on_to_first_clock_draw_ms"],
                         {"n": 2, "min": 300, "median": 300, "max": 300})
        self.assertEqual(list(read_cycles("55 REFUSED detail=private\n80 RETURN_SEND_AT request=req")), [])
        broken = cycle([s.replace("request=req1.100", "") if "COMMIT_RECEIVED_AT" in s else s
                        for s in rows()])
        self.assertIn("request_id_missing_or_conflicting", broken["issues"])


if __name__ == "__main__":
    unittest.main()
