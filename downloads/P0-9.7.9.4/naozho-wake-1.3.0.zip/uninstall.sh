#!/system/bin/sh
/system/bin/sh "${0%/*}/stop.sh"
/system/bin/run-as com.naozho.clock /system/bin/rm -f files/wake-epoch.locked
