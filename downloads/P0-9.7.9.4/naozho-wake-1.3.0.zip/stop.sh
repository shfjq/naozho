#!/system/bin/sh
mod=/data/adb/modules/naozho_wake
umask 077
touch "$mod/STOP"
rm -f "$mod/armed"
/system/bin/run-as com.naozho.clock /system/bin/rm -f files/wake-epoch.proof files/wake-proof.tmp
# Revocation is valid only for this exact prewarm. The app has its own non-waking
# expiry in case Android is shutting down or the module daemon was already killed.
if [ -r "$mod/preview-dark" ] && read -r boot dark extra < "$mod/preview-dark"; then
  case "$boot" in ''|*[!0-9]*) boot= ;; esac
  case "$dark" in ''|*[!0-9]*) dark= ;; esac
  if [ -n "$boot" ] && [ -n "$dark" ] && [ -z "$extra" ] &&
      [ "${#boot}" -le 10 ] && [ "${#dark}" -le 19 ]; then
    /system/bin/timeout 2 /system/bin/am broadcast --user 0 --receiver-foreground --exclude-stopped-packages \
      -n com.naozho.clock/.mode.ConfirmedPowerReceiver -a com.naozho.clock.action.WAKE_PREVIEW_DISMISS \
      -i "dismiss.$boot.$dark" --ei boot_count "$boot" --el dark_elapsed "$dark" >/dev/null 2>&1
  fi
fi
echo "Wake return disarmed"
