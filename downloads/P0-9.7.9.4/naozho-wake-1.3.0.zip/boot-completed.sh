#!/system/bin/sh
/system/bin/sh /data/adb/modules/naozho_wake/start.sh </dev/null >/dev/null 2>&1 &
