package com.naozho.clock.mode

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

/** Explicit system delivery. No input event listener or receiver-supplied launch target. */
class ConfirmedPowerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.component != ComponentName(context, ConfirmedPowerReceiver::class.java)) return
        try {
            if (intent.action == ClockPrewarm.ACTION) { ClockPrewarm.request(context, intent); return }
            // The root sender must verify the full formal delivery in AMS before it publishes
            // the private receipt. The later commit authorizes that same request only.
            if (intent.action == WakeTicket.RETURN) return
            val wake = intent.action == WakeTicket.COMMIT
            if (wake) {
                if (android.os.Build.VERSION.SDK_INT < 34) return
                val actual = sentFromUid
                if (actual >= 0 && actual != intent.getIntExtra("sender_uid", -1)) return
            }
            val validated = if (wake) {
                val ticket = WakeTicket.read(intent) ?: return
                if (intent.identifier != ticket.id + ".commit") return
                ticket.entry(context)
            } else intent
            if (!ClockPowerReturn.accept(context, validated, PowerDelivery.RESERVE)) {
                Log.i("NaozhoPowerReturn", "Double rejected at receiver; no activity requested")
                return
            }
            val entry = if (wake) validated else Intent(ClockPowerReturn.ACTION).setComponent(ClockPowerReturn.target(context))
                .putExtra(EXTRA_BOOT_COUNT, intent.getIntExtra(EXTRA_BOOT_COUNT, -1))
                .putExtra(ClockPowerReturn.FIRST, intent.getLongExtra(ClockPowerReturn.FIRST, -1))
                .putExtra(ClockPowerReturn.RELEASE, intent.getLongExtra(ClockPowerReturn.RELEASE, -1))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (wake) entry.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            context.startActivity(entry)
            Log.i("NaozhoPowerReturn", "Protected request delivered; awaiting foreground and lock readback")
        } catch (error: RuntimeException) {
            Log.w("NaozhoPowerReturn", "Confirmed double unavailable", error)
        }
    }
}
