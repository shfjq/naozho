Apply e09f843.patch with git apply, then change only the clock versionCode from 29 to 30; build with the original signer. Build the 1.0.0 module against that APK.
