package com.naozho.power;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.*;
import android.view.Display;
import com.naozho.power.TrialChecks.Refused;
import com.naozho.wakeprobe.WakeEpochManager;
import java.nio.channels.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** KernelSU boot entry. Only default-display events and two fixed administrative file watches. */
public final class WakeDaemon implements DisplayManager.DisplayListener {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final DisplayManager displays;
    private final PowerManager power;
    private final WakeBoard board;
    private final WakeEpochManager cycle;
    private final ExecutorService revocations = Executors.newSingleThreadExecutor();
    private String lastRevoked;
    private void revokeInFlight() {
        String id = board.published;
        if (id == null || id.equals(lastRevoked)) return;
        lastRevoked = id;
        revocations.execute(() -> {
            try { WakeBoard.revoke(id); } catch (Exception failed) { record("REFUSED receipt_revocation_failed"); }
        });
    }
    // Prewarming never shares the serial power/return executor. Reclaim, slow startup or an
    // out-of-date warmup cannot hold a genuine full wake in a work queue.
    private final ExecutorService warmWorker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean warming = new AtomicBoolean();
    private long lastWarmDark = -1;
    private final AtomicBoolean busy = new AtomicBoolean();
    private volatile int generation;
    private volatile boolean listening;
    private FileObserver moduleWatch, modeWatch;
    private Runnable scheduled;
    private long edge;
    private boolean reading, deferred;
    private String deploymentState = "";

    WakeDaemon(Context context, WakeBoard board) {
        displays = context.getSystemService(DisplayManager.class);
        power = context.getSystemService(PowerManager.class);
        if (displays == null || power == null) throw new IllegalStateException("framework_services");
        this.board = board;
        cycle = new WakeEpochManager(board.boot, board.bootId);
    }

    static synchronized void record(String code) {
        try {
            Path file = WakeBoard.DIR.resolve("events");
            if (Files.exists(file) && Files.size(file) > 32768)
                Files.move(file, WakeBoard.DIR.resolve("events.1"), StandardCopyOption.REPLACE_EXISTING);
            String safe = code.matches("[A-Za-z0-9_ .:/=-]{1,200}") ? code : "REFUSED_UNCLASSIFIED";
            Files.write(file, (SystemClock.elapsedRealtime() + " " + safe + "\n").getBytes(StandardCharsets.US_ASCII),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception error) { throw new IllegalStateException("journal_failed"); }
    }
    private static String reason(Exception e) {
        return e instanceof Refused ? e.getMessage() : e.getClass().getSimpleName();
    }
    private FileObserver watch(Path dir, boolean mode) {
        FileObserver observer = new FileObserver(dir.toFile(), FileObserver.CLOSE_WRITE | FileObserver.MOVED_TO |
                FileObserver.MOVED_FROM | FileObserver.CREATE | FileObserver.DELETE | FileObserver.DELETE_SELF | FileObserver.MOVE_SELF) {
            @Override public void onEvent(int event, String path) {
                if (path == null || (mode ? path.equals("primary_home_display.xml") :
                        path.equals("armed") || path.equals("disable") || path.equals("STOP") || path.equals("remove"))) {
                    handler.post(WakeDaemon.this::refresh);
                }
            }
        };
        observer.startWatching();
        return observer;
    }
    private void refresh() {
        try { board.enabled(); } catch (Exception disabled) { generation++; listening = false;
            try { WakeBoard.clear(); } catch (Exception ignored) { /* lease also expires in the app */ }
            record("STOPPED"); System.exit(0); return; }
        boolean active = false;
        String state;
        try { active = WakeBoard.deploymentHint(); state = active ? "ENABLED" : "MAINTENANCE_PAUSED"; }
        catch (Exception e) { state = "REFUSED deployment_hint_unavailable"; }
        if (!state.equals(deploymentState)) { record(state); deploymentState = state; }
        if (active == listening) return;
        generation++;
        revokeInFlight();
        cycle.reset();
        if (scheduled != null) handler.removeCallbacks(scheduled);
        listening = active;
        if (active) {
            displays.registerDisplayListener(handler::post, DisplayManager.EVENT_TYPE_DISPLAY_STATE |
                DisplayManager.EVENT_TYPE_DISPLAY_ADDED | DisplayManager.EVENT_TYPE_DISPLAY_REMOVED, this);
            record("NORMAL_ANDROID observer_registered");
            sample();
        } else {
            displays.unregisterDisplayListener(this);
            record("observer_unregistered");
        }
    }
    private int displayState() {
        Display d = displays.getDisplay(Display.DEFAULT_DISPLAY);
        return d == null || !d.isValid() ? Display.STATE_UNKNOWN : d.getState();
    }
    private void prewarm(long dark, int rev) {
        if (dark < 0 || dark == lastWarmDark || !warming.compareAndSet(false, true)) return;
        lastWarmDark = dark;
        warmWorker.execute(() -> {
            try {
                board.prewarm(dark, () -> {
                    if (!listening || rev != generation || displayState() != Display.STATE_OFF ||
                        power.isInteractive()) throw new Refused("prewarm_superseded");
                });
            } catch (Exception e) { record("PREWARM_SKIPPED " + reason(e)); }
            finally { warming.set(false); }
        });
    }

    private void sample() {
        if (!listening) return;
        int state = displayState(), old = cycle.display();
        boolean interactive = power.isInteractive();
        long observed = SystemClock.elapsedRealtime();
        String event = cycle.observe(state, interactive, SystemClock.uptimeMillis(), observed);
        if (event.equals("DUPLICATE")) return;
        generation++;
        if (state != Display.STATE_ON || !power.isInteractive()) revokeInFlight();
        if (old != state) edge = SystemClock.elapsedRealtime();
        if (scheduled != null) handler.removeCallbacks(scheduled);
        record(cycle.phase() + " " + event);
        if (state == Display.STATE_OFF && old != state && cycle.darkElapsed() >= 0)
            record("DARK_OBSERVED_AT boot=" + board.boot + " dark=" + cycle.darkElapsed() + " at=" + observed);
        if (state == Display.STATE_OFF) {
            long dark = cycle.darkElapsed();
            int rev = generation;
            if (!interactive) prewarm(dark, rev);
            else handler.postDelayed(() -> {
                if (listening && generation == rev && displayState() == Display.STATE_OFF && !power.isInteractive())
                    prewarm(dark, rev);
            }, 200);
        }
        if (state == Display.STATE_ON) {
            if (old != state && cycle.waiting())
                record("WAKE_CANDIDATE_AT boot=" + board.boot + " dark=" + cycle.darkElapsed() + " at=" + observed);
            schedule(0, 0);
        }
    }
    public void onDisplayAdded(int id) { if (id == 0) sample(); }
    public void onDisplayChanged(int id) { if (id == 0) sample(); }
    public void onDisplayRemoved(int id) {
        if (id == 0) {
            generation++; revokeInFlight(); cycle.reset(); record("REFUSED display_removed");
        }
    }

    private void schedule(long delay, int attempt) {
        boolean last = attempt >= 2;
        scheduled = () -> {
            if (!listening || cycle.display() != Display.STATE_ON) return;
            if (reading) { deferred = true; return; }
            final int rev = generation;
            reading = true;
            io.execute(() -> {
                String raw;
                try { raw = WakeBoard.power(); } catch (Exception fail) { record("REFUSED power_read " + reason(fail)); raw = ""; }
                final String proof = raw;
                handler.post(() -> {
                    reading = false;
                    if (rev != generation || !listening || displayState() != cycle.display()) {
                        if (listening) sample();
                        if (deferred && listening && cycle.display() == Display.STATE_ON) schedule(0, 2);
                        deferred = false;
                        return;
                    }
                    deferred = false;
                    long now = SystemClock.elapsedRealtime(), up = SystemClock.uptimeMillis();
                    cycle.observe(Display.STATE_ON, power.isInteractive(), up, now);
                    boolean expired = now - edge > 3000;
                    WakeEpochManager.Epoch epoch = cycle.settle(expired ? "" : proof, up, now, last || expired);
                    if (epoch != null) submit(epoch, rev);
                    else if (!last && !expired && cycle.waiting()) schedule(attempt == 0 ? 200 : 400, attempt + 1);
                    else record("power_readback " + cycle.phase() + " " + cycle.classification());
                });
            });
        };
        handler.postDelayed(scheduled, delay);
    }
    private void submit(WakeEpochManager.Epoch epoch, int rev) {
        if (!busy.compareAndSet(false, true)) { record("REFUSED previous_request_in_progress"); return; }
        record("FULL_WAKE_AT boot=" + board.boot + " dark=" + epoch.dark + " epoch=" + epoch.id + " at=" + epoch.event);
        io.execute(() -> {
            try {
                WakeBoard.Live live = () -> {
                    if (!listening || rev != generation || !power.isInteractive() || displayState() != Display.STATE_ON)
                        throw new Refused("wake_superseded");
                };
                live.check();
                // With a proven sender the common guards below already verify mode, owner,
                // real foreground and NONE before any formal dispatch.
                if (board.uid < 0) {
                    board.androidMode(epoch.dark);
                    if (WakeLockReadback.focused(DailyBoard.displayFocus()) && WakeLockReadback.locked()) {
                        record("ALREADY_CLOCK no_request"); return;
                    }
                    board.uid = Board.verifyPermission(false);
                    if (board.uid != 0 && board.uid != 2000) throw new Refused("permission_sender_unsupported");
                }
                record("RETURN_PENDING_AT boot=" + board.boot + " dark=" + epoch.dark);
                String outcome = board.dispatch(epoch, live);
                record(outcome + " boot=" + board.boot + " dark=" + epoch.dark);
            } catch (Exception blocked) { record("REFUSED " + reason(blocked)); }
            finally { busy.set(false); }
        });
    }
    private void run() {
        if (!Files.isDirectory(WakeBoard.DE)) throw new IllegalStateException("deployment_hint_unavailable");
        moduleWatch = watch(WakeBoard.DIR, false);
        modeWatch = watch(WakeBoard.DE, true);
        record("observer_ready pid=" + android.os.Process.myPid());
        try { refresh(); Looper.loop(); }
        finally {
            generation++;
            if (listening) displays.unregisterDisplayListener(this);
            listening = false;
            moduleWatch.stopWatching(); modeWatch.stopWatching(); io.shutdownNow(); revocations.shutdownNow(); warmWorker.shutdownNow();
            try { WakeBoard.clear(); } catch (Exception ignored) { /* expiry still enforced by APK */ }
        }
    }
    @SuppressWarnings("deprecation")
    public static void main(String[] args) {
        int status = 0;
        String step = "instance_lock";
        try (FileChannel file = FileChannel.open(WakeBoard.DIR.resolve("instance.lock"),
                StandardOpenOption.CREATE, StandardOpenOption.WRITE); FileLock lock = SessionLease.claim(file, WakeBoard.DIR, SessionLease.token(WakeBoard.DIR.resolve("armed")))) {
            if (lock == null) return;
            WakeBoard board = new WakeBoard();
            step = "firmware_package_owner";
            board.init();
            Files.write(WakeBoard.DIR.resolve("running"), board.generation.getBytes(StandardCharsets.US_ASCII));
            step = "framework_context";
            Looper.prepareMainLooper();
            Class<?> thread = Class.forName("android.app.ActivityThread");
            Object runtime = thread.getMethod("systemMain").invoke(null);
            Context context = (Context)thread.getMethod("getSystemContext").invoke(runtime);
            board.uid = -1;
            step = "display_subscription";
            new WakeDaemon(context, board).run();
        } catch (Exception | LinkageError failure) {
            Throwable cause = failure.getCause() == null ? failure : failure.getCause();
            String diagnostic = cause instanceof Exception ? reason((Exception)cause) : cause.getClass().getSimpleName();
            record("REFUSED " + step + " " + diagnostic);
            status = 1;
        }
        System.exit(status);
    }
}
