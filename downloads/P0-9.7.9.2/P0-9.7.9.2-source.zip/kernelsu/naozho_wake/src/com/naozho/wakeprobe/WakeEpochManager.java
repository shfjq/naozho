package com.naozho.wakeprobe;

/** Display callbacks own this state on a single Looper. Uptime and elapsed time serve different clocks. */
public final class WakeEpochManager {
    private final WakeCycle cycle;
    private final String bootId;
    private String classification = "INITIAL";
    public String classification() { return classification; }
    private long darkElapsed = -1;
    public WakeEpochManager(int count, String bootId) {
        this.bootId = bootId;
        cycle = new WakeCycle(count, bootId);
    }

    public String observe(int state, boolean interactive, long uptime, long elapsed) {
        boolean started = cycle.darkStart < 0;
        String event = cycle.observe(state, interactive, uptime);
        if (started && cycle.darkStart >= 0) darkElapsed = elapsed;
        return event;
    }

    public static final class Epoch {
        public final long dark, sequence, event, wakeUptime;
        public final String id;
        Epoch(String boot, long dark, long sequence, long event, long wakeUptime) {
            this.dark = dark; this.sequence = sequence; this.event = event; this.wakeUptime = wakeUptime;
            id = boot + "/" + dark + "/" + sequence;
        }
    }

    public Epoch settle(String powerDump, long up, long elapsed, boolean last) {
        PowerEvidence power = PowerEvidence.parse(powerDump);
        classification = cycle.verify(power, up, last);
        if (!"FULL_WAKE".equals(classification)) return null;
        return new Epoch(bootId, darkElapsed, cycle.count, elapsed, power.wake);
    }
    public long darkElapsed() { return cycle.darkStart >= 0 ? darkElapsed : -1; }
    public boolean waiting() { return cycle.waiting; }
    public int revision() { return cycle.revision; }
    public int display() { return cycle.display; }
    public String phase() { return cycle.phase; }
    public void reset() { cycle.invalidate(); darkElapsed = -1; }

    public static boolean stillAwake(String dump, Epoch epoch) {
        PowerEvidence power = PowerEvidence.parse(dump);
        return power.error == null && !power.changing && "Awake".equals(power.wakefulness) &&
                power.wake == epoch.wakeUptime && power.sleep < power.wake;
    }
}
