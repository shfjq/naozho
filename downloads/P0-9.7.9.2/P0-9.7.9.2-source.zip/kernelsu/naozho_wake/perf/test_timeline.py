import unittest
from timeline import STAGES,read_cycles
class PerfTest(unittest.TestCase):
    def test_independent_app_module_clocks(self):
        times=[100,102,112,5000,5030,5040,5100,5200,5110,5150,5140,5170,5210]
        lines=[f"{v} {k} boot=1 dark=100 "+("pid=18 " if k in ("PREWARM_READY_AT","ACTIVITY_START_AT") else "")+
               ("request=req" if k in STAGES[6:12] else "") for k,v in zip(STAGES,times)]
        result=list(read_cycles("\n".join(reversed(lines))))[0]
        self.assertEqual(result["on_to_first_clock_draw_ms"],150)
        self.assertEqual(result["full_to_draw_ms"],120)
        self.assertEqual(result["warm"],"ready_same_process")
        duplicate=list(read_cycles("\n".join(lines+["5250 COMMIT_DELIVERED_AT boot=1 dark=100 request=other"])))[0]
        self.assertIsNone(duplicate["on_to_focus_ms"])
        self.assertEqual(list(read_cycles(lines[0]))[0]["issues"][-1],"incomplete")
if __name__=="__main__":unittest.main()
