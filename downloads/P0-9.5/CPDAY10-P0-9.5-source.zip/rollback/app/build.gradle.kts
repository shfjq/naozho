plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.naozho.clock"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.naozho.clock"
        minSdk = 23
        targetSdk = 35
        versionCode = 28
        versionName = "0.6.9-rollback"
    }

    buildTypes {
        create("development") {
            initWith(getByName("debug"))
            versionNameSuffix = "-dev"
            matchingFallbacks += "debug"
        }
        create("deployment") {
            initWith(getByName("release"))
            // Keep the signer already installed on CPDAY10 so an update retains Device Owner.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    testOptions.unitTests.isIncludeAndroidResources = true

    buildFeatures {
        compose = true
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.room:room-runtime:2.7.2")
    implementation("androidx.room:room-ktx:2.7.2")
    ksp("androidx.room:room-compiler:2.7.2")
    implementation(platform("androidx.compose:compose-bom:2025.05.01"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.0")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.15.1")
    testImplementation("androidx.compose.ui:ui-test-junit4:1.8.2")
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}
