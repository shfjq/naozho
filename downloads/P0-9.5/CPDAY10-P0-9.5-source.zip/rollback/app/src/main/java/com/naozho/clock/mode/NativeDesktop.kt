package com.naozho.clock.mode

import android.app.Activity
import android.app.ActivityManager
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import android.os.UserManager
import android.os.Process
import android.util.Log
import androidx.annotation.RequiresApi
import com.naozho.clock.MainActivity
import com.naozho.clock.display.ClockDeviceAdmin
import java.util.UUID
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

internal data class NativeHome(val component: ComponentName, val label: String)

internal sealed interface DesktopResult {
    data object Applied : DesktopResult
    data class Rejected(val step: String, val reason: String) : DesktopResult {
        val message: String get() = "$step：$reason"
    }
}

internal fun desktopFailure(step: String, reason: String, cause: RuntimeException? = null): DesktopResult.Rejected =
    DesktopResult.Rejected(step, reason).also { Log.w("NaozhoMode", it.message, cause) }

private fun homeIntent() = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)

// PackageManager uses both categories for HOME registration and role candidates.
private fun homeCandidateIntent() = homeIntent().addCategory(Intent.CATEGORY_DEFAULT)

// ActivityTaskSupervisor adds MATCH_DEFAULT_ONLY and the stock library metadata flag.
private const val HOME_LAUNCH_FLAGS = PackageManager.MATCH_DEFAULT_ONLY or PackageManager.GET_SHARED_LIBRARY_FILES

@Suppress("DEPRECATION")
private fun PackageManager.homeHandlers(inPackage: String? = null): List<ResolveInfo> =
    queryIntentActivities(homeCandidateIntent().setPackage(inPackage), PackageManager.MATCH_DEFAULT_ONLY)

@Suppress("DEPRECATION")
private fun PackageManager.resolveHome(intent: Intent, flags: Int): ComponentName? =
    resolveActivity(intent, flags)?.homeComponent()

private fun ActivityInfo.component() = ComponentName.createRelative(packageName, name)

private fun ResolveInfo.homeComponent() = activityInfo?.component()

internal class NativeDesktop(private val context: Context) {
    private val manager = context.packageManager

    fun candidates(saved: ComponentName? = null): List<NativeHome> {
        val current = manager.resolveHome(homeIntent(), HOME_LAUNCH_FLAGS)
        val candidates = manager.homeHandlers()
        val savedCandidate = if (saved != null && candidates.none { it.homeComponent() == saved }) {
            manager.homeHandlers(saved.packageName).filter { it.homeComponent() == saved }
        } else emptyList()
        return (candidates + savedCandidate)
            .mapNotNull { result ->
                val activity = result.activityInfo ?: return@mapNotNull null
                val component = activity.component()
                val system = activity.applicationInfo.flags and
                    (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                // The configured OEM Home may be distributed as an updated or user app.
                if (!system && component != current && component != saved) return@mapNotNull null
                // Android Settings advertises a temporary Direct Boot HOME at priority -1000.
                if (result.priority <= -1000 || !activity.exported || !activity.enabled || !activity.applicationInfo.enabled ||
                    activity.packageName == context.packageName || activity.packageName == "android" ||
                    (activity.permission != null && context.checkSelfPermission(activity.permission) != PackageManager.PERMISSION_GRANTED)
                ) return@mapNotNull null
                NativeHome(component, result.loadLabel(manager).toString())
            }.distinctBy(NativeHome::component).sortedBy(NativeHome::label)
    }

    fun target(saved: ComponentName?): ComponentName? {
        val available = candidates(saved)
        if (saved != null) return available.firstOrNull { it.component == saved }?.component
        return available.singleOrNull()?.component
    }

    fun open(saved: ComponentName?): DesktopResult {
        val component = target(saved) ?: return if (saved == null) {
            desktopFailure("启动原桌面", "没有唯一的可用原桌面，请在恢复页选择。")
        } else unavailableHome(saved)
        return try {
            context.startActivity(homeIntent().setComponent(component)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
            DesktopResult.Applied
        } catch (error: ActivityNotFoundException) {
            desktopFailure("启动原桌面", "Android 找不到 ${component.flattenToShortString()}。", error)
        } catch (error: SecurityException) {
            desktopFailure("启动原桌面", "Android 拒绝启动 ${component.flattenToShortString()}。", error)
        }
    }

    fun validateSavedHome(saved: ComponentName?): DesktopResult {
        if (saved == null) return desktopFailure("检查原桌面", "尚未保存原桌面，请先选择 DroiClaw。")
        return if (target(saved) == saved) DesktopResult.Applied else unavailableHome(saved)
    }

    @Suppress("DEPRECATION")
    private fun unavailableHome(saved: ComponentName): DesktopResult.Rejected {
        val step = "检查原桌面"
        val name = saved.flattenToShortString()
        val info = try {
            manager.getActivityInfo(saved, PackageManager.GET_DISABLED_COMPONENTS)
        } catch (_: PackageManager.NameNotFoundException) {
            return desktopFailure(step, "当前用户 ${Process.myUserHandle()} 无法解析已保存组件 $name。")
        }
        val reason = when {
            !info.enabled || !info.applicationInfo.enabled -> "已禁用"
            !info.exported -> "未导出"
            info.permission != null && context.checkSelfPermission(info.permission) != PackageManager.PERMISSION_GRANTED ->
                "要求本应用未获授的启动权限"
            else -> "没有作为可用 HOME 候选返回"
        }
        return desktopFailure(step, "已保存组件 $name$reason。")
    }
}

internal class ManagedDesktop(private val context: Context) {
    private val admin = ComponentName(context, ClockDeviceAdmin::class.java)
    private val policy = context.getSystemService(DevicePolicyManager::class.java)
    private val tasks = context.getSystemService(ActivityManager::class.java)
    private val packageName = context.packageName
    val clockHome = ComponentName(context, MainActivity::class.java)

    val activeAdmin: Boolean get() = policy?.isAdminActive(admin) == true
    val owner: Boolean get() = policy?.isDeviceOwnerApp(packageName) == true
    val profileOwner: Boolean get() = policy?.isProfileOwnerApp(packageName) == true
    val supported: Boolean get() = owner && Build.VERSION.SDK_INT >= 28
    val state: Int get() = tasks?.lockTaskModeState ?: ActivityManager.LOCK_TASK_MODE_NONE
    val permitted: Boolean get() = policy?.isLockTaskPermitted(packageName) == true
    val dedicatedReady: Boolean get() = Build.VERSION.SDK_INT >= 28 &&
        matchesLockPolicy(dedicatedFeatures())

    val hasLegacyLockPolicy: Boolean get() = Build.VERSION.SDK_INT >= 28 &&
        matchesLockPolicy(dedicatedFeatures() or DevicePolicyManager.LOCK_TASK_FEATURE_KEYGUARD)

    private fun matchesLockPolicy(expected: Int): Boolean =
        features() == expected && packages()?.toSet() == setOf(packageName) && permitted

    @RequiresApi(28)
    private fun dedicatedFeatures(): Int {
        var flags = DevicePolicyManager.LOCK_TASK_FEATURE_GLOBAL_ACTIONS
        if (Build.VERSION.SDK_INT >= 30) flags = flags or DevicePolicyManager.LOCK_TASK_FEATURE_BLOCK_ACTIVITY_START_IN_TASK
        return flags
    }

    @RequiresApi(28)
    private fun featureNames(flags: Int?): String {
        if (flags == null) return "unavailable"
        if (flags == DevicePolicyManager.LOCK_TASK_FEATURE_NONE) return "NONE"
        return buildList {
            if (flags and DevicePolicyManager.LOCK_TASK_FEATURE_SYSTEM_INFO != 0) add("SYSTEM_INFO")
            if (flags and DevicePolicyManager.LOCK_TASK_FEATURE_NOTIFICATIONS != 0) add("NOTIFICATIONS")
            if (flags and DevicePolicyManager.LOCK_TASK_FEATURE_HOME != 0) add("HOME")
            if (flags and DevicePolicyManager.LOCK_TASK_FEATURE_OVERVIEW != 0) add("OVERVIEW")
            if (flags and DevicePolicyManager.LOCK_TASK_FEATURE_GLOBAL_ACTIONS != 0) add("GLOBAL_ACTIONS")
            if (flags and DevicePolicyManager.LOCK_TASK_FEATURE_KEYGUARD != 0) add("KEYGUARD")
            if (Build.VERSION.SDK_INT >= 30 && flags and DevicePolicyManager.LOCK_TASK_FEATURE_BLOCK_ACTIVITY_START_IN_TASK != 0)
                add("BLOCK_ACTIVITY_START_IN_TASK")
        }.joinToString("|")
    }

    fun restrictsNotificationShade(): Boolean {
        if (Build.VERSION.SDK_INT < 28 || state != ActivityManager.LOCK_TASK_MODE_LOCKED) return false
        return features()?.let { it and DevicePolicyManager.LOCK_TASK_FEATURE_NOTIFICATIONS == 0 } == true
    }

    private fun features(): Int? {
        if (Build.VERSION.SDK_INT < 28 || !owner) return null
        return try {
            policy?.getLockTaskFeatures(admin)
        } catch (_: SecurityException) {
            null
        }
    }

    private fun packages(): Array<String>? = if (supported) {
        try { policy?.getLockTaskPackages(admin) } catch (_: SecurityException) { null }
    } else null

    suspend fun allowClock(): DesktopResult {
        val step = "写入 Lock Task 策略"
        val manager = policy ?: return desktopFailure(step, "系统没有返回 DevicePolicyManager。")
        if (Build.VERSION.SDK_INT < 28 || !owner) return desktopFailure(step, "系统版本或 Device Owner 身份不满足要求。")
        val existing = packages() ?: return desktopFailure(step, "无法读取当前允许名单。")
        if (state != ActivityManager.LOCK_TASK_MODE_NONE) return desktopFailure(step, "当前 Lock Task 状态为 ${stateName()}。")
        if (existing.any { it != packageName }) return desktopFailure(step, "现有允许名单包含其他应用 ${existing.joinToString()}。")
        val clockFeatures = dedicatedFeatures()
        try {
            if (existing.isEmpty()) manager.setLockTaskPackages(admin, arrayOf(packageName))
            if (features() != clockFeatures) manager.setLockTaskFeatures(admin, clockFeatures)
        } catch (error: RuntimeException) {
            return desktopFailure(step, "Android 策略调用异常（${error.javaClass.simpleName}）。", error)
        }
        return if (awaitState { matchesLockPolicy(clockFeatures) }) DesktopResult.Applied
        else desktopFailure("确认 Lock Task 策略", "等待后仍未读到目标名单和导航限制。" +
            "当前名单=${packages()?.contentToString()}，功能=${features()}，允许本应用=$permitted。")
    }

    suspend fun disallowClock(reason: String): Boolean {
        val manager = policy ?: return false
        val existing = packages() ?: return false
        if (state == ActivityManager.LOCK_TASK_MODE_PINNED) return false
        return try {
            if (packageName in existing) {
                Log.i("NaozhoMode", "Remove clock from Lock Task allowlist reason=$reason state=${stateName()}")
                manager.setLockTaskPackages(admin, existing.filterNot { it == packageName }.toTypedArray())
            }
            awaitState { state == ActivityManager.LOCK_TASK_MODE_NONE && !permitted }
        } catch (error: RuntimeException) {
            desktopFailure("撤回 Lock Task 白名单", "Android 策略调用异常（${error.javaClass.simpleName}）。", error)
            false
        }
    }

    // The framework's default-display HOME launch supplies HOME without CATEGORY_DEFAULT.
    fun effectiveHome(): ComponentName? = context.packageManager.resolveHome(homeIntent(), HOME_LAUNCH_FLAGS)

    private fun settingsHome(): ComponentName? = context.packageManager
        .resolveHome(homeCandidateIntent(), PackageManager.MATCH_DEFAULT_ONLY)

    // Match DSH's unrestricted MAIN + HOME query exactly (no package or resolution flags).
    @Suppress("DEPRECATION")
    private fun rawHomeCandidates(inPackage: String? = null): List<ComponentName> =
        context.packageManager.queryIntentActivities(homeIntent().setPackage(inPackage), 0)
            .mapNotNull { it.homeComponent() }

    fun isHomeConfirmed(target: ComponentName): Boolean = effectiveHome() == target && settingsHome() == target &&
        (target != clockHome || (target in rawHomeCandidates() &&
            context.packageManager.homeHandlers().any { it.homeComponent() == target }))

    fun homeRoleRequest(): Intent? {
        if (Build.VERSION.SDK_INT < 29) return null
        val roles = context.getSystemService(RoleManager::class.java) ?: return null
        if (!roles.isRoleAvailable(RoleManager.ROLE_HOME) || roles.isRoleHeld(RoleManager.ROLE_HOME)) return null
        return roles.createRequestRoleIntent(RoleManager.ROLE_HOME)
    }

    @Suppress("DEPRECATION")
    fun diagnoseHome(): String {
        val pm = context.packageManager
        val trace = "homeDiagnostic user=${Process.myUserHandle()}"
        val rawGlobal = rawHomeCandidates()
        val rawScoped = rawHomeCandidates(packageName)
        val unlocked = Build.VERSION.SDK_INT < 24 || context.getSystemService(UserManager::class.java).isUserUnlocked
        Log.i("NaozhoMode", "$trace MAIN+HOME flags=0 global=$rawGlobal package=$packageName scoped=$rawScoped" +
            " unlocked=$unlocked safeMode=${pm.isSafeMode} componentOverride=${pm.getComponentEnabledSetting(clockHome)}" +
            " appOverride=${pm.getApplicationEnabledSetting(packageName)}")
        val launchCandidates = queryHome(pm, homeIntent(), clockHome, trace, flags = HOME_LAUNCH_FLAGS)
        val candidates = queryHome(pm, homeCandidateIntent(), clockHome, trace)
        val scoped = queryHome(pm, homeCandidateIntent().setPackage(packageName), clockHome, trace)
        val withoutDefault = queryHome(pm, homeIntent().setPackage(packageName), clockHome, trace, flags = 0)
        val roles = if (Build.VERSION.SDK_INT >= 29) context.getSystemService(RoleManager::class.java) else null
        val role = if (Build.VERSION.SDK_INT >= 29 && roles?.isRoleAvailable(RoleManager.ROLE_HOME) == true) {
            if (roles.isRoleHeld(RoleManager.ROLE_HOME)) "时钟持有" else "时钟未持有"
        } else "系统未提供"
        val actualHome = effectiveHome()?.flattenToShortString() ?: "未解析"
        val preferencesHome = settingsHome()?.flattenToShortString() ?: "未解析"
        val status = "启动 Home $actualHome。默认桌面解析 $preferencesHome。HOME 角色 $role。" +
            "HOME(0) 全局=${clockHome in rawGlobal}，本包=${clockHome in rawScoped}，用户已解锁=$unlocked。" +
            "启动候选=$launchCandidates，默认桌面全局候选=$candidates，本包=$scoped，本包不带 DEFAULT=$withoutDefault。"
        Log.i("NaozhoMode", "$trace $status")
        return status
    }

    fun checkHomeScope(native: ComponentName?): DesktopResult.Rejected? =
        if (Build.VERSION.SDK_INT >= 36 && !HomePolicyTransaction(context).hasKnownScope(native))
            desktopFailure("核对持久 HOME 策略", "请先按维护手册登记当前用户和目标包的策略范围。")
        else null

    fun receiptMatches(component: ComponentName): Boolean = Build.VERSION.SDK_INT < 36 ||
        HomePolicyTransaction(context).verified(component)

    @RequiresApi(34)
    private suspend fun applyAuditedPolicy(target: ComponentName?, trace: String, refreshExisting: Boolean = false): DesktopResult {
        val manager = policy ?: return desktopFailure("写入 Home 策略", "系统未提供设备策略服务。")
        if (!owner) return desktopFailure("写入 Home 策略", "需要 Device Owner。")
        return HomePolicyTransaction(context).apply(ModeState(context).selectedHome(), clockHome, target,
            trace, refreshExisting, ::effectiveHome, { manager.clearPackagePersistentPreferredActivities(admin, it) },
            { manager.addPersistentPreferredActivity(admin, homePolicyFilter(), it) })
    }

    suspend fun clearAuditedHome(): DesktopResult {
        if (Build.VERSION.SDK_INT < 36 || state != ActivityManager.LOCK_TASK_MODE_NONE) {
            return desktopFailure("独立清除 HOME", "需要 Android 16 及 NONE 状态。")
        }
        return applyAuditedPolicy(null, "homeOp=${UUID.randomUUID()} goal=clear-only user=${Process.myUserHandle()}")
    }

    private fun homePolicyFilter() = IntentFilter(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_HOME)
        addCategory(Intent.CATEGORY_DEFAULT)
    }

    suspend fun setHome(component: ComponentName, reapply: Boolean = false, rollback: Boolean = false): DesktopResult {
        val clock = component == clockHome
        val trace = "homeOp=${UUID.randomUUID()} goal=${if (clock) "clock" else "freeme"}" +
            " target=${component.flattenToShortString()} user=${Process.myUserHandle()} rollback=$rollback"
        val current = effectiveHome()
        Log.i("NaozhoMode", "$trace before=${current?.flattenToShortString()} reapply=$reapply")
        val manager = policy
        if (manager == null || !supported) {
            Log.w("NaozhoMode", "$trace write=skipped reason=device-policy-unavailable")
            return desktopFailure("写入 Home 策略", "系统版本或 Device Owner 身份不满足要求。")
        }
        val rejected = validateHomeTarget(component, clock, trace)
        if (rejected != null) {
            Log.w("NaozhoMode", "$trace write=skipped after=${current?.flattenToShortString()} reason=${rejected.message}")
            return rejected
        }
        if (!reapply && current == component && receiptMatches(component) && isHomeConfirmed(component)) {
            Log.i("NaozhoMode", "$trace write=skipped after=${current.flattenToShortString()} reason=already-effective")
            return DesktopResult.Applied
        }
        if (Build.VERSION.SDK_INT >= 36 && state != ActivityManager.LOCK_TASK_MODE_NONE) {
            return desktopFailure("切换 HOME", "写入持久策略前需要 NONE，当前为 ${stateName()}。")
        }
        val applied = if (Build.VERSION.SDK_INT >= 36) applyAuditedPolicy(component, trace, refreshExisting = reapply || !isHomeConfirmed(component))
            else applyLegacyPolicy(manager, component, trace)
        if (applied is DesktopResult.Rejected) return applied
        if (awaitState { isHomeConfirmed(component) }) {
            if (Build.VERSION.SDK_INT >= 36 && !HomePolicyTransaction(context).verify(component)) {
                return desktopFailure("确认有效 Home", "系统解析已改变，但无法保存已验证目标。")
            }
            Log.i("NaozhoMode", "$trace result=confirmed launchHome=${component.flattenToShortString()} settingsHome=${component.flattenToShortString()}")
            return DesktopResult.Applied
        }
        val effective = effectiveHome()?.flattenToShortString() ?: "未解析"
        val settings = settingsHome()?.flattenToShortString() ?: "未解析"
        val listed = queryHome(context.packageManager, homeCandidateIntent(), component, trace)
        val rawGlobal = component in rawHomeCandidates()
        val rawScoped = component in rawHomeCandidates(component.packageName)
        Log.w("NaozhoMode", "$trace HOME(0) global=$rawGlobal scoped=$rawScoped")
        Log.w("NaozhoMode", "$trace result=unconfirmed launchHome=$effective settingsHome=$settings defaultCandidate=$listed")
        return desktopFailure("确认有效 Home", "目标 ${component.flattenToShortString()}。系统启动解析 $effective，" +
            "默认桌面解析 $settings，HOME(0) 全局=$rawGlobal，本包=$rawScoped，目标在全局 DEFAULT 候选中=${if (listed) "是" else "否"}。")
    }

    private fun applyLegacyPolicy(manager: DevicePolicyManager, component: ComponentName, trace: String): DesktopResult {
        val clock = component == clockHome
        val other = if (clock) ModeState(context).selectedHome()?.packageName else packageName
        try {
            // Clear only this admin's previous mapping for the other Home. Some PackageManagers
            // keep both mappings for the same filter when switching between packages.
            if (other != null) {
                Log.i("NaozhoMode", "$trace clear=call package=$other")
                manager.clearPackagePersistentPreferredActivities(admin, other)
                Log.i("NaozhoMode", "$trace clear=returned package=$other")
            }
        } catch (error: RuntimeException) {
            Log.w("NaozhoMode", "$trace clear=exception write=skipped after=${effectiveHome()?.flattenToShortString()}", error)
            return desktopFailure("清理旧 Home 策略", "Android 拒绝清理 $other（${error.javaClass.simpleName}）。", error)
        }
        try {
            Log.i("NaozhoMode", "$trace write=call api=addPersistentPreferredActivity")
            manager.addPersistentPreferredActivity(admin, homePolicyFilter(), component)
            Log.i("NaozhoMode", "$trace write=returned")
        } catch (error: RuntimeException) {
            Log.w("NaozhoMode", "$trace write=exception after=${effectiveHome()?.flattenToShortString()}", error)
            return desktopFailure("写入 Home 策略", "Android 拒绝设置 ${component.flattenToShortString()}（${error.javaClass.simpleName}）。", error)
        }
        return DesktopResult.Applied
    }

    @Suppress("DEPRECATION")
    private fun validateHomeTarget(component: ComponentName, clock: Boolean, trace: String): DesktopResult.Rejected? {
        val pm = context.packageManager
        val broadMatch = queryHome(pm, homeCandidateIntent(), component, trace)
        val scopedMatch = !broadMatch && queryHome(pm, homeCandidateIntent().setPackage(component.packageName), component, trace)
        if (!clock) {
            return if (broadMatch || scopedMatch) null else desktopFailure("检查目标 HOME", "当前用户的 HOME 查询未返回 ${component.flattenToShortString()}。")
        }
        val info = try {
            pm.getActivityInfo(component, 0)
        } catch (error: PackageManager.NameNotFoundException) {
            Log.w("NaozhoMode", "$trace explicitLookup=missing", error)
            return desktopFailure("检查时钟 HOME", "当前用户无法直接读取已注册的时钟组件。")
        }
        Log.i("NaozhoMode", "$trace explicit=${info.component().flattenToShortString()} enabled=${info.enabled}" +
            " appEnabled=${info.applicationInfo.enabled} exported=${info.exported}")
        if (info.component() != component || !info.enabled || !info.applicationInfo.enabled || !info.exported) {
            return desktopFailure("检查时钟 HOME", "时钟组件名称不符、已禁用或未导出。")
        }
        if (!broadMatch && !scopedMatch) {
            // This exact component declares HOME in our own APK. Let DPM perform the policy write,
            // then require the independent effective-Home readback before marking it applied.
            Log.w("NaozhoMode", "$trace candidate=omitted explicit=usable decision=attempt-policy-and-verify")
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun queryHome(pm: PackageManager, intent: Intent, target: ComponentName, trace: String,
        flags: Int = PackageManager.MATCH_DEFAULT_ONLY,
    ): Boolean {
        val queryFlags = flags or PackageManager.GET_RESOLVED_FILTER
        val raw = pm.queryIntentActivities(intent, queryFlags)
        val matches = raw.filter { it.homeComponent() == target }
        val candidates = raw.joinToString {
            "${it.homeComponent()?.flattenToShortString()}(defaultFilter=${it.filter?.hasCategory(Intent.CATEGORY_DEFAULT)}, " +
                "isDefault=${it.isDefault}, priority=${it.priority}, order=${it.preferredOrder})"
        }
        Log.i("NaozhoMode", "$trace query=$intent flags=0x${queryFlags.toString(16)} raw=[$candidates] matched=${matches.size}")
        return matches.isNotEmpty()
    }

    fun setUnsecuredKeyguardDisabled(disabled: Boolean): Boolean {
        val manager = policy ?: return false
        if (!supported || state != ActivityManager.LOCK_TASK_MODE_NONE) return false
        if (disabled && context.getSystemService(KeyguardManager::class.java).isDeviceSecure) return false
        return try {
            manager.setKeyguardDisabled(admin, disabled)
        } catch (_: SecurityException) {
            false
        }
    }

    suspend fun start(activity: Activity): DesktopResult {
        val step = "进入受管锁定"
        if (Build.VERSION.SDK_INT < 28 || !dedicatedReady) return desktopFailure(step, "允许名单或当前模式的功能标志尚未生效。")
        if (state != ActivityManager.LOCK_TASK_MODE_NONE) return desktopFailure(step, "当前系统状态为 ${stateName()}。")
        val mode = ModeState(context)
        if (mode.managesHome() && (!isHomeConfirmed(clockHome) || !receiptMatches(clockHome))) {
            return desktopFailure(step, "完整专机等待系统确认时钟 HOME。当前系统启动解析为 ${effectiveHome()}。")
        }
        try {
            Log.i("NaozhoMode", "startLockTask requested flags=${features()} allowed=$permitted")
            activity.startLockTask()
        } catch (error: RuntimeException) {
            return desktopFailure(step, "系统拒绝启动（${error.javaClass.simpleName}）。", error)
        }
        awaitState { state != ActivityManager.LOCK_TASK_MODE_NONE }
        val observed = state
        val actualFlags = features()
        val allowlist = packages()?.toSet()
        val independent = mode.independentLock()
        val readback = "state=${stateName(observed)} independent=$independent flags=$actualFlags (${featureNames(actualFlags)})" +
            " allowlist=$allowlist user=${Process.myUserHandle()}"
        Log.i("NaozhoMode", "Lock Task after start: $readback")
        return if (observed == ActivityManager.LOCK_TASK_MODE_LOCKED && actualFlags == dedicatedFeatures() && allowlist == setOf(packageName)) {
            DesktopResult.Applied
        } else desktopFailure(step, "系统读回的锁定状态、功能或名单不符：$readback")
    }

    suspend fun leave(activity: Activity): Boolean {
        if (state == ActivityManager.LOCK_TASK_MODE_NONE) return true
        if (!supported || !permitted || state != ActivityManager.LOCK_TASK_MODE_LOCKED) return false
        return try {
            Log.i("NaozhoMode", "stopLockTask requested reason=desktop-handoff state=${stateName()}")
            activity.stopLockTask()
            awaitState { state == ActivityManager.LOCK_TASK_MODE_NONE }
        } catch (error: RuntimeException) {
            desktopFailure("退出受管锁定", "系统拒绝停止（${error.javaClass.simpleName}）。", error)
            false
        }
    }

    fun stateName(observed: Int = state): String = when (observed) {
        ActivityManager.LOCK_TASK_MODE_NONE -> "NONE"
        ActivityManager.LOCK_TASK_MODE_PINNED -> "PINNED"
        ActivityManager.LOCK_TASK_MODE_LOCKED -> "LOCKED"
        else -> "UNKNOWN"
    }

    private suspend fun awaitState(check: () -> Boolean) = withTimeoutOrNull(5_000L) {
        while (!check()) delay(100L)
        true
    } ?: false

}
