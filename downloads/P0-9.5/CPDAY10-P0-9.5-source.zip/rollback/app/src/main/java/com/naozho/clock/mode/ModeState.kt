package com.naozho.clock.mode

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.os.UserManager
import android.provider.Settings
import android.util.Log
import com.naozho.clock.R
import com.naozho.clock.alarm.AlarmRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

internal enum class DesktopMode { CLOCK, ANDROID }
internal const val INDEPENDENT_BOOT_ACTION = "com.naozho.clock.action.INDEPENDENT_BOOT"
internal const val EXTRA_BOOT_COUNT = "boot_count"

internal val Context.isDevelopmentBuild: Boolean get() = resources.getBoolean(R.bool.development_mode)

// Report persistence failures to the caller and write the boot marker before a desktop handoff.
@SuppressLint("ApplySharedPref", "UseKtx")
internal class ModeState(private val context: Context) {
    private val prefs = context.getSharedPreferences("desktop_mode", Context.MODE_PRIVATE)

    fun current(): DesktopMode {
        syncBoot()
        return if (prefs.getBoolean("android", false)) DesktopMode.ANDROID else DesktopMode.CLOCK
    }

    fun set(mode: DesktopMode): Boolean {
        syncBoot()
        return prefs.edit().putBoolean("android", mode == DesktopMode.ANDROID).commit()
    }

    fun selectedHome(): ComponentName? = prefs.getString("native_home", null)?.let(ComponentName::unflattenFromString)

    fun saveHome(component: ComponentName): Boolean {
        if (selectedHome() == component) return true
        return prefs.edit().putString("native_home", component.flattenToString()).commit()
    }

    fun managedLock(): Boolean = prefs.getBoolean("managed_lock", false)

    fun managesHome(): Boolean = (managedLock() && prefs.getBoolean("managed_home", false)) || developmentRehearsal()

    fun independentLock(): Boolean = context.isDevelopmentBuild && managedLock() && !managesHome()

    fun lastBootLaunch(): Int = prefs.getInt("independent_boot_launch", -1)

    fun recordBootLaunch(boot: Int): Boolean = prefs.edit().putInt("independent_boot_launch", boot).commit()

    fun acceptsBootLaunch(boot: Int): Boolean = boot >= 0 && boot == bootCount(context) &&
        boot == lastBootLaunch() && independentLock() && current() == DesktopMode.CLOCK

    fun developmentRehearsal(): Boolean = context.isDevelopmentBuild && !managedLock() &&
        prefs.getBoolean("dev_rehearsal", false)

    fun beginDevelopmentRehearsal(): Boolean {
        if (!context.isDevelopmentBuild || managedLock()) return false
        syncBoot()
        return prefs.edit().putBoolean("dev_rehearsal", true).putBoolean("android", false).commit()
    }

    fun saveDeployment(enabled: Boolean, mode: DesktopMode, manageHome: Boolean = enabled): Boolean {
        syncBoot()
        return prefs.edit().putBoolean("managed_lock", enabled).putBoolean("managed_home", manageHome)
            .putBoolean("android", mode == DesktopMode.ANDROID).remove("dev_rehearsal").remove("dev_exit_home")
            .remove("dev_verified_home").commit()
    }

    fun syncBoot(completed: Boolean = false) {
        val boot = bootCount(context)
        val paused = prefs.contains("managed_lock") && !managedLock() && !developmentRehearsal()
        if (boot >= 0 && prefs.getInt("boot", -1) != boot) {
            prefs.edit().putBoolean("android", paused).putInt("boot", boot).remove("dev_exit_home").commit()
        } else if (completed && boot < 0) {
            if (!independentLock()) prefs.edit().putBoolean("android", paused).remove("dev_exit_home").commit()
        }
    }
}

internal fun bootCount(context: Context): Int = if (Build.VERSION.SDK_INT >= 24) {
    Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, -1)
} else -1

class ModeBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val boot = intent.action == Intent.ACTION_BOOT_COMPLETED
        if (intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            (Build.VERSION.SDK_INT >= 24 && !context.getSystemService(UserManager::class.java).isUserUnlocked)
        ) {
            // The existing deployment and pause state are credential-encrypted. BOOT_COMPLETED
            // is delivered after this user's storage is available, including automatic unlock.
            Log.i("NaozhoMode", "Mode boot event=${intent.action} waitingForUnlockedBoot elapsedMs=${SystemClock.elapsedRealtime()}")
            return
        }
        if (!boot && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val mode = ModeState(context)
                if (boot) mode.syncBoot(completed = true)
                if (boot && !context.isDevelopmentBuild) ModeCredentials(context).onBootCompleted()
                if (boot && mode.independentLock()) {
                    val result = ManagedDeployment(context).restoreIndependentAfterBoot()
                    if (result is DesktopResult.Rejected) Log.w("NaozhoMode", "Independent boot rejected: ${result.message}")
                } else if (boot && !mode.managesHome()) {
                    Log.i("NaozhoMode", "Mode boot: automatic launch disabled managed=${mode.managedLock()}")
                }
                val runtime = context.applicationContext as AlarmRuntime
                runtime.isolation.reconcile()
                if (!mode.managesHome()) return@launch
                val deployment = ManagedDeployment(context)
                if (mode.current() == DesktopMode.ANDROID) {
                    deployment.reconcileHome()
                    return@launch
                }
                val restored = deployment.recoverManagedClock()
                if (restored is DesktopResult.Rejected) {
                    Log.w("NaozhoMode", "Home recovery event=${intent.action} rejected=${restored.message}")
                    return@launch
                }
                val desktop = ManagedDesktop(context)
                val keyguard = context.getSystemService(KeyguardManager::class.java)
                val canShow = !keyguard.isKeyguardLocked || (context.isDevelopmentBuild && !keyguard.isDeviceSecure)
                val confirmed = desktop.receiptMatches(desktop.clockHome) && desktop.isHomeConfirmed(desktop.clockHome)
                val launchHome = canShow && confirmed && mode.current() == DesktopMode.CLOCK &&
                    ((mode.managedLock() && desktop.dedicatedReady) || mode.developmentRehearsal())
                Log.i("NaozhoMode", "Home recovery event=${intent.action} boot=${bootCount(context)} confirmed=$confirmed " +
                    "keyguardLocked=${keyguard.isKeyguardLocked} launchHome=$launchHome state=${desktop.stateName()}")
                if (launchHome) {
                    // Use the system's HOME resolution, including on the recovery launch.
                    val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { context.startActivity(home) }
                    catch (error: RuntimeException) { Log.w("NaozhoMode", "Clock home recovery launch rejected", error) }
                }
            } finally {
                pending.finish()
            }
        }
    }
}
