package com.naozho.clock.mode

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** An explicitly addressed, signature-protected signal. All policy decisions run as the app. */
class ModuleBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION || !isOrderedBroadcast) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val outcome = handle(context, intent.getIntExtra(EXTRA_BOOT_COUNT, -1))
                pending.resultCode = outcome.first
                pending.resultData = outcome.second
                Log.i("NaozhoModuleBoot", "result=${outcome.first} ${outcome.second}")
            } catch (error: Exception) {
                pending.resultCode = 503
                pending.resultData = "recovery_error"
                Log.e("NaozhoModuleBoot", "boot recovery failed", error)
            } finally {
                pending.finish()
            }
        }
    }

    internal suspend fun handle(context: Context, boot: Int): Pair<Int, String> {
        if (Build.VERSION.SDK_INT < 28 || boot < 0 || boot != bootCount(context))
            return 409 to "boot_mismatch"
        val user = context.getSystemService(UserManager::class.java)
        val keyguard = context.getSystemService(KeyguardManager::class.java)
        fun ready() = user.isUserUnlocked && !(keyguard.isDeviceSecure && keyguard.isKeyguardLocked)
        if (!ready()) return 423 to "user_or_credential_locked"
        val mode = ModeState(context)
        if (!mode.independentLock()) return 204 to "independent_not_armed"
        if (mode.current() == DesktopMode.ANDROID) return 204 to "desktop_mode"
        if (!ManagedDesktop(context).owner) return 403 to "owner_missing"
        var requested = false
        val result = ManagedDeployment(context).restoreIndependentAfterBoot(
            source = "kernelsu", onLaunchRequested = { requested = true }, stillRequested = { ready() },
        )
        return when {
            result is DesktopResult.Rejected -> 503 to result.message
            requested -> 201 to "activity_requested"
            else -> 204 to "no_new_request"
        }
    }

    private companion object {
        const val ACTION = "com.naozho.clock.action.MODULE_BOOT_READY"
    }
}
