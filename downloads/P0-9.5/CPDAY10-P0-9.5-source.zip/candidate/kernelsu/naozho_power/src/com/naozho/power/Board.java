package com.naozho.power;

import android.os.SystemClock;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import com.naozho.power.TrialChecks.Refused;

/** All arguments/paths are fixed or derived from verified local kernel metadata. */
final class Board {
    static final Path MODULE = Paths.get("/data/adb/modules/naozho_power_trial");
    static final String DS = "/system/bin/dumpsys";

    static String text(Path p, int limit) throws IOException {
        try (InputStream in = Files.newInputStream(p)) { return text(in, limit).trim(); }
    }

    private static String text(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) {
            if (data.size() + n > limit) throw new IOException("output_limit");
            data.write(buf, 0, n);
        }
        return new String(data.toByteArray(), StandardCharsets.UTF_8);
    }

    static String command(int timeoutMs, int limit, String... args) throws Exception {
        Process proc = new ProcessBuilder(args).redirectErrorStream(true).start();
        java.util.concurrent.FutureTask<String> read = new java.util.concurrent.FutureTask<>(
                () -> text(proc.getInputStream(), limit).trim());
        Thread io = new Thread(read, "power-trial-command");
        io.setDaemon(true);
        io.start();
        long start = SystemClock.elapsedRealtime();
        try {
            String answer = read.get(timeoutMs, TimeUnit.MILLISECONDS);
            long remaining = timeoutMs - (SystemClock.elapsedRealtime() - start);
            if (remaining <= 0 || !proc.waitFor(remaining, TimeUnit.MILLISECONDS) || proc.exitValue() != 0)
                throw new Refused("system_command_failed");
            return answer;
        } catch (java.util.concurrent.TimeoutException e) {
            throw new Refused("system_command_timeout");
        } finally {
            proc.destroyForcibly();
            proc.getInputStream().close();
        }
    }

    static boolean enabled() {
        return Files.isRegularFile(MODULE.resolve("module.prop")) &&
                !Files.exists(MODULE.resolve("disable")) && !Files.exists(MODULE.resolve("remove")) &&
                !Files.exists(MODULE.resolve("STOP"));
    }

    static int number(String raw, int low, int high, String reason) throws Refused {
        if (!raw.matches("[0-9]{1,9}")) throw new Refused(reason);
        int n = Integer.parseInt(raw);
        if (n < low || n > high) throw new Refused(reason);
        return n;
    }

    static int boot() throws Exception {
        return number(command(1500, 128, "/system/bin/settings", "get", "global", "boot_count"),
                0, 999999999, "boot_unknown");
    }

    static Path discover() throws Exception {
        Path selected = null;
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get("/sys/class/input"), "event*")) {
            for (Path event : ds) {
                if (!event.getFileName().toString().matches("event[0-9]{1,4}")) continue;
                Path path = event.toRealPath();
                String real = path.toString();
                if (!real.startsWith("/sys/devices/platform/") ||
                    real.matches(".*(?:/usb[0-9]+/|/bluetooth/|/virtual/|/uhid/).*")) continue;
                Path dev = event.resolve("device");
                if (!TrialChecks.dedicatedKeys(text(dev.resolve("capabilities/key"), 400),
                        text(dev.resolve("id/bustype"), 32))) continue;
                if (selected != null) throw new Refused("multiple_builtin_power_sources");
                selected = path;
            }
        }
        if (selected == null) throw new Refused("no_builtin_power_only_or_volume_power_source");
        return selected;
    }

    static String layoutFile(String raw, String kind, String suffix) throws Exception {
        if (!raw.matches("/(?:system|vendor|odm|product|system_ext)/usr/" + kind + "/[A-Za-z0-9_.-]+\\." + suffix))
            throw new Refused("unverified_layout_location");
        return text(Paths.get(raw), 512 * 1024);
    }

    static String node(Path source) { return "/dev/input/" + source.getFileName(); }

    static void verifyLayout(Path source) throws Exception {
        String dump = command(5000, 4*1024*1024, DS, "input");
        TrialChecks.Layout layout = TrialChecks.layout(dump, node(source));
        if (!TrialChecks.powerMapping(layoutFile(layout.kl, "keylayout", "kl"),
                layout.kcm.isEmpty() ? "" : layoutFile(layout.kcm, "keychars", "kcm")))
            throw new Refused("scan_116_not_verified_as_power");
        System.out.println("active_kl=" + layout.kl);
        System.out.println("active_kcm=" + (layout.kcm.isEmpty() ? "none" : layout.kcm));
    }

    static boolean sameSource(Path source) throws IOException {
        return Paths.get("/sys/class/input").resolve(source.getFileName()).toRealPath().equals(source);
    }

    static void environment() throws Exception {
        if (!enabled() || android.os.Process.myUid() != 0 ||
            !command(1000,128,"/system/bin/getprop","sys.boot_completed").equals("1") ||
            !command(1000,128,"/system/bin/getenforce").equals("Enforcing") ||
            !command(1000,128,"/system/bin/getprop","ro.product.device").equalsIgnoreCase("CPDAY10") ||
            android.os.Build.VERSION.SDK_INT != 36) throw new Refused("unsupported_environment");
    }

    static void ownerUser() throws Exception {
        if (!command(1500, 128, "/system/bin/am", "get-current-user").equals("0"))
            throw new Refused("not_owner_user");
    }

    static String launcherSection() throws Exception {
        String displays = command(1100, 3*1024*1024, DS, "window", "displays");
        String section = "displays";
        if (!displays.contains("mCurrentFocus=")) {
            section = "windows";
            displays = command(1100, 3*1024*1024, DS, "window", section);
        }
        requireLauncher(displays);
        return section;
    }

    static void requireLauncher(String dump) throws Refused {
        if (!TrialChecks.FREEME.equals(TrialChecks.focus(dump))) throw new Refused("freeme_not_focused");
    }

    static void verifyFramework() throws Exception {
        java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
        try (InputStream input = Files.newInputStream(Paths.get("/system/framework/services.jar"))) {
            byte[] buffer = new byte[65536];
            int n;
            while ((n = input.read(buffer)) != -1) digest.update(buffer, 0, n);
        }
        StringBuilder actual = new StringBuilder();
        for (byte value : digest.digest()) actual.append(String.format(java.util.Locale.ROOT, "%02x", value));
        if (!actual.toString().equals("70fa04e1e51c4008078cdc7fd6c1cc041769e39bd3cce99712ce1d374d81f468"))
            throw new Refused("framework_build_not_reviewed");
    }

    static void awake(long firstUptime) throws Exception {
        TrialChecks.awakeSince(command(850, 256*1024, DS, "power"), firstUptime);
    }

    private static void dispatch(String[] args) throws Exception {
        String reply = command(3000, 8192, args);
        if (reply.contains("Permission Denial") || reply.contains("SecurityException"))
            throw new Refused("broadcast_permission_denied");
        if (!reply.contains("Broadcast completed: result=") || reply.contains("Exception occurred"))
            throw new Refused("broadcast_command_unconfirmed");
    }

    private static int verifiedSender(String action, String id) throws Exception {
        for (int i = 0; i < 3; i++) {
            String history = command(1800, 512*1024, DS, "activity", "-a", "broadcasts", "filter", "--action", action);
            int uid = DeliveryProof.sender(history, action, id);
            if (uid >= 0) return uid;
            if (i < 2) Thread.sleep(150);
        }
        throw new Refused("delivery_history_unconfirmed");
    }

    // Same transport, component, receiver permission and user, with an unknown action and no
    // gesture extras. The unmodified APK rejects it before reading or writing mode state.
    static int verifyPermission() throws Exception {
        String id = java.util.UUID.randomUUID().toString();
        String action = DeliveryProof.PROBE + id;
        dispatch(DeliveryProof.envelope(action, id));
        int uid = verifiedSender(action, id);
        System.out.println("permission_probe=DELIVERED uid=" + uid + " user=0 permission=" + DeliveryProof.PERMISSION);
        return uid;
    }

    static void send(int boot, long first, long up, int expectedUid) throws Exception {
        dispatch(TrialChecks.broadcast(boot, first, up));
        int uid = verifiedSender(TrialChecks.ACTION, TrialChecks.returnId(boot, first));
        if (uid != expectedUid) throw new Refused("broadcast_sender_changed");
        System.out.println("return_receiver=DELIVERED uid=" + uid + " user=0");
    }

    private Board() {}
}
