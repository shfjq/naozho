package com.naozho.power;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.naozho.power.TrialChecks.Refused;

/** Android 16 ActivityManager terminal history for this explicit, user-zero delivery. */
final class DeliveryProof {
    static final String PROBE = "com.naozho.clock.action.P095_PERMISSION_PROBE.";
    static final String PERMISSION = "android.permission.STATUS_BAR_SERVICE";
    private static final Pattern RECORD = Pattern.compile(
            "(?m)^  Historical Broadcast #[0-9]+:\\s*\\n((?:[ \\t]{4}[^\\n]*\\n?)+)");
    private static final Pattern TARGET = Pattern.compile(
            "(?m)^    (\\w+) [^\\n]*#[0-9]+: (.+)$");

    static String[] envelope(String action, String id, String... extras) {
        List<String> args = new ArrayList<>(Arrays.asList("/system/bin/am", "broadcast", "--user", "0",
                "--receiver-foreground", "--exclude-stopped-packages", "-n", TrialChecks.RECEIVER,
                "-a", action, "-i", id));
        args.addAll(Arrays.asList(extras));
        return args.toArray(new String[0]);
    }

    // -1 only means the identified terminal record isn't visible yet. Never resend.
    static int sender(String dump, String action, String id) throws Refused {
        Matcher records = RECORD.matcher(dump);
        int sender = -1;
        while (records.find()) {
            String r = records.group(1);
            Matcher intent = Pattern.compile("(?m)^    Intent \\{ ([^\\n]+)\\} *$").matcher(r);
            if (!intent.find()) continue;
            List<String> fields = Arrays.asList(intent.group(1).trim().split(" +"));
            if (!fields.contains("id=" + id)) continue;
            if (sender != -1 || !fields.contains("act=" + action) || !fields.contains("cmp=" + TrialChecks.RECEIVER)
                    || !r.lines().findFirst().orElse("").endsWith(" to user 0"))
                throw new Refused("delivery_record_mismatch");
            Matcher target = TARGET.matcher(r);
            if (!target.find()) throw new Refused("delivery_missing_manifest_receiver");
            String state = target.group(1);
            if (!"DELIVERED".equals(state)) {
                if (r.contains("Permission Denial") && r.contains(PERMISSION))
                    throw new Refused("delivery_denied_STATUS_BAR_SERVICE");
                if (r.contains("reason: Autostart blocked: broadcasting from "))
                    throw new Refused("delivery_autostart_policy_blocked");
                throw new Refused("delivery_" + (state.matches("[A-Z_]{1,16}") ? state : "unknown"));
            }
            if (!target.group(0).endsWith("#0: (manifest)") || target.find())
                throw new Refused("delivery_receiver_ambiguous");
            String uid = TrialChecks.one(r, "^    caller=[^\\n]* uid=([0-9]{1,9}) *$", "sender_uid_unknown");
            sender = Integer.parseInt(uid);
        }
        return sender;
    }

    private DeliveryProof() {}
}
