# CPDAY10 P0-9.5 源码

系统适配器与此次测试的源码提交 39eb092d2d2fc3df36a570f265b0edc105c03083。
candidate 是完整 Gradle 工程和 KernelSU 源码。候选 APK 的 app 运行时代码来自 d82bc1247b590655f3aa9ed1e0cf33fa57af2876；本阶段只增加主机测试、模块和验收工具。rollback 是完整 0.6.9 回滚 APK Gradle 工程；以 79954aa38defd455e5b485626d2019fe20c852f5 为基线，仅将 app 版本改为 0.6.9-rollback / 28。各目录可以独立构建。

时钟工程用 JDK 17、SDK 35、Gradle wrapper，从相应目录运行 ./gradlew :app:assembleDevelopment。用户本地生成的调试密钥不同；须使用交付的已签名 APK 才能覆盖原机。系统端从 candidate 根目录用 Python 3 运行 kernelsu/naozho_power/test.py --android-jar SDK/platforms/android-36/android.jar --d8 SDK/build-tools/35.0.0/d8 --out module.zip，JAVA_HOME 指向 JDK 17。验收依据为 tools/p095/DSH.md 和 REPORT.md。历史 P0-9.4 文档供源码对照。
