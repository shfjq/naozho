# CPDAY10 P0-9.2 审查包

先读 cpday10-p092-review.md，再读 cpday10-p092-dsh.md。单独的 HOME 方案在 cpday10-p092-home-next.md。本版只供离线审查，DSH 暂不操作设备。

review-source/tools/p092 包含最小 RRO 的 Manifest、资源映射及主机验证脚本。verify_rro.py --help 可查看正式参数，使用 Python 3（正常断言模式）、SDK AAPT2、API 36 android.jar 和可在开发主机运行的 API 36 idmap2。--evidence 使用原私有证据包，--stock-dir 使用已有的四个 RRO，--output 指向全新实验输出文件。check_power_dispatch.py 使用同构建私有 services.jar 及 SDK 的 dexdump。两者仅供 Codex 复核。

application-changes.patch 含 APK 对父版本的所有生产与测试源码改动；签名密钥和固件均由各自原持有人保管。主机手势模型及测试位于 review-source/tools/p09，执行 python -m unittest discover -s review-source/tools/p09 即可复跑。模型中的系统裁决输入需要未来的厂商接口，现有普通双击不提供该输入。

SHA256SUMS 可用于核验本 ZIP 的内部文件。候选、回滚和未签名 RRO 作为同一提交中独立的下载文件交付。