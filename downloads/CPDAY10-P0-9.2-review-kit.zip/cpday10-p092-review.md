# CPDAY10 P0-9.2　电源双击快捷返回审查记录

**发布决策：原生 RRO 的资源映射通过；停止把原生双击直接转成 Lock Task 的路线。** 0.6.11-dev 是供审查的候选 APK。独立入口默认关闭，即使在离线测试中直接调用也只诊断并结束。本轮没有让手机接管电源键。时钟图标、开发退出和原有独立锁定仍采用项目原路径。

## 同固件验证

收到的私有 ZIP 为 676,391 字节，SHA-256 为 `0c190b7c33c5fb2a63e0cac2567a80d2760c3c33f98a4e8a3b6172cd242a1950`，CRC 通过。提取工具报告的原 APK 摘要与此前本机采集一致。本次独立复算 ZIP 中两个成员的摘要，包括 resources.arsc 的 `c330c3bf61ac9e381978f2d2e70e37cbc8354342b83a6aabe26ba799097ca088`。开发端重新按二进制 chunk 边界遍历 Android 包。7 个 package chunk 各有 0 个 overlayable group。完整 framework-res.apk 留在采集端。

使用 API 36 的 android.jar 和 AAPT2 构建独立、无代码、未签名的 RRO 原型。以提供的二进制 Manifest 和 ARSC 构造只用于主机测试的资源容器。Android 16 参考镜像的原生 idmap2 保持正规权限检查，在该容器和四个原厂 RRO 上执行 create、dump 和 lookup。

| 主机资源实验 | 实际结果 |
| --- | --- |
| 只满足 public | 创建原型 idmap 被拒，报告 no resources were overlaid。 |
| 模拟满足 product | 仅出现 0x010e0085 行为整数和 0x0104026b 目标字符串，两项均映射。 |
| 原厂四份映射 | 两个目标均未出现在四份原厂 idmap 中。无原型时 lookup 为 0 和空字符串。 |
| 加入原型，分别置首和置末 | 两种装载序列均回读 3 和 com.naozho.clock/.mode.PowerReturnActivity。 |
| 移出原型，使用原厂映射序列 | 两项回读 0 和空字符串。单击、early short press、长按、超长按、三击、相机和紧急手势的八项对照资源在测试前后均相同。 |

0 组时 Android 16 的默认资格接受相应预装分区或合格签名。本机 IdmapManager 还会对 targetSdk ≥ 29 的 overlay 强制检查，由系统根据包的实际身份计算满足的策略。本实验的 product 是离线输入。已有清单中另有导航和 SystemUI 动态 overlay；没有收到本机构建的分区 overlay/config/config.xml、merge 文件和自定义分区排序文件，实际 OMS 全排序及新包能否取得分区资格仍未验证。原厂已有 readback 为 0/空，Global.power_button_double_press 未设置。init 会缓存目标组件。主机移除映射能验资源恢复，设备上资源之外的缓存与手势恢复须另测。公开包只有实验侧产物。[Android 16 的 idmap2 规则](https://github.com/aosp-mirror/platform_frameworks_base/blob/android-16.0.0_r1/cmds/idmap2/libidmap2/ResourceMapping.cpp) · [官方 RRO 机制](https://source.android.com/docs/core/runtime/rros)

## 决定停止直接锁定路线的证据

已验证相同固件 services.jar 的 SHA-256。用 DEX 工具重新检查七个方法的 36 个指令位置。关键是同时跟踪两个返回值：系统是否**消费**本次按下，以及是否已经**启动**相机、钱包或紧急界面。

1. 手机分支、紧急手势启用、当前亮屏、设置向导已完成且无其它改写的普通路径中，GestureLauncherService.interceptPowerKeyDown 在 0x0093–0x00a7 处理连续次数。超过第一次即可置拦截标记，第五次才进入紧急手势的后续时长等判断。0x0230–0x0239 独立返回是否消费。在普通第二次按下时，可以返回“已消费、尚未启动紧急界面”。
2. PhoneWindowManager.handleCameraGesture 在 0x0015–0x0017 将这个消费结果返回给 handleKeyGesture。后者在 0x002a–0x0031 清空普通多击检测器并返回。因此在上述路径上，配置行为 3 也收不到期望的普通双击。该结论来自固件控制流，尚未通过实机输入追踪。
3. 若事件确实交给普通多击检测器，设定三击为 0、双击为 3 时，其最大普通计数可以为 2。达到最大次数时，SingleKeyGestureDetector.interceptKeyDown 可在第二次按下便派发。launchTargetActivityOnMultiPressPower 只构造显式、无 action 的 Intent；没有携带首击屏幕状态、最后一次释放、SOS 结束或可撤销的系统授权。
4. 普通双击、第二击按住和后续紧急连击共享相同的按下前缀。应用从该 Intent 无法区分。延时 300ms、查询此刻亮屏、读取 SOS 开关或相信 Intent extras，都无法为 Lock Task 提供系统侧的最终手势裁决。即使连击识别继续工作，早入 LOCKED 也可能妨碍实际紧急 UI 获得前台。
5. 本机长按值 100 经厂商逻辑解析，超长按对应 GLOBAL_ACTIONS。原型不改长按、短按、相机、SOS、全球超时或输入驱动。资源值一致仍不足以证明更改双击计数后各实体键的时序完全保留。

## 候选应用与权限

候选版为 com.naozho.clock 0.6.11-dev / 26，基于 P0-9 源码 126f372。仅 development 变体声明 PowerReturnActivity，无 HOME/LAUNCHER filter，NoDisplay、noHistory、独立空 taskAffinity、enabled=false。组件侧要求系统权限 android.permission.STATUS_BAR_SERVICE；应用没有新增 uses-permission。本机 framework 二进制 Manifest 中该权限的 protectionLevel 为 0x02000002，基础等级为 signature。该保护约束外部调用者，本身不能证明某次手势已经完成。入参中的“已通过”标志均不采信。

受控入口读取项目现有 ModeState 和 ManagedDesktop，检查用户存储、维护暂停/未配置、ANDROID、独立部署、Owner、Lock Task、当前亮屏与 Keyguard。重复交付、已锁、启动恢复期间或系统状态不可用时立即结束。所有原生请求即使满足模式前提也止于 SYSTEM_ARBITRATION_MISSING。入口没有启动时钟、提交锁定、写 HOME、创建后台请求的调用，暂停后也没有排队的工作可迟到重放。没有接入任意 Root 命令或系统服务代理。原桌面图标的主动返回仍可完成原有锁定。变更包含开发变体入口和 Manifest、版本号、RRO 与离线验证工具、针对性回归、审查文档。HOME、Owner 接收器、闹铃、KernelSU 模块、OEM 文件均无实施变更。

## 测试与边界

| 要求 | 结果与证据 |
| --- | --- |
| 普通 Android 状态的有效双击 | 有受信系统“完整独占手势”输入的离线模型接受一次。真实原生协议缺少该输入。候选 APK 在 Android 状态拒绝原始请求，实际实体双击返回未通过。 |
| 单击、长按、相机、SOS | 单击、按住第二击、长按、三击和五击在离线模型不产生返回；固件分支审计和八项资源对照完成。没有向设备发送按键，没有呼叫紧急电话。 |
| 维护暂停、延迟、重复、重新启用 | Android 组件测试检查暂停前后的独立请求、重新武装无重放、重复调用、伪造 extras、存续模式与无新 Activity。模型另覆盖跨 boot 和模式代次拒绝旧请求。 |
| 已锁、PINNED、息屏、Keyguard、缺 Owner | 针对性组件测试验证拒绝和保持原状态。原主动图标退出、重入、LOCKED + 80 的既有集成测试一起回归。 |
| 恢复原厂资源 | 原厂 ARSC 加真实四个 overlay 的主机实验已回读 0/空。完整本机 OMS、system_server 的目标缓存、单击时延、原厂长按和实际 SOS 前台尚未验收。 |

development 单元测试 134 项通过，零失败、零跳过；Lint 为 0 错误、10 项警告。主机手势合约及采集器回归 10 项通过。资源映射、候选与回滚 APK 构建、验签、最终 Manifest 对照及固件静态分支检查均通过。数量、构建、签名与最终 APK Manifest 对照见审查包中的 validation-summary.json 和 rro-results.json。组件测试使用 Robolectric；idmap2 来自 Android 16 参考系统，使用本机真实资源成员。没有实机或运行中的 Android 模拟器端到端验收。

## 后续最低风险方案及独立的 HOME 任务

**立即可用的返回入口**仍是 Freeme 中的「小方块时钟」图标。保留已验证的退出、维护暂停和独立 LOCKED + 80。

**实体快捷键的下一版接口**应由厂商原有的按键仲裁层提供。它须在第一次按下时记录亮屏，保留完整释放序列，优先处理按住、相机、紧急手势及来电。在系统确认二击独占后，才可向指定包交付一次受保护、按用户/开机/代次绑定的请求。暂停先作废任何待交付请求。还须保证在交付后另起紧急操作时，紧急界面和拨号器依然能置前并保持操作，然后才允许时钟获得焦点并恢复锁定。若厂商无法提供上述能力，另选不与 SOS 争用的显式快捷入口。此次不会为普通双击改变紧急策略。

**HOME 第一屏单独立项。** 当前固件 ComputerEngine 对全局 HOME 候选按内置包名过滤。本轮没有修改或重新测试 HOME。向厂商核实按用户授权、可撤销、在首次 HOME 解析前生效的主屏登记或专机启动接口。先在 NONE 验证有效 HOME 和恢复 Freeme，再分别从 CLOCK、当次开发退出、维护暂停启动并录像至首次触摸。现有 naozho_boot 仅保留延后恢复能力；本轮第一屏未验收。
